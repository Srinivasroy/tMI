﻿using Master.Models.client10;
namespace Master.Models.Helper
{
    public class Helper
    {
        static DBcontext _context = new DBcontext();
        public static bool IntCompanyIdExists(long id)
        {
            return _context.CompanyDetailMasters.Any(e => e.CompanySeqId == id);
        }
        public static bool IntDocIdExists(long id)
        {
            return _context.DocumentMasters.Any(e => e.IntDocId == id);
        }
        public static bool OnboardInitiationSeqIdExists(long id)
        {
            return _context.OnboardingInitiations.Any(e => e.OnboardInitiationSeqId == id);
        }
        public static bool ReportingManagerNameExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId == id);
        }
        public static bool IntCategoryIdExists(long id)
        {
            return _context.EmployeeCategoryMasters.Any(e => e.EmployeeCategorySeqId == id);
        }
        public static bool MidPointsExists(long id)
        {
            return _context.MidpointMasters.Any(e => e.MidpointSeqId == id);
        }
        public static bool PresentCostCenterExists(long id)
        {
            return _context.CostcenterMasters.Any(e => e.CostcenterSeqId == id);
        }
        public static bool PresentDepartmentExists(long id)
        {
            return _context.DepartmentMasters.Any(e => e.DeptSeqId == id);
        }
        public static bool PresentDesignationExists(long id)
        {
            return _context.DesignationMasters.Any(e => e.DesignationSeqId == id);
        }
        public static bool PresentLocationExists(long id)
        {
            return _context.LocationMasters.Any(e => e.LocationSeqId == id);
        }
        public static bool DepartmentsExists(long id)
        {
            return _context.DepartmentsMasters.Any(e => e.DeptsSeqId == id);
        }
        public static bool ExitTemplateItemsIdExists(long id)
        {
            return _context.ExitMasQuestionTemplateItems.Any(e => e.ExitTemplateItemId == id);
        }
        public static bool IntExitTemplateIdExists(long id)
        {
            return _context.ExitMasQuestionTemplates.Any(e => e.ExitTemplateId == id);
        }
        public static bool IntIntQuestionIdIdExists(long id)
        {
            return _context.ExitMasQuestions.Any(e => e.IntQuestionId == id);
        }
        public static bool IntExEmpreqIdExits(long id)
        {
            return _context.ExitTransEmprequests.Any(e => e.IntExEmpreqId == id);
        }
        public static bool IntEmpIdExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId == id);
        }
       
        public static bool IntResigIdExists(long id)
        {
            return _context.ExitMasResignations.Any(e => e.IntResigId == id);
        }
        public static bool IntResignacceptLetterIdExists(long id)
        {
            return _context.LetterMasHtmlTemplates.Any(e => e.IntLetterHtmlId == id);
        }
        public static bool IntScheduleInterIdExists(long id)
        {
            return _context.RecTransScheduleInterviews.Any(e => e.IntScheduleInterId == id);
        }
        public static bool IntDomainIdExists(long id)
        {
            return _context.DomainMasters.Any(e => e.DomainSeqId == id);
        }
        public static bool IntManpowerReqIdExists(long id)
        {
            return _context.RecTransManpowerRequests.Any(e => e.IntManpowerReqId == id);
        }
        public static bool IntSkillIdExists(long id)
        {
            return _context.SkillMasters.Any(e => e.SkillSeqId == id);
        }
        public static bool IntNewCandidateSeqIdExists(long id)
        {
            return _context.RecMasNewCandidates.Any(e => e.IntNewCandidateSeqId == id);
        }
        public static bool IntRecCompetListSeqidExists(long id)
        {
            return _context.RecMasCompetencyLists.Any(e => e.IntRecCompetListSeqid == id);
        }
        public static bool IntQualificationIdExists(long id)
        {
            return _context.QualificationMasters.Any(e => e.QualificationSeqId == id);
        }
        public static bool IntMpPlanJobIdExists(long id)
        {
            return _context.RecMasManpowerPlanJobids.Any(e => e.IntMpPlanJobId == id);
        }
        public static bool IntVendorSeqIdExists(long id)
        {
            return _context.VendorMasters.Any(e => e.VendorSeqId == id);
        }
        public static bool IntPlanIdExists(long id)
        {
             return _context.RecMasManpowerPlans.Any(e => e.IntPlanId == id);
        }
        public static bool IntCandidateSeqIdExists(long id)

        {
            return _context.RecMasAddCandidates.Any(e => e.IntCandidateSeqId == id);
        }
        public static bool IntEmpCategoryIdExists(long id)
        {
            return _context.EmployeeCategoryMasters.Any(e => e.EmployeeCategorySeqId == id);
        }

        public static bool IntConfirmReqIdExists(long id)
        {
            return _context.ConfirmationAssessmentRequests.Any(e => e.IntConfirmReqId == id);
        }
        public static bool ExitTemplateItemIdExists(long id)
        {
            return _context.ExitMasQuestionTemplateItems.Any(e => e.ExitTemplateItemId == id);
        }
        public static bool IntTrainigVendorIdExists(long id)
        {
            return _context.TrainMasVendors.Any(e => e.IntTrainingVendSeqid == id);
        }
         public static bool IntInitiationIdExists(long id)
        {
            return _context.TrainTransHrInitiations.Any(e => e.IntInitiationId == id);
        }
        public static bool IntCategoryId(long id)
        {
            return _context.TrainMasCategories.Any(e => e.IntCategoryId == id);
        }
        public static bool IntTypeIdExists(long id)
        {
            return _context.TrainMasTypes.Any(e => e.IntTypeId == id);
        }

        public static bool IntQuestionIdExists(long id)
        {
            return _context.TrainMasQuestions.Any(e => e.IntQuestionId == id);
        }
        public static bool IntTRequestIdExists(long id)
        {
            return _context.TrainTransRequests.Any(e => e.IntTRequestId == id);
        }
        public static bool IntLocationIdExists(long id)
        {
            return _context.LocationMasters.Any(e => e.LocationSeqId == id);
        }
        public static bool IntDepartmentIdExists(long id)
        {
            return _context.DepartmentMasters.Any(e => e.DeptSeqId == id);
        }
        public static bool IntTrainingVendmapSeqidExists(long id)
        {
            return _context.TrainMasVendorMappings.Any(e => e.IntTrainingVendmapSeqid == id);
        }
        
        public static bool IntEmpMappingIdExists(long id)
        {
            return _context.ApprTransEmptoappMappings.Any(e => e.IntApprMasEmpappMapSeqid == id);
        }
        public static bool IntCompetListSeqidExists(long id)
        {
            return _context.ApprMasCompetencyLists.Any(e => e.IntCompetListSeqid == id);
        }
        public static bool IntSelfRatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntP1RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntP2RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntP3RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntSo1RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntSo2RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntSo3RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntSup1RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        public static bool IntSup2RatingIdExists(long id)
        {
            return _context.ApprMasRatingParaMappings.Any(e => e.IntRatingMappingId == id);
        }
        
        public static bool IntGoalIdExists(long id)
        {
            return _context.ApprMasGoals.Any(e => e.IntGoalId == id);
        }
       
        public static bool IntEmpgroupIdExists(long id)
        {
            return _context.ApprMasEmpGroupings.Any(e => e.IntEmpgroupId == id);
        }

        public static bool IntReviewSeqidExists(long id)
        {
            return _context.ApprMasReviewperiodConfigs.Any(e => e.IntReviewSeqid == id);
        }
        public static bool IntSubordiemployee2SeqIdExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId== id);
        }
        public static bool IntSubordiemployee3SeqIdExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId == id);
        }
        public static bool IntSuperioremployee2SeqIdExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId == id);
        }
        public static bool IntSuperioremployee1SeqIdExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId == id);
        }
        public static bool IntAppraiserSeqidExists(long id)
        {
            return _context.ApprMasAppraisers.Any(e => e.IntApprMasAppraiserSeqid == id);
        }
        public static bool IntRatingOrderIdExists(long id)
        {
            return _context.ApprMasRatingOrders.Any(e => e.IntRatingOrderId == id);
        }
        public static bool IntDesIdExists(long id)
        {
            return _context.ApprMasRatingDescriptions.Any(e => e.IntDesId == id);
        }
        public static bool IntEmpMappingHisIdExists(long id)
        {
            return _context.ApprTransEmptoappMappingHistories.Any(e => e.IntApprMasEmpappMapHisSeqid == id);
        }


        public static bool IntClientIdExists(long id)
        {
            return _context.ConfigMasClientCreations.Any(e => e.IntClientId == id);
        }

        public static bool IntClientModuleGrpIdExists(long id)
        {
            return _context.CofigMasClientModules.Any(e => e.IntClientModuleGrpId == id);
        }
        public static bool IntClientUserRoleIdExists(long id)
        {
            return _context.ComMClientUserRoles.Any(e => e.IntClientUserRoleId == id);
        }
        public static bool IntCompanyRoleIdExists(long id)
        {
            return _context.ComMCompanyRoles.Any(e => e.IntCompanyRoleId == id);
        }

        public static bool IntEmployeeSeqIdExists(long id)
        {
            return _context.EmployeeMasters.Any(e => e.EmployeeSeqId == id);

        }
        public static bool IntCompSeqIdExists(long id)
        {
            return _context.ComponentMasCreations.Any(e => e.IntCompSeqId == id);

        }
        public static bool IntComMCtcMasIdExists(long id)
        {
            return _context.ComponentMasCtcMasters.Any(e => e.IntComMCtcMasId == id);

        }

        public static bool IntRcsgradeIdExists(long id)
        {
            return _context.RcsgradeMasters.Any(e => e.IntRcsgradeId == id);

        }

        //employee master
        public static bool AbeCodeValueExists(long id)
        {
            return _context.AbeCodeMasters.Any(e => e.AbeCodeSeqId == id);
        }
        public static bool BankNameExists(long id)
        {
            return _context.BankNameMasters.Any(e => e.BankNameSeqId == id);
        }
        public static bool EmploymentTypeExists(long id)
        {
            return _context.EmploymentTypeMasters.Any(e => e.IntEmploymentTypeId == id);
        }
        public static bool ItsRoleSfiaValueExists(long id)
        {
            return _context.ItsRoleSfiaMasters.Any(e => e.IntItsRoleSfiaId == id);
        }
        public static bool LeaveGroupExists(long id)
        {
            return _context.LeaveGroupMasters.Any(e => e.LeaveGroupSeqId == id);
        }
        public static bool MaritalStatusExists(long id)
        {
            return _context.MaritalStatusMasters.Any(e => e.MaritalStatusSeqId == id);
        }
       
        public static bool MidpointValueExists(long id)
        {
            return _context.MidpointMasters.Any(e => e.MidpointSeqId == id);
        }
        public static bool PhysicalStatusExists(long id)
        {
            return _context.PhysicalStatusMasters.Any(e => e.PhysicalStatusSeqId == id);
        }
        public static bool ProductivityFactorExists(long id)
        {
            return _context.ProductivityFactorMasters.Any(e => e.ProductivityFactorSeqId == id);
        }
        public static bool RcslevelValueExists(long id)
        {
            return _context.RcslevelMasters.Any(e => e.RcslevelSeqId == id);
        }
        public static bool SubdepartmentExists(long id)
        {
            return _context.SubdepartmentMasters.Any(e => e.SubdepartmentSeqId == id);
        }
        public static bool TaxSlabOptedExists(long id)
        {
            return _context.TaxSlabOptedforMasters.Any(e => e.IntTaxSlabOptedforId == id);
        }
        public static bool DesignationExists(long id)
        {
            return _context.DesignationMasters.Any(e => e.DesignationSeqId == id);
        }
        public static bool CostcenterExists(long id)
        {
            return _context.CostcenterMasters.Any(e => e.CostcenterSeqId == id);
        }
        public static bool DepartmentExists(long id)
        {
            return _context.DepartmentMasters.Any(e => e.DeptSeqId == id);
        }
        public static bool LocationExists(long id)
        {
            return _context.LocationMasters.Any(e => e.LocationSeqId == id);
        }
        public static bool CategoryExists(long id)
        {
            return _context.EmployeeCategoryMasters.Any(e => e.EmployeeCategorySeqId == id);
        }
        public static bool IntGradeIdExists(long id)
        {
            return _context.CompanyMGrades.Any(e => e.IntGradeId == id);
        }
    }
}

