﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeMaster
    {
        public EmployeeMaster()
        {
            ApprTransEmptoappMappingHistoryIntPeeremployee1Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntPeeremployee2Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntPeeremployee3Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntSelfemployeeSeqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntSubordiemployee1Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntSubordiemployee2Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntSubordiemployee3Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntSuperioremployee1Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingHistoryIntSuperioremployee2Seqs = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappingIntPeeremployee1Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntPeeremployee2Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntPeeremployee3Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntSelfemployeeSeqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntSubordiemployee1Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntSubordiemployee2Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntSubordiemployee3Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntSuperioremployee1Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransEmptoappMappingIntSuperioremployee2Seqs = new HashSet<ApprTransEmptoappMapping>();
            ApprTransProcessHistories = new HashSet<ApprTransProcessHistory>();
            ApprTransProcesses = new HashSet<ApprTransProcess>();
            AuditBankDetails = new HashSet<AuditBankDetail>();
            AuditEmpBankDetails = new HashSet<AuditEmpBankDetail>();
            AuditEmpCategoryChanges = new HashSet<AuditEmpCategoryChange>();
            AuditEmpCostcenterChanges = new HashSet<AuditEmpCostcenterChange>();
            AuditEmpDeptChanges = new HashSet<AuditEmpDeptChange>();
            AuditEmpDesignationChanges = new HashSet<AuditEmpDesignationChange>();
            AuditEmpLocationChanges = new HashSet<AuditEmpLocationChange>();
            AuditOrgKycInfos = new HashSet<AuditOrgKycInfo>();
            AuthMasEmployeeLoginDetails = new HashSet<AuthMasEmployeeLoginDetail>();
            ClientUserMasters = new HashSet<ClientUserMaster>();
            ComAdmEmpDocuments = new HashSet<ComAdmEmpDocument>();
            ComponentMasCtcMasterTmps = new HashSet<ComponentMasCtcMasterTmp>();
            ComponentMasCtcMasters = new HashSet<ComponentMasCtcMaster>();
            ComponentTransEmpSalMasterValues = new HashSet<ComponentTransEmpSalMasterValue>();
            ComponentTransEmpSalaryHistories = new HashSet<ComponentTransEmpSalaryHistory>();
            ComponentTransEmpSalaryValuesHistories = new HashSet<ComponentTransEmpSalaryValuesHistory>();
            ConfigQuicklinkEmployees = new HashSet<ConfigQuicklinkEmployee>();
            ConfirmationAssessmentRequests = new HashSet<ConfirmationAssessmentRequest>();
            EmployeeDocumentSizeDetails = new HashSet<EmployeeDocumentSizeDetail>();
            EmployeeMakerCheckers = new HashSet<EmployeeMakerChecker>();
            EmployeeMasDetails = new HashSet<EmployeeMasDetail>();
            EmployeeMasNomineeDetails = new HashSet<EmployeeMasNomineeDetail>();
            EmployeeSalaryDetails = new HashSet<EmployeeSalaryDetail>();
            EmployeeSalaryDetailsMakerCheckers = new HashSet<EmployeeSalaryDetailsMakerChecker>();
            ExitMasEmployeeMaps = new HashSet<ExitMasEmployeeMap>();
            ExitTransEmprequestAuditLogs = new HashSet<ExitTransEmprequestAuditLog>();
            ExitTransEmprequests = new HashSet<ExitTransEmprequest>();
            HashOnboardingInitiations = new HashSet<HashOnboardingInitiation>();
            JsonEmployeeAllowances = new HashSet<JsonEmployeeAllowance>();
            LetterMasGenerationMappings = new HashSet<LetterMasGenerationMapping>();
            OnboardingInitiations = new HashSet<OnboardingInitiation>();
            PfDetailMasters = new HashSet<PfDetailMaster>();
            RecMasManpowerPlanJobids = new HashSet<RecMasManpowerPlanJobid>();
            RecTransScheduleInterCandidates = new HashSet<RecTransScheduleInterCandidate>();
            RecTransScheduleInterviews = new HashSet<RecTransScheduleInterview>();
            TrainTransRequests = new HashSet<TrainTransRequest>();
            TrainTransTrainerdetInters = new HashSet<TrainTransTrainerdetInter>();
        }

        public long EmployeeSeqId { get; set; }
        public string? EmpCode { get; set; }
        public string? EmpName { get; set; }
        public string? ReportTo { get; set; }
        public string? Gender { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ProbationDate { get; set; }
        public int? ProbationDays { get; set; }
        public DateTime? ConfirmationDate { get; set; }
        public DateTime? ResignationDate { get; set; }
        public DateTime? LeavingDate { get; set; }
        public string? Company { get; set; }
        public string? Division { get; set; }
        public string? Branch { get; set; }
        public long? Category { get; set; }
        public string? Status { get; set; }
        public string? Grade { get; set; }
        public long? Designation { get; set; }
        public long? Department { get; set; }
        public long? Departments { get; set; }
        public long? Costcenter { get; set; }
        public long? Location { get; set; }
        public long? LeaveGroup { get; set; }
        public long? PhysicalStatus { get; set; }
        public long? EmploymentType { get; set; }
        public long? BankName { get; set; }
        public long? TaxSlabOpted { get; set; }
        public long? AbeCodeValue { get; set; }
        public long? ItsRoleSfiaValue { get; set; }
        public long? MidpointValue { get; set; }
        public long? RcslevelValue { get; set; }
        public long? Subdepartment { get; set; }
        public long? ProductivityFactor { get; set; }
        public long? MaritalStatus { get; set; }
        public string? PtLocation { get; set; }
        public double? CtcAmount { get; set; }
        public long? Role { get; set; }
        public string? Reference { get; set; }
        public DateOnly? DateOfBirth { get; set; }
        public long? SalaryDtl { get; set; }
        public long? PersonalInfo { get; set; }
        public decimal? DouNewCtc { get; set; }
        public decimal? DouCurrCtc { get; set; }
        public long? IntGradeId { get; set; }
        public string? VchReptCode { get; set; }
        public string? VchPanCode { get; set; }
        public string? VchMailid { get; set; }
        public long? IntCompanyRoleId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchPassword { get; set; }
        public long? EmpDetailInfoSeq { get; set; }
        public long? IntNimineeSeqId { get; set; }
        public decimal? IntEmpSalaryDtls { get; set; }
        public string? VarPerMiddleName { get; set; }
        public string? VarPerLastName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? RoleChangeDate { get; set; }
        public string? VchRoleAssignBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchReptName { get; set; }
        public string? VchProfilePath { get; set; }
        public byte[]? EmpPhotoBlob { get; set; }
        public DateOnly? EffectiveDate { get; set; }
        public string? VchOperation { get; set; }
        public string? VchSchemaKey { get; set; }
        public int? IntAppraisalCount { get; set; }
        public string? VchRmFlag { get; set; }
        public string? VchPwdChangeReq { get; set; }
        public string? VchPwdResetKey { get; set; }
        public string? VchSignupReq { get; set; }
        public string? VchSignupResetKey { get; set; }
        public string? VchOldPwd1 { get; set; }
        public string? VchOldPwd2 { get; set; }
        public DateTime? TsPwdChangeDate { get; set; }
        public string? VchPwdExpired { get; set; }
        public string? CnfPending { get; set; }
        public string? ExitInitiationPending { get; set; }
        public long? IntRcsgradeId { get; set; }
        public int? IntConfExtendedTimes { get; set; }
        public string? HireType { get; set; }
        public string? OncallAllowanceEligibility { get; set; }
        public string? ShiftAllowanceEligibility { get; set; }
        public string? TypeOfWorker { get; set; }
        public string? Billing { get; set; }
        public string? ProfessionalShiftAllowanceEligibility { get; set; }
        public string? VchBusinessPartner { get; set; }
        public string? VchBusinessUnit { get; set; }
        public string? VchGroup { get; set; }
        public string? VchGroups { get; set; }
        public string? TotalExperience { get; set; }
        public string? Ldap { get; set; }
        public string? SapEmployeeNo { get; set; }
        public DateOnly? GroupDoj { get; set; }
        public string? SapPositionId { get; set; }
        public string? VarKycPfNo { get; set; }
        public string? VchOldPf { get; set; }
        public float? IntPrivilegeLeave { get; set; }
        public float? IntCasualLeave { get; set; }
        public float? IntSickLeave { get; set; }
        public int? IntMaternityLeave { get; set; }
        public int? IntPaternityLeave { get; set; }
        public int? IntMiscarriageLeave { get; set; }
        public int? IntOptionalLeave { get; set; }
        public int? IntCovaccineLeave { get; set; }
        public DateOnly? DpdhlJoining { get; set; }
        public string? ActionCode { get; set; }
        public string? ReasonCode { get; set; }
        public string? RcsFlag { get; set; }
        public string? SapFlag { get; set; }
        public string? DescFlag { get; set; }
        public string? SapSalaryFlag { get; set; }
        public string? SalaryFlag { get; set; }

        public virtual AbeCodeMaster? AbeCodeValueNavigation { get; set; }
        public virtual BankNameMaster? BankNameNavigation { get; set; }
        public virtual EmployeeCategoryMaster? CategoryNavigation { get; set; }
        public virtual CostcenterMaster? CostcenterNavigation { get; set; }
        public virtual DepartmentMaster? DepartmentNavigation { get; set; }
        public virtual DepartmentsMaster? DepartmentsNavigation { get; set; }
        public virtual DesignationMaster? DesignationNavigation { get; set; }
        public virtual EmploymentTypeMaster? EmploymentTypeNavigation { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ComMCompanyRole? IntCompanyRole { get; set; }
        public virtual CompanyMGrade? IntGrade { get; set; }
        public virtual RcsgradeMaster? IntRcsgrade { get; set; }
        public virtual ItsRoleSfiaMaster? ItsRoleSfiaValueNavigation { get; set; }
        public virtual LeaveGroupMaster? LeaveGroupNavigation { get; set; }
        public virtual LocationMaster? LocationNavigation { get; set; }
        public virtual MaritalStatusMaster? MaritalStatusNavigation { get; set; }
        public virtual MidpointMaster? MidpointValueNavigation { get; set; }
        public virtual PhysicalStatusMaster? PhysicalStatusNavigation { get; set; }
        public virtual ProductivityFactorMaster? ProductivityFactorNavigation { get; set; }
        public virtual RcslevelMaster? RcslevelValueNavigation { get; set; }
        public virtual SubdepartmentMaster? SubdepartmentNavigation { get; set; }
        public virtual TaxSlabOptedforMaster? TaxSlabOptedNavigation { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntPeeremployee1Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntPeeremployee2Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntPeeremployee3Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntSelfemployeeSeqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntSubordiemployee1Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntSubordiemployee2Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntSubordiemployee3Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntSuperioremployee1Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistoryIntSuperioremployee2Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntPeeremployee1Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntPeeremployee2Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntPeeremployee3Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntSelfemployeeSeqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntSubordiemployee1Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntSubordiemployee2Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntSubordiemployee3Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntSuperioremployee1Seqs { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappingIntSuperioremployee2Seqs { get; set; }
        public virtual ICollection<ApprTransProcessHistory> ApprTransProcessHistories { get; set; }
        public virtual ICollection<ApprTransProcess> ApprTransProcesses { get; set; }
        public virtual ICollection<AuditBankDetail> AuditBankDetails { get; set; }
        public virtual ICollection<AuditEmpBankDetail> AuditEmpBankDetails { get; set; }
        public virtual ICollection<AuditEmpCategoryChange> AuditEmpCategoryChanges { get; set; }
        public virtual ICollection<AuditEmpCostcenterChange> AuditEmpCostcenterChanges { get; set; }
        public virtual ICollection<AuditEmpDeptChange> AuditEmpDeptChanges { get; set; }
        public virtual ICollection<AuditEmpDesignationChange> AuditEmpDesignationChanges { get; set; }
        public virtual ICollection<AuditEmpLocationChange> AuditEmpLocationChanges { get; set; }
        public virtual ICollection<AuditOrgKycInfo> AuditOrgKycInfos { get; set; }
        public virtual ICollection<AuthMasEmployeeLoginDetail> AuthMasEmployeeLoginDetails { get; set; }
        public virtual ICollection<ClientUserMaster> ClientUserMasters { get; set; }
        public virtual ICollection<ComAdmEmpDocument> ComAdmEmpDocuments { get; set; }
        public virtual ICollection<ComponentMasCtcMasterTmp> ComponentMasCtcMasterTmps { get; set; }
        public virtual ICollection<ComponentMasCtcMaster> ComponentMasCtcMasters { get; set; }
        public virtual ICollection<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; }
        public virtual ICollection<ComponentTransEmpSalaryHistory> ComponentTransEmpSalaryHistories { get; set; }
        public virtual ICollection<ComponentTransEmpSalaryValuesHistory> ComponentTransEmpSalaryValuesHistories { get; set; }
        public virtual ICollection<ConfigQuicklinkEmployee> ConfigQuicklinkEmployees { get; set; }
        public virtual ICollection<ConfirmationAssessmentRequest> ConfirmationAssessmentRequests { get; set; }
        public virtual ICollection<EmployeeDocumentSizeDetail> EmployeeDocumentSizeDetails { get; set; }
        public virtual ICollection<EmployeeMakerChecker> EmployeeMakerCheckers { get; set; }
        public virtual ICollection<EmployeeMasDetail> EmployeeMasDetails { get; set; }
        public virtual ICollection<EmployeeMasNomineeDetail> EmployeeMasNomineeDetails { get; set; }
        public virtual ICollection<EmployeeSalaryDetail> EmployeeSalaryDetails { get; set; }
        public virtual ICollection<EmployeeSalaryDetailsMakerChecker> EmployeeSalaryDetailsMakerCheckers { get; set; }
        public virtual ICollection<ExitMasEmployeeMap> ExitMasEmployeeMaps { get; set; }
        public virtual ICollection<ExitTransEmprequestAuditLog> ExitTransEmprequestAuditLogs { get; set; }
        public virtual ICollection<ExitTransEmprequest> ExitTransEmprequests { get; set; }
        public virtual ICollection<HashOnboardingInitiation> HashOnboardingInitiations { get; set; }
        public virtual ICollection<JsonEmployeeAllowance> JsonEmployeeAllowances { get; set; }
        public virtual ICollection<LetterMasGenerationMapping> LetterMasGenerationMappings { get; set; }
        public virtual ICollection<OnboardingInitiation> OnboardingInitiations { get; set; }
        public virtual ICollection<PfDetailMaster> PfDetailMasters { get; set; }
        public virtual ICollection<RecMasManpowerPlanJobid> RecMasManpowerPlanJobids { get; set; }
        public virtual ICollection<RecTransScheduleInterCandidate> RecTransScheduleInterCandidates { get; set; }
        public virtual ICollection<RecTransScheduleInterview> RecTransScheduleInterviews { get; set; }
        public virtual ICollection<TrainTransRequest> TrainTransRequests { get; set; }
        public virtual ICollection<TrainTransTrainerdetInter> TrainTransTrainerdetInters { get; set; }
    }
}
