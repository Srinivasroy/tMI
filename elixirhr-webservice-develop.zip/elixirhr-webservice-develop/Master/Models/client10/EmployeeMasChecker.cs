﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeMasChecker
    {
        public long IntEmpMcId { get; set; }
        public string? VchFieldName { get; set; }
        public string? VchInitiatedBy { get; set; }
        public string? EmpCode { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? Status { get; set; }
        public string? VchFieldValueOld { get; set; }
        public string? EmpName { get; set; }
        public DateTime? DateOfJoin { get; set; }
        public string? VchFieldValueNew { get; set; }
        public double? IntFieldValueIndexNew { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
    }
}
