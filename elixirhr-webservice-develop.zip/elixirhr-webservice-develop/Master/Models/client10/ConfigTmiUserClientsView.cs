﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigTmiUserClientsView
    {
        public long IntTmiClientViewId { get; set; }
        public long? IntTmiUserId { get; set; }
        public string? VchTmiUserName { get; set; }
        public string? VchTmiUserCode { get; set; }
        public string? VchTmiEmpCode { get; set; }
        public string? VchClientNames { get; set; }
        public string? VchClientCompanies { get; set; }
        public string? VchAssignedBy { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
