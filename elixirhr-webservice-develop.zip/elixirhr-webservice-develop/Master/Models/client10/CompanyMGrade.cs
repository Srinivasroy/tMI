﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class CompanyMGrade
    {
        public CompanyMGrade()
        {
            EmployeeMasters = new HashSet<EmployeeMaster>();
        }

        public long IntGradeId { get; set; }
        public string? VchGradeName { get; set; }
        public string? VchDescription { get; set; }
        public string? VchActive { get; set; }
        public DateTime? DtUpdatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public double? IntDesignationId { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }

        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
    }
}
