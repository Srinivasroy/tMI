﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasTmiAdmClientAssign
    {
        public long IntClientAssignId { get; set; }
        public long? IntTmiAdmId { get; set; }
        public long? IntClientId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual ConfigMasClientCreation? IntClient { get; set; }
        public virtual ConfigMasTmiAdmnCreation? IntTmiAdm { get; set; }
    }
}
