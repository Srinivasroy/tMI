﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreOnboarding
    {
        public long IntOnbReptId { get; set; }
        public string? OnboardingInitiationReferenceNumber { get; set; }
        public string? OnboardingInitiatedBy { get; set; }
        public DateOnly? OnboardingInitiatedDate { get; set; }
        public string? OnboardingRequestStatus { get; set; }
        public string? OnboardingRequestApprover { get; set; }
        public string? EmployeeId { get; set; }
        public string? EmployeeFirstName { get; set; }
        public string? EmployeeMiddleName { get; set; }
        public string? EmployeeLastName { get; set; }
        public string? Location { get; set; }
        public string? Department { get; set; }
        public string? Designation { get; set; }
        public string? Grade { get; set; }
        public string? EmployeeCategory { get; set; }
        public string? CostCenter { get; set; }
        public string? ReportingManagerId { get; set; }
        public string? ReportingManagerName { get; set; }
        public DateOnly? EmployeeDoj { get; set; }
        public DateOnly? EmployeeDob { get; set; }
        public string? EmployeePan { get; set; }
        public string? EmployeeAadhar { get; set; }
        public string? EmployeePassport { get; set; }
        public string? EmployeeUan { get; set; }
        public string? EmployeeGender { get; set; }
        public string? EmployeeMobileNo { get; set; }
        public string? EmployeeCity { get; set; }
        public string? EmployeeState { get; set; }
        public string? EmployeePinCode { get; set; }
        public string? EmployeeCountry { get; set; }
        public string? EmployeeExperience { get; set; }
        public string? EmployeePreviousEmployerName { get; set; }
        public string? EmployeePreviousDesignation { get; set; }
        public string? EmployeeSchoolName { get; set; }
        public string? EmployeeSchoolPassOutYear { get; set; }
        public string? EmployeeUniversity { get; set; }
        public string? EmployeeUniversityPassOutYear { get; set; }
        public string? EmployeeBankName { get; set; }
        public string? EmployeeBankAccountNumber { get; set; }
        public string? EmployeeBankBranch { get; set; }
        public string? EmployeeBankIfsc { get; set; }
        public string? EmployeePreviousCtc { get; set; }
        public string? EmployeeCurrentCtc { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
