﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementReturnAsset
    {
        public int IntReturnAssetId { get; set; }
        public long? IntCompanyId { get; set; }
        public int? IntAssetNameId { get; set; }
        public string? VchReason { get; set; }
        public DateOnly? VchDate { get; set; }

        public virtual AssetManagementAssetName? IntAssetName { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
