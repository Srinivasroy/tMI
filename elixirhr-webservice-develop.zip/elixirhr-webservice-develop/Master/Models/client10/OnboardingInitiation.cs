﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class OnboardingInitiation
    {
        public OnboardingInitiation()
        {
            OnboardDocumentDetails = new HashSet<OnboardDocumentDetail>();
            OnboardingInitChecklists = new HashSet<OnboardingInitChecklist>();
        }

        /// <summary>
        /// Primary Key Of onboard iniation
        /// </summary>
        public long OnboardInitiationSeqId { get; set; }
        public string? PersonalFirstName { get; set; }
        public string? PersonalLastName { get; set; }
        public string? PersonalMiddleName { get; set; }
        public string? PersonalRefId { get; set; }
        public DateTime? PersonalDob { get; set; }
        public string? PersonalPanNum { get; set; }
        public string? PersonalAadharCard { get; set; }
        public string? PersonalAddress1 { get; set; }
        public string? PersonalAddress2 { get; set; }
        public string? PersonalAddress3 { get; set; }
        public string? PersonalLocation { get; set; }
        public string? PersonalMobileNum { get; set; }
        public string? PersonalEmailId { get; set; }
        public string? PreviousCompanyName { get; set; }
        public string? PreviousDesignation { get; set; }
        public string? PreviousGrade { get; set; }
        public string? PreviousDepartment { get; set; }
        public string? PreviousReferralPerson { get; set; }
        public string? PreviousCtc { get; set; }
        public string? PreviousAddress1 { get; set; }
        public string? PreviousAddress2 { get; set; }
        public string? PreviousLocation { get; set; }
        public long? PresentDesignation { get; set; }
        public long? PresentDepartment { get; set; }
        public string? PresentGrade { get; set; }
        public DateTime? PresentDoj { get; set; }
        public long? PresentCostCenter { get; set; }
        public long? PresentLocation { get; set; }
        public string? ReportingManagerDesi { get; set; }
        public long? ReportingManagerName { get; set; }
        public string? VchBgv { get; set; }
        public string? VchInitiationStatus { get; set; }
        public string? VchOnboardStatus { get; set; }
        public string? VchInitApproveBy { get; set; }
        public DateTime? DtInitApproveTime { get; set; }
        public string? VchSecApproveBy { get; set; }
        public DateTime? DtSecApproveTime { get; set; }
        public string? VchObApproveBy { get; set; }
        public DateTime? DtObApprovalTime { get; set; }
        public string? VchObApprovalBy1 { get; set; }
        public DateTime? DtObApproveTime1 { get; set; }
        public string? VchInitRejectionMark { get; set; }
        public string? VchSecRejectionMark { get; set; }
        public string? VchObRejectionMark1 { get; set; }
        public string? VchObRejectionMark2 { get; set; }
        public string? VchRaisedBy { get; set; }
        public DateTime? TsRaisedTime { get; set; }
        public string? PreviousReferralMobile { get; set; }
        public string? VchEmpcode { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchExperience { get; set; }
        public string? VchFivePagerUname { get; set; }
        public string? VchFivePagerPword { get; set; }
        public byte[]? BlobOfferLetter { get; set; }
        public byte[]? BlobAppointmentLetter { get; set; }
        public long? IntNewCtc { get; set; }
        public long? IntCtcDifference { get; set; }
        public string? VchSchemaKey { get; set; }
        public long? IntCategoryId { get; set; }
        public string? VchOfferLetterPath { get; set; }
        public string? VchAppointmentLetterPath { get; set; }
        public string? CtcRanges { get; set; }
        public int? IntMidPoints { get; set; }
        public int? IntComparatorsRatio { get; set; }
        public DateOnly? GroupDoj { get; set; }
        public DateOnly? DpdhlJoining { get; set; }
        public long? Departments { get; set; }
        public long? MidPoints { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual DepartmentsMaster? DepartmentsNavigation { get; set; }
        public virtual EmployeeCategoryMaster? IntCategory { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual MidpointMaster? MidPointsNavigation { get; set; }
        public virtual CostcenterMaster? PresentCostCenterNavigation { get; set; }
        public virtual DepartmentMaster? PresentDepartmentNavigation { get; set; }
        public virtual DesignationMaster? PresentDesignationNavigation { get; set; }
        public virtual LocationMaster? PresentLocationNavigation { get; set; }
        public virtual EmployeeMaster? ReportingManagerNameNavigation { get; set; }
        public virtual AuthMasOnbFivepagerLoginDetail AuthMasOnbFivepagerLoginDetail { get; set; } = null!;
        public virtual ICollection<OnboardDocumentDetail> OnboardDocumentDetails { get; set; }
        public virtual ICollection<OnboardingInitChecklist> OnboardingInitChecklists { get; set; }
    }
}
