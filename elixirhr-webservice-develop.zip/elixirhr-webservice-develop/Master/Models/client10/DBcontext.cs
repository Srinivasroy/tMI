﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Master.Models.client10
{
    public partial class DBcontext : DbContext
    {
        public DBcontext()
        {
        }

        public DBcontext(DbContextOptions<DBcontext> options)
            : base(options)
        {
        }

        public virtual DbSet<AbeCodeMaster> AbeCodeMasters { get; set; } = null!;
        public virtual DbSet<AbeCodeMasterTmp> AbeCodeMasterTmps { get; set; } = null!;
        public virtual DbSet<ApprMasAppraiser> ApprMasAppraisers { get; set; } = null!;
        public virtual DbSet<ApprMasAppraiserMappingKra> ApprMasAppraiserMappingKras { get; set; } = null!;
        public virtual DbSet<ApprMasCompetKraMapping> ApprMasCompetKraMappings { get; set; } = null!;
        public virtual DbSet<ApprMasCompetencyList> ApprMasCompetencyLists { get; set; } = null!;
        public virtual DbSet<ApprMasEmpGrouping> ApprMasEmpGroupings { get; set; } = null!;
        public virtual DbSet<ApprMasEmpGroupingAssign> ApprMasEmpGroupingAssigns { get; set; } = null!;
        public virtual DbSet<ApprMasEmptoappMappingHash> ApprMasEmptoappMappingHashes { get; set; } = null!;
        public virtual DbSet<ApprMasGoal> ApprMasGoals { get; set; } = null!;
        public virtual DbSet<ApprMasGoalKraMapping> ApprMasGoalKraMappings { get; set; } = null!;
        public virtual DbSet<ApprMasRatingDescription> ApprMasRatingDescriptions { get; set; } = null!;
        public virtual DbSet<ApprMasRatingOrder> ApprMasRatingOrders { get; set; } = null!;
        public virtual DbSet<ApprMasRatingParaMapping> ApprMasRatingParaMappings { get; set; } = null!;
        public virtual DbSet<ApprMasReviewperiodConfig> ApprMasReviewperiodConfigs { get; set; } = null!;
        public virtual DbSet<ApprTransCompetencyRating> ApprTransCompetencyRatings { get; set; } = null!;
        public virtual DbSet<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashes { get; set; } = null!;
        public virtual DbSet<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistories { get; set; } = null!;
        public virtual DbSet<ApprTransEmptoappMapping> ApprTransEmptoappMappings { get; set; } = null!;
        public virtual DbSet<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistories { get; set; } = null!;
        public virtual DbSet<ApprTransGolesRating> ApprTransGolesRatings { get; set; } = null!;
        public virtual DbSet<ApprTransGolesRatingHash> ApprTransGolesRatingHashes { get; set; } = null!;
        public virtual DbSet<ApprTransGolesRatingHistory> ApprTransGolesRatingHistories { get; set; } = null!;
        public virtual DbSet<ApprTransIncrementalGrid> ApprTransIncrementalGrids { get; set; } = null!;
        public virtual DbSet<ApprTransProcess> ApprTransProcesses { get; set; } = null!;
        public virtual DbSet<ApprTransProcessHistory> ApprTransProcessHistories { get; set; } = null!;
        public virtual DbSet<AssetManagementAssetAttribute> AssetManagementAssetAttributes { get; set; } = null!;
        public virtual DbSet<AssetManagementAssetGroup> AssetManagementAssetGroups { get; set; } = null!;
        public virtual DbSet<AssetManagementAssetName> AssetManagementAssetNames { get; set; } = null!;
        public virtual DbSet<AssetManagementAssetRegister> AssetManagementAssetRegisters { get; set; } = null!;
        public virtual DbSet<AssetManagementAssetRequest> AssetManagementAssetRequests { get; set; } = null!;
        public virtual DbSet<AssetManagementAttributeAssetgroupMap> AssetManagementAttributeAssetgroupMaps { get; set; } = null!;
        public virtual DbSet<AssetManagementReturnAsset> AssetManagementReturnAssets { get; set; } = null!;
        public virtual DbSet<AssetRegisterDetail> AssetRegisterDetails { get; set; } = null!;
        public virtual DbSet<AuditApprMasRatingDesc> AuditApprMasRatingDescs { get; set; } = null!;
        public virtual DbSet<AuditBankDetail> AuditBankDetails { get; set; } = null!;
        public virtual DbSet<AuditEmpBankDetail> AuditEmpBankDetails { get; set; } = null!;
        public virtual DbSet<AuditEmpCategoryChange> AuditEmpCategoryChanges { get; set; } = null!;
        public virtual DbSet<AuditEmpCostcenterChange> AuditEmpCostcenterChanges { get; set; } = null!;
        public virtual DbSet<AuditEmpDeptChange> AuditEmpDeptChanges { get; set; } = null!;
        public virtual DbSet<AuditEmpDesignationChange> AuditEmpDesignationChanges { get; set; } = null!;
        public virtual DbSet<AuditEmpLocationChange> AuditEmpLocationChanges { get; set; } = null!;
        public virtual DbSet<AuditLog> AuditLogs { get; set; } = null!;
        public virtual DbSet<AuditOrgKycInfo> AuditOrgKycInfos { get; set; } = null!;
        public virtual DbSet<AuthMasClientAdminLoginDetail> AuthMasClientAdminLoginDetails { get; set; } = null!;
        public virtual DbSet<AuthMasClientUserLoginDetail> AuthMasClientUserLoginDetails { get; set; } = null!;
        public virtual DbSet<AuthMasEmployeeLoginDetail> AuthMasEmployeeLoginDetails { get; set; } = null!;
        public virtual DbSet<AuthMasOnbFivepagerLoginDetail> AuthMasOnbFivepagerLoginDetails { get; set; } = null!;
        public virtual DbSet<AuthMasTmiAdminDetail> AuthMasTmiAdminDetails { get; set; } = null!;
        public virtual DbSet<AuthMasTmiSuperAdminLoginDetail> AuthMasTmiSuperAdminLoginDetails { get; set; } = null!;
        public virtual DbSet<AuthMasTmiUserLoginDetail> AuthMasTmiUserLoginDetails { get; set; } = null!;
        public virtual DbSet<BankNameMaster> BankNameMasters { get; set; } = null!;
        public virtual DbSet<BankNameMasterTmp> BankNameMasterTmps { get; set; } = null!;
        public virtual DbSet<ClientUserMaster> ClientUserMasters { get; set; } = null!;
        public virtual DbSet<CofigMasClientModule> CofigMasClientModules { get; set; } = null!;
        public virtual DbSet<ComAdmEmpDocument> ComAdmEmpDocuments { get; set; } = null!;
        public virtual DbSet<ComMCity> ComMCities { get; set; } = null!;
        public virtual DbSet<ComMCityTmp> ComMCityTmps { get; set; } = null!;
        public virtual DbSet<ComMClientAdminRole> ComMClientAdminRoles { get; set; } = null!;
        public virtual DbSet<ComMClientUserRole> ComMClientUserRoles { get; set; } = null!;
        public virtual DbSet<ComMCompanyPolicyDocument> ComMCompanyPolicyDocuments { get; set; } = null!;
        public virtual DbSet<ComMCompanyRole> ComMCompanyRoles { get; set; } = null!;
        public virtual DbSet<ComMCompanyRolePage> ComMCompanyRolePages { get; set; } = null!;
        public virtual DbSet<ComMCompanyRolesAssign> ComMCompanyRolesAssigns { get; set; } = null!;
        public virtual DbSet<ComMEmployeeBdayLog> ComMEmployeeBdayLogs { get; set; } = null!;
        public virtual DbSet<ComMEmployeeLoginLog> ComMEmployeeLoginLogs { get; set; } = null!;
        public virtual DbSet<ComTransClientUserCompany> ComTransClientUserCompanies { get; set; } = null!;
        public virtual DbSet<CompanyDetailMaster> CompanyDetailMasters { get; set; } = null!;
        public virtual DbSet<CompanyMGrade> CompanyMGrades { get; set; } = null!;
        public virtual DbSet<CompanyPayRole> CompanyPayRoles { get; set; } = null!;
        public virtual DbSet<ComponentMasCreation> ComponentMasCreations { get; set; } = null!;
        public virtual DbSet<ComponentMasCriteriaDesigAssign> ComponentMasCriteriaDesigAssigns { get; set; } = null!;
        public virtual DbSet<ComponentMasCriteriaOperator> ComponentMasCriteriaOperators { get; set; } = null!;
        public virtual DbSet<ComponentMasCriteriaPatternAssign> ComponentMasCriteriaPatternAssigns { get; set; } = null!;
        public virtual DbSet<ComponentMasCriterion> ComponentMasCriteria { get; set; } = null!;
        public virtual DbSet<ComponentMasCtcMaster> ComponentMasCtcMasters { get; set; } = null!;
        public virtual DbSet<ComponentMasCtcMasterTmp> ComponentMasCtcMasterTmps { get; set; } = null!;
        public virtual DbSet<ComponentMasIdGenerateHistory> ComponentMasIdGenerateHistories { get; set; } = null!;
        public virtual DbSet<ComponentMasOrgAttribute> ComponentMasOrgAttributes { get; set; } = null!;
        public virtual DbSet<ComponentMasUdfMaster> ComponentMasUdfMasters { get; set; } = null!;
        public virtual DbSet<ComponentTransCriteriaComponentAssign> ComponentTransCriteriaComponentAssigns { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalMaster> ComponentTransEmpSalMasters { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalMasterTmp> ComponentTransEmpSalMasterTmps { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalaryHistory> ComponentTransEmpSalaryHistories { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalaryValuesHistory> ComponentTransEmpSalaryValuesHistories { get; set; } = null!;
        public virtual DbSet<ConfigMasClientAdmRight> ConfigMasClientAdmRights { get; set; } = null!;
        public virtual DbSet<ConfigMasClientCreation> ConfigMasClientCreations { get; set; } = null!;
        public virtual DbSet<ConfigMasClientModulesGrpRole> ConfigMasClientModulesGrpRoles { get; set; } = null!;
        public virtual DbSet<ConfigMasDynamicEmpMasterField> ConfigMasDynamicEmpMasterFields { get; set; } = null!;
        public virtual DbSet<ConfigMasEmailSetting> ConfigMasEmailSettings { get; set; } = null!;
        public virtual DbSet<ConfigMasEmpmasNameChange> ConfigMasEmpmasNameChanges { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiAdmClientAssign> ConfigMasTmiAdmClientAssigns { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiAdmnCreation> ConfigMasTmiAdmnCreations { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiClient> ConfigMasTmiClients { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiClientCompany> ConfigMasTmiClientCompanies { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiSuperAdminMaster> ConfigMasTmiSuperAdminMasters { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiUserCreation> ConfigMasTmiUserCreations { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiUserRight> ConfigMasTmiUserRights { get; set; } = null!;
        public virtual DbSet<ConfigQuicklinkEmployee> ConfigQuicklinkEmployees { get; set; } = null!;
        public virtual DbSet<ConfigTmiAdminNoHistory> ConfigTmiAdminNoHistories { get; set; } = null!;
        public virtual DbSet<ConfigTmiUserClientsView> ConfigTmiUserClientsViews { get; set; } = null!;
        public virtual DbSet<ConfigTmiUserNoHistory> ConfigTmiUserNoHistories { get; set; } = null!;
        public virtual DbSet<ConfirmationAssessmentAn> ConfirmationAssessmentAns { get; set; } = null!;
        public virtual DbSet<ConfirmationAssessmentQuestion> ConfirmationAssessmentQuestions { get; set; } = null!;
        public virtual DbSet<ConfirmationAssessmentRequest> ConfirmationAssessmentRequests { get; set; } = null!;
        public virtual DbSet<ConfirmationQuestionEmployeeMap> ConfirmationQuestionEmployeeMaps { get; set; } = null!;
        public virtual DbSet<CostcenterMaster> CostcenterMasters { get; set; } = null!;
        public virtual DbSet<CostcenterMasterTmp> CostcenterMasterTmps { get; set; } = null!;
        public virtual DbSet<Country> Countries { get; set; } = null!;
        public virtual DbSet<CountryTmp> CountryTmps { get; set; } = null!;
        public virtual DbSet<Databasechangelog> Databasechangelogs { get; set; } = null!;
        public virtual DbSet<Databasechangeloglock> Databasechangeloglocks { get; set; } = null!;
        public virtual DbSet<DepartmentMaster> DepartmentMasters { get; set; } = null!;
        public virtual DbSet<DepartmentMasterTmp> DepartmentMasterTmps { get; set; } = null!;
        public virtual DbSet<DepartmentsMaster> DepartmentsMasters { get; set; } = null!;
        public virtual DbSet<DepartmentsMasterTmp> DepartmentsMasterTmps { get; set; } = null!;
        public virtual DbSet<DesignationMaster> DesignationMasters { get; set; } = null!;
        public virtual DbSet<DesignationMasterTmp> DesignationMasterTmps { get; set; } = null!;
        public virtual DbSet<DocumentMaster> DocumentMasters { get; set; } = null!;
        public virtual DbSet<DomainMaster> DomainMasters { get; set; } = null!;
        public virtual DbSet<DomainMasterTmp> DomainMasterTmps { get; set; } = null!;
        public virtual DbSet<Dual> Duals { get; set; } = null!;
        public virtual DbSet<EmpCodeFormula> EmpCodeFormulas { get; set; } = null!;
        public virtual DbSet<EmpMasUniqueUploadField> EmpMasUniqueUploadFields { get; set; } = null!;
        public virtual DbSet<EmpMasterEffectiveDateValidateTmp> EmpMasterEffectiveDateValidateTmps { get; set; } = null!;
        public virtual DbSet<EmpNoHistory> EmpNoHistories { get; set; } = null!;
        public virtual DbSet<EmployeeAttribute> EmployeeAttributes { get; set; } = null!;
        public virtual DbSet<EmployeeCategoryMaster> EmployeeCategoryMasters { get; set; } = null!;
        public virtual DbSet<EmployeeCategoryMasterTmp> EmployeeCategoryMasterTmps { get; set; } = null!;
        public virtual DbSet<EmployeeDocumentSizeDetail> EmployeeDocumentSizeDetails { get; set; } = null!;
        public virtual DbSet<EmployeeMakerChecker> EmployeeMakerCheckers { get; set; } = null!;
        public virtual DbSet<EmployeeMakerCheckerTmp> EmployeeMakerCheckerTmps { get; set; } = null!;
        public virtual DbSet<EmployeeMasChecker> EmployeeMasCheckers { get; set; } = null!;
        public virtual DbSet<EmployeeMasDetail> EmployeeMasDetails { get; set; } = null!;
        public virtual DbSet<EmployeeMasDtlAuditLog> EmployeeMasDtlAuditLogs { get; set; } = null!;
        public virtual DbSet<EmployeeMasNomineeAuditLog> EmployeeMasNomineeAuditLogs { get; set; } = null!;
        public virtual DbSet<EmployeeMasNomineeDetail> EmployeeMasNomineeDetails { get; set; } = null!;
        public virtual DbSet<EmployeeMaster> EmployeeMasters { get; set; } = null!;
        public virtual DbSet<EmployeeMasterTmp> EmployeeMasterTmps { get; set; } = null!;
        public virtual DbSet<EmployeeMasterUniqueUploadTmp> EmployeeMasterUniqueUploadTmps { get; set; } = null!;
        public virtual DbSet<EmployeeMasterUploadTmp> EmployeeMasterUploadTmps { get; set; } = null!;
        public virtual DbSet<EmployeeSalaryAuditLog> EmployeeSalaryAuditLogs { get; set; } = null!;
        public virtual DbSet<EmployeeSalaryDetail> EmployeeSalaryDetails { get; set; } = null!;
        public virtual DbSet<EmployeeSalaryDetailsMakerChecker> EmployeeSalaryDetailsMakerCheckers { get; set; } = null!;
        public virtual DbSet<EmploymentTypeMaster> EmploymentTypeMasters { get; set; } = null!;
        public virtual DbSet<EmploymentTypeMasterTmp> EmploymentTypeMasterTmps { get; set; } = null!;
        public virtual DbSet<ExitMasAn> ExitMasAns { get; set; } = null!;
        public virtual DbSet<ExitMasEmployeeMap> ExitMasEmployeeMaps { get; set; } = null!;
        public virtual DbSet<ExitMasQuestion> ExitMasQuestions { get; set; } = null!;
        public virtual DbSet<ExitMasQuestionTemplate> ExitMasQuestionTemplates { get; set; } = null!;
        public virtual DbSet<ExitMasQuestionTemplateItem> ExitMasQuestionTemplateItems { get; set; } = null!;
        public virtual DbSet<ExitMasResignation> ExitMasResignations { get; set; } = null!;
        public virtual DbSet<ExitTransClearance> ExitTransClearances { get; set; } = null!;
        public virtual DbSet<ExitTransEmprequest> ExitTransEmprequests { get; set; } = null!;
        public virtual DbSet<ExitTransEmprequestAuditLog> ExitTransEmprequestAuditLogs { get; set; } = null!;
        public virtual DbSet<GenerateSeqNum> GenerateSeqNums { get; set; } = null!;
        public virtual DbSet<GenericEmployeeCodeHistory> GenericEmployeeCodeHistories { get; set; } = null!;
        public virtual DbSet<HashOnboardSalaryStructure> HashOnboardSalaryStructures { get; set; } = null!;
        public virtual DbSet<HashOnboardingInitiation> HashOnboardingInitiations { get; set; } = null!;
        public virtual DbSet<ItsRoleSfiaMaster> ItsRoleSfiaMasters { get; set; } = null!;
        public virtual DbSet<ItsRoleSfiaMasterTmp> ItsRoleSfiaMasterTmps { get; set; } = null!;
        public virtual DbSet<JhiAuthority> JhiAuthorities { get; set; } = null!;
        public virtual DbSet<JhiPersistentAuditEvent> JhiPersistentAuditEvents { get; set; } = null!;
        public virtual DbSet<JhiPersistentAuditEvtDatum> JhiPersistentAuditEvtData { get; set; } = null!;
        public virtual DbSet<JhiUser> JhiUsers { get; set; } = null!;
        public virtual DbSet<JsonConstantAttribute> JsonConstantAttributes { get; set; } = null!;
        public virtual DbSet<JsonEmployeeAllowance> JsonEmployeeAllowances { get; set; } = null!;
        public virtual DbSet<JsonMasDatatype> JsonMasDatatypes { get; set; } = null!;
        public virtual DbSet<JsonMasFieldManagement> JsonMasFieldManagements { get; set; } = null!;
        public virtual DbSet<JsonTreeStructureElement> JsonTreeStructureElements { get; set; } = null!;
        public virtual DbSet<JsonTreeStructureManagement> JsonTreeStructureManagements { get; set; } = null!;
        public virtual DbSet<LeaveGroupMaster> LeaveGroupMasters { get; set; } = null!;
        public virtual DbSet<LeaveGroupMasterTmp> LeaveGroupMasterTmps { get; set; } = null!;
        public virtual DbSet<LetterMasGenerationMapping> LetterMasGenerationMappings { get; set; } = null!;
        public virtual DbSet<LetterMasHtmlTemplate> LetterMasHtmlTemplates { get; set; } = null!;
        public virtual DbSet<LetterMasLogo> LetterMasLogos { get; set; } = null!;
        public virtual DbSet<LetterMasSignature> LetterMasSignatures { get; set; } = null!;
        public virtual DbSet<LetterTemplateType> LetterTemplateTypes { get; set; } = null!;
        public virtual DbSet<LocationMaster> LocationMasters { get; set; } = null!;
        public virtual DbSet<LocationMasterTmp> LocationMasterTmps { get; set; } = null!;
        public virtual DbSet<MaritalStatusMaster> MaritalStatusMasters { get; set; } = null!;
        public virtual DbSet<MaritalStatusMasterTmp> MaritalStatusMasterTmps { get; set; } = null!;
        public virtual DbSet<MidpointMaster> MidpointMasters { get; set; } = null!;
        public virtual DbSet<MidpointMasterTmp> MidpointMasterTmps { get; set; } = null!;
        public virtual DbSet<OnboardDocumentDetail> OnboardDocumentDetails { get; set; } = null!;
        public virtual DbSet<OnboardEmployeeDetail> OnboardEmployeeDetails { get; set; } = null!;
        public virtual DbSet<OnboardEmployeeDetailsHash> OnboardEmployeeDetailsHashes { get; set; } = null!;
        public virtual DbSet<OnboardNomineeDetail> OnboardNomineeDetails { get; set; } = null!;
        public virtual DbSet<OnboardNomineeDetailsHash> OnboardNomineeDetailsHashes { get; set; } = null!;
        public virtual DbSet<OnboardSalaryStructure> OnboardSalaryStructures { get; set; } = null!;
        public virtual DbSet<OnboardingInitChecklist> OnboardingInitChecklists { get; set; } = null!;
        public virtual DbSet<OnboardingInitChecklistHash> OnboardingInitChecklistHashes { get; set; } = null!;
        public virtual DbSet<OnboardingInitiation> OnboardingInitiations { get; set; } = null!;
        public virtual DbSet<OnboardingRefIdHistory> OnboardingRefIdHistories { get; set; } = null!;
        public virtual DbSet<PfDetailMaster> PfDetailMasters { get; set; } = null!;
        public virtual DbSet<PhysicalStatusMaster> PhysicalStatusMasters { get; set; } = null!;
        public virtual DbSet<PhysicalStatusMasterTmp> PhysicalStatusMasterTmps { get; set; } = null!;
        public virtual DbSet<ProductivityFactorMaster> ProductivityFactorMasters { get; set; } = null!;
        public virtual DbSet<ProductivityFactorMasterTmp> ProductivityFactorMasterTmps { get; set; } = null!;
        public virtual DbSet<QualificationMaster> QualificationMasters { get; set; } = null!;
        public virtual DbSet<QualificationMasterTmp> QualificationMasterTmps { get; set; } = null!;
        public virtual DbSet<RcsgradeMaster> RcsgradeMasters { get; set; } = null!;
        public virtual DbSet<RcsgradeTmp> RcsgradeTmps { get; set; } = null!;
        public virtual DbSet<RcslevelMaster> RcslevelMasters { get; set; } = null!;
        public virtual DbSet<RcslevelMasterTmp> RcslevelMasterTmps { get; set; } = null!;
        public virtual DbSet<RecMasAddCandidate> RecMasAddCandidates { get; set; } = null!;
        public virtual DbSet<RecMasCandidateIdHistory> RecMasCandidateIdHistories { get; set; } = null!;
        public virtual DbSet<RecMasCompetManpowreqMapping> RecMasCompetManpowreqMappings { get; set; } = null!;
        public virtual DbSet<RecMasCompetencyList> RecMasCompetencyLists { get; set; } = null!;
        public virtual DbSet<RecMasInterviewCompRating> RecMasInterviewCompRatings { get; set; } = null!;
        public virtual DbSet<RecMasJobIdNoHistory> RecMasJobIdNoHistories { get; set; } = null!;
        public virtual DbSet<RecMasManpowerPlan> RecMasManpowerPlans { get; set; } = null!;
        public virtual DbSet<RecMasManpowerPlanJobid> RecMasManpowerPlanJobids { get; set; } = null!;
        public virtual DbSet<RecMasNewCandidate> RecMasNewCandidates { get; set; } = null!;
        public virtual DbSet<RecMasNewcanEdudet> RecMasNewcanEdudets { get; set; } = null!;
        public virtual DbSet<RecMasNewcanEmpdet> RecMasNewcanEmpdets { get; set; } = null!;
        public virtual DbSet<RecMasReqIdHistory> RecMasReqIdHistories { get; set; } = null!;
        public virtual DbSet<RecOfferLetterManagement> RecOfferLetterManagements { get; set; } = null!;
        public virtual DbSet<RecTransManpowerRequest> RecTransManpowerRequests { get; set; } = null!;
        public virtual DbSet<RecTransOfferletterManagement> RecTransOfferletterManagements { get; set; } = null!;
        public virtual DbSet<RecTransReferPublishRequest> RecTransReferPublishRequests { get; set; } = null!;
        public virtual DbSet<RecTransScheduleInterCandidate> RecTransScheduleInterCandidates { get; set; } = null!;
        public virtual DbSet<RecTransScheduleInterview> RecTransScheduleInterviews { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreAppraisal> ReportToolGenericDataStoreAppraisals { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreConfAttribute> ReportToolGenericDataStoreConfAttributes { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreDhlAttribute> ReportToolGenericDataStoreDhlAttributes { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreEmpSignupAttribute> ReportToolGenericDataStoreEmpSignupAttributes { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreEmployeeAllowance> ReportToolGenericDataStoreEmployeeAllowances { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreExit> ReportToolGenericDataStoreExits { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreExitclrAttribute> ReportToolGenericDataStoreExitclrAttributes { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreKycAttribute> ReportToolGenericDataStoreKycAttributes { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreNomineeAttribute> ReportToolGenericDataStoreNomineeAttributes { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreOnboarding> ReportToolGenericDataStoreOnboardings { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreRecruitment> ReportToolGenericDataStoreRecruitments { get; set; } = null!;
        public virtual DbSet<ReportToolGenericDataStoreTraining> ReportToolGenericDataStoreTrainings { get; set; } = null!;
        public virtual DbSet<ReportToolGenericFieldName> ReportToolGenericFieldNames { get; set; } = null!;
        public virtual DbSet<ReportsDomainMaster> ReportsDomainMasters { get; set; } = null!;
        public virtual DbSet<ReportsFieldValue> ReportsFieldValues { get; set; } = null!;
        public virtual DbSet<ReportsGenericFieldValue> ReportsGenericFieldValues { get; set; } = null!;
        public virtual DbSet<ReportsGenericQuery> ReportsGenericQueries { get; set; } = null!;
        public virtual DbSet<ReportsGenericQueryField> ReportsGenericQueryFields { get; set; } = null!;
        public virtual DbSet<ReportsMasStandardReportsList> ReportsMasStandardReportsLists { get; set; } = null!;
        public virtual DbSet<ReportsQuery> ReportsQueries { get; set; } = null!;
        public virtual DbSet<ReportsQueryField> ReportsQueryFields { get; set; } = null!;
        public virtual DbSet<ReportsToolConditionValue> ReportsToolConditionValues { get; set; } = null!;
        public virtual DbSet<ReportsToolFieldStatusValue> ReportsToolFieldStatusValues { get; set; } = null!;
        public virtual DbSet<ReportsToolQuery> ReportsToolQueries { get; set; } = null!;
        public virtual DbSet<RoleMClientAdminNoHistory> RoleMClientAdminNoHistories { get; set; } = null!;
        public virtual DbSet<RoleMClientUserNoHistory> RoleMClientUserNoHistories { get; set; } = null!;
        public virtual DbSet<RoleMCompanyNoHistory> RoleMCompanyNoHistories { get; set; } = null!;
        public virtual DbSet<RoleMTmiNoHistory> RoleMTmiNoHistories { get; set; } = null!;
        public virtual DbSet<SkillMaster> SkillMasters { get; set; } = null!;
        public virtual DbSet<SkillMasterTmp> SkillMasterTmps { get; set; } = null!;
        public virtual DbSet<State> States { get; set; } = null!;
        public virtual DbSet<StateTmp> StateTmps { get; set; } = null!;
        public virtual DbSet<SubdepartmentMaster> SubdepartmentMasters { get; set; } = null!;
        public virtual DbSet<SubdepartmentMasterTmp> SubdepartmentMasterTmps { get; set; } = null!;
        public virtual DbSet<TaxSlabOptedforMaster> TaxSlabOptedforMasters { get; set; } = null!;
        public virtual DbSet<TaxSlabOptedforMasterTmp> TaxSlabOptedforMasterTmps { get; set; } = null!;
        public virtual DbSet<TrainMasCategory> TrainMasCategories { get; set; } = null!;
        public virtual DbSet<TrainMasQuestion> TrainMasQuestions { get; set; } = null!;
        public virtual DbSet<TrainMasTrCodeHistory> TrainMasTrCodeHistories { get; set; } = null!;
        public virtual DbSet<TrainMasType> TrainMasTypes { get; set; } = null!;
        public virtual DbSet<TrainMasVendor> TrainMasVendors { get; set; } = null!;
        public virtual DbSet<TrainMasVendorMapping> TrainMasVendorMappings { get; set; } = null!;
        public virtual DbSet<TrainTransAnswer> TrainTransAnswers { get; set; } = null!;
        public virtual DbSet<TrainTransHrInitiation> TrainTransHrInitiations { get; set; } = null!;
        public virtual DbSet<TrainTransRequest> TrainTransRequests { get; set; } = null!;
        public virtual DbSet<TrainTransTrainerdetExter> TrainTransTrainerdetExters { get; set; } = null!;
        public virtual DbSet<TrainTransTrainerdetInter> TrainTransTrainerdetInters { get; set; } = null!;
        public virtual DbSet<TrainTransTrainingDetail> TrainTransTrainingDetails { get; set; } = null!;
        public virtual DbSet<UserMaster> UserMasters { get; set; } = null!;
        public virtual DbSet<VendorCategoryMaster> VendorCategoryMasters { get; set; } = null!;
        public virtual DbSet<VendorMaster> VendorMasters { get; set; } = null!;
        public virtual DbSet<ViewDocumentCompanyLevelDetail> ViewDocumentCompanyLevelDetails { get; set; } = null!;
        public virtual DbSet<ViewEmployeeMasterValue> ViewEmployeeMasterValues { get; set; } = null!;
        public virtual DbSet<ViewOverallTraining> ViewOverallTrainings { get; set; } = null!;
        public virtual DbSet<ViewTrainingDetail> ViewTrainingDetails { get; set; } = null!;
        public virtual DbSet<WttMCompanyType> WttMCompanyTypes { get; set; } = null!;
        public virtual DbSet<WttMakerChecker> WttMakerCheckers { get; set; } = null!;
        public virtual DbSet<WttTransAnnualReport> WttTransAnnualReports { get; set; } = null!;
        public virtual DbSet<WttTransAnnualReportDetail> WttTransAnnualReportDetails { get; set; } = null!;
        public virtual DbSet<WttTransMonthlyReport> WttTransMonthlyReports { get; set; } = null!;

        public static string? ConnectionString { get; set; } = "server=127.0.0.1;port=3306;database=client10;uid=root;pwd=Test";

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseMySql(ConnectionString, Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.28-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("latin1_swedish_ci")
                .HasCharSet("latin1");

            modelBuilder.Entity<AbeCodeMaster>(entity =>
            {
                entity.HasKey(e => e.AbeCodeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("abe_code_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.AbeCodeSeqId).HasColumnName("ABE_CODE_SEQ_ID");

                entity.Property(e => e.AbeCodeValue)
                    .HasMaxLength(100)
                    .HasColumnName("ABE_CODE_VALUE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<AbeCodeMasterTmp>(entity =>
            {
                entity.HasKey(e => e.AbeCodeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("abe_code_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.AbeCodeSeqId).HasColumnName("ABE_CODE_SEQ_ID");

                entity.Property(e => e.AbeCodeValue)
                    .HasMaxLength(100)
                    .HasColumnName("ABE_CODE_VALUE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ApprMasAppraiser>(entity =>
            {
                entity.HasKey(e => e.IntApprMasAppraiserSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_appraiser");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_APPR_COMP_ID");

                entity.Property(e => e.IntApprMasAppraiserSeqid).HasColumnName("INT_APPR_MAS_APPRAISER_SEQID");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchApprShortName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_APPR_SHORT_NAME");

                entity.Property(e => e.VchAppraiserName)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_APPRAISER_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasAppraisers)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_APPR_COMP_ID");
            });

            modelBuilder.Entity<ApprMasAppraiserMappingKra>(entity =>
            {
                entity.HasKey(e => e.IntApprMappingKraSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_appraiser_mapping_kra");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntAppraiserSeqid, "FK_APP_MAP_KRA_APPRAISER_SEQID");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_APP_MAP_KRA_EMPGROUP_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_APPR_MAP_KRA_COMP_ID");

                entity.Property(e => e.IntApprMappingKraSeqid).HasColumnName("INT_APPR_MAPPING_KRA_SEQID");

                entity.Property(e => e.DtReviewPerioddate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_REVIEW_PERIODDATE");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntAppraiserSeqid).HasColumnName("INT_APPRAISER_SEQID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("INT_EMPGROUP_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntAppraiserSeq)
                    .WithMany(p => p.ApprMasAppraiserMappingKras)
                    .HasForeignKey(d => d.IntAppraiserSeqid)
                    .HasConstraintName("FK_APP_MAP_KRA_APPRAISER_SEQID");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasAppraiserMappingKras)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_APPR_MAP_KRA_COMP_ID");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprMasAppraiserMappingKras)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_APP_MAP_KRA_EMPGROUP_ID");
            });

            modelBuilder.Entity<ApprMasCompetKraMapping>(entity =>
            {
                entity.HasKey(e => e.IntKraMappingSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_compet_kra_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APPR_MAS_COMPET_KRA_MAPPING_INT_COMPANY_ID_idx");

                entity.HasIndex(e => e.IntCompetListSeqid, "FK_KRA_MAPPING_COMPET_LIST");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_KRA_MAPPING_EMP_GROUPING");

                entity.Property(e => e.IntKraMappingSeqid).HasColumnName("INT_KRA_MAPPING_SEQID");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCompetListSeqid).HasColumnName("INT_COMPET_LIST_SEQID");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("INT_EMPGROUP_ID");

                entity.Property(e => e.IntWeightage)
                    .HasPrecision(5, 2)
                    .HasColumnName("INT_WEIGHTAGE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasCompetKraMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APPR_MAS_COMPET_KRA_MAPPING_INT_COMPANY_ID");

                entity.HasOne(d => d.IntCompetListSeq)
                    .WithMany(p => p.ApprMasCompetKraMappings)
                    .HasForeignKey(d => d.IntCompetListSeqid)
                    .HasConstraintName("FK_KRA_MAPPING_COMPET_LIST");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprMasCompetKraMappings)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_KRA_MAPPING_EMP_GROUPING");
            });

            modelBuilder.Entity<ApprMasCompetencyList>(entity =>
            {
                entity.HasKey(e => e.IntCompetListSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_competency_list");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_COMP_LIST_COMP_ID");

                entity.Property(e => e.IntCompetListSeqid).HasColumnName("INT_COMPET_LIST_SEQID");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchBehaviour)
                    .HasMaxLength(3000)
                    .HasColumnName("VCH_BEHAVIOUR");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(1000)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchShortname)
                    .HasMaxLength(200)
                    .HasColumnName("VCH_SHORTNAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasCompetencyLists)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_COMP_LIST_COMP_ID");
            });

            modelBuilder.Entity<ApprMasEmpGrouping>(entity =>
            {
                entity.HasKey(e => e.IntEmpgroupId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_emp_grouping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_EMP_GRP_COMP_ID");

                entity.Property(e => e.IntEmpgroupId)
                    .HasColumnName("INT_EMPGROUP_ID")
                    .HasComment("Primary key column of a table");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchGroupName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_GROUP_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasEmpGroupings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_EMP_GRP_COMP_ID");
            });

            modelBuilder.Entity<ApprMasEmpGroupingAssign>(entity =>
            {
                entity.HasKey(e => e.IntEmpGrpAssignId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_emp_grouping_assign");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_APP_M_EMP_GRP_ASS_GRP_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_EMP_GRP_COMPANY_ID_idx");

                entity.Property(e => e.IntEmpGrpAssignId)
                    .HasColumnName("INT_EMP_GRP_ASSIGN_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntDeptSeqId)
                    .HasColumnName("INT_DEPT_SEQ_ID")
                    .HasComment("Reference From dept master table");

                entity.Property(e => e.IntDesigSeqId)
                    .HasColumnName("INT_DESIG_SEQ_ID")
                    .HasComment("Reference from Designation master table");

                entity.Property(e => e.IntEmpgroupId)
                    .HasColumnName("INT_EMPGROUP_ID")
                    .HasComment("Reference from employee group table");

                entity.Property(e => e.IntLocationSeqId)
                    .HasColumnName("INT_LOCATION_SEQ_ID")
                    .HasComment("Reference From Location master table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasEmpGroupingAssigns)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_EMP_GRP_COMPANY_ID");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprMasEmpGroupingAssigns)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_APP_M_EMP_GRP_ASS_GRP_ID");
            });

            modelBuilder.Entity<ApprMasEmptoappMappingHash>(entity =>
            {
                entity.HasKey(e => e.IntApprEmpappMapSeqidHash)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_emptoapp_mapping_hash");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntApprMasEmpappMapSeqid, "fk_emptoapp_map_has_appr_seqid_idx");

                entity.HasIndex(e => e.IntCategoryId, "fk_emptoapp_map_has_catid_idx");

                entity.HasIndex(e => e.IntCompanyId, "fk_emptoapp_map_has_compid_idx");

                entity.HasIndex(e => e.IntTypeId, "fk_emptoapp_map_has_typeid");

                entity.Property(e => e.IntApprEmpappMapSeqidHash).HasColumnName("int_appr_empapp_map_seqid_hash");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update_date");

                entity.Property(e => e.IntApprMasEmpappMapSeqid).HasColumnName("int_appr_mas_empapp_map_seqid");

                entity.Property(e => e.IntCategoryId).HasColumnName("int_category_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntTypeId).HasColumnName("int_type_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchP1Status)
                    .HasMaxLength(10)
                    .HasColumnName("vch_p1_status");

                entity.Property(e => e.VchP2Status)
                    .HasMaxLength(10)
                    .HasColumnName("vch_p2_status");

                entity.Property(e => e.VchP3Status)
                    .HasMaxLength(10)
                    .HasColumnName("vch_p3_status");

                entity.Property(e => e.VchSelfComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_self_comments");

                entity.Property(e => e.VchSelfStatus)
                    .HasMaxLength(6)
                    .HasColumnName("vch_self_status");

                entity.Property(e => e.VchSkipComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_skip_comments");

                entity.Property(e => e.VchSkipStatus)
                    .HasMaxLength(6)
                    .HasColumnName("vch_skip_status");

                entity.Property(e => e.VchSo1Status)
                    .HasMaxLength(10)
                    .HasColumnName("vch_so1_status");

                entity.Property(e => e.VchSo2Status)
                    .HasMaxLength(10)
                    .HasColumnName("vch_so2_status");

                entity.Property(e => e.VchSo3Status)
                    .HasMaxLength(10)
                    .HasColumnName("vch_so3_status");

                entity.Property(e => e.VchSupStatus)
                    .HasMaxLength(6)
                    .HasColumnName("vch_sup_status");

                entity.Property(e => e.VchTrainComments)
                    .HasMaxLength(600)
                    .HasColumnName("vch_train_comments");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntApprMasEmpappMapSeq)
                    .WithMany(p => p.ApprMasEmptoappMappingHashes)
                    .HasForeignKey(d => d.IntApprMasEmpappMapSeqid)
                    .HasConstraintName("fk_emptoapp_map_has_appr_seqid");

                entity.HasOne(d => d.IntCategory)
                    .WithMany(p => p.ApprMasEmptoappMappingHashes)
                    .HasForeignKey(d => d.IntCategoryId)
                    .HasConstraintName("fk_emptoapp_map_has_catid");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasEmptoappMappingHashes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_emptoapp_map_has_compid");

                entity.HasOne(d => d.IntType)
                    .WithMany(p => p.ApprMasEmptoappMappingHashes)
                    .HasForeignKey(d => d.IntTypeId)
                    .HasConstraintName("fk_emptoapp_map_has_typeid");
            });

            modelBuilder.Entity<ApprMasGoal>(entity =>
            {
                entity.HasKey(e => e.IntGoalId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_goal");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_app_m_goal_id");

                entity.Property(e => e.IntGoalId).HasColumnName("int_goal_id");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchGoalDescription)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_goal_description");

                entity.Property(e => e.VchGoalShortname)
                    .HasMaxLength(200)
                    .HasColumnName("vch_goal_shortname");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasGoals)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_app_m_goal_id");
            });

            modelBuilder.Entity<ApprMasGoalKraMapping>(entity =>
            {
                entity.HasKey(e => e.IntGoalMappingSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_goal_kra_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntGoalId, "fk_kra_mapping_goal");

                entity.HasIndex(e => e.IntEmpgroupId, "fk_kra_mapping_goal_emp_grouping");

                entity.HasIndex(e => e.IntCompanyId, "fk_mas_goal_kra_mapping_int_company_id_idx");

                entity.Property(e => e.IntGoalMappingSeqid).HasColumnName("int_goal_mapping_seqid");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("int_empgroup_id");

                entity.Property(e => e.IntGoalId).HasColumnName("int_goal_id");

                entity.Property(e => e.IntWeightage)
                    .HasPrecision(5, 2)
                    .HasColumnName("int_weightage");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasGoalKraMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_mas_goal_kra_mapping_int_company_id");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprMasGoalKraMappings)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("fk_kra_mapping_goal_emp_grouping");

                entity.HasOne(d => d.IntGoal)
                    .WithMany(p => p.ApprMasGoalKraMappings)
                    .HasForeignKey(d => d.IntGoalId)
                    .HasConstraintName("fk_kra_mapping_goal");
            });

            modelBuilder.Entity<ApprMasRatingDescription>(entity =>
            {
                entity.HasKey(e => e.IntDesId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_rating_description");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_RAT_DESC_COMP_ID");

                entity.Property(e => e.IntDesId)
                    .HasColumnName("INT_DES_ID")
                    .HasComment("PRIMARY KEY");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchShortName)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_SHORT_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasRatingDescriptions)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_RAT_DESC_COMP_ID");
            });

            modelBuilder.Entity<ApprMasRatingOrder>(entity =>
            {
                entity.HasKey(e => e.IntRatingOrderId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_rating_order");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_APPR_M_RO_EMPGROUP");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_RAT_ORDER_COMP_ID");

                entity.Property(e => e.IntRatingOrderId)
                    .HasColumnName("INT_RATING_ORDER_ID")
                    .HasComment("PRIMARY KEY OF TABLE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpgroupId)
                    .HasColumnName("INT_EMPGROUP_ID")
                    .HasComment("REFERENCE FROM EMPLOYEE GROUP TABLE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchOrder)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ORDER")
                    .HasComment("A-ASCENDING,D-DESCENDING");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasRatingOrders)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_RAT_ORDER_COMP_ID");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprMasRatingOrders)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_APPR_M_RO_EMPGROUP");
            });

            modelBuilder.Entity<ApprMasRatingParaMapping>(entity =>
            {
                entity.HasKey(e => e.IntRatingMappingId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_rating_para_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDesId, "FK_APPR_M_RPM_RATING_DESC_ID");

                entity.HasIndex(e => e.IntRatingOrderId, "FK_APPR_M_RPM_RATING_ORDER_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_APPR_M_RPM_Rating_COMPID_idx");

                entity.Property(e => e.IntRatingMappingId)
                    .HasColumnName("INT_RATING_MAPPING_ID")
                    .HasComment("PRIMARK KEY");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntDesId)
                    .HasColumnName("INT_DES_ID")
                    .HasComment("REFERENCE FROM RATING DESCRIPTION TABLE");

                entity.Property(e => e.IntRatingNo).HasColumnName("INT_RATING_NO");

                entity.Property(e => e.IntRatingOrderId)
                    .HasColumnName("INT_RATING_ORDER_ID")
                    .HasComment("REFERENCE FROM RATING ORDER TABLE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasRatingParaMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APPR_M_RPM_Rating_COMPID");

                entity.HasOne(d => d.IntDes)
                    .WithMany(p => p.ApprMasRatingParaMappings)
                    .HasForeignKey(d => d.IntDesId)
                    .HasConstraintName("FK_APPR_M_RPM_RATING_DESC_ID");

                entity.HasOne(d => d.IntRatingOrder)
                    .WithMany(p => p.ApprMasRatingParaMappings)
                    .HasForeignKey(d => d.IntRatingOrderId)
                    .HasConstraintName("FK_APPR_M_RPM_RATING_ORDER_ID");
            });

            modelBuilder.Entity<ApprMasReviewperiodConfig>(entity =>
            {
                entity.HasKey(e => e.IntReviewSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_mas_reviewperiod_config");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_M_REV_PERIOD_COMP_ID");

                entity.Property(e => e.IntReviewSeqid).HasColumnName("INT_REVIEW_SEQID");

                entity.Property(e => e.DtConfirmCutoff)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CONFIRM_CUTOFF");

                entity.Property(e => e.DtPerfEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PERF_END");

                entity.Property(e => e.DtPerfStart)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PERF_START");

                entity.Property(e => e.DtReviewStart)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_REVIEW_START");

                entity.Property(e => e.DtRoleChg)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_ROLE_CHG");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchReviewtype)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_REVIEWTYPE");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprMasReviewperiodConfigs)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_M_REV_PERIOD_COMP_ID");
            });

            modelBuilder.Entity<ApprTransCompetencyRating>(entity =>
            {
                entity.HasKey(e => e.IntReviewId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_competency_rating");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompetListSeqid, "FK_CR_COMPET_LIST_ID");

                entity.HasIndex(e => e.IntEmpMappingId, "FK_CR_EMP_MAPPING_ID");

                entity.HasIndex(e => e.IntP1RatingId, "FK_CR_P1_RATING_ID");

                entity.HasIndex(e => e.IntP2RatingId, "FK_CR_P2_RATING_ID");

                entity.HasIndex(e => e.IntP3RatingId, "FK_CR_P3_RATING_ID");

                entity.HasIndex(e => e.IntSelfRatingId, "FK_CR_SELF_RATING_ID");

                entity.HasIndex(e => e.IntSo1RatingId, "FK_CR_SO1_RATING_ID");

                entity.HasIndex(e => e.IntSo2RatingId, "FK_CR_SO2_RATING_ID");

                entity.HasIndex(e => e.IntSo3RatingId, "FK_CR_SO3_RATING_ID");

                entity.HasIndex(e => e.IntSup1RatingId, "FK_CR_SUP1_RATING_ID");

                entity.HasIndex(e => e.IntSup2RatingId, "FK_CR_SUP2_RATING_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_TRANS_COMPETENCY_idx");

                entity.Property(e => e.IntReviewId)
                    .HasColumnName("INT_REVIEW_ID")
                    .HasComment("Primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCompetListSeqid)
                    .HasColumnName("INT_COMPET_LIST_SEQID")
                    .HasComment("Reference Competency list");

                entity.Property(e => e.IntEmpMappingId)
                    .HasColumnName("INT_EMP_MAPPING_ID")
                    .HasComment("Reference from emp_to_appraisal_mapping");

                entity.Property(e => e.IntP1RatingId)
                    .HasColumnName("INT_P1_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP2RatingId)
                    .HasColumnName("INT_P2_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP3RatingId)
                    .HasColumnName("INT_P3_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSelfRatingId)
                    .HasColumnName("INT_SELF_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo1RatingId)
                    .HasColumnName("INT_SO1_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo2RatingId)
                    .HasColumnName("INT_SO2_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo3RatingId)
                    .HasColumnName("INT_SO3_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup1RatingId)
                    .HasColumnName("INT_SUP1_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup2RatingId)
                    .HasColumnName("INT_SUP2_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchP1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_P1_REMARK");

                entity.Property(e => e.VchP2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_P2_REMARK");

                entity.Property(e => e.VchP3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_P3_REMARK");

                entity.Property(e => e.VchSelfRemark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SELF_REMARK");

                entity.Property(e => e.VchSo1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SO1_REMARK");

                entity.Property(e => e.VchSo2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SO2_REMARK");

                entity.Property(e => e.VchSo3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SO3_REMARK");

                entity.Property(e => e.VchSup1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SUP1_REMARK");

                entity.Property(e => e.VchSup2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SUP2_REMARK");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransCompetencyRatings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TRANS_COMPETENCY");

                entity.HasOne(d => d.IntCompetListSeq)
                    .WithMany(p => p.ApprTransCompetencyRatings)
                    .HasForeignKey(d => d.IntCompetListSeqid)
                    .HasConstraintName("FK_CR_COMPET_LIST_ID");

                entity.HasOne(d => d.IntEmpMapping)
                    .WithMany(p => p.ApprTransCompetencyRatings)
                    .HasForeignKey(d => d.IntEmpMappingId)
                    .HasConstraintName("FK_CR_EMP_MAPPING_ID");

                entity.HasOne(d => d.IntP1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntP1Ratings)
                    .HasForeignKey(d => d.IntP1RatingId)
                    .HasConstraintName("FK_CR_P1_RATING_ID");

                entity.HasOne(d => d.IntP2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntP2Ratings)
                    .HasForeignKey(d => d.IntP2RatingId)
                    .HasConstraintName("FK_CR_P2_RATING_ID");

                entity.HasOne(d => d.IntP3Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntP3Ratings)
                    .HasForeignKey(d => d.IntP3RatingId)
                    .HasConstraintName("FK_CR_P3_RATING_ID");

                entity.HasOne(d => d.IntSelfRating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntSelfRatings)
                    .HasForeignKey(d => d.IntSelfRatingId)
                    .HasConstraintName("FK_CR_SELF_RATING_ID");

                entity.HasOne(d => d.IntSo1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntSo1Ratings)
                    .HasForeignKey(d => d.IntSo1RatingId)
                    .HasConstraintName("FK_CR_SO1_RATING_ID");

                entity.HasOne(d => d.IntSo2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntSo2Ratings)
                    .HasForeignKey(d => d.IntSo2RatingId)
                    .HasConstraintName("FK_CR_SO2_RATING_ID");

                entity.HasOne(d => d.IntSo3Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntSo3Ratings)
                    .HasForeignKey(d => d.IntSo3RatingId)
                    .HasConstraintName("FK_CR_SO3_RATING_ID");

                entity.HasOne(d => d.IntSup1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntSup1Ratings)
                    .HasForeignKey(d => d.IntSup1RatingId)
                    .HasConstraintName("FK_CR_SUP1_RATING_ID");

                entity.HasOne(d => d.IntSup2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingIntSup2Ratings)
                    .HasForeignKey(d => d.IntSup2RatingId)
                    .HasConstraintName("FK_CR_SUP2_RATING_ID");
            });

            modelBuilder.Entity<ApprTransCompetencyRatingHash>(entity =>
            {
                entity.HasKey(e => e.IntReviewHashId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_competency_rating_hash");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompetListSeqid, "fk_cr_hash_compet_list_id");

                entity.HasIndex(e => e.IntEmpMappingId, "fk_cr_hash_emp_mapping_id");

                entity.HasIndex(e => e.IntP1RatingId, "fk_cr_hash_p1_rating_id");

                entity.HasIndex(e => e.IntP2RatingId, "fk_cr_hash_p2_rating_id");

                entity.HasIndex(e => e.IntP3RatingId, "fk_cr_hash_p3_rating_id");

                entity.HasIndex(e => e.IntSelfRatingId, "fk_cr_hash_self_rating_id");

                entity.HasIndex(e => e.IntSo1RatingId, "fk_cr_hash_so1_rating_id");

                entity.HasIndex(e => e.IntSo2RatingId, "fk_cr_hash_so2_rating_id");

                entity.HasIndex(e => e.IntSo3RatingId, "fk_cr_hash_so3_rating_id");

                entity.HasIndex(e => e.IntSup1RatingId, "fk_cr_hash_sup1_rating_id");

                entity.HasIndex(e => e.IntSup2RatingId, "fk_cr_hash_sup2_rating_id");

                entity.Property(e => e.IntReviewHashId)
                    .HasColumnName("int_review_hash_id")
                    .HasComment("primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompetListSeqid)
                    .HasColumnName("int_compet_list_seqid")
                    .HasComment("reference competency list");

                entity.Property(e => e.IntEmpMappingId)
                    .HasColumnName("int_emp_mapping_id")
                    .HasComment("reference from emp_to_appraisal_mapping");

                entity.Property(e => e.IntP1RatingId)
                    .HasColumnName("int_p1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP2RatingId)
                    .HasColumnName("int_p2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP3RatingId)
                    .HasColumnName("int_p3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSelfRatingId)
                    .HasColumnName("int_self_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo1RatingId)
                    .HasColumnName("int_so1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo2RatingId)
                    .HasColumnName("int_so2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo3RatingId)
                    .HasColumnName("int_so3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup1RatingId)
                    .HasColumnName("int_sup1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup2RatingId)
                    .HasColumnName("int_sup2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchP1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p1_remark");

                entity.Property(e => e.VchP2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p2_remark");

                entity.Property(e => e.VchP3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p3_remark");

                entity.Property(e => e.VchSelfRemark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_self_remark");

                entity.Property(e => e.VchSo1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so1_remark");

                entity.Property(e => e.VchSo2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so2_remark");

                entity.Property(e => e.VchSo3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so3_remark");

                entity.Property(e => e.VchSup1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup1_remark");

                entity.Property(e => e.VchSup2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup2_remark");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompetListSeq)
                    .WithMany(p => p.ApprTransCompetencyRatingHashes)
                    .HasForeignKey(d => d.IntCompetListSeqid)
                    .HasConstraintName("fk_cr_hash_compet_list_id");

                entity.HasOne(d => d.IntEmpMapping)
                    .WithMany(p => p.ApprTransCompetencyRatingHashes)
                    .HasForeignKey(d => d.IntEmpMappingId)
                    .HasConstraintName("fk_cr_hash_emp_mapping_id");

                entity.HasOne(d => d.IntP1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntP1Ratings)
                    .HasForeignKey(d => d.IntP1RatingId)
                    .HasConstraintName("fk_cr_hash_p1_rating_id");

                entity.HasOne(d => d.IntP2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntP2Ratings)
                    .HasForeignKey(d => d.IntP2RatingId)
                    .HasConstraintName("fk_cr_hash_p2_rating_id");

                entity.HasOne(d => d.IntP3Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntP3Ratings)
                    .HasForeignKey(d => d.IntP3RatingId)
                    .HasConstraintName("fk_cr_hash_p3_rating_id");

                entity.HasOne(d => d.IntSelfRating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntSelfRatings)
                    .HasForeignKey(d => d.IntSelfRatingId)
                    .HasConstraintName("fk_cr_hash_self_rating_id");

                entity.HasOne(d => d.IntSo1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntSo1Ratings)
                    .HasForeignKey(d => d.IntSo1RatingId)
                    .HasConstraintName("fk_cr_hash_so1_rating_id");

                entity.HasOne(d => d.IntSo2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntSo2Ratings)
                    .HasForeignKey(d => d.IntSo2RatingId)
                    .HasConstraintName("fk_cr_hash_so2_rating_id");

                entity.HasOne(d => d.IntSo3Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntSo3Ratings)
                    .HasForeignKey(d => d.IntSo3RatingId)
                    .HasConstraintName("fk_cr_hash_so3_rating_id");

                entity.HasOne(d => d.IntSup1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntSup1Ratings)
                    .HasForeignKey(d => d.IntSup1RatingId)
                    .HasConstraintName("fk_cr_hash_sup1_rating_id");

                entity.HasOne(d => d.IntSup2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHashIntSup2Ratings)
                    .HasForeignKey(d => d.IntSup2RatingId)
                    .HasConstraintName("fk_cr_hash_sup2_rating_id");
            });

            modelBuilder.Entity<ApprTransCompetencyRatingHistory>(entity =>
            {
                entity.HasKey(e => e.IntReviewHisId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_competency_rating_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_TRANS_COMP_RATING_HIS_COMPANY_ID_idx");

                entity.HasIndex(e => e.IntCompetListSeqid, "FK_CR_HIS_COMPET_LIST_ID");

                entity.HasIndex(e => e.IntEmpMappingHisId, "FK_CR_HIS_EMP_MAPPING_ID");

                entity.HasIndex(e => e.IntP1RatingId, "FK_CR_HIS_P1_RATING_ID");

                entity.HasIndex(e => e.IntP2RatingId, "FK_CR_HIS_P2_RATING_ID");

                entity.HasIndex(e => e.IntP3RatingId, "FK_CR_HIS_P3_RATING_ID");

                entity.HasIndex(e => e.IntSelfRatingId, "FK_CR_HIS_SELF_RATING_ID");

                entity.HasIndex(e => e.IntSo1RatingId, "FK_CR_HIS_SO1_RATING_ID");

                entity.HasIndex(e => e.IntSo2RatingId, "FK_CR_HIS_SO2_RATING_ID");

                entity.HasIndex(e => e.IntSo3RatingId, "FK_CR_HIS_SO3_RATING_ID");

                entity.HasIndex(e => e.IntSup1RatingId, "FK_CR_HIS_SUP1_RATING_ID");

                entity.HasIndex(e => e.IntSup2RatingId, "FK_CR_HIS_SUP2_RATING_ID");

                entity.Property(e => e.IntReviewHisId)
                    .HasColumnName("INT_REVIEW_HIS_ID")
                    .HasComment("Primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntCompetListSeqid)
                    .HasColumnName("INT_COMPET_LIST_SEQID")
                    .HasComment("Reference Competency list");

                entity.Property(e => e.IntEmpMappingHisId)
                    .HasColumnName("INT_EMP_MAPPING_HIS_ID")
                    .HasComment("Reference from emp_to_appraisal_mapping");

                entity.Property(e => e.IntP1RatingId)
                    .HasColumnName("INT_P1_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP2RatingId)
                    .HasColumnName("INT_P2_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP3RatingId)
                    .HasColumnName("INT_P3_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSelfRatingId)
                    .HasColumnName("INT_SELF_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo1RatingId)
                    .HasColumnName("INT_SO1_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo2RatingId)
                    .HasColumnName("INT_SO2_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo3RatingId)
                    .HasColumnName("INT_SO3_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup1RatingId)
                    .HasColumnName("INT_SUP1_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup2RatingId)
                    .HasColumnName("INT_SUP2_RATING_ID")
                    .HasComment("reference from rating table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchP1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_P1_REMARK");

                entity.Property(e => e.VchP2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_P2_REMARK");

                entity.Property(e => e.VchP3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_P3_REMARK");

                entity.Property(e => e.VchSelfRemark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SELF_REMARK");

                entity.Property(e => e.VchSo1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SO1_REMARK");

                entity.Property(e => e.VchSo2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SO2_REMARK");

                entity.Property(e => e.VchSo3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SO3_REMARK");

                entity.Property(e => e.VchSup1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SUP1_REMARK");

                entity.Property(e => e.VchSup2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("VCH_SUP2_REMARK");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransCompetencyRatingHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_TRANS_COMP_RATING_HIS_COMPANY_ID");

                entity.HasOne(d => d.IntCompetListSeq)
                    .WithMany(p => p.ApprTransCompetencyRatingHistories)
                    .HasForeignKey(d => d.IntCompetListSeqid)
                    .HasConstraintName("FK_CR_HIS_COMPET_LIST_ID");

                entity.HasOne(d => d.IntEmpMappingHis)
                    .WithMany(p => p.ApprTransCompetencyRatingHistories)
                    .HasForeignKey(d => d.IntEmpMappingHisId)
                    .HasConstraintName("FK_CR_HIS_EMP_MAPPING_ID");

                entity.HasOne(d => d.IntP1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntP1Ratings)
                    .HasForeignKey(d => d.IntP1RatingId)
                    .HasConstraintName("FK_CR_HIS_P1_RATING_ID");

                entity.HasOne(d => d.IntP2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntP2Ratings)
                    .HasForeignKey(d => d.IntP2RatingId)
                    .HasConstraintName("FK_CR_HIS_P2_RATING_ID");

                entity.HasOne(d => d.IntP3Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntP3Ratings)
                    .HasForeignKey(d => d.IntP3RatingId)
                    .HasConstraintName("FK_CR_HIS_P3_RATING_ID");

                entity.HasOne(d => d.IntSelfRating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntSelfRatings)
                    .HasForeignKey(d => d.IntSelfRatingId)
                    .HasConstraintName("FK_CR_HIS_SELF_RATING_ID");

                entity.HasOne(d => d.IntSo1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntSo1Ratings)
                    .HasForeignKey(d => d.IntSo1RatingId)
                    .HasConstraintName("FK_CR_HIS_SO1_RATING_ID");

                entity.HasOne(d => d.IntSo2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntSo2Ratings)
                    .HasForeignKey(d => d.IntSo2RatingId)
                    .HasConstraintName("FK_CR_HIS_SO2_RATING_ID");

                entity.HasOne(d => d.IntSo3Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntSo3Ratings)
                    .HasForeignKey(d => d.IntSo3RatingId)
                    .HasConstraintName("FK_CR_HIS_SO3_RATING_ID");

                entity.HasOne(d => d.IntSup1Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntSup1Ratings)
                    .HasForeignKey(d => d.IntSup1RatingId)
                    .HasConstraintName("FK_CR_HIS_SUP1_RATING_ID");

                entity.HasOne(d => d.IntSup2Rating)
                    .WithMany(p => p.ApprTransCompetencyRatingHistoryIntSup2Ratings)
                    .HasForeignKey(d => d.IntSup2RatingId)
                    .HasConstraintName("FK_CR_HIS_SUP2_RATING_ID");
            });

            modelBuilder.Entity<ApprTransEmptoappMapping>(entity =>
            {
                entity.HasKey(e => e.IntApprMasEmpappMapSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_emptoapp_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntSelfemployeeSeqId, "FK1_EMPTOAPP_MAPPING_EMP_SEQID");

                entity.HasIndex(e => e.IntPeeremployee1SeqId, "FK2_EMPTOAPP_MAPPING_PEER1");

                entity.HasIndex(e => e.IntPeeremployee2SeqId, "FK3_EMPTOAPP_MAPPING_PEER2");

                entity.HasIndex(e => e.IntPeeremployee3SeqId, "FK4_EMPTOAPP_MAPPING_PEER3");

                entity.HasIndex(e => e.IntSubordiemployee1SeqId, "FK5_EMPTOAPP_MAPPING_SUBORD1");

                entity.HasIndex(e => e.IntSubordiemployee2SeqId, "FK6_EMPTOAPP_MAPPING_SUBORD2");

                entity.HasIndex(e => e.IntSubordiemployee3SeqId, "FK7_EMPTOAPP_MAPPING_SUBORD3");

                entity.HasIndex(e => e.IntSuperioremployee1SeqId, "FK8_EMPTOAPP_MAPPING_SUPERIOR1");

                entity.HasIndex(e => e.IntSuperioremployee2SeqId, "FK9_EMPTOAPP_MAPPING_SUPERIOR2");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_T_EMPTOAPP_COMP_ID");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_EMPTOAPPMAPPING_EMPGROUP");

                entity.HasIndex(e => e.IntTRequestId, "FK_EMPTOAPP_MAPPING_TR_REQ_ID");

                entity.HasIndex(e => e.IntReviewSeqid, "fk_appr_t_emptoappmap_reviewseqid");

                entity.Property(e => e.IntApprMasEmpappMapSeqid).HasColumnName("INT_APPR_MAS_EMPAPP_MAP_SEQID");

                entity.Property(e => e.DouFinalAvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_FINAL_AVG_SCORE");

                entity.Property(e => e.DouGoalPeer1Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_peer1_score");

                entity.Property(e => e.DouGoalPeer2Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_peer2_score");

                entity.Property(e => e.DouGoalPeer3Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_peer3_score");

                entity.Property(e => e.DouGoalSelfScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_self_score");

                entity.Property(e => e.DouGoalSo1Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_so1_score");

                entity.Property(e => e.DouGoalSo2Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_so2_score");

                entity.Property(e => e.DouGoalSo3Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_so3_score");

                entity.Property(e => e.DouGoalSupScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_sup_score");

                entity.Property(e => e.DouP1AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_P1_AVG_SCORE");

                entity.Property(e => e.DouP2AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_P2_AVG_SCORE");

                entity.Property(e => e.DouP3AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_P3_AVG_SCORE");

                entity.Property(e => e.DouSelfAvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SELF_AVG_SCORE");

                entity.Property(e => e.DouSo1AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SO1_AVG_SCORE");

                entity.Property(e => e.DouSo2AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SO2_AVG_SCORE");

                entity.Property(e => e.DouSo3AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SO3_AVG_SCORE");

                entity.Property(e => e.DouSup1AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SUP1_AVG_SCORE");

                entity.Property(e => e.DouSup2AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SUP2_AVG_SCORE");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("INT_EMPGROUP_ID");

                entity.Property(e => e.IntPeeremployee1SeqId).HasColumnName("INT_PEEREMPLOYEE1_SEQ_ID");

                entity.Property(e => e.IntPeeremployee2SeqId).HasColumnName("INT_PEEREMPLOYEE2_SEQ_ID");

                entity.Property(e => e.IntPeeremployee3SeqId).HasColumnName("INT_PEEREMPLOYEE3_SEQ_ID");

                entity.Property(e => e.IntReviewSeqid).HasColumnName("INT_REVIEW_SEQID");

                entity.Property(e => e.IntSelfemployeeSeqId).HasColumnName("INT_SELFEMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntSubordiemployee1SeqId).HasColumnName("INT_SUBORDIEMPLOYEE1_SEQ_ID");

                entity.Property(e => e.IntSubordiemployee2SeqId).HasColumnName("INT_SUBORDIEMPLOYEE2_SEQ_ID");

                entity.Property(e => e.IntSubordiemployee3SeqId).HasColumnName("INT_SUBORDIEMPLOYEE3_SEQ_ID");

                entity.Property(e => e.IntSuperioremployee1SeqId).HasColumnName("INT_SUPERIOREMPLOYEE1_SEQ_ID");

                entity.Property(e => e.IntSuperioremployee2SeqId).HasColumnName("INT_SUPERIOREMPLOYEE2_SEQ_ID");

                entity.Property(e => e.IntTRequestId).HasColumnName("INT_T_REQUEST_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchFinalStatus)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_FINAL_STATUS");

                entity.Property(e => e.VchP1Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_P1_STATUS");

                entity.Property(e => e.VchP2Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_P2_STATUS");

                entity.Property(e => e.VchP3Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_P3_STATUS");

                entity.Property(e => e.VchReviewStatus)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_REVIEW_STATUS");

                entity.Property(e => e.VchSelfComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_self_comments");

                entity.Property(e => e.VchSkipComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_skip_comments");

                entity.Property(e => e.VchSo1Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_SO1_STATUS");

                entity.Property(e => e.VchSo2Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_SO2_STATUS");

                entity.Property(e => e.VchSo3Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_SO3_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchUploadFlag)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_UPLOAD_FLAG");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransEmptoappMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_T_EMPTOAPP_COMP_ID");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprTransEmptoappMappings)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_EMPTOAPPMAPPING_EMPGROUP");

                entity.HasOne(d => d.IntPeeremployee1Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntPeeremployee1Seqs)
                    .HasForeignKey(d => d.IntPeeremployee1SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_2");

                entity.HasOne(d => d.IntPeeremployee2Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntPeeremployee2Seqs)
                    .HasForeignKey(d => d.IntPeeremployee2SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_3");

                entity.HasOne(d => d.IntPeeremployee3Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntPeeremployee3Seqs)
                    .HasForeignKey(d => d.IntPeeremployee3SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_4");

                entity.HasOne(d => d.IntReviewSeq)
                    .WithMany(p => p.ApprTransEmptoappMappings)
                    .HasForeignKey(d => d.IntReviewSeqid)
                    .HasConstraintName("fk_appr_t_emptoappmap_reviewseqid");

                entity.HasOne(d => d.IntSelfemployeeSeq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntSelfemployeeSeqs)
                    .HasForeignKey(d => d.IntSelfemployeeSeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_1");

                entity.HasOne(d => d.IntSubordiemployee1Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntSubordiemployee1Seqs)
                    .HasForeignKey(d => d.IntSubordiemployee1SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_5");

                entity.HasOne(d => d.IntSubordiemployee2Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntSubordiemployee2Seqs)
                    .HasForeignKey(d => d.IntSubordiemployee2SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_6");

                entity.HasOne(d => d.IntSubordiemployee3Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntSubordiemployee3Seqs)
                    .HasForeignKey(d => d.IntSubordiemployee3SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_7");

                entity.HasOne(d => d.IntSuperioremployee1Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntSuperioremployee1Seqs)
                    .HasForeignKey(d => d.IntSuperioremployee1SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_8");

                entity.HasOne(d => d.IntSuperioremployee2Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingIntSuperioremployee2Seqs)
                    .HasForeignKey(d => d.IntSuperioremployee2SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_ibfk_9");

                entity.HasOne(d => d.IntTRequest)
                    .WithMany(p => p.ApprTransEmptoappMappings)
                    .HasForeignKey(d => d.IntTRequestId)
                    .HasConstraintName("FK_EMPTOAPP_MAPPING_TR_REQ_ID");
            });

            modelBuilder.Entity<ApprTransEmptoappMappingHistory>(entity =>
            {
                entity.HasKey(e => e.IntApprMasEmpappMapHisSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_emptoapp_mapping_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntSelfemployeeSeqId, "FK1_EMPTOAPP_MAPPING_HIS_EMP_SEQID");

                entity.HasIndex(e => e.IntPeeremployee1SeqId, "FK2_EMPTOAPP_MAPPING_HIS_PEER1");

                entity.HasIndex(e => e.IntPeeremployee2SeqId, "FK3_EMPTOAPP_MAPPING_HIS_PEER2");

                entity.HasIndex(e => e.IntPeeremployee3SeqId, "FK4_EMPTOAPP_MAPPING_HIS_PEER3");

                entity.HasIndex(e => e.IntSubordiemployee1SeqId, "FK5_EMPTOAPP_MAPPING_HIS_SUBORD1");

                entity.HasIndex(e => e.IntSubordiemployee2SeqId, "FK6_EMPTOAPP_MAPPING_HIS_SUBORD2");

                entity.HasIndex(e => e.IntSubordiemployee3SeqId, "FK7_EMPTOAPP_MAPPING_HIS_SUBORD3");

                entity.HasIndex(e => e.IntSuperioremployee1SeqId, "FK8_EMPTOAPP_MAPPING_HIS_SUPERIOR1");

                entity.HasIndex(e => e.IntSuperioremployee2SeqId, "FK9_EMPTOAPP_MAPPING_HIS_SUPERIOR2");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_T_EMPTOAPP_HIS_COMP_ID");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_EMPTOAPPMAPPING_HIS_EMPGROUP");

                entity.HasIndex(e => e.IntTRequestId, "FK_EMPTOAPP_MAPPING_HIS_TR_REQ_ID");

                entity.HasIndex(e => e.IntReviewSeqid, "fk_appr_t_emptoappmap_his_reviewseqid");

                entity.Property(e => e.IntApprMasEmpappMapHisSeqid).HasColumnName("INT_APPR_MAS_EMPAPP_MAP_HIS_SEQID");

                entity.Property(e => e.DouFinalAvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_FINAL_AVG_SCORE");

                entity.Property(e => e.DouGoalPeer1Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_peer1_score");

                entity.Property(e => e.DouGoalPeer2Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_peer2_score");

                entity.Property(e => e.DouGoalPeer3Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_peer3_score");

                entity.Property(e => e.DouGoalSelfScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_self_score");

                entity.Property(e => e.DouGoalSo1Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_so1_score");

                entity.Property(e => e.DouGoalSo2Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_so2_score");

                entity.Property(e => e.DouGoalSo3Score)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_so3_score");

                entity.Property(e => e.DouGoalSupScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("dou_goal_sup_score");

                entity.Property(e => e.DouP1AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_P1_AVG_SCORE");

                entity.Property(e => e.DouP2AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_P2_AVG_SCORE");

                entity.Property(e => e.DouP3AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_P3_AVG_SCORE");

                entity.Property(e => e.DouSelfAvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SELF_AVG_SCORE");

                entity.Property(e => e.DouSo1AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SO1_AVG_SCORE");

                entity.Property(e => e.DouSo2AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SO2_AVG_SCORE");

                entity.Property(e => e.DouSo3AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SO3_AVG_SCORE");

                entity.Property(e => e.DouSup1AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SUP1_AVG_SCORE");

                entity.Property(e => e.DouSup2AvgScore)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_SUP2_AVG_SCORE");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("INT_EMPGROUP_ID");

                entity.Property(e => e.IntPeeremployee1SeqId).HasColumnName("INT_PEEREMPLOYEE1_SEQ_ID");

                entity.Property(e => e.IntPeeremployee2SeqId).HasColumnName("INT_PEEREMPLOYEE2_SEQ_ID");

                entity.Property(e => e.IntPeeremployee3SeqId).HasColumnName("INT_PEEREMPLOYEE3_SEQ_ID");

                entity.Property(e => e.IntReviewSeqid).HasColumnName("INT_REVIEW_SEQID");

                entity.Property(e => e.IntSelfemployeeSeqId).HasColumnName("INT_SELFEMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntSubordiemployee1SeqId).HasColumnName("INT_SUBORDIEMPLOYEE1_SEQ_ID");

                entity.Property(e => e.IntSubordiemployee2SeqId).HasColumnName("INT_SUBORDIEMPLOYEE2_SEQ_ID");

                entity.Property(e => e.IntSubordiemployee3SeqId).HasColumnName("INT_SUBORDIEMPLOYEE3_SEQ_ID");

                entity.Property(e => e.IntSuperioremployee1SeqId).HasColumnName("INT_SUPERIOREMPLOYEE1_SEQ_ID");

                entity.Property(e => e.IntSuperioremployee2SeqId).HasColumnName("INT_SUPERIOREMPLOYEE2_SEQ_ID");

                entity.Property(e => e.IntTRequestId).HasColumnName("INT_T_REQUEST_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchFinalStatus)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_FINAL_STATUS");

                entity.Property(e => e.VchP1Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_P1_STATUS");

                entity.Property(e => e.VchP2Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_P2_STATUS");

                entity.Property(e => e.VchP3Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_P3_STATUS");

                entity.Property(e => e.VchReviewStatus)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_REVIEW_STATUS");

                entity.Property(e => e.VchSelfComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_self_comments");

                entity.Property(e => e.VchSkipComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_skip_comments");

                entity.Property(e => e.VchSo1Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_SO1_STATUS");

                entity.Property(e => e.VchSo2Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_SO2_STATUS");

                entity.Property(e => e.VchSo3Status)
                    .HasMaxLength(6)
                    .HasColumnName("VCH_SO3_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchUploadFlag)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_UPLOAD_FLAG");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransEmptoappMappingHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_T_EMPTOAPP_HIS_COMP_ID");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprTransEmptoappMappingHistories)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_EMPTOAPPMAPPING_HIS_EMPGROUP");

                entity.HasOne(d => d.IntPeeremployee1Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntPeeremployee1Seqs)
                    .HasForeignKey(d => d.IntPeeremployee1SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_2");

                entity.HasOne(d => d.IntPeeremployee2Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntPeeremployee2Seqs)
                    .HasForeignKey(d => d.IntPeeremployee2SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_3");

                entity.HasOne(d => d.IntPeeremployee3Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntPeeremployee3Seqs)
                    .HasForeignKey(d => d.IntPeeremployee3SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_4");

                entity.HasOne(d => d.IntReviewSeq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistories)
                    .HasForeignKey(d => d.IntReviewSeqid)
                    .HasConstraintName("fk_appr_t_emptoappmap_his_reviewseqid");

                entity.HasOne(d => d.IntSelfemployeeSeq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntSelfemployeeSeqs)
                    .HasForeignKey(d => d.IntSelfemployeeSeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_1");

                entity.HasOne(d => d.IntSubordiemployee1Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntSubordiemployee1Seqs)
                    .HasForeignKey(d => d.IntSubordiemployee1SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_5");

                entity.HasOne(d => d.IntSubordiemployee2Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntSubordiemployee2Seqs)
                    .HasForeignKey(d => d.IntSubordiemployee2SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_6");

                entity.HasOne(d => d.IntSubordiemployee3Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntSubordiemployee3Seqs)
                    .HasForeignKey(d => d.IntSubordiemployee3SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_7");

                entity.HasOne(d => d.IntSuperioremployee1Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntSuperioremployee1Seqs)
                    .HasForeignKey(d => d.IntSuperioremployee1SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_8");

                entity.HasOne(d => d.IntSuperioremployee2Seq)
                    .WithMany(p => p.ApprTransEmptoappMappingHistoryIntSuperioremployee2Seqs)
                    .HasForeignKey(d => d.IntSuperioremployee2SeqId)
                    .HasConstraintName("appr_trans_emptoapp_mapping_his_ibfk_9");

                entity.HasOne(d => d.IntTRequest)
                    .WithMany(p => p.ApprTransEmptoappMappingHistories)
                    .HasForeignKey(d => d.IntTRequestId)
                    .HasConstraintName("FK_EMPTOAPP_MAPPING_HIS_TR_REQ_ID");
            });

            modelBuilder.Entity<ApprTransGolesRating>(entity =>
            {
                entity.HasKey(e => e.IntGolesReviewId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_goles_rating");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpMappingId, "fk_gr_emp_mapping_id");

                entity.HasIndex(e => e.IntGoalId, "fk_gr_goal_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_gr_int_company_id_idx");

                entity.HasIndex(e => e.IntP1RatingId, "fk_gr_p1_rating_id");

                entity.HasIndex(e => e.IntP2RatingId, "fk_gr_p2_rating_id");

                entity.HasIndex(e => e.IntP3RatingId, "fk_gr_p3_rating_id");

                entity.HasIndex(e => e.IntSelfRatingId, "fk_gr_self_rating_id");

                entity.HasIndex(e => e.IntSo1RatingId, "fk_gr_so1_rating_id");

                entity.HasIndex(e => e.IntSo2RatingId, "fk_gr_so2_rating_id");

                entity.HasIndex(e => e.IntSo3RatingId, "fk_gr_so3_rating_id");

                entity.HasIndex(e => e.IntSup1RatingId, "fk_gr_sup1_rating_id");

                entity.HasIndex(e => e.IntSup2RatingId, "fk_gr_sup2_rating_id");

                entity.Property(e => e.IntGolesReviewId)
                    .HasColumnName("int_goles_review_id")
                    .HasComment("primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpMappingId)
                    .HasColumnName("int_emp_mapping_id")
                    .HasComment("reference from emp_to_appraisal_mapping");

                entity.Property(e => e.IntGoalId)
                    .HasColumnName("int_goal_id")
                    .HasComment("reference goal master");

                entity.Property(e => e.IntP1RatingId)
                    .HasColumnName("int_p1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP2RatingId)
                    .HasColumnName("int_p2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP3RatingId)
                    .HasColumnName("int_p3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSelfRatingId)
                    .HasColumnName("int_self_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo1RatingId)
                    .HasColumnName("int_so1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo2RatingId)
                    .HasColumnName("int_so2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo3RatingId)
                    .HasColumnName("int_so3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup1RatingId)
                    .HasColumnName("int_sup1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup2RatingId)
                    .HasColumnName("int_sup2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchP1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p1_remark");

                entity.Property(e => e.VchP2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p2_remark");

                entity.Property(e => e.VchP3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p3_remark");

                entity.Property(e => e.VchSelfRemark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_self_remark");

                entity.Property(e => e.VchSo1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so1_remark");

                entity.Property(e => e.VchSo2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so2_remark");

                entity.Property(e => e.VchSo3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so3_remark");

                entity.Property(e => e.VchSup1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup1_remark");

                entity.Property(e => e.VchSup2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup2_remark");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransGolesRatings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_gr_int_company_id");

                entity.HasOne(d => d.IntEmpMapping)
                    .WithMany(p => p.ApprTransGolesRatings)
                    .HasForeignKey(d => d.IntEmpMappingId)
                    .HasConstraintName("fk_gr_emp_mapping_id");

                entity.HasOne(d => d.IntGoal)
                    .WithMany(p => p.ApprTransGolesRatings)
                    .HasForeignKey(d => d.IntGoalId)
                    .HasConstraintName("fk_gr_goal_id");

                entity.HasOne(d => d.IntSelfRating)
                    .WithMany(p => p.ApprTransGolesRatings)
                    .HasForeignKey(d => d.IntSelfRatingId)
                    .HasConstraintName("fk_gr_p1_rating_id");
            });

            modelBuilder.Entity<ApprTransGolesRatingHash>(entity =>
            {
                entity.HasKey(e => e.IntGolesReviewHashId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_goles_rating_hash");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpMappingId, "fk_gr_hash_emp_mapping_id");

                entity.HasIndex(e => e.IntGoalId, "fk_gr_hash_goal_id");

                entity.HasIndex(e => e.IntP1RatingId, "fk_gr_hash_p1_rating_id");

                entity.HasIndex(e => e.IntP2RatingId, "fk_gr_hash_p2_rating_id");

                entity.HasIndex(e => e.IntP3RatingId, "fk_gr_hash_p3_rating_id");

                entity.HasIndex(e => e.IntSelfRatingId, "fk_gr_hash_self_rating_id");

                entity.HasIndex(e => e.IntSo1RatingId, "fk_gr_hash_so1_rating_id");

                entity.HasIndex(e => e.IntSo2RatingId, "fk_gr_hash_so2_rating_id");

                entity.HasIndex(e => e.IntSo3RatingId, "fk_gr_hash_so3_rating_id");

                entity.HasIndex(e => e.IntSup1RatingId, "fk_gr_hash_sup1_rating_id");

                entity.HasIndex(e => e.IntSup2RatingId, "fk_gr_hash_sup2_rating_id");

                entity.HasIndex(e => e.IntCompanyId, "int_company_id_idx");

                entity.Property(e => e.IntGolesReviewHashId)
                    .HasColumnName("int_goles_review_hash_id")
                    .HasComment("primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpMappingId)
                    .HasColumnName("int_emp_mapping_id")
                    .HasComment("reference from emp_to_appraisal_mapping");

                entity.Property(e => e.IntGoalId)
                    .HasColumnName("int_goal_id")
                    .HasComment("reference goal master");

                entity.Property(e => e.IntP1RatingId)
                    .HasColumnName("int_p1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP2RatingId)
                    .HasColumnName("int_p2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP3RatingId)
                    .HasColumnName("int_p3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSelfRatingId)
                    .HasColumnName("int_self_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo1RatingId)
                    .HasColumnName("int_so1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo2RatingId)
                    .HasColumnName("int_so2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo3RatingId)
                    .HasColumnName("int_so3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup1RatingId)
                    .HasColumnName("int_sup1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup2RatingId)
                    .HasColumnName("int_sup2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchP1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p1_remark");

                entity.Property(e => e.VchP2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p2_remark");

                entity.Property(e => e.VchP3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p3_remark");

                entity.Property(e => e.VchSelfRemark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_self_remark");

                entity.Property(e => e.VchSo1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so1_remark");

                entity.Property(e => e.VchSo2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so2_remark");

                entity.Property(e => e.VchSo3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so3_remark");

                entity.Property(e => e.VchSup1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup1_remark");

                entity.Property(e => e.VchSup2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup2_remark");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransGolesRatingHashes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("int_company_id");

                entity.HasOne(d => d.IntEmpMapping)
                    .WithMany(p => p.ApprTransGolesRatingHashes)
                    .HasForeignKey(d => d.IntEmpMappingId)
                    .HasConstraintName("fk_gr_hash_emp_mapping_id");

                entity.HasOne(d => d.IntGoal)
                    .WithMany(p => p.ApprTransGolesRatingHashes)
                    .HasForeignKey(d => d.IntGoalId)
                    .HasConstraintName("fk_gr_hash_goal_id");

                entity.HasOne(d => d.IntSelfRating)
                    .WithMany(p => p.ApprTransGolesRatingHashes)
                    .HasForeignKey(d => d.IntSelfRatingId)
                    .HasConstraintName("fk_gr_hash_p1_rating_id");
            });

            modelBuilder.Entity<ApprTransGolesRatingHistory>(entity =>
            {
                entity.HasKey(e => e.IntGolesReviewHisId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_goles_rating_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_gr_his_company_id_idx");

                entity.HasIndex(e => e.IntEmpMappingHisId, "fk_gr_his_emp_mapping_id");

                entity.HasIndex(e => e.IntGoalId, "fk_gr_his_goal_id");

                entity.HasIndex(e => e.IntP1RatingId, "fk_gr_his_p1_rating_id");

                entity.HasIndex(e => e.IntP2RatingId, "fk_gr_his_p2_rating_id");

                entity.HasIndex(e => e.IntP3RatingId, "fk_gr_his_p3_rating_id");

                entity.HasIndex(e => e.IntSelfRatingId, "fk_gr_his_self_rating_id");

                entity.HasIndex(e => e.IntSo1RatingId, "fk_gr_his_so1_rating_id");

                entity.HasIndex(e => e.IntSo2RatingId, "fk_gr_his_so2_rating_id");

                entity.HasIndex(e => e.IntSo3RatingId, "fk_gr_his_so3_rating_id");

                entity.HasIndex(e => e.IntSup1RatingId, "fk_gr_his_sup1_rating_id");

                entity.HasIndex(e => e.IntSup2RatingId, "fk_gr_his_sup2_rating_id");

                entity.Property(e => e.IntGolesReviewHisId)
                    .HasColumnName("int_goles_review_his_id")
                    .HasComment("primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpMappingHisId)
                    .HasColumnName("int_emp_mapping_his_id")
                    .HasComment("reference from appr_trans_emptoapp_mapping_history");

                entity.Property(e => e.IntGoalId)
                    .HasColumnName("int_goal_id")
                    .HasComment("reference goal master");

                entity.Property(e => e.IntP1RatingId)
                    .HasColumnName("int_p1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP2RatingId)
                    .HasColumnName("int_p2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntP3RatingId)
                    .HasColumnName("int_p3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSelfRatingId)
                    .HasColumnName("int_self_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo1RatingId)
                    .HasColumnName("int_so1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo2RatingId)
                    .HasColumnName("int_so2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSo3RatingId)
                    .HasColumnName("int_so3_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup1RatingId)
                    .HasColumnName("int_sup1_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.IntSup2RatingId)
                    .HasColumnName("int_sup2_rating_id")
                    .HasComment("reference from rating table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchP1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p1_remark");

                entity.Property(e => e.VchP2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p2_remark");

                entity.Property(e => e.VchP3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_p3_remark");

                entity.Property(e => e.VchSelfRemark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_self_remark");

                entity.Property(e => e.VchSo1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so1_remark");

                entity.Property(e => e.VchSo2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so2_remark");

                entity.Property(e => e.VchSo3Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_so3_remark");

                entity.Property(e => e.VchSup1Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup1_remark");

                entity.Property(e => e.VchSup2Remark)
                    .HasMaxLength(1200)
                    .HasColumnName("vch_sup2_remark");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransGolesRatingHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_gr_his_company_id");

                entity.HasOne(d => d.IntEmpMappingHis)
                    .WithMany(p => p.ApprTransGolesRatingHistories)
                    .HasForeignKey(d => d.IntEmpMappingHisId)
                    .HasConstraintName("fk_gr_his_emp_mapping_id");

                entity.HasOne(d => d.IntGoal)
                    .WithMany(p => p.ApprTransGolesRatingHistories)
                    .HasForeignKey(d => d.IntGoalId)
                    .HasConstraintName("fk_gr_his_goal_id");

                entity.HasOne(d => d.IntSelfRating)
                    .WithMany(p => p.ApprTransGolesRatingHistories)
                    .HasForeignKey(d => d.IntSelfRatingId)
                    .HasConstraintName("fk_gr_his_p1_rating_id");
            });

            modelBuilder.Entity<ApprTransIncrementalGrid>(entity =>
            {
                entity.HasKey(e => e.IntGridId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_incremental_grid");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpgroupId, "FK_APPR_T_IG_EMPGROUP_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_APP_T_INC_GRID_COMP_ID");

                entity.Property(e => e.IntGridId).HasColumnName("INT_GRID_ID");

                entity.Property(e => e.DouMultiplier1)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER1");

                entity.Property(e => e.DouMultiplier2)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER2");

                entity.Property(e => e.DouMultiplier3)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER3");

                entity.Property(e => e.DouMultiplier4)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER4");

                entity.Property(e => e.DouMultiplier5)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER5");

                entity.Property(e => e.DouMultiplier6)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER6");

                entity.Property(e => e.DouMultiplier7)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER7");

                entity.Property(e => e.DouMultiplier8)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER8");

                entity.Property(e => e.DouMultiplier9)
                    .HasPrecision(8, 2)
                    .HasColumnName("DOU_MULTIPLIER9");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpgroupId)
                    .HasColumnName("INT_EMPGROUP_ID")
                    .HasComment("REFERENCE FROM EMPLOYEE GROUP TABLE");

                entity.Property(e => e.IntMultiplierValue).HasColumnName("INT_MULTIPLIER_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransIncrementalGrids)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_APP_T_INC_GRID_COMP_ID");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprTransIncrementalGrids)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("FK_APPR_T_IG_EMPGROUP_ID");
            });

            modelBuilder.Entity<ApprTransProcess>(entity =>
            {
                entity.HasKey(e => e.IntProcessId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_process");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_app_t_process_comp_id");

                entity.HasIndex(e => e.IntEmpgroupId, "fk_appr_t_proce_empgroup_id");

                entity.HasIndex(e => e.IntEmpId, "fk_appr_t_process_emp_id");

                entity.HasIndex(e => e.IntReviewSeqid, "fk_appr_t_process_reviewseqid");

                entity.HasIndex(e => new { e.IntProcessId, e.IntEmpId, e.IntEmpgroupId, e.IntCompanyId }, "index_appr_trans_process");

                entity.Property(e => e.IntProcessId).HasColumnName("int_process_id");

                entity.Property(e => e.BlobAppraisalLetter)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_appraisal_letter");

                entity.Property(e => e.DouCurrentCtc).HasColumnName("dou_current_ctc");

                entity.Property(e => e.DouIncreasing)
                    .HasColumnType("double(20,4)")
                    .HasColumnName("dou_increasing");

                entity.Property(e => e.DouRating)
                    .HasColumnType("double(20,4)")
                    .HasColumnName("dou_rating");

                entity.Property(e => e.DouRevisedCtc).HasColumnName("dou_revised_ctc");

                entity.Property(e => e.DouRevisedPer)
                    .HasColumnType("double(20,4)")
                    .HasColumnName("dou_revised_per");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId).HasColumnName("int_emp_id");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("int_empgroup_id");

                entity.Property(e => e.IntReviewSeqid).HasColumnName("INT_REVIEW_SEQID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchAdjustMode)
                    .HasMaxLength(10)
                    .HasColumnName("vch_adjust_mode");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchLetterGenStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_letter_gen_status");

                entity.Property(e => e.VchRatingPoint)
                    .HasMaxLength(5)
                    .HasColumnName("vch_rating_point");

                entity.Property(e => e.VchSalaryProcessed)
                    .HasMaxLength(3)
                    .HasColumnName("vch_salary_processed");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransProcesses)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_app_t_process_comp_id");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.ApprTransProcesses)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("appr_trans_process_ibfk_1");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprTransProcesses)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("fk_appr_t_proce_empgroup_id");

                entity.HasOne(d => d.IntReviewSeq)
                    .WithMany(p => p.ApprTransProcesses)
                    .HasForeignKey(d => d.IntReviewSeqid)
                    .HasConstraintName("fk_appr_t_process_reviewseqid");
            });

            modelBuilder.Entity<ApprTransProcessHistory>(entity =>
            {
                entity.HasKey(e => e.IntProcessId)
                    .HasName("PRIMARY");

                entity.ToTable("appr_trans_process_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_app_t_process_his_comp_id");

                entity.HasIndex(e => e.IntEmpgroupId, "fk_appr_t_proce_his_empgroup_id");

                entity.HasIndex(e => e.IntEmpId, "fk_appr_t_process_his_emp_id");

                entity.HasIndex(e => e.IntReviewSeqid, "fk_appr_t_process_his_reviewseqid");

                entity.HasIndex(e => new { e.IntProcessId, e.IntEmpId, e.IntEmpgroupId, e.IntCompanyId }, "index_appr_trans_his_process");

                entity.Property(e => e.IntProcessId).HasColumnName("int_process_id");

                entity.Property(e => e.BlobAppraisalLetter)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_appraisal_letter");

                entity.Property(e => e.DouCurrentCtc).HasColumnName("dou_current_ctc");

                entity.Property(e => e.DouIncreasing)
                    .HasColumnType("double(20,4)")
                    .HasColumnName("dou_increasing");

                entity.Property(e => e.DouRating)
                    .HasColumnType("double(20,4)")
                    .HasColumnName("dou_rating");

                entity.Property(e => e.DouRevisedCtc).HasColumnName("dou_revised_ctc");

                entity.Property(e => e.DouRevisedPer)
                    .HasColumnType("double(20,4)")
                    .HasColumnName("dou_revised_per");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId).HasColumnName("int_emp_id");

                entity.Property(e => e.IntEmpgroupId).HasColumnName("int_empgroup_id");

                entity.Property(e => e.IntReviewSeqid).HasColumnName("INT_REVIEW_SEQID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchAdjustMode)
                    .HasMaxLength(10)
                    .HasColumnName("vch_adjust_mode");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchLetterGenStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_letter_gen_status");

                entity.Property(e => e.VchRatingPoint)
                    .HasMaxLength(5)
                    .HasColumnName("vch_rating_point");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ApprTransProcessHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_app_t_process_his_comp_id");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.ApprTransProcessHistories)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("appr_trans_process_his_ibfk_1");

                entity.HasOne(d => d.IntEmpgroup)
                    .WithMany(p => p.ApprTransProcessHistories)
                    .HasForeignKey(d => d.IntEmpgroupId)
                    .HasConstraintName("fk_appr_t_proce_his_empgroup_id");

                entity.HasOne(d => d.IntReviewSeq)
                    .WithMany(p => p.ApprTransProcessHistories)
                    .HasForeignKey(d => d.IntReviewSeqid)
                    .HasConstraintName("fk_appr_t_process_his_reviewseqid");
            });

            modelBuilder.Entity<AssetManagementAssetAttribute>(entity =>
            {
                entity.HasKey(e => e.IntAssetAttributeId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_asset_attributes");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntCompanyId, "fk_asset_attribute_company_id");

                entity.Property(e => e.IntAssetAttributeId).HasColumnName("int_asset_attribute_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchAssetAttributeName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_asset_attribute_name");

                entity.Property(e => e.VchAssetType)
                    .HasMaxLength(15)
                    .HasColumnName("vch_asset_type");

                entity.Property(e => e.VchMandatory)
                    .HasMaxLength(3)
                    .HasColumnName("vch_mandatory");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementAssetAttributes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_asset_attribute_company_id");
            });

            modelBuilder.Entity<AssetManagementAssetGroup>(entity =>
            {
                entity.HasKey(e => e.IntAssetGroupId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_asset_group");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_mas_asset_company_id");

                entity.Property(e => e.IntAssetGroupId).HasColumnName("int_asset_group_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchAssetGroupDescription)
                    .HasMaxLength(300)
                    .HasColumnName("vch_asset_group_description");

                entity.Property(e => e.VchAssetGroupName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_asset_group_name");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementAssetGroups)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_asset_company_id");
            });

            modelBuilder.Entity<AssetManagementAssetName>(entity =>
            {
                entity.HasKey(e => e.IntAssetNameId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_asset_name");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntAssetGroupId, "fk_asset_name_group_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_mas_asset_name_company_id");

                entity.Property(e => e.IntAssetNameId).HasColumnName("int_asset_name_id");

                entity.Property(e => e.IntAssetGroupId).HasColumnName("int_asset_group_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchAssetName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_asset_name");

                entity.Property(e => e.VchAssetNameDescription)
                    .HasMaxLength(300)
                    .HasColumnName("vch_asset_name_description");

                entity.HasOne(d => d.IntAssetGroup)
                    .WithMany(p => p.AssetManagementAssetNames)
                    .HasForeignKey(d => d.IntAssetGroupId)
                    .HasConstraintName("fk_asset_name_group_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementAssetNames)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_doc_mas_asset_name_company_id");
            });

            modelBuilder.Entity<AssetManagementAssetRegister>(entity =>
            {
                entity.HasKey(e => e.IntAssetRegisterId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_asset_register");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.AssetAttributeId, "fk_asset_reg_attribute_id");

                entity.HasIndex(e => e.IntAttributeAssetGroupMapId, "fk_asset_reg_attribute_map_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_asset_reg_company_id");

                entity.HasIndex(e => e.AssetGroupId, "fk_asset_reg_group_id");

                entity.HasIndex(e => e.IntAssetNameId, "fk_doc_asset_reg_Name_id");

                entity.Property(e => e.IntAssetRegisterId).HasColumnName("int_asset_register_id");

                entity.Property(e => e.AssetAttributeId).HasColumnName("asset_attribute_id");

                entity.Property(e => e.AssetGroupId).HasColumnName("asset_group_id");

                entity.Property(e => e.IntAssetNameId).HasColumnName("int_asset_name_id");

                entity.Property(e => e.IntAttributeAssetGroupMapId).HasColumnName("int_attribute_assetGroup_map_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchAssetDate).HasColumnName("vch_asset_date");

                entity.Property(e => e.VchAssetNumeric).HasColumnName("vch_asset_numeric");

                entity.Property(e => e.VchAssetString)
                    .HasMaxLength(15)
                    .HasColumnName("vch_asset_string");

                entity.Property(e => e.VchCount).HasColumnName("vch_count");

                entity.Property(e => e.VchDataType)
                    .HasMaxLength(15)
                    .HasColumnName("vch_data_type");

                entity.HasOne(d => d.AssetAttribute)
                    .WithMany(p => p.AssetManagementAssetRegisters)
                    .HasForeignKey(d => d.AssetAttributeId)
                    .HasConstraintName("fk_asset_reg_attribute_id");

                entity.HasOne(d => d.AssetGroup)
                    .WithMany(p => p.AssetManagementAssetRegisters)
                    .HasForeignKey(d => d.AssetGroupId)
                    .HasConstraintName("fk_asset_reg_group_id");

                entity.HasOne(d => d.IntAssetName)
                    .WithMany(p => p.AssetManagementAssetRegisters)
                    .HasForeignKey(d => d.IntAssetNameId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_doc_asset_reg_Name_id");

                entity.HasOne(d => d.IntAttributeAssetGroupMap)
                    .WithMany(p => p.AssetManagementAssetRegisters)
                    .HasForeignKey(d => d.IntAttributeAssetGroupMapId)
                    .HasConstraintName("fk_asset_reg_attribute_map_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementAssetRegisters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_asset_reg_company_id");
            });

            modelBuilder.Entity<AssetManagementAssetRequest>(entity =>
            {
                entity.HasKey(e => e.IntAssetRequestId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_asset_request");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntAssetNameId, "fk_doc_asset_request_asset_Name_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_asset_request_company_id");

                entity.Property(e => e.IntAssetRequestId).HasColumnName("int_asset_request_id");

                entity.Property(e => e.IntAssetNameId).HasColumnName("int_asset_name_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchFromDate).HasColumnName("vch_from_date");

                entity.Property(e => e.VchPurpose)
                    .HasMaxLength(50)
                    .HasColumnName("vch_purpose");

                entity.Property(e => e.VchRemarks)
                    .HasMaxLength(50)
                    .HasColumnName("vch_remarks");

                entity.Property(e => e.VchToDate).HasColumnName("vch_to_date");

                entity.HasOne(d => d.IntAssetName)
                    .WithMany(p => p.AssetManagementAssetRequests)
                    .HasForeignKey(d => d.IntAssetNameId)
                    .HasConstraintName("fk_doc_asset_request_asset_Name_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementAssetRequests)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_doc_asset_request_company_id");
            });

            modelBuilder.Entity<AssetManagementAttributeAssetgroupMap>(entity =>
            {
                entity.HasKey(e => e.IntAttributeAssetGroupMapId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_attribute_assetgroup_map");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.AssetAttributeId, "fk_asset_attribute_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_asset_group_company_id");

                entity.HasIndex(e => e.AssetGroupId, "fk_asset_group_id");

                entity.Property(e => e.IntAttributeAssetGroupMapId).HasColumnName("int_attribute_assetGroup_map_id");

                entity.Property(e => e.AssetAttributeId).HasColumnName("asset_attribute_id");

                entity.Property(e => e.AssetGroupId).HasColumnName("asset_group_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.HasOne(d => d.AssetAttribute)
                    .WithMany(p => p.AssetManagementAttributeAssetgroupMaps)
                    .HasForeignKey(d => d.AssetAttributeId)
                    .HasConstraintName("fk_asset_attribute_id");

                entity.HasOne(d => d.AssetGroup)
                    .WithMany(p => p.AssetManagementAttributeAssetgroupMaps)
                    .HasForeignKey(d => d.AssetGroupId)
                    .HasConstraintName("fk_asset_group_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementAttributeAssetgroupMaps)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_asset_group_company_id");
            });

            modelBuilder.Entity<AssetManagementReturnAsset>(entity =>
            {
                entity.HasKey(e => e.IntReturnAssetId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_management_return_asset");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntAssetNameId, "fk_doc_return_of_asset_Name_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_return_of_asset_company_id");

                entity.Property(e => e.IntReturnAssetId).HasColumnName("int_return_asset_id");

                entity.Property(e => e.IntAssetNameId).HasColumnName("int_asset_name_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchDate).HasColumnName("vch_date");

                entity.Property(e => e.VchReason)
                    .HasMaxLength(50)
                    .HasColumnName("vch_reason");

                entity.HasOne(d => d.IntAssetName)
                    .WithMany(p => p.AssetManagementReturnAssets)
                    .HasForeignKey(d => d.IntAssetNameId)
                    .HasConstraintName("fk_doc_return_of_asset_Name_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AssetManagementReturnAssets)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_doc_return_of_asset_company_id");
            });

            modelBuilder.Entity<AssetRegisterDetail>(entity =>
            {
                entity.HasKey(e => e.IntAttributesDetailId)
                    .HasName("PRIMARY");

                entity.ToTable("asset_register_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.IntAttributesDetailId).HasColumnName("int_attributes_detail_id");

                entity.Property(e => e.IntAssetId).HasColumnName("int_asset_id");

                entity.Property(e => e.IntAttributeId).HasColumnName("int_attribute_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");
            });

            modelBuilder.Entity<AuditApprMasRatingDesc>(entity =>
            {
                entity.HasKey(e => e.IntAuditId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_appr_mas_rating_desc");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntAuditId).HasColumnName("int_audit_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntDesId)
                    .HasColumnName("INT_DES_ID")
                    .HasComment("PRIMARY KEY");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(10)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchShortName)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_SHORT_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<AuditBankDetail>(entity =>
            {
                entity.HasKey(e => e.IntAdBankId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_bank_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_AD_BANK_COMP_ID");

                entity.HasIndex(e => e.IntEmployeeId, "FK_AD_BANK_EMP_ID");

                entity.Property(e => e.IntAdBankId).HasColumnName("INT_AD_BANK_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeId).HasColumnName("INT_EMPLOYEE_ID");

                entity.Property(e => e.VchAcNo)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_AC_NO");

                entity.Property(e => e.VchBankBranch)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_BANK_BRANCH");

                entity.Property(e => e.VchBankName)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_BANK_NAME");

                entity.Property(e => e.VchIfscCode)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_IFSC_CODE");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AuditBankDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_AD_BANK_COMP_ID");

                entity.HasOne(d => d.IntEmployee)
                    .WithMany(p => p.AuditBankDetails)
                    .HasForeignKey(d => d.IntEmployeeId)
                    .HasConstraintName("FK_AD_BANK_EMP_ID");
            });

            modelBuilder.Entity<AuditEmpBankDetail>(entity =>
            {
                entity.HasKey(e => e.IntBankDetailsId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_emp_bank_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_EMPMAS_DET_COMPANY_ID");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_EMPMAS_DET_EMP_SEQ_ID");

                entity.Property(e => e.IntBankDetailsId).HasColumnName("INT_BANK_DETAILS_ID");

                entity.Property(e => e.DtCreatedDate).HasColumnName("DT_CREATED_DATE");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate).HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("INT_EMPLOYEE_SEQ_ID");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(70)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycDlNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_DL_NO");

                entity.Property(e => e.VarKycEpsNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_EPS_NO");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_OPERATION");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AuditEmpBankDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EMPMAS_DET_COMPANY_ID");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuditEmpBankDetails)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_EMPMAS_DET_EMP_SEQ_ID");
            });

            modelBuilder.Entity<AuditEmpCategoryChange>(entity =>
            {
                entity.HasKey(e => e.IntCategoryChId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_emp_category_change");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_em_id");

                entity.HasIndex(e => e.IntNewCategSeqId, "fk_new_loc");

                entity.HasIndex(e => e.IntOldCategSeqId, "fk_old_loc");

                entity.Property(e => e.IntCategoryChId).HasColumnName("int_category_ch_id");

                entity.Property(e => e.DtCreatedDate).HasColumnName("dt_created_date");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNewCategSeqId).HasColumnName("int_new_categ_seq_id");

                entity.Property(e => e.IntOldCategSeqId).HasColumnName("int_old_categ_seq_id");

                entity.Property(e => e.TsUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActiveStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active_status");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(3)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuditEmpCategoryChanges)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_em_id");

                entity.HasOne(d => d.IntNewCategSeq)
                    .WithMany(p => p.AuditEmpCategoryChangeIntNewCategSeqs)
                    .HasForeignKey(d => d.IntNewCategSeqId)
                    .HasConstraintName("fk_new_categ");

                entity.HasOne(d => d.IntOldCategSeq)
                    .WithMany(p => p.AuditEmpCategoryChangeIntOldCategSeqs)
                    .HasForeignKey(d => d.IntOldCategSeqId)
                    .HasConstraintName("fk_old_categ");
            });

            modelBuilder.Entity<AuditEmpCostcenterChange>(entity =>
            {
                entity.HasKey(e => e.IntCostChId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_emp_costcenter_change");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_employ_id");

                entity.HasIndex(e => e.IntNewCostSeqId, "fk_new_cost");

                entity.HasIndex(e => e.IntOldCostSeqId, "fk_old_cost");

                entity.Property(e => e.IntCostChId).HasColumnName("int_cost_ch_id");

                entity.Property(e => e.DtCreatedDate).HasColumnName("dt_created_date");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNewCostSeqId).HasColumnName("int_new_cost_seq_id");

                entity.Property(e => e.IntOldCostSeqId).HasColumnName("int_old_cost_seq_id");

                entity.Property(e => e.TsUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActiveStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active_status");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(10)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuditEmpCostcenterChanges)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_employ_id");

                entity.HasOne(d => d.IntNewCostSeq)
                    .WithMany(p => p.AuditEmpCostcenterChangeIntNewCostSeqs)
                    .HasForeignKey(d => d.IntNewCostSeqId)
                    .HasConstraintName("fk_new_cost");

                entity.HasOne(d => d.IntOldCostSeq)
                    .WithMany(p => p.AuditEmpCostcenterChangeIntOldCostSeqs)
                    .HasForeignKey(d => d.IntOldCostSeqId)
                    .HasConstraintName("fk_old_cost");
            });

            modelBuilder.Entity<AuditEmpDeptChange>(entity =>
            {
                entity.HasKey(e => e.IntDepChId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_emp_dept_change");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_emp_id");

                entity.HasIndex(e => e.IntNewDeptSeqId, "fk_new_dept");

                entity.HasIndex(e => e.IntOldDeptSeqId, "fk_old_dept");

                entity.Property(e => e.IntDepChId).HasColumnName("int_dep_ch_id");

                entity.Property(e => e.DtCreatedDate).HasColumnName("dt_created_date");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNewDeptSeqId).HasColumnName("int_new_dept_seq_id");

                entity.Property(e => e.IntOldDeptSeqId).HasColumnName("int_old_dept_seq_id");

                entity.Property(e => e.TsUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActiveStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active_status");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(10)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(150)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuditEmpDeptChanges)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_emp_id");

                entity.HasOne(d => d.IntNewDeptSeq)
                    .WithMany(p => p.AuditEmpDeptChangeIntNewDeptSeqs)
                    .HasForeignKey(d => d.IntNewDeptSeqId)
                    .HasConstraintName("fk_new_dept");

                entity.HasOne(d => d.IntOldDeptSeq)
                    .WithMany(p => p.AuditEmpDeptChangeIntOldDeptSeqs)
                    .HasForeignKey(d => d.IntOldDeptSeqId)
                    .HasConstraintName("fk_old_dept");
            });

            modelBuilder.Entity<AuditEmpDesignationChange>(entity =>
            {
                entity.HasKey(e => e.IntDesigChId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_emp_designation_change");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_empl_id");

                entity.HasIndex(e => e.IntNewDesigSeqId, "fk_new_desig");

                entity.HasIndex(e => e.IntOldDesigSeqId, "fk_old_desig");

                entity.Property(e => e.IntDesigChId).HasColumnName("int_desig_ch_id");

                entity.Property(e => e.DtCreatedDate).HasColumnName("dt_created_date");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNewDesigSeqId).HasColumnName("int_new_desig_seq_id");

                entity.Property(e => e.IntOldDesigSeqId).HasColumnName("int_old_desig_seq_id");

                entity.Property(e => e.TsUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActiveStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active_status");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(10)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(150)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuditEmpDesignationChanges)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_empl_id");

                entity.HasOne(d => d.IntNewDesigSeq)
                    .WithMany(p => p.AuditEmpDesignationChangeIntNewDesigSeqs)
                    .HasForeignKey(d => d.IntNewDesigSeqId)
                    .HasConstraintName("fk_new_desig");

                entity.HasOne(d => d.IntOldDesigSeq)
                    .WithMany(p => p.AuditEmpDesignationChangeIntOldDesigSeqs)
                    .HasForeignKey(d => d.IntOldDesigSeqId)
                    .HasConstraintName("fk_old_desig");
            });

            modelBuilder.Entity<AuditEmpLocationChange>(entity =>
            {
                entity.HasKey(e => e.IntLocationChId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_emp_location_change");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_employe_id");

                entity.HasIndex(e => e.IntNewLocSeqId, "fk_new_loc");

                entity.HasIndex(e => e.IntOldLocSeqId, "fk_old_loc");

                entity.Property(e => e.IntLocationChId).HasColumnName("int_location_ch_id");

                entity.Property(e => e.DtCreatedDate).HasColumnName("dt_created_date");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNewLocSeqId).HasColumnName("int_new_loc_seq_id");

                entity.Property(e => e.IntOldLocSeqId).HasColumnName("int_old_loc_seq_id");

                entity.Property(e => e.TsUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActiveStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active_status");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(10)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(150)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuditEmpLocationChanges)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_employe_id");

                entity.HasOne(d => d.IntNewLocSeq)
                    .WithMany(p => p.AuditEmpLocationChangeIntNewLocSeqs)
                    .HasForeignKey(d => d.IntNewLocSeqId)
                    .HasConstraintName("fk_new_loc");

                entity.HasOne(d => d.IntOldLocSeq)
                    .WithMany(p => p.AuditEmpLocationChangeIntOldLocSeqs)
                    .HasForeignKey(d => d.IntOldLocSeqId)
                    .HasConstraintName("fk_old_loc");
            });

            modelBuilder.Entity<AuditLog>(entity =>
            {
                entity.HasKey(e => e.LogId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_log");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LogId).HasColumnName("LOG_ID");

                entity.Property(e => e.Author)
                    .HasMaxLength(100)
                    .HasColumnName("AUTHOR");

                entity.Property(e => e.Event)
                    .HasMaxLength(100)
                    .HasColumnName("EVENT");

                entity.Property(e => e.EventDate)
                    .HasColumnType("datetime")
                    .HasColumnName("EVENT_DATE");

                entity.Property(e => e.StringAttribute1).HasColumnName("STRING_ATTRIBUTE_1");

                entity.Property(e => e.StringAttribute2)
                    .HasMaxLength(50)
                    .HasColumnName("STRING_ATTRIBUTE_2");

                entity.Property(e => e.StringAttribute3).HasColumnName("STRING_ATTRIBUTE_3");
            });

            modelBuilder.Entity<AuditOrgKycInfo>(entity =>
            {
                entity.HasKey(e => e.IntAdOrKyId)
                    .HasName("PRIMARY");

                entity.ToTable("audit_org_kyc_info");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_AD_ORG_KYC_COMP_ID");

                entity.HasIndex(e => e.IntEmpId, "FK_AD_ORG_KYC_EMP_ID");

                entity.HasIndex(e => e.IntNewCostValue, "FK_AD_ORG_KYC_NEW_COST");

                entity.HasIndex(e => e.IntNewDepValue, "FK_AD_ORG_KYC_NEW_DEPT");

                entity.HasIndex(e => e.IntNewDesigValue, "FK_AD_ORG_KYC_NEW_DESIG");

                entity.HasIndex(e => e.IntNewLocValue, "FK_AD_ORG_KYC_NEW_LOC");

                entity.HasIndex(e => e.IntOldCostValue, "FK_AD_ORG_KYC_OLD_COST");

                entity.HasIndex(e => e.IntOldDepValue, "FK_AD_ORG_KYC_OLD_DEPT");

                entity.HasIndex(e => e.IntOldDesigValue, "FK_AD_ORG_KYC_OLD_DESIG");

                entity.HasIndex(e => e.IntOldLocValue, "FK_AD_ORG_KYC_OLD_LOC");

                entity.HasIndex(e => e.IntNewCategoryValue, "fk_audit_new_category_id");

                entity.HasIndex(e => e.IntOldCategoryValue, "fk_audit_old_category_id");

                entity.Property(e => e.IntAdOrKyId).HasColumnName("INT_AD_OR_KY_ID");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_FROM_DATE");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_TO_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpId).HasColumnName("INT_EMP_ID");

                entity.Property(e => e.IntNewCategoryValue).HasColumnName("INT_NEW_CATEGORY_VALUE");

                entity.Property(e => e.IntNewCostValue).HasColumnName("INT_NEW_COST_VALUE");

                entity.Property(e => e.IntNewDepValue).HasColumnName("INT_NEW_DEP_VALUE");

                entity.Property(e => e.IntNewDesigValue).HasColumnName("INT_NEW_DESIG_VALUE");

                entity.Property(e => e.IntNewLocValue).HasColumnName("INT_NEW_LOC_VALUE");

                entity.Property(e => e.IntOldCategoryValue).HasColumnName("INT_OLD_CATEGORY_VALUE");

                entity.Property(e => e.IntOldCostValue).HasColumnName("INT_OLD_COST_VALUE");

                entity.Property(e => e.IntOldDepValue).HasColumnName("INT_OLD_DEP_VALUE");

                entity.Property(e => e.IntOldDesigValue).HasColumnName("INT_OLD_DESIG_VALUE");

                entity.Property(e => e.IntOldLocValue).HasColumnName("INT_OLD_LOC_VALUE");

                entity.Property(e => e.VchAttribute)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_ATTRIBUTE");

                entity.Property(e => e.VchNewAdhaar)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_NEW_ADHAAR");

                entity.Property(e => e.VchNewDl)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_NEW_DL");

                entity.Property(e => e.VchNewEsi)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_NEW_ESI");

                entity.Property(e => e.VchNewPan)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_NEW_PAN");

                entity.Property(e => e.VchNewPassport)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_NEW_PASSPORT");

                entity.Property(e => e.VchNewPf)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_NEW_PF");

                entity.Property(e => e.VchNewRmCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NEW_RM_CODE");

                entity.Property(e => e.VchNewUan)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_NEW_UAN");

                entity.Property(e => e.VchOldAdhaar)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_OLD_ADHAAR");

                entity.Property(e => e.VchOldDl)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_OLD_DL");

                entity.Property(e => e.VchOldEsi)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_OLD_ESI");

                entity.Property(e => e.VchOldPan)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_OLD_PAN");

                entity.Property(e => e.VchOldPassport)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_OLD_PASSPORT");

                entity.Property(e => e.VchOldPf)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_OLD_PF");

                entity.Property(e => e.VchOldRmCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_OLD_RM_CODE");

                entity.Property(e => e.VchOldUan)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_OLD_UAN");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.AuditOrgKycInfos)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_AD_ORG_KYC_COMP_ID");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.AuditOrgKycInfos)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("FK_AD_ORG_KYC_EMP_ID");

                entity.HasOne(d => d.IntNewCategoryValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntNewCategoryValueNavigations)
                    .HasForeignKey(d => d.IntNewCategoryValue)
                    .HasConstraintName("fk_audit_new_category_id");

                entity.HasOne(d => d.IntNewCostValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntNewCostValueNavigations)
                    .HasForeignKey(d => d.IntNewCostValue)
                    .HasConstraintName("FK_AD_ORG_KYC_NEW_COST");

                entity.HasOne(d => d.IntNewDepValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntNewDepValueNavigations)
                    .HasForeignKey(d => d.IntNewDepValue)
                    .HasConstraintName("FK_AD_ORG_KYC_NEW_DEPT");

                entity.HasOne(d => d.IntNewDesigValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntNewDesigValueNavigations)
                    .HasForeignKey(d => d.IntNewDesigValue)
                    .HasConstraintName("FK_AD_ORG_KYC_NEW_DESIG");

                entity.HasOne(d => d.IntNewLocValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntNewLocValueNavigations)
                    .HasForeignKey(d => d.IntNewLocValue)
                    .HasConstraintName("FK_AD_ORG_KYC_NEW_LOC");

                entity.HasOne(d => d.IntOldCategoryValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntOldCategoryValueNavigations)
                    .HasForeignKey(d => d.IntOldCategoryValue)
                    .HasConstraintName("fk_audit_old_category_id");

                entity.HasOne(d => d.IntOldCostValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntOldCostValueNavigations)
                    .HasForeignKey(d => d.IntOldCostValue)
                    .HasConstraintName("FK_AD_ORG_KYC_OLD_COST");

                entity.HasOne(d => d.IntOldDepValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntOldDepValueNavigations)
                    .HasForeignKey(d => d.IntOldDepValue)
                    .HasConstraintName("FK_AD_ORG_KYC_OLD_DEPT");

                entity.HasOne(d => d.IntOldDesigValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntOldDesigValueNavigations)
                    .HasForeignKey(d => d.IntOldDesigValue)
                    .HasConstraintName("FK_AD_ORG_KYC_OLD_DESIG");

                entity.HasOne(d => d.IntOldLocValueNavigation)
                    .WithMany(p => p.AuditOrgKycInfoIntOldLocValueNavigations)
                    .HasForeignKey(d => d.IntOldLocValue)
                    .HasConstraintName("FK_AD_ORG_KYC_OLD_LOC");
            });

            modelBuilder.Entity<AuthMasClientAdminLoginDetail>(entity =>
            {
                entity.HasKey(e => e.IntClientLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_client_admin_login_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "fk_aut_cl_admi_log_det_clientid");

                entity.Property(e => e.IntClientLoginId).HasColumnName("int_client_login_id");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.AuthMasClientAdminLoginDetails)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("fk_aut_cl_admi_log_det_clientid");
            });

            modelBuilder.Entity<AuthMasClientUserLoginDetail>(entity =>
            {
                entity.HasKey(e => e.IntClientUserLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_client_user_login_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "fk_aut_cl_user_log_det_clientid");

                entity.Property(e => e.IntClientUserLoginId).HasColumnName("int_client_user_login_id");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.AuthMasClientUserLoginDetails)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("fk_aut_cl_user_log_det_clientid");
            });

            modelBuilder.Entity<AuthMasEmployeeLoginDetail>(entity =>
            {
                entity.HasKey(e => e.IntEmployeeLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_employee_login_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_aut_emp_log_det_empid");

                entity.Property(e => e.IntEmployeeLoginId).HasColumnName("int_employee_login_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.AuthMasEmployeeLoginDetails)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_aut_emp_log_det_empid");
            });

            modelBuilder.Entity<AuthMasOnbFivepagerLoginDetail>(entity =>
            {
                entity.HasKey(e => e.IntFpLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_onb_fivepager_login_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntFpLoginId, "fk_aut_onb_fp_login_onbseqid");

                entity.Property(e => e.IntFpLoginId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("int_fp_login_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.IntOnbSeqId).HasColumnName("int_onb_seq_id");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntFpLogin)
                    .WithOne(p => p.AuthMasOnbFivepagerLoginDetail)
                    .HasForeignKey<AuthMasOnbFivepagerLoginDetail>(d => d.IntFpLoginId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_aut_onb_fp_login_onbseqid");
            });

            modelBuilder.Entity<AuthMasTmiAdminDetail>(entity =>
            {
                entity.HasKey(e => e.IntTmiaLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_tmi_admin_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntTmiAdmId, "fk_aut_tmia_log_det_tmiadmid");

                entity.Property(e => e.IntTmiaLoginId).HasColumnName("int_tmia_login_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.IntTmiAdmId).HasColumnName("int_tmi_adm_id");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntTmiAdm)
                    .WithMany(p => p.AuthMasTmiAdminDetails)
                    .HasForeignKey(d => d.IntTmiAdmId)
                    .HasConstraintName("fk_aut_tmia_log_det_tmiadmid");
            });

            modelBuilder.Entity<AuthMasTmiSuperAdminLoginDetail>(entity =>
            {
                entity.HasKey(e => e.IntTmisaLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_tmi_super_admin_login_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntTmisaId, "fk_aut_tmisa_log_det_tmisaid");

                entity.Property(e => e.IntTmisaLoginId).HasColumnName("int_tmisa_login_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.IntTmisaId).HasColumnName("int_tmisa_id");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntTmisa)
                    .WithMany(p => p.AuthMasTmiSuperAdminLoginDetails)
                    .HasForeignKey(d => d.IntTmisaId)
                    .HasConstraintName("fk_aut_tmisa_log_det_tmisaid");
            });

            modelBuilder.Entity<AuthMasTmiUserLoginDetail>(entity =>
            {
                entity.HasKey(e => e.IntTmiuLoginId)
                    .HasName("PRIMARY");

                entity.ToTable("auth_mas_tmi_user_login_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntTmiUserId, "fk_aut_tmiu_log_det_tmiuserid");

                entity.Property(e => e.IntTmiuLoginId).HasColumnName("int_tmiu_login_id");

                entity.Property(e => e.IntLoginFailedCount).HasColumnName("int_login_failed_count");

                entity.Property(e => e.IntLoginSuccessCount).HasColumnName("int_login_success_count");

                entity.Property(e => e.IntTmiUserId).HasColumnName("int_tmi_user_id");

                entity.Property(e => e.TsLastFailLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_fail_login_time");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntTmiUser)
                    .WithMany(p => p.AuthMasTmiUserLoginDetails)
                    .HasForeignKey(d => d.IntTmiUserId)
                    .HasConstraintName("fk_aut_tmiu_log_det_tmiuserid");
            });

            modelBuilder.Entity<BankNameMaster>(entity =>
            {
                entity.HasKey(e => e.BankNameSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("bank_name_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.BankNameSeqId).HasColumnName("BANK_NAME_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_BANK_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<BankNameMasterTmp>(entity =>
            {
                entity.HasKey(e => e.BankNameSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("bank_name_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.BankNameSeqId).HasColumnName("BANK_NAME_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_BANK_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ClientUserMaster>(entity =>
            {
                entity.HasKey(e => e.ClientSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("client_user_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientUserRoleId, "FK_CLIEUSEMAS_CLI_USER_ROLE_ID_idx");

                entity.HasIndex(e => e.IntCompanyRoleId, "FK_CLIUSEMAS_COMP_ROLE_ID_idx");

                entity.HasIndex(e => e.IntEmpSeqId, "INT_EMP_SEQ_ID");

                entity.HasIndex(e => e.IntClientId, "fk_cl_use_mas_clientid");

                entity.HasIndex(e => e.IntClientModuleGrpId, "fk_cl_use_mas_clientmodgrpid");

                entity.Property(e => e.ClientSeqId).HasColumnName("CLIENT_SEQ_ID");

                entity.Property(e => e.AdminOrUser)
                    .HasMaxLength(45)
                    .HasColumnName("ADMIN_OR_USER");

                entity.Property(e => e.BlobEmployeePhoto)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_employee_photo");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntClientModuleGrpId).HasColumnName("INT_CLIENT_MODULE_GRP_ID");

                entity.Property(e => e.IntClientUserRoleId).HasColumnName("INT_CLIENT_USER_ROLE_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("INT_COMPANY_ROLE_ID");

                entity.Property(e => e.IntEmpSeqId).HasColumnName("INT_EMP_SEQ_ID");

                entity.Property(e => e.IntOtpValue).HasColumnName("int_otp_value");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsPwdChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_pwd_change_date");

                entity.Property(e => e.UserCode)
                    .HasMaxLength(45)
                    .HasColumnName("USER_CODE");

                entity.Property(e => e.UserMailid)
                    .HasMaxLength(60)
                    .HasColumnName("USER_MAILID");

                entity.Property(e => e.UserMobileno)
                    .HasMaxLength(45)
                    .HasColumnName("USER_MOBILENO");

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .HasColumnName("USER_NAME");

                entity.Property(e => e.UserPassword)
                    .HasMaxLength(80)
                    .HasColumnName("user_password");

                entity.Property(e => e.VchClientUserCompanies)
                    .HasColumnType("text")
                    .HasColumnName("vch_client_user_companies");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchGender)
                    .HasMaxLength(10)
                    .HasColumnName("vch_gender");

                entity.Property(e => e.VchOldPwd1)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd1");

                entity.Property(e => e.VchOldPwd2)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd2");

                entity.Property(e => e.VchOtpVerifyStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_otp_verify_status");

                entity.Property(e => e.VchProfilePath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_profile_path");

                entity.Property(e => e.VchPwdChangeReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_change_req");

                entity.Property(e => e.VchPwdExpired)
                    .HasMaxLength(2)
                    .HasColumnName("vch_pwd_expired");

                entity.Property(e => e.VchPwdResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pwd_reset_key");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchUserCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_USER_CREATED_BY");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.ClientUserMasters)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("fk_cl_use_mas_clientid");

                entity.HasOne(d => d.IntClientModuleGrp)
                    .WithMany(p => p.ClientUserMasters)
                    .HasForeignKey(d => d.IntClientModuleGrpId)
                    .HasConstraintName("fk_cl_use_mas_clientmodgrpid");

                entity.HasOne(d => d.IntClientUserRole)
                    .WithMany(p => p.ClientUserMasters)
                    .HasForeignKey(d => d.IntClientUserRoleId)
                    .HasConstraintName("FK_CLIEUSEMAS_CLI_USER_ROLE_ID");

                entity.HasOne(d => d.IntCompanyRole)
                    .WithMany(p => p.ClientUserMasters)
                    .HasForeignKey(d => d.IntCompanyRoleId)
                    .HasConstraintName("FK_CLIUSEMAS_COMP_ROLE_ID");

                entity.HasOne(d => d.IntEmpSeq)
                    .WithMany(p => p.ClientUserMasters)
                    .HasForeignKey(d => d.IntEmpSeqId)
                    .HasConstraintName("client_user_master_ibfk_1");
            });

            modelBuilder.Entity<CofigMasClientModule>(entity =>
            {
                entity.HasKey(e => e.IntClientModuleGrpId)
                    .HasName("PRIMARY");

                entity.ToTable("cofig_mas_client_modules");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntClientModuleGrpId).HasColumnName("INT_CLIENT_MODULE_GRP_ID");

                entity.Property(e => e.IntIncrementBy).HasColumnName("int_increment_by");

                entity.Property(e => e.IntLastEmpNo).HasColumnName("int_last_emp_no");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME")
                    .HasComment("created time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME")
                    .HasComment("updated time");

                entity.Property(e => e.VchAppraisal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL")
                    .HasComment("Appraisal module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchAppraisalGoal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL_GOAL");

                entity.Property(e => e.VchCandidateManagement)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CANDIDATE_MANAGEMENT");

                entity.Property(e => e.VchCareer)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CAREER")
                    .HasComment("Carrer module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchCompanyAdmin)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_COMPANY_ADMIN")
                    .HasComment("Company Admin module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchConfirmationAssessment)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CONFIRMATION_ASSESSMENT");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY")
                    .HasComment("admin id for created by");

                entity.Property(e => e.VchDashboard)
                    .HasMaxLength(3)
                    .HasColumnName("vch_dashboard");

                entity.Property(e => e.VchDocManagement)
                    .HasMaxLength(3)
                    .HasColumnName("vch_doc_management");

                entity.Property(e => e.VchDynamicEmployeeMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_dynamic_employee_master");

                entity.Property(e => e.VchDynamicEmployeeMasterConfig)
                    .HasMaxLength(5)
                    .HasColumnName("vch_dynamic_employee_master_config");

                entity.Property(e => e.VchEmpCodeAssigned)
                    .HasMaxLength(3)
                    .HasColumnName("vch_emp_code_assigned");

                entity.Property(e => e.VchEmpCodeFormula)
                    .HasMaxLength(200)
                    .HasColumnName("vch_emp_code_formula");

                entity.Property(e => e.VchEmployeeMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_employee_master");

                entity.Property(e => e.VchEss)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ESS");

                entity.Property(e => e.VchExit)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_EXIT")
                    .HasComment("Exit module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchInputToPayroll)
                    .HasMaxLength(3)
                    .HasColumnName("vch_input_to_payroll");

                entity.Property(e => e.VchLetterGeneration)
                    .HasMaxLength(3)
                    .HasColumnName("vch_letter_generation");

                entity.Property(e => e.VchMobileApp)
                    .HasMaxLength(3)
                    .HasColumnName("vch_mobile_app");

                entity.Property(e => e.VchModuleNames)
                    .HasMaxLength(1000)
                    .HasColumnName("VCH_MODULE_NAMES")
                    .HasComment("For Store All module Name");

                entity.Property(e => e.VchOnboarding)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ONBOARDING")
                    .HasComment("Onboarding module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchRecuirement)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_RECUIREMENT")
                    .HasComment("Recuirement module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchReports)
                    .HasMaxLength(3)
                    .HasColumnName("vch_reports");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_ROLE_NAME")
                    .HasComment("Name of the role");

                entity.Property(e => e.VchSalaryMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_salary_master");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchShow)
                    .HasMaxLength(2)
                    .HasColumnName("vch_show");

                entity.Property(e => e.VchStorageMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_storage_master");

                entity.Property(e => e.VchTraining)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TRAINING")
                    .HasComment("Training module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY")
                    .HasComment("admin id for updated by");
            });

            modelBuilder.Entity<ComAdmEmpDocument>(entity =>
            {
                entity.HasKey(e => e.IntEmpDocId)
                    .HasName("PRIMARY");

                entity.ToTable("com_adm_emp_documents");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDocId, "FK_EMP_DOC_MASTER");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_emp_document");

                entity.Property(e => e.IntEmpDocId).HasColumnName("int_emp_doc_id");

                entity.Property(e => e.BlobDocument)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_document");

                entity.Property(e => e.FlagOnbDoc)
                    .HasColumnName("flag_onb_doc")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IntDocId).HasColumnName("int_doc_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.MandatoryDoc)
                    .HasColumnName("mandatory_doc")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.OldStatus)
                    .HasMaxLength(3)
                    .HasColumnName("old_status");

                entity.Property(e => e.OldVchComments)
                    .HasMaxLength(2000)
                    .HasColumnName("old_vch_comments");

                entity.Property(e => e.OldVchDocumentName)
                    .HasMaxLength(100)
                    .HasColumnName("old_vch_document_name");

                entity.Property(e => e.OldVchExtension)
                    .HasMaxLength(10)
                    .HasColumnName("old_vch_extension");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchComments)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_comments");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocumentFinalPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_final_path");

                entity.Property(e => e.VchDocumentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_document_name");

                entity.Property(e => e.VchDocumentPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_path");

                entity.Property(e => e.VchExtension)
                    .HasMaxLength(10)
                    .HasColumnName("vch_extension");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntDoc)
                    .WithMany(p => p.ComAdmEmpDocuments)
                    .HasForeignKey(d => d.IntDocId)
                    .HasConstraintName("FK_EMP_DOC_MASTER");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.ComAdmEmpDocuments)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_emp_document");
            });

            modelBuilder.Entity<ComMCity>(entity =>
            {
                entity.HasKey(e => e.IntCityId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_city");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntCityId).HasColumnName("INT_CITY_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntStateId)
                    .HasColumnName("INT_STATE_ID")
                    .HasComment("Reference from state table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCityName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CITY_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchStateName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_state_name");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ComMCityTmp>(entity =>
            {
                entity.HasKey(e => e.IntCityId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_city_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntCityId).HasColumnName("INT_CITY_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntStateId)
                    .HasColumnName("INT_STATE_ID")
                    .HasComment("Reference from state table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCityName)
                    .HasColumnType("text")
                    .HasColumnName("VCH_CITY_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchStateName)
                    .HasColumnType("text")
                    .HasColumnName("vch_state_name");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ComMClientAdminRole>(entity =>
            {
                entity.HasKey(e => e.IntClientAdminRoleId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_client_admin_role");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntClientAdminRoleId)
                    .HasColumnName("INT_CLIENT_ADMIN_ROLE_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME")
                    .HasComment("created time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME")
                    .HasComment("updated time");

                entity.Property(e => e.VchAppraisal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL")
                    .HasComment("Appraisal module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchCareer)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CAREER")
                    .HasComment("Carrer module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchCompanyAdmin)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_COMPANY_ADMIN")
                    .HasComment("Company Admin module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY")
                    .HasComment("admin id for created by");

                entity.Property(e => e.VchExit)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_EXIT")
                    .HasComment("Exit module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchOnboarding)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ONBOARDING")
                    .HasComment("Onboarding module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchRecuirement)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_RECUIREMENT")
                    .HasComment("Recuirement module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_ROLE_NAME")
                    .HasComment("Name of the role");

                entity.Property(e => e.VchTraining)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TRAINING")
                    .HasComment("Training module for this role.(Y/N).If 'Y' then active. If  'N' then Inactive.");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY")
                    .HasComment("admin id for updated by");
            });

            modelBuilder.Entity<ComMClientUserRole>(entity =>
            {
                entity.HasKey(e => e.IntClientUserRoleId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_client_user_role");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntClientUserRoleId).HasColumnName("INT_CLIENT_USER_ROLE_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchAppraisal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL");

                entity.Property(e => e.VchAppraisalGoal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL_GOAL");

                entity.Property(e => e.VchCareer)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CAREER");

                entity.Property(e => e.VchClientAdminCode)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_CLIENT_ADMIN_CODE");

                entity.Property(e => e.VchCompanyAdmin)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_COMPANY_ADMIN");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDynamicEmployeeMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_dynamic_employee_master");

                entity.Property(e => e.VchEmployeeMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_employee_master");

                entity.Property(e => e.VchEss)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ESS");

                entity.Property(e => e.VchExit)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_EXIT");

                entity.Property(e => e.VchLetterGeneration)
                    .HasMaxLength(3)
                    .HasColumnName("vch_letter_generation");

                entity.Property(e => e.VchModuleNames)
                    .HasColumnType("text")
                    .HasColumnName("vch_module_names");

                entity.Property(e => e.VchOnboarding)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ONBOARDING");

                entity.Property(e => e.VchRecuirement)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_RECUIREMENT");

                entity.Property(e => e.VchReports)
                    .HasMaxLength(3)
                    .HasColumnName("vch_reports");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_ROLE_NAME");

                entity.Property(e => e.VchSalaryMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_salary_master");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTraining)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TRAINING");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ComMCompanyPolicyDocument>(entity =>
            {
                entity.HasKey(e => e.IntCompDocId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_company_policy_documents");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_company_document_comp_id");

                entity.Property(e => e.IntCompDocId).HasColumnName("int_comp_doc_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntSize).HasColumnName("int_size");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocumentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_document_name");

                entity.Property(e => e.VchDocumentPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_path");

                entity.Property(e => e.VchExtension)
                    .HasMaxLength(10)
                    .HasColumnName("vch_extension");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComMCompanyPolicyDocuments)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_company_document_comp_id");
            });

            modelBuilder.Entity<ComMCompanyRole>(entity =>
            {
                entity.HasKey(e => e.IntCompanyRoleId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_company_role");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_com_m_company_role_companyid");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("INT_COMPANY_ROLE_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchAppraisal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL");

                entity.Property(e => e.VchAppraisalGoal)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_APPRAISAL_GOAL");

                entity.Property(e => e.VchCandidateManagement)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CANDIDATE_MANAGEMENT");

                entity.Property(e => e.VchCareer)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CAREER");

                entity.Property(e => e.VchCompanyAdmin)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_COMPANY_ADMIN");

                entity.Property(e => e.VchConfirmationAssessment)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CONFIRMATION_ASSESSMENT");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDynamicEmployeeMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_dynamic_employee_master");

                entity.Property(e => e.VchEmployeeMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_employee_master");

                entity.Property(e => e.VchExit)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_EXIT");

                entity.Property(e => e.VchLetterGeneration)
                    .HasMaxLength(50)
                    .HasColumnName("vch_letter_generation");

                entity.Property(e => e.VchModuleNames)
                    .HasColumnType("text")
                    .HasColumnName("VCH_MODULE_NAMES");

                entity.Property(e => e.VchOnboarding)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ONBOARDING");

                entity.Property(e => e.VchRecuirement)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_RECUIREMENT");

                entity.Property(e => e.VchReport)
                    .HasMaxLength(2)
                    .HasColumnName("vch_report");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_ROLE_NAME");

                entity.Property(e => e.VchSalaryMaster)
                    .HasMaxLength(3)
                    .HasColumnName("vch_salary_master");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTraining)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TRAINING");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComMCompanyRoles)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_com_m_company_role_companyid");
            });

            modelBuilder.Entity<ComMCompanyRolePage>(entity =>
            {
                entity.HasKey(e => e.IntRolePageId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_company_role_pages");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyRoleId, "FK_ROLE_PAGES_COMPANY_ROLE_ID_idx");

                entity.Property(e => e.IntRolePageId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("INT_ROLE_PAGE_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("INT_COMPANY_ROLE_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchPageName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_PAGE_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompanyRole)
                    .WithMany(p => p.ComMCompanyRolePages)
                    .HasForeignKey(d => d.IntCompanyRoleId)
                    .HasConstraintName("FK_ROLE_PAGES_COMPANY_ROLE_ID");
            });

            modelBuilder.Entity<ComMCompanyRolesAssign>(entity =>
            {
                entity.HasKey(e => e.IntCompRolesAssiId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_company_roles_assign");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_COMP_ROLES_ASSIG_COMP_ID");

                entity.HasIndex(e => e.IntCompanyRoleId, "FK_COMP_ROLES_ASSIG_ROLE_ID");

                entity.Property(e => e.IntCompRolesAssiId)
                    .HasColumnName("INT_COMP_ROLES_ASSI_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("INT_COMPANY_ID")
                    .HasComment("Reference from company_details_master");

                entity.Property(e => e.IntCompanyRoleId)
                    .HasColumnName("INT_COMPANY_ROLE_ID")
                    .HasComment("Reference from com_m_company_role");

                entity.Property(e => e.VchAssignedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_ASSIGNED_BY");

                entity.Property(e => e.VchDeleted)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_DELETED");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComMCompanyRolesAssigns)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_COMP_ROLES_ASSIG_COMP_ID");

                entity.HasOne(d => d.IntCompanyRole)
                    .WithMany(p => p.ComMCompanyRolesAssigns)
                    .HasForeignKey(d => d.IntCompanyRoleId)
                    .HasConstraintName("FK_COMP_ROLES_ASSIG_ROLE_ID");
            });

            modelBuilder.Entity<ComMEmployeeBdayLog>(entity =>
            {
                entity.HasKey(e => e.IntEmpBdayId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_employee_bday_log");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmpBdayId).HasColumnName("int_emp_bday_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.VchDepartmentName)
                    .HasMaxLength(60)
                    .HasColumnName("vch_department_name");

                entity.Property(e => e.VchDesignationName)
                    .HasMaxLength(60)
                    .HasColumnName("vch_designation_name");

                entity.Property(e => e.VchEmpCode)
                    .HasMaxLength(80)
                    .HasColumnName("vch_emp_code");

                entity.Property(e => e.VchEmpName)
                    .HasMaxLength(80)
                    .HasColumnName("vch_emp_name");

                entity.Property(e => e.VchGender)
                    .HasMaxLength(6)
                    .HasColumnName("vch_gender");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(60)
                    .HasColumnName("vch_location_name");

                entity.Property(e => e.VchProfile)
                    .HasMaxLength(3)
                    .HasColumnName("vch_profile");

                entity.Property(e => e.VchProfileUrl)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_profile_url");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<ComMEmployeeLoginLog>(entity =>
            {
                entity.HasKey(e => e.IntLogId)
                    .HasName("PRIMARY");

                entity.ToTable("com_m_employee_login_log");

                entity.HasComment("For Employee Login")
                    .HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_com_m_company_log");

                entity.HasIndex(e => e.IntEmployeeSeqId, "idx_com_m_login_log");

                entity.Property(e => e.IntLogId).HasColumnName("int_log_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsLastLoginTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_last_login_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOpen)
                    .HasMaxLength(3)
                    .HasColumnName("vch_open");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComMEmployeeLoginLogs)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_com_m_company_log");
            });

            modelBuilder.Entity<ComTransClientUserCompany>(entity =>
            {
                entity.HasKey(e => e.IntClUserCompanyId)
                    .HasName("PRIMARY");

                entity.ToTable("com_trans_client_user_company");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntClUserCompanyId).HasColumnName("INT_CL_USER_COMPANY_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntClientSeqId)
                    .HasColumnName("INT_CLIENT_SEQ_ID")
                    .HasComment("Reference from client_user_mastertable");

                entity.Property(e => e.IntCompanySeqId)
                    .HasColumnName("INT_COMPANY_SEQ_ID")
                    .HasComment("Reference from company_detail_master table");

                entity.Property(e => e.VchRoleAssigned)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ROLE_ASSIGNED");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchUserCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_USER_CREATED_BY");
            });

            modelBuilder.Entity<CompanyDetailMaster>(entity =>
            {
                entity.HasKey(e => e.CompanySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("company_detail_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "int_client_id");

                entity.Property(e => e.CompanySeqId).HasColumnName("COMPANY_SEQ_ID");

                entity.Property(e => e.CompanyAddress)
                    .HasMaxLength(300)
                    .HasColumnName("COMPANY_ADDRESS");

                entity.Property(e => e.CompanyLogo).HasColumnName("COMPANY_LOGO");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(50)
                    .HasColumnName("COMPANY_NAME");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EsiReg)
                    .HasMaxLength(50)
                    .HasColumnName("ESI_REG");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntIncrementBy).HasColumnName("int_increment_by");

                entity.Property(e => e.IntLastEmpNo).HasColumnName("int_last_emp_no");

                entity.Property(e => e.PanNo)
                    .HasMaxLength(45)
                    .HasColumnName("PAN_NO");

                entity.Property(e => e.PfReg)
                    .HasMaxLength(50)
                    .HasColumnName("PF_REG");

                entity.Property(e => e.TanNo)
                    .HasMaxLength(45)
                    .HasColumnName("TAN_NO");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCompanyId)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_COMPANY_ID");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmpCodeAssigned)
                    .HasMaxLength(3)
                    .HasColumnName("vch_emp_code_assigned");

                entity.Property(e => e.VchEmpCodeFormula)
                    .HasMaxLength(200)
                    .HasColumnName("vch_emp_code_formula");

                entity.Property(e => e.VchEsiReg)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_ESI_REG");

                entity.Property(e => e.VchLogoPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_logo_path");

                entity.Property(e => e.VchPfReg)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_PF_REG");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.CompanyDetailMasters)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("company_detail_master_ibfk_1");
            });

            modelBuilder.Entity<CompanyMGrade>(entity =>
            {
                entity.HasKey(e => e.IntGradeId)
                    .HasName("PRIMARY");

                entity.ToTable("company_m_grade");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntGradeId).HasColumnName("INT_GRADE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntDesignationId).HasColumnName("INT_DESIGNATION_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(1)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(200)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchGradeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_GRADE_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<CompanyPayRole>(entity =>
            {
                entity.HasKey(e => e.PayroleSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("company_pay_role");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.PayroleSeqid).HasColumnName("PAYROLE_SEQID");

                entity.Property(e => e.Arrear).HasColumnName("ARREAR");

                entity.Property(e => e.ComponentCode)
                    .HasMaxLength(45)
                    .HasColumnName("COMPONENT_CODE");

                entity.Property(e => e.ComponentName)
                    .HasMaxLength(45)
                    .HasColumnName("COMPONENT_NAME");

                entity.Property(e => e.ComponentRoundingOff)
                    .HasMaxLength(45)
                    .HasColumnName("COMPONENT_ROUNDING_OFF");

                entity.Property(e => e.ComponentRoundingValue)
                    .HasMaxLength(45)
                    .HasColumnName("COMPONENT_ROUNDING_VALUE");

                entity.Property(e => e.ComponentType)
                    .HasMaxLength(45)
                    .HasColumnName("COMPONENT_TYPE");

                entity.Property(e => e.ComponentsequenceOrder)
                    .HasMaxLength(45)
                    .HasColumnName("COMPONENTSEQUENCE_ORDER");

                entity.Property(e => e.EsiDeduction).HasColumnName("ESI_DEDUCTION");

                entity.Property(e => e.EsiEligibility).HasColumnName("ESI_ELIGIBILITY");

                entity.Property(e => e.ExemptionLimit).HasColumnName("EXEMPTION_LIMIT");

                entity.Property(e => e.FormulaAction)
                    .HasMaxLength(45)
                    .HasColumnName("FORMULA_ACTION");

                entity.Property(e => e.FormulaFixedValue).HasColumnName("FORMULA_FIXED_VALUE");

                entity.Property(e => e.FormulaOpen)
                    .HasMaxLength(45)
                    .HasColumnName("FORMULA_OPEN");

                entity.Property(e => e.FormulaType)
                    .HasMaxLength(45)
                    .HasColumnName("FORMULA_TYPE");

                entity.Property(e => e.FormulaTypes)
                    .HasMaxLength(45)
                    .HasColumnName("FORMULA_TYPES");

                entity.Property(e => e.Gratuity).HasColumnName("GRATUITY");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LeaveEncashment).HasColumnName("LEAVE_ENCASHMENT");

                entity.Property(e => e.LopApplicabilty).HasColumnName("LOP_APPLICABILTY");

                entity.Property(e => e.NoticePayPayment).HasColumnName("NOTICE_PAY_PAYMENT");

                entity.Property(e => e.NoticePayRecovery).HasColumnName("NOTICE_PAY_RECOVERY");

                entity.Property(e => e.PaymentFrequency)
                    .HasMaxLength(45)
                    .HasColumnName("PAYMENT_FREQUENCY");

                entity.Property(e => e.PerquisitesApplicable)
                    .HasMaxLength(45)
                    .HasColumnName("PERQUISITES_APPLICABLE");

                entity.Property(e => e.PfEligibility).HasColumnName("PF_ELIGIBILITY");

                entity.Property(e => e.Prorate).HasColumnName("PRORATE");

                entity.Property(e => e.PtEligibility).HasColumnName("PT_ELIGIBILITY");

                entity.Property(e => e.ReimbursementProcedureAnnual).HasColumnName("REIMBURSEMENT_PROCEDURE_ANNUAL");

                entity.Property(e => e.ReimbursementSetting).HasColumnName("REIMBURSEMENT_SETTING");

                entity.Property(e => e.ResultFormula)
                    .HasMaxLength(45)
                    .HasColumnName("RESULT_FORMULA");

                entity.Property(e => e.StatutoryBonus).HasColumnName("STATUTORY_BONUS");

                entity.Property(e => e.Taxable)
                    .HasMaxLength(45)
                    .HasColumnName("TAXABLE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.UnclaimedAmount).HasColumnName("UNCLAIMED_AMOUNT");

                entity.Property(e => e.UnprocessedBillStatus).HasColumnName("UNPROCESSED_BILL_STATUS");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");
            });

            modelBuilder.Entity<ComponentMasCreation>(entity =>
            {
                entity.HasKey(e => e.IntCompSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_creation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_crt_company_id");

                entity.Property(e => e.IntCompSeqId)
                    .HasColumnName("int_comp_seq_id")
                    .HasComment("primary key of component_mas_creation");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from company_detail_master");

                entity.Property(e => e.IntRangeFrom)
                    .HasColumnName("int_range_from")
                    .HasComment("Minimun Money Range");

                entity.Property(e => e.IntRangeTo)
                    .HasColumnName("int_range_to")
                    .HasComment("Maximun money range");

                entity.Property(e => e.IntSequenceNo).HasColumnName("int_sequence_no");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchBooleanType)
                    .HasMaxLength(1)
                    .HasColumnName("vch_boolean_type")
                    .HasComment("D - Default,C - Customize");

                entity.Property(e => e.VchCalcMode)
                    .HasMaxLength(8)
                    .HasColumnName("vch_calc_mode");

                entity.Property(e => e.VchCompId)
                    .HasMaxLength(10)
                    .HasColumnName("vch_comp_id")
                    .HasComment("Unique identification for each component");

                entity.Property(e => e.VchCompensationPlan)
                    .HasMaxLength(1)
                    .HasColumnName("vch_compensation_plan")
                    .HasComment("Y - Yes,N - No");

                entity.Property(e => e.VchComponentName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_component_name")
                    .HasComment("Store Component Name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchCtcType)
                    .HasMaxLength(1)
                    .HasColumnName("vch_ctc_type")
                    .HasComment("C-Ctc,N-Non-ctc");

                entity.Property(e => e.VchCurrency)
                    .HasMaxLength(50)
                    .HasColumnName("vch_currency")
                    .HasComment("It will stored currency type");

                entity.Property(e => e.VchDataType)
                    .HasMaxLength(1)
                    .HasColumnName("vch_data_type")
                    .HasComment("N-Number,L-List,D-Date,C-Character,B-Boolean");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_description")
                    .HasComment("To describe the component");

                entity.Property(e => e.VchFormulaText)
                    .HasColumnType("text")
                    .HasColumnName("vch_formula_text");

                entity.Property(e => e.VchFormulaType)
                    .HasMaxLength(1)
                    .HasColumnName("vch_formula_type")
                    .HasComment("O - Open,S - Standard");

                entity.Property(e => e.VchGrossProcessFormula)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_gross_process_formula");

                entity.Property(e => e.VchNature)
                    .HasMaxLength(1)
                    .HasColumnName("vch_nature")
                    .HasComment("E-Earnings,D-Detuctions,O-Others");

                entity.Property(e => e.VchSysShortname)
                    .HasMaxLength(50)
                    .HasColumnName("vch_sys_shortname");

                entity.Property(e => e.VchType)
                    .HasMaxLength(4)
                    .HasColumnName("vch_type")
                    .HasComment("F-fixed,V-variable,P-Perquisites,REIM-Reimburstment,RET-Retrials");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchYtdValidations)
                    .HasMaxLength(1)
                    .HasColumnName("vch_ytd_validations")
                    .HasComment("Y - Yes,N - No");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentMasCreations)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_crt_company_id");
            });

            modelBuilder.Entity<ComponentMasCriteriaDesigAssign>(entity =>
            {
                entity.HasKey(e => e.IntCriteriaDesignId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_criteria_desig_assign");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompCreteriaSeqId, "fk_criteria_design_id");

                entity.Property(e => e.IntCriteriaDesignId).HasColumnName("int_criteria_design_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompCreteriaSeqId).HasColumnName("int_comp_creteria_seq_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntDepartmentSeqId).HasColumnName("int_department_seq_id");

                entity.Property(e => e.IntDesignationSeqId).HasColumnName("int_designation_seq_id");

                entity.Property(e => e.IntLocationSeqId).HasColumnName("int_location_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDesignationName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_designation_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompCreteriaSeq)
                    .WithMany(p => p.ComponentMasCriteriaDesigAssigns)
                    .HasForeignKey(d => d.IntCompCreteriaSeqId)
                    .HasConstraintName("fk_criteria_design_id");
            });

            modelBuilder.Entity<ComponentMasCriteriaOperator>(entity =>
            {
                entity.HasKey(e => e.IntOperatorId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_criteria_operator");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntOperatorId).HasColumnName("int_operator_id");

                entity.Property(e => e.VchInput)
                    .HasMaxLength(2)
                    .HasColumnName("vch_input");

                entity.Property(e => e.VchOperator)
                    .HasMaxLength(100)
                    .HasColumnName("vch_operator");

                entity.Property(e => e.VchOperatorName)
                    .HasMaxLength(65)
                    .HasColumnName("vch_operator_name");
            });

            modelBuilder.Entity<ComponentMasCriteriaPatternAssign>(entity =>
            {
                entity.HasKey(e => e.IntCriteriaPatternId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_criteria_pattern_assign");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompCreteriaSeqId, "fk_criteria_pattern_id");

                entity.Property(e => e.IntCriteriaPatternId).HasColumnName("int_criteria_pattern_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompCreteriaSeqId).HasColumnName("int_comp_creteria_seq_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntOrgId).HasColumnName("int_org_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchAttributeName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_attribute_name");

                entity.Property(e => e.VchAttributeValue)
                    .HasMaxLength(4000)
                    .HasColumnName("vch_attribute_value");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchOperator)
                    .HasMaxLength(50)
                    .HasColumnName("vch_operator");

                entity.Property(e => e.VchPattern)
                    .HasMaxLength(4100)
                    .HasColumnName("vch_pattern");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompCreteriaSeq)
                    .WithMany(p => p.ComponentMasCriteriaPatternAssigns)
                    .HasForeignKey(d => d.IntCompCreteriaSeqId)
                    .HasConstraintName("fk_criteria_pattern_id");
            });

            modelBuilder.Entity<ComponentMasCriterion>(entity =>
            {
                entity.HasKey(e => e.IntCompCreteriaSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_criteria");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_m_crite_company_id");

                entity.Property(e => e.IntCompCreteriaSeqId).HasColumnName("int_comp_creteria_seq_id");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("REFERENCE FROM company_detail_master");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchAttributeName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_attribute_name");

                entity.Property(e => e.VchAttributeValues)
                    .HasMaxLength(4000)
                    .HasColumnName("vch_attribute_values");

                entity.Property(e => e.VchComponentAssign)
                    .HasMaxLength(3)
                    .HasColumnName("vch_component_assign");

                entity.Property(e => e.VchComponentNames)
                    .HasColumnType("text")
                    .HasColumnName("vch_component_names");

                entity.Property(e => e.VchComponentValueAssign)
                    .HasMaxLength(3)
                    .HasColumnName("vch_component_value_assign");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchCreationType)
                    .HasMaxLength(50)
                    .HasColumnName("vch_creation_type");

                entity.Property(e => e.VchCriteriaName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_criteria_name");

                entity.Property(e => e.VchProcessed)
                    .HasMaxLength(3)
                    .HasColumnName("vch_processed");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("vch_updated_time");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentMasCriteria)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_m_crite_company_id");
            });

            modelBuilder.Entity<ComponentMasCtcMaster>(entity =>
            {
                entity.HasKey(e => e.IntComMCtcMasId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_ctc_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_company_seq_id");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_component_ctc_seq_id");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.DouCtcAmount)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_ctc_amount");

                entity.Property(e => e.DtEffectiveDate).HasColumnName("dt_effective_date");

                entity.Property(e => e.DtSalUpdatedDate).HasColumnName("dt_sal_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchCtcModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_ctc_modified");

                entity.Property(e => e.VchMoveView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_move_view");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentMasCtcMasters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_company_seq_id");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.ComponentMasCtcMasters)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_component_ctc_seq_id");
            });

            modelBuilder.Entity<ComponentMasCtcMasterTmp>(entity =>
            {
                entity.HasKey(e => e.IntComMCtcMasId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_ctc_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_ctc_mas_tmp_compid");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_comp_ctc_mas_tmp_empid");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.DouCtcAmount)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_ctc_amount");

                entity.Property(e => e.DtEffectiveDate).HasColumnName("dt_effective_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchCtcModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_ctc_modified");

                entity.Property(e => e.VchMoveView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_move_view");

                entity.Property(e => e.VchSalProcessed)
                    .HasMaxLength(3)
                    .HasColumnName("vch_sal_processed");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentMasCtcMasterTmps)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_ctc_mas_tmp_compid");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.ComponentMasCtcMasterTmps)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_comp_ctc_mas_tmp_empid");
            });

            modelBuilder.Entity<ComponentMasIdGenerateHistory>(entity =>
            {
                entity.HasKey(e => e.IntComIdGenId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_id_generate_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_id_gen_company_id");

                entity.Property(e => e.IntComIdGenId).HasColumnName("int_com_id_gen_id");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("REFERENCE FROM company_detail_master");

                entity.Property(e => e.VchLastGenId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_last_gen_id")
                    .HasComment("FOR store last seq id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentMasIdGenerateHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_id_gen_company_id");
            });

            modelBuilder.Entity<ComponentMasOrgAttribute>(entity =>
            {
                entity.HasKey(e => e.IntAttributeId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_org_attribute");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntAttributeId).HasColumnName("int_attribute_id");

                entity.Property(e => e.VchAttributeName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_attribute_name");

                entity.Property(e => e.VchHqlQuery)
                    .HasMaxLength(400)
                    .HasColumnName("vch_hql_query");

                entity.Property(e => e.VchNativeQuery)
                    .HasMaxLength(4000)
                    .HasColumnName("vch_native_query");

                entity.Property(e => e.VchOrgFieldName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_org_field_name");

                entity.Property(e => e.VchSeqIdFieldName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_seq_id_field_name");

                entity.Property(e => e.VchSeqIdInEmployee)
                    .HasMaxLength(64)
                    .HasColumnName("vch_seq_id_in_employee");

                entity.Property(e => e.VchTableName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_table_name");
            });

            modelBuilder.Entity<ComponentMasUdfMaster>(entity =>
            {
                entity.HasKey(e => e.IntUdfSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_udf_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntUdfSeqId).HasColumnName("int_udf_seq_id");

                entity.Property(e => e.VchFunctionName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_function_name");

                entity.Property(e => e.VchSysFunctionName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_sys_function_name");
            });

            modelBuilder.Entity<ComponentTransCriteriaComponentAssign>(entity =>
            {
                entity.HasKey(e => e.IntCompCretSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_criteria_component_assign");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_t_comp_ass_company_id");

                entity.HasIndex(e => e.IntCompCreteriaSeqId, "fk_comp_t_cret_comp_assi_crt_sq_id");

                entity.HasIndex(e => e.IntCompSeqId, "fk_comp_t_crit_comp_assi_comp_seq_id");

                entity.Property(e => e.IntCompCretSeqId).HasColumnName("int_comp_cret_seq_id");

                entity.Property(e => e.IntCompCreteriaSeqId).HasColumnName("int_comp_creteria_seq_id");

                entity.Property(e => e.IntCompSeqId).HasColumnName("int_comp_seq_id");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("REFERENCE FROM company_detail_master");

                entity.Property(e => e.IntCompoAssign).HasColumnName("int_compo_assign");

                entity.Property(e => e.IntSeqId)
                    .HasColumnName("int_seq_id")
                    .HasComment("Store sequence numbers for display");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchComponentName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_component_name")
                    .HasComment("For Storing component name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchGrossProcessFormula)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_gross_process_formula");

                entity.Property(e => e.VchShowPayslip)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_payslip");

                entity.Property(e => e.VchShowView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_view");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchValue)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_value")
                    .HasComment("Store Component Values");

                entity.HasOne(d => d.IntCompCreteriaSeq)
                    .WithMany(p => p.ComponentTransCriteriaComponentAssigns)
                    .HasForeignKey(d => d.IntCompCreteriaSeqId)
                    .HasConstraintName("fk_comp_t_cret_comp_assi_crt_sq_id");

                entity.HasOne(d => d.IntCompSeq)
                    .WithMany(p => p.ComponentTransCriteriaComponentAssigns)
                    .HasForeignKey(d => d.IntCompSeqId)
                    .HasConstraintName("fk_comp_t_crit_comp_assi_comp_seq_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentTransCriteriaComponentAssigns)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_t_comp_ass_company_id");
            });

            modelBuilder.Entity<ComponentTransEmpSalMaster>(entity =>
            {
                entity.HasKey(e => e.IntCompSalMasSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_sal_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntCompSalMasSeqId).HasColumnName("int_comp_sal_mas_seq_id");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ComponentTransEmpSalMasterTmp>(entity =>
            {
                entity.HasKey(e => e.IntCompSalMasId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_sal_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntCompSalMasId).HasColumnName("int_comp_sal_mas_id");

                entity.Property(e => e.DtDateValue).HasColumnName("dt_date_value");

                entity.Property(e => e.DtEffectiveDate).HasColumnName("dt_effective_date");

                entity.Property(e => e.IntCompSeqId)
                    .HasColumnName("int_comp_seq_id")
                    .HasComment("Reference from component_mas_creation");

                entity.Property(e => e.IntCompanySeqId).HasColumnName("int_company_seq_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNumValue).HasColumnName("int_num_value");

                entity.Property(e => e.IntProcessSeqNo).HasColumnName("int_process_seq_no");

                entity.Property(e => e.IntRowIndex).HasColumnName("int_row_index");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCompShortName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_comp_short_name");

                entity.Property(e => e.VchComponentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_component_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmpCode)
                    .HasMaxLength(45)
                    .HasColumnName("vch_emp_code");

                entity.Property(e => e.VchShowPayslip)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_payslip");

                entity.Property(e => e.VchShowView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_view");

                entity.Property(e => e.VchStrValue)
                    .HasMaxLength(255)
                    .HasColumnName("vch_str_value");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchValueAssiged)
                    .HasMaxLength(9)
                    .HasColumnName("vch_value_assiged");
            });

            modelBuilder.Entity<ComponentTransEmpSalMasterValue>(entity =>
            {
                entity.HasKey(e => e.IntCompSalMasValId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_sal_master_values");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompSeqId, "fk_com_t_empsal_comp_seq_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_com_t_empsal_company_seq_id");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_com_t_empsal_emp_seq_id");

                entity.HasIndex(e => e.IntComMCtcMasId, "fk_comp_t_sal_mas_values_ctcmasid");

                entity.Property(e => e.IntCompSalMasValId).HasColumnName("int_comp_sal_mas_val_id");

                entity.Property(e => e.DtDateValue).HasColumnName("dt_date_value");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.IntCompSeqId)
                    .HasColumnName("int_comp_seq_id")
                    .HasComment("Reference from component_mas_creation");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNumValue).HasColumnName("int_num_value");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCompShortName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_comp_short_name");

                entity.Property(e => e.VchComponentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_component_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchShowPayslip)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_payslip");

                entity.Property(e => e.VchShowView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_view");

                entity.Property(e => e.VchStrValue)
                    .HasMaxLength(255)
                    .HasColumnName("vch_str_value");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchValueAssiged)
                    .HasMaxLength(9)
                    .HasColumnName("vch_value_assiged");

                entity.HasOne(d => d.IntComMCtcMas)
                    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                    .HasForeignKey(d => d.IntComMCtcMasId)
                    .HasConstraintName("fk_comp_t_sal_mas_values_ctcmasid");

                entity.HasOne(d => d.IntCompSeq)
                    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                    .HasForeignKey(d => d.IntCompSeqId)
                    .HasConstraintName("fk_com_t_empsal_comp_seq_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_com_t_empsal_company_seq_id");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_com_t_empsal_emp_seq_id");
            });

            modelBuilder.Entity<ComponentTransEmpSalaryHistory>(entity =>
            {
                entity.HasKey(e => e.IntEmpSalHisId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_salary_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_t_emp_sal_his_companyid");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_comp_t_emp_sal_his_empseqid");

                entity.Property(e => e.IntEmpSalHisId).HasColumnName("int_emp_sal_his_id");

                entity.Property(e => e.DouCtcAmount)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_ctc_amount");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(45)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentTransEmpSalaryHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_t_emp_sal_his_companyid");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.ComponentTransEmpSalaryHistories)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_comp_t_emp_sal_his_empseqid");
            });

            modelBuilder.Entity<ComponentTransEmpSalaryValuesHistory>(entity =>
            {
                entity.HasKey(e => e.IntEmpSalHisValId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_salary_values_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompSeqId, "fk_comp_t_emp_sal_his_comseqid");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_comp_t_emp_sal_his_empseqid_idx");

                entity.HasIndex(e => e.IntEmpSalHisId, "fk_comp_t_emp_sal_his_salhisid");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_t_emp_sala_his_compseqid");

                entity.Property(e => e.IntEmpSalHisValId).HasColumnName("int_emp_sal_his_val_id");

                entity.Property(e => e.DtDateValue).HasColumnName("dt_date_value");

                entity.Property(e => e.IntCompSeqId)
                    .HasColumnName("int_comp_seq_id")
                    .HasComment("Reference from component_mas_creation");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpSalHisId).HasColumnName("int_emp_sal_his_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNumValue).HasColumnName("int_num_value");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchComponentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_component_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status")
                    .HasComment("H-history,P-Previous");

                entity.Property(e => e.VchStrValue)
                    .HasMaxLength(255)
                    .HasColumnName("vch_str_value");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchValueAssiged)
                    .HasMaxLength(9)
                    .HasColumnName("vch_value_assiged");

                entity.HasOne(d => d.IntCompSeq)
                    .WithMany(p => p.ComponentTransEmpSalaryValuesHistories)
                    .HasForeignKey(d => d.IntCompSeqId)
                    .HasConstraintName("fk_comp_t_emp_sal_his_comseqid");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ComponentTransEmpSalaryValuesHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_t_emp_sala_his_compseqid");

                entity.HasOne(d => d.IntEmpSalHis)
                    .WithMany(p => p.ComponentTransEmpSalaryValuesHistories)
                    .HasForeignKey(d => d.IntEmpSalHisId)
                    .HasConstraintName("fk_comp_t_emp_sal_his_salhisid");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.ComponentTransEmpSalaryValuesHistories)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_comp_t_emp_sala_his_empseqid");
            });

            modelBuilder.Entity<ConfigMasClientAdmRight>(entity =>
            {
                entity.HasKey(e => e.IntClientAdmRightsId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_client_adm_rights");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "fk_con_m_cli_ad_rights_clientid");

                entity.Property(e => e.IntClientAdmRightsId).HasColumnName("int_client_adm_rights_id");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDelete)
                    .HasMaxLength(3)
                    .HasColumnName("vch_delete");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchOverallRights)
                    .HasMaxLength(3)
                    .HasColumnName("vch_overall_rights");

                entity.Property(e => e.VchRead)
                    .HasMaxLength(3)
                    .HasColumnName("vch_read");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchWrite)
                    .HasMaxLength(3)
                    .HasColumnName("vch_write");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.ConfigMasClientAdmRights)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("fk_con_m_cli_ad_rights_clientid");
            });

            modelBuilder.Entity<ConfigMasClientCreation>(entity =>
            {
                entity.HasKey(e => e.IntClientId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_client_creation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntCompanyCount).HasColumnName("int_company_count");

                entity.Property(e => e.IntConfEmailAlertBeforeDay).HasColumnName("int_conf_email_alert_before_day");

                entity.Property(e => e.IntConfExtendedTimes).HasColumnName("int_conf_extended_times");

                entity.Property(e => e.IntConfInitialDueMonths).HasColumnName("int_conf_initial_due_months");

                entity.Property(e => e.IntConfTotalProbationMonths).HasColumnName("int_conf_total_probation_months");

                entity.Property(e => e.IntCreatedCompanies).HasColumnName("int_created_companies");

                entity.Property(e => e.IntPwdDuration).HasColumnName("int_pwd_duration");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchClientCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_client_code");

                entity.Property(e => e.VchClientName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_client_name");

                entity.Property(e => e.VchConfAssSettings)
                    .HasMaxLength(3)
                    .HasColumnName("vch_conf_ass_settings");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDbKey)
                    .HasMaxLength(30)
                    .HasColumnName("vch_db_key");

                entity.Property(e => e.VchDisplayName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_display_name");

                entity.Property(e => e.VchEmailid)
                    .HasMaxLength(80)
                    .HasColumnName("vch_emailid");

                entity.Property(e => e.VchEnableClientAdmin)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable_client_admin");

                entity.Property(e => e.VchEnableClientEmployee)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable_client_employee");

                entity.Property(e => e.VchEnableClientUser)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable_client_user");

                entity.Property(e => e.VchEnableEmail)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable_email");

                entity.Property(e => e.VchEnableSms)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable_sms");

                entity.Property(e => e.VchEnableTwoFactor)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable_two_factor");

                entity.Property(e => e.VchLetterGeneration)
                    .HasMaxLength(3)
                    .HasColumnName("vch_letter_generation");

                entity.Property(e => e.VchMailPassword)
                    .HasMaxLength(15)
                    .HasColumnName("vch_mail_password");

                entity.Property(e => e.VchMobileno)
                    .HasMaxLength(10)
                    .HasColumnName("vch_mobileno");

                entity.Property(e => e.VchModuleAssign)
                    .HasMaxLength(3)
                    .HasColumnName("vch_module_assign");

                entity.Property(e => e.VchModuleAssignedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_assigned_by");

                entity.Property(e => e.VchModuleNames)
                    .HasColumnType("text")
                    .HasColumnName("vch_module_names");

                entity.Property(e => e.VchPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_password");

                entity.Property(e => e.VchPwdConfig)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_config");

                entity.Property(e => e.VchReports)
                    .HasMaxLength(3)
                    .HasColumnName("vch_reports");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_role_name");

                entity.Property(e => e.VchSchemaActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_schema_active");

                entity.Property(e => e.VchSchemaAllowed)
                    .HasMaxLength(3)
                    .HasColumnName("vch_schema_allowed");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchSchemaName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_name");

                entity.Property(e => e.VchSenderEmail)
                    .HasMaxLength(80)
                    .HasColumnName("vch_sender_email");

                entity.Property(e => e.VchSenderEmailPword)
                    .HasMaxLength(100)
                    .HasColumnName("vch_sender_email_pword");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ConfigMasClientModulesGrpRole>(entity =>
            {
                entity.HasKey(e => e.IntClientModuleRoleId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_client_modules_grp_roles");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntClientModuleRoleId).HasColumnName("int_client_module_role_id");

                entity.Property(e => e.IntClientModuleGrpId).HasColumnName("int_client_module_grp_id");

                entity.Property(e => e.IntExitClearanceOrder).HasColumnName("int_exit_clearance_order");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(60)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(60)
                    .HasColumnName("vch_role_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ConfigMasDynamicEmpMasterField>(entity =>
            {
                entity.HasKey(e => e.IntDynamicEmpMasId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_dynamic_emp_master_fields");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntDynamicEmpMasId).HasColumnName("int_dynamic_emp_mas_id");

                entity.Property(e => e.TsCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("ts_created_by");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(500)
                    .HasColumnName("vch_role_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchSchemaUsed)
                    .HasMaxLength(45)
                    .HasColumnName("vch_schema_used");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ConfigMasEmailSetting>(entity =>
            {
                entity.HasKey(e => e.IntEmailConfigId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_email_settings");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmailConfigId).HasColumnName("int_email_config_id");

                entity.Property(e => e.IntPort).HasColumnName("int_port");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchEnable)
                    .HasMaxLength(3)
                    .HasColumnName("vch_enable");

                entity.Property(e => e.VchHost)
                    .HasMaxLength(500)
                    .HasColumnName("vch_host");

                entity.Property(e => e.VchPassword)
                    .HasMaxLength(100)
                    .HasColumnName("vch_password");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchUsername)
                    .HasMaxLength(100)
                    .HasColumnName("vch_username");
            });

            modelBuilder.Entity<ConfigMasEmpmasNameChange>(entity =>
            {
                entity.HasKey(e => e.IntEmpmasNameChId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_empmas_name_change");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmpmasNameChId).HasColumnName("int_empmas_name_ch_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchBranchName)
                    .HasMaxLength(45)
                    .HasColumnName("vch_branch_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDepartmentName)
                    .HasMaxLength(45)
                    .HasColumnName("vch_department_name");

                entity.Property(e => e.VchDesignationName)
                    .HasMaxLength(45)
                    .HasColumnName("vch_designation_name");

                entity.Property(e => e.VchDivisionName)
                    .HasMaxLength(45)
                    .HasColumnName("vch_division_name");

                entity.Property(e => e.VchGradeName)
                    .HasMaxLength(45)
                    .HasColumnName("vch_grade_name");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(45)
                    .HasColumnName("vch_location_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ConfigMasTmiAdmClientAssign>(entity =>
            {
                entity.HasKey(e => e.IntClientAssignId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_adm_client_assign");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "int_client_id");

                entity.HasIndex(e => e.IntTmiAdmId, "int_tmi_adm_id");

                entity.Property(e => e.IntClientAssignId).HasColumnName("int_client_assign_id");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntTmiAdmId).HasColumnName("int_tmi_adm_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.ConfigMasTmiAdmClientAssigns)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("fk_con_m_tmi_adm_cli_ass_clientid");

                entity.HasOne(d => d.IntTmiAdm)
                    .WithMany(p => p.ConfigMasTmiAdmClientAssigns)
                    .HasForeignKey(d => d.IntTmiAdmId)
                    .HasConstraintName("fk_con_m_tmi_adm_cli_ass_tmiadmid");
            });

            modelBuilder.Entity<ConfigMasTmiAdmnCreation>(entity =>
            {
                entity.HasKey(e => e.IntTmiAdmId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_admn_creation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTmiAdmId).HasColumnName("int_tmi_adm_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsPwdChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_pwd_change_date");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchClientAssign)
                    .HasMaxLength(3)
                    .HasColumnName("vch_client_assign");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchOldPwd1)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd1");

                entity.Property(e => e.VchOldPwd2)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd2");

                entity.Property(e => e.VchPwdChangeReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_change_req");

                entity.Property(e => e.VchPwdExpired)
                    .HasMaxLength(2)
                    .HasColumnName("vch_pwd_expired");

                entity.Property(e => e.VchPwdResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pwd_reset_key");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTmiAdmClients)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_tmi_adm_clients");

                entity.Property(e => e.VchTmiAdmCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_tmi_adm_code");

                entity.Property(e => e.VchTmiAdmEmpCode)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmi_adm_emp_code");

                entity.Property(e => e.VchTmiAdmName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmi_adm_name");

                entity.Property(e => e.VchTmiAdmPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmi_adm_password");

                entity.Property(e => e.VchTmiEmailid)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmi_emailid");

                entity.Property(e => e.VchTmiPhoneno)
                    .HasMaxLength(15)
                    .HasColumnName("vch_tmi_phoneno");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ConfigMasTmiClient>(entity =>
            {
                entity.HasKey(e => e.IntTmiClientId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_clients");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "fk_con_mas_tmi_clients_client_id");

                entity.HasIndex(e => e.IntTmiUserId, "fk_int_tmi_user_id");

                entity.Property(e => e.IntTmiClientId).HasColumnName("int_tmi_client_id");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntTmiUserId).HasColumnName("int_tmi_user_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntClient)
                    .WithMany(p => p.ConfigMasTmiClients)
                    .HasForeignKey(d => d.IntClientId)
                    .HasConstraintName("fk_con_mas_tmi_clients_client_id");

                entity.HasOne(d => d.IntTmiUser)
                    .WithMany(p => p.ConfigMasTmiClients)
                    .HasForeignKey(d => d.IntTmiUserId)
                    .HasConstraintName("fk_con_mas_tmi_clients_tmi_user_id");
            });

            modelBuilder.Entity<ConfigMasTmiClientCompany>(entity =>
            {
                entity.HasKey(e => e.IntTmiClientCompId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_client_companies");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_con_m_tmi_cli_comp_company_id");

                entity.HasIndex(e => e.IntTmiUserId, "fk_con_mas_tmiclient_com_tmiuserid");

                entity.HasIndex(e => e.IntTmiClientId, "fk_int_tmi_client_id");

                entity.Property(e => e.IntTmiClientCompId).HasColumnName("int_tmi_client_comp_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntTmiClientId).HasColumnName("int_tmi_client_id");

                entity.Property(e => e.IntTmiUserId).HasColumnName("int_tmi_user_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ConfigMasTmiClientCompanyIntCompanies)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_con_m_tmi_cli_comp_company_id");

                entity.HasOne(d => d.IntTmiClient)
                    .WithMany(p => p.ConfigMasTmiClientCompanies)
                    .HasForeignKey(d => d.IntTmiClientId)
                    .HasConstraintName("fk_con_m_tmi_cli_comp_tmi_client_id");

                entity.HasOne(d => d.IntTmiUser)
                    .WithMany(p => p.ConfigMasTmiClientCompanyIntTmiUsers)
                    .HasForeignKey(d => d.IntTmiUserId)
                    .HasConstraintName("fk_con_mas_tmiclient_com_tmiuserid");
            });

            modelBuilder.Entity<ConfigMasTmiSuperAdminMaster>(entity =>
            {
                entity.HasKey(e => e.IntTmisaId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_super_admin_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTmisaId).HasColumnName("int_tmisa_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTmisaCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_tmisa_code");

                entity.Property(e => e.VchTmisaEmailid)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmisa_emailid");

                entity.Property(e => e.VchTmisaEmpCode)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmisa_emp_code");

                entity.Property(e => e.VchTmisaName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmisa_name");

                entity.Property(e => e.VchTmisaPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmisa_password");

                entity.Property(e => e.VchTmisaPhoneno)
                    .HasMaxLength(15)
                    .HasColumnName("vch_tmisa_phoneno");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ConfigMasTmiUserCreation>(entity =>
            {
                entity.HasKey(e => e.IntTmiUserId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_user_creation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTmiUserId).HasColumnName("int_tmi_user_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsPwdChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_pwd_change_date");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCompanies)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_companies");

                entity.Property(e => e.VchCompanyAssign)
                    .HasMaxLength(3)
                    .HasColumnName("vch_company_assign");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchOldPwd1)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd1");

                entity.Property(e => e.VchOldPwd2)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd2");

                entity.Property(e => e.VchPwdChangeReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_change_req");

                entity.Property(e => e.VchPwdExpired)
                    .HasMaxLength(2)
                    .HasColumnName("vch_pwd_expired");

                entity.Property(e => e.VchPwdResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pwd_reset_key");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTmiEmailid)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmi_emailid");

                entity.Property(e => e.VchTmiPhoneno)
                    .HasMaxLength(15)
                    .HasColumnName("vch_tmi_phoneno");

                entity.Property(e => e.VchTmiUserCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_tmi_user_code");

                entity.Property(e => e.VchTmiUserEmpCode)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmi_user_emp_code");

                entity.Property(e => e.VchTmiUserName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmi_user_name");

                entity.Property(e => e.VchTmiUserPword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmi_user_pword");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ConfigMasTmiUserRight>(entity =>
            {
                entity.HasKey(e => e.IntTmiUserRightsId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_user_rights");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntTmiUserId, "fk_con_m_tmi_use_rights_tmiuserid");

                entity.Property(e => e.IntTmiUserRightsId).HasColumnName("int_tmi_user_rights_id");

                entity.Property(e => e.IntTmiUserId).HasColumnName("int_tmi_user_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDelete)
                    .HasMaxLength(3)
                    .HasColumnName("vch_delete");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchOverallRights)
                    .HasMaxLength(3)
                    .HasColumnName("vch_overall_rights");

                entity.Property(e => e.VchRead)
                    .HasMaxLength(3)
                    .HasColumnName("vch_read");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchWrite)
                    .HasMaxLength(3)
                    .HasColumnName("vch_write");

                entity.HasOne(d => d.IntTmiUser)
                    .WithMany(p => p.ConfigMasTmiUserRights)
                    .HasForeignKey(d => d.IntTmiUserId)
                    .HasConstraintName("fk_con_m_tmi_use_rights_tmiuserid");
            });

            modelBuilder.Entity<ConfigQuicklinkEmployee>(entity =>
            {
                entity.HasKey(e => e.IntEmpQlSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("config_quicklink_employee");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpSeqId, "fk_emp_seq_id");

                entity.Property(e => e.IntEmpQlSeqId).HasColumnName("int_emp_ql_seq_id");

                entity.Property(e => e.IntEmpSeqId).HasColumnName("int_emp_seq_id");

                entity.Property(e => e.VchQlName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_ql_name");

                entity.Property(e => e.VchQuickLinkUrl)
                    .HasMaxLength(50)
                    .HasColumnName("vch_quick_link_url");

                entity.HasOne(d => d.IntEmpSeq)
                    .WithMany(p => p.ConfigQuicklinkEmployees)
                    .HasForeignKey(d => d.IntEmpSeqId)
                    .HasConstraintName("fk_emp_seq_id");
            });

            modelBuilder.Entity<ConfigTmiAdminNoHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("config_tmi_admin_no_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchLastId)
                    .HasMaxLength(40)
                    .HasColumnName("vch_last_id");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<ConfigTmiUserClientsView>(entity =>
            {
                entity.HasKey(e => e.IntTmiClientViewId)
                    .HasName("PRIMARY");

                entity.ToTable("config_tmi_user_clients_view");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTmiClientViewId).HasColumnName("int_tmi_client_view_id");

                entity.Property(e => e.IntTmiUserId).HasColumnName("int_tmi_user_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchAssignedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_assigned_by");

                entity.Property(e => e.VchClientCompanies)
                    .HasColumnType("text")
                    .HasColumnName("vch_client_companies");

                entity.Property(e => e.VchClientNames)
                    .HasMaxLength(3000)
                    .HasColumnName("vch_client_names");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTmiEmpCode)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmi_emp_code");

                entity.Property(e => e.VchTmiUserCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_tmi_user_code");

                entity.Property(e => e.VchTmiUserName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmi_user_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ConfigTmiUserNoHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("config_tmi_user_no_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchLastId)
                    .HasMaxLength(40)
                    .HasColumnName("vch_last_id");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<ConfirmationAssessmentAn>(entity =>
            {
                entity.HasKey(e => e.IntAnsId)
                    .HasName("PRIMARY");

                entity.ToTable("confirmation_assessment_ans");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_conf_ans_companyid");

                entity.HasIndex(e => e.ExitTemplateItemId, "fk_conf_ans_template_items");

                entity.HasIndex(e => e.ExitTemplateId, "fk_conf_template");

                entity.HasIndex(e => e.IntConfirmReqId, "fk_int_confirm_req_id");

                entity.Property(e => e.IntAnsId).HasColumnName("INT_ANS_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.ExitTemplateId).HasColumnName("exit_template_id");

                entity.Property(e => e.ExitTemplateItemId).HasColumnName("exit_template_item_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntConfirmReqId).HasColumnName("int_confirm_req_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchAnswer)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_ANSWER");

                entity.Property(e => e.VchAnsweredStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_answered_status");

                entity.Property(e => e.VchComments)
                    .HasMaxLength(1000)
                    .HasColumnName("VCH_COMMENTS");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchQuesType)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_QUES_TYPE");

                entity.Property(e => e.VchQuestDesc)
                    .HasMaxLength(166)
                    .HasColumnName("VCH_QUEST_DESC");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.ExitTemplate)
                    .WithMany(p => p.ConfirmationAssessmentAns)
                    .HasForeignKey(d => d.ExitTemplateId)
                    .HasConstraintName("fk_conf_template");


                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ConfirmationAssessmentAns)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_conf_ansitem_companyid");

                entity.HasOne(d => d.IntConfirmReq)
                    .WithMany(p => p.ConfirmationAssessmentAns)
                    .HasForeignKey(d => d.IntConfirmReqId)
                    .HasConstraintName("fk_int_confirm_req_id");
            });

            modelBuilder.Entity<ConfirmationAssessmentQuestion>(entity =>
            {
                entity.HasKey(e => e.IntConfirmasseQuesId)
                    .HasName("PRIMARY");

                entity.ToTable("confirmation_assessment_questions");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntCompanyId, "fk_conf_as_que_company_id_idx");

                entity.HasIndex(e => e.IntConfirmReqId, "fk_confassquestion_req_id");

                entity.Property(e => e.IntConfirmasseQuesId).HasColumnName("int_confirmasse_ques_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntConfirmReqId)
                    .HasColumnName("int_confirm_req_id")
                    .HasComment("reference from confirmation_assessment_request(int_confirm_req_id)");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchAnswer)
                    .HasMaxLength(3)
                    .HasColumnName("vch_answer");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchQuestion)
                    .HasMaxLength(5000)
                    .HasColumnName("vch_question");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ConfirmationAssessmentQuestions)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_conf_as_que_company_id");

                entity.HasOne(d => d.IntConfirmReq)
                    .WithMany(p => p.ConfirmationAssessmentQuestions)
                    .HasForeignKey(d => d.IntConfirmReqId)
                    .HasConstraintName("fk_confassquestion_req_id");
            });

            modelBuilder.Entity<ConfirmationAssessmentRequest>(entity =>
            {
                entity.HasKey(e => e.IntConfirmReqId)
                    .HasName("PRIMARY");

                entity.ToTable("confirmation_assessment_request");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntCompanyId, "fk_conf_t_emp_req");

                entity.HasIndex(e => e.IntEmpId, "fk_ex_m_confreq_emp_id");

                entity.Property(e => e.IntConfirmReqId).HasColumnName("int_confirm_req_id");

                entity.Property(e => e.DtExtendFromDate).HasColumnName("dt_extend_from_date");

                entity.Property(e => e.DtExtendToDate).HasColumnName("dt_extend_to_date");

                entity.Property(e => e.DtLetterGenDate).HasColumnName("dt_letter_gen_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("int_emp_id")
                    .HasComment("reference from employee master(employee_master)");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchAnswered)
                    .HasMaxLength(3)
                    .HasColumnName("vch_answered");

                entity.Property(e => e.VchApproveHrCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_approve_hr_code");

                entity.Property(e => e.VchApproveHrName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_approve_hr_name");

                entity.Property(e => e.VchApproveRmCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_approve_rm_code");

                entity.Property(e => e.VchApproveRmName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_approve_rm_name");

                entity.Property(e => e.VchApproverAction)
                    .HasMaxLength(45)
                    .HasColumnName("vch_approver_action");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocumentPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_path");

                entity.Property(e => e.VchHrComments)
                    .HasMaxLength(3000)
                    .HasColumnName("vch_hr_comments")
                    .HasComment("for hr comments");

                entity.Property(e => e.VchHrReason)
                    .HasMaxLength(3000)
                    .HasColumnName("vch_hr_reason");

                entity.Property(e => e.VchLetterGenPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_letter_gen_path");

                entity.Property(e => e.VchRmComments)
                    .HasMaxLength(3000)
                    .HasColumnName("vch_rm_comments")
                    .HasComment("for rm comments");

                entity.Property(e => e.VchRmReason)
                    .HasMaxLength(3000)
                    .HasColumnName("vch_rm_reason");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(5)
                    .HasColumnName("vch_status")
                    .HasComment("RMP,RMR,HRP,HRR,HRA");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ConfirmationAssessmentRequests)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_conf_t_emp_req");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.ConfirmationAssessmentRequests)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("fk_ex_m_confreq_emp_id");
            });

            modelBuilder.Entity<ConfirmationQuestionEmployeeMap>(entity =>
            {
                entity.HasKey(e => e.IntEmpMapId)
                    .HasName("PRIMARY");

                entity.ToTable("confirmation_question_employee_map");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_conf_map_companyid");

                entity.HasIndex(e => e.ExitTemplateId, "fk_conf_map_template");

                entity.Property(e => e.IntEmpMapId).HasColumnName("INT_EMP_MAP_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("Dt_updated_date");

                entity.Property(e => e.ExitTemplateId).HasColumnName("exit_template_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("Ts_created_time");

                entity.Property(e => e.VchDesignationList)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_designation_list");

                entity.HasOne(d => d.ExitTemplate)
                    .WithMany(p => p.ConfirmationQuestionEmployeeMaps)
                    .HasForeignKey(d => d.ExitTemplateId)
                    .HasConstraintName("fk_conf_map_template");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ConfirmationQuestionEmployeeMaps)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_conf_map_companyid");
            });

            modelBuilder.Entity<CostcenterMaster>(entity =>
            {
                entity.HasKey(e => e.CostcenterSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("costcenter_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.CostcenterSeqId).HasColumnName("COSTCENTER_SEQ_ID");

                entity.Property(e => e.CostcenterName)
                    .HasMaxLength(100)
                    .HasColumnName("COSTCENTER_NAME");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchOldPf)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_OLD_PF");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<CostcenterMasterTmp>(entity =>
            {
                entity.HasKey(e => e.CostcenterSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("costcenter_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.CostcenterSeqId).HasColumnName("COSTCENTER_SEQ_ID");

                entity.Property(e => e.CostcenterName)
                    .HasMaxLength(100)
                    .HasColumnName("COSTCENTER_NAME");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<Country>(entity =>
            {
                entity.HasKey(e => e.CountrySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("country");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.CountrySeqId).HasColumnName("COUNTRY_SEQ_ID");

                entity.Property(e => e.CountryName)
                    .HasColumnType("text")
                    .HasColumnName("country_name");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<CountryTmp>(entity =>
            {
                entity.HasKey(e => e.CountrySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("country_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.CountrySeqId).HasColumnName("COUNTRY_SEQ_ID");

                entity.Property(e => e.CountryName)
                    .HasMaxLength(1000)
                    .HasColumnName("country_name");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<Databasechangelog>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("databasechangelog");

                entity.Property(e => e.Author)
                    .HasMaxLength(255)
                    .HasColumnName("AUTHOR");

                entity.Property(e => e.Comments)
                    .HasMaxLength(255)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Contexts)
                    .HasMaxLength(255)
                    .HasColumnName("CONTEXTS");

                entity.Property(e => e.Dateexecuted)
                    .HasColumnType("datetime")
                    .HasColumnName("DATEEXECUTED");

                entity.Property(e => e.DeploymentId)
                    .HasMaxLength(10)
                    .HasColumnName("DEPLOYMENT_ID");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.Exectype)
                    .HasMaxLength(10)
                    .HasColumnName("EXECTYPE");

                entity.Property(e => e.Filename)
                    .HasMaxLength(255)
                    .HasColumnName("FILENAME");

                entity.Property(e => e.Id)
                    .HasMaxLength(255)
                    .HasColumnName("ID");

                entity.Property(e => e.Labels)
                    .HasMaxLength(255)
                    .HasColumnName("LABELS");

                entity.Property(e => e.Liquibase)
                    .HasMaxLength(20)
                    .HasColumnName("LIQUIBASE");

                entity.Property(e => e.Md5sum)
                    .HasMaxLength(35)
                    .HasColumnName("MD5SUM");

                entity.Property(e => e.Orderexecuted).HasColumnName("ORDEREXECUTED");

                entity.Property(e => e.Tag)
                    .HasMaxLength(255)
                    .HasColumnName("TAG");
            });

            modelBuilder.Entity<Databasechangeloglock>(entity =>
            {
                entity.ToTable("databasechangeloglock");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Locked)
                    .HasColumnType("bit(1)")
                    .HasColumnName("LOCKED");

                entity.Property(e => e.Lockedby)
                    .HasMaxLength(255)
                    .HasColumnName("LOCKEDBY");

                entity.Property(e => e.Lockgranted)
                    .HasColumnType("datetime")
                    .HasColumnName("LOCKGRANTED");
            });

            modelBuilder.Entity<DepartmentMaster>(entity =>
            {
                entity.HasKey(e => e.DeptSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("department_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DeptSeqId).HasColumnName("DEPT_SEQ_ID");

                entity.Property(e => e.DepName)
                    .HasMaxLength(100)
                    .HasColumnName("DEP_NAME");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDepShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_DEP_SHORT_NAME");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_LOCATION_NAME");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchOldPf)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_OLD_PF");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<DepartmentMasterTmp>(entity =>
            {
                entity.HasKey(e => e.DeptSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("department_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DeptSeqId).HasColumnName("DEPT_SEQ_ID");

                entity.Property(e => e.DepName)
                    .HasMaxLength(100)
                    .HasColumnName("DEP_NAME");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDepShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_DEP_SHORT_NAME");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_LOCATION_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<DepartmentsMaster>(entity =>
            {
                entity.HasKey(e => e.DeptsSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("departments_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DeptsSeqId).HasColumnName("DEPTS_SEQ_ID");

                entity.Property(e => e.DeptsName)
                    .HasMaxLength(100)
                    .HasColumnName("DEPTS_NAME");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDeptsShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_DEPTS_SHORT_NAME");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_LOCATION_NAME");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<DepartmentsMasterTmp>(entity =>
            {
                entity.HasKey(e => e.DeptsSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("departments_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DeptsSeqId).HasColumnName("DEPTS_SEQ_ID");

                entity.Property(e => e.DeptsName)
                    .HasMaxLength(100)
                    .HasColumnName("DEPTS_NAME");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDeptsShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_DEPTS_SHORT_NAME");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_LOCATION_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<DesignationMaster>(entity =>
            {
                entity.HasKey(e => e.DesignationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("designation_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntRcsgradeId, "fk_designation_grade_idx");

                entity.Property(e => e.DesignationSeqId).HasColumnName("DESIGNATION_SEQ_ID");

                entity.Property(e => e.DepartmentName)
                    .HasMaxLength(100)
                    .HasColumnName("DEPARTMENT_NAME");

                entity.Property(e => e.DeptSeqId).HasColumnName("DEPT_SEQ_ID");

                entity.Property(e => e.DesName)
                    .HasMaxLength(100)
                    .HasColumnName("DES_NAME");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("INT_RCSGRADE_ID");

                entity.Property(e => e.LocationName)
                    .HasMaxLength(100)
                    .HasColumnName("LOCATION_NAME");

                entity.Property(e => e.RcsgradeName)
                    .HasMaxLength(1000)
                    .HasColumnName("RCSGRADE_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchCriteriaAssign)
                    .HasMaxLength(3)
                    .HasColumnName("vch_criteria_assign");

                entity.Property(e => e.VchDeptShortName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_DEPT_SHORT_NAME");

                entity.Property(e => e.VchDesShortName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_DES_SHORT_NAME");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchDesignationMapped)
                    .HasMaxLength(50)
                    .HasColumnName("vch_designation_mapped");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntRcsgrade)
                    .WithMany(p => p.DesignationMasters)
                    .HasForeignKey(d => d.IntRcsgradeId)
                    .HasConstraintName("fk_designation_grade_idx");
            });

            modelBuilder.Entity<DesignationMasterTmp>(entity =>
            {
                entity.HasKey(e => e.DesignationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("designation_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntRcsgradeId, "fk_designation_tmp_grade_idx");

                entity.Property(e => e.DesignationSeqId).HasColumnName("DESIGNATION_SEQ_ID");

                entity.Property(e => e.DepartmentName)
                    .HasMaxLength(100)
                    .HasColumnName("DEPARTMENT_NAME");

                entity.Property(e => e.DeptSeqId).HasColumnName("DEPT_SEQ_ID");

                entity.Property(e => e.DesName)
                    .HasMaxLength(100)
                    .HasColumnName("DES_NAME");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("INT_RCSGRADE_ID");

                entity.Property(e => e.LocationName)
                    .HasMaxLength(100)
                    .HasColumnName("LOCATION_NAME");

                entity.Property(e => e.RcsgradeName)
                    .HasMaxLength(1000)
                    .HasColumnName("RCSGRADE_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDeptShortName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_DEPT_SHORT_NAME");

                entity.Property(e => e.VchDesShortName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_DES_SHORT_NAME");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntRcsgrade)
                    .WithMany(p => p.DesignationMasterTmps)
                    .HasForeignKey(d => d.IntRcsgradeId)
                    .HasConstraintName("fk_designation_tmp_grade_idx");
            });

            modelBuilder.Entity<DocumentMaster>(entity =>
            {
                entity.HasKey(e => e.IntDocId)
                    .HasName("PRIMARY");

                entity.ToTable("document_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_mas_company_id");

                entity.Property(e => e.IntDocId).HasColumnName("int_doc_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocDescription)
                    .HasMaxLength(300)
                    .HasColumnName("vch_doc_description");

                entity.Property(e => e.VchDocName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_doc_name")
                    .HasComment("HRP,HRA,HRR,LG");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.DocumentMasters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_doc_mas_company_id");
            });

            modelBuilder.Entity<DomainMaster>(entity =>
            {
                entity.HasKey(e => e.DomainSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("domain_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DomainSeqId).HasColumnName("DOMAIN_SEQ_ID");

                entity.Property(e => e.DomainName)
                    .HasMaxLength(100)
                    .HasColumnName("DOMAIN_NAME");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<DomainMasterTmp>(entity =>
            {
                entity.HasKey(e => e.DomainSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("domain_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DomainSeqId).HasColumnName("DOMAIN_SEQ_ID");

                entity.Property(e => e.DomainName)
                    .HasColumnType("text")
                    .HasColumnName("DOMAIN_NAME");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<Dual>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("dual");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.Dummy)
                    .HasMaxLength(1)
                    .HasColumnName("DUMMY");
            });

            modelBuilder.Entity<EmpCodeFormula>(entity =>
            {
                entity.HasKey(e => e.FormulaId)
                    .HasName("PRIMARY");

                entity.ToTable("emp_code_formula");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.FormulaId).HasColumnName("formula_id");

                entity.Property(e => e.VchFormula)
                    .HasMaxLength(100)
                    .HasColumnName("vch_formula");
            });

            modelBuilder.Entity<EmpMasUniqueUploadField>(entity =>
            {
                entity.HasKey(e => e.IntAttributeId)
                    .HasName("PRIMARY");

                entity.ToTable("emp_mas_unique_upload_fields");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntAttributeId).HasColumnName("int_attribute_id");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VchAttributeName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_attribute_name");

                entity.Property(e => e.VchAttributeValue)
                    .HasMaxLength(50)
                    .HasColumnName("vch_attribute_value");

                entity.Property(e => e.VchDataType)
                    .HasMaxLength(20)
                    .HasColumnName("vch_data_type");

                entity.Property(e => e.VchQuery)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_query");
            });

            modelBuilder.Entity<EmpMasterEffectiveDateValidateTmp>(entity =>
            {
                entity.HasKey(e => e.EmpSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("emp_master_effective_date_validate_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmpSeqId).HasColumnName("emp_seq_id");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(70)
                    .HasColumnName("employee_code");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");
            });

            modelBuilder.Entity<EmpNoHistory>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("emp_no_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.VchCompanyCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_Company_CODE");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<EmployeeAttribute>(entity =>
            {
                entity.HasKey(e => e.EmpAttrId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_attribute");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmpAttrId).HasColumnName("emp_attr_id");

                entity.Property(e => e.VchLabelName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_label_name");

                entity.Property(e => e.VchLabelValue)
                    .HasMaxLength(100)
                    .HasColumnName("vch_label_value");

                entity.Property(e => e.VchQuery)
                    .HasMaxLength(4000)
                    .HasColumnName("vch_query");

                entity.Property(e => e.VchShow)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show");

                entity.Property(e => e.VchType)
                    .HasMaxLength(50)
                    .HasColumnName("vch_type");
            });

            modelBuilder.Entity<EmployeeCategoryMaster>(entity =>
            {
                entity.HasKey(e => e.EmployeeCategorySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_category_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmployeeCategorySeqId).HasColumnName("EMPLOYEE_CATEGORY_SEQ_ID");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpCategoryName)
                    .HasMaxLength(100)
                    .HasColumnName("EMP_CATEGORY_NAME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Tenure)
                    .HasMaxLength(45)
                    .HasColumnName("TENURE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeCategoryMasterTmp>(entity =>
            {
                entity.HasKey(e => e.EmployeeCategorySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_category_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmployeeCategorySeqId).HasColumnName("EMPLOYEE_CATEGORY_SEQ_ID");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpCategoryName)
                    .HasColumnType("text")
                    .HasColumnName("EMP_CATEGORY_NAME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Tenure)
                    .HasColumnType("text")
                    .HasColumnName("TENURE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeDocumentSizeDetail>(entity =>
            {
                entity.HasKey(e => e.IntEmpDocSizeId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_document_size_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_company_document_size");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_employee_document_size");

                entity.Property(e => e.IntEmpDocSizeId).HasColumnName("int_emp_doc_size_id");

                entity.Property(e => e.DouDocsSize)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_docs_size");

                entity.Property(e => e.DouFeedbackSize)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_feedback_size");

                entity.Property(e => e.DouOnbSize)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_onb_size");

                entity.Property(e => e.DouProfileSize)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_profile_size");

                entity.Property(e => e.DouResumeSize)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_resume_size");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeDocumentSizeDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_company_document_size");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.EmployeeDocumentSizeDetails)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_employee_document_size");
            });

            modelBuilder.Entity<EmployeeMakerChecker>(entity =>
            {
                entity.HasKey(e => e.EmployeeMakerCheckerSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_maker_checker");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntNewAbeCode, "FK_EMP_ABE_CODE_NEW");

                entity.HasIndex(e => e.IntOldAbeCode, "FK_EMP_ABE_CODE_OLD");

                entity.HasIndex(e => e.IntOldBankName, "FK_EMP_BANK_NAME_NEW");

                entity.HasIndex(e => e.IntNewBankName, "FK_EMP_BANK_NAME_OLD");

                entity.HasIndex(e => e.IntNewItsroleValue, "FK_EMP_ITSROLE_MASTER_NEW");

                entity.HasIndex(e => e.IntOldItsroleValue, "FK_EMP_ITSROLE_MASTER_OLD");

                entity.HasIndex(e => e.IntNewProductivityfactor, "FK_EMP_PROD_FACT_NEW");

                entity.HasIndex(e => e.IntOldProductivityfactor, "FK_EMP_PROD_FACT_OLD");

                entity.HasIndex(e => e.IntNewRcsLevelValue, "FK_EMP_RCS_LEVEL_MASTER");

                entity.HasIndex(e => e.IntOldRcsLevelValue, "FK_RCS_LEVEL_MASTER");

                entity.HasIndex(e => e.IntSalMakerId, "fk_emp_mk_emp_sal_mk");

                entity.HasIndex(e => e.IntNewEmpCatValue, "fk_new_emp_cat_key");

                entity.HasIndex(e => e.IntOldEmpCatValue, "fk_old_emp_cat_key");

                entity.HasIndex(e => e.IntCompanyId, "int_company_id");

                entity.HasIndex(e => e.IntEmpId, "int_emp_id");

                entity.HasIndex(e => e.IntNewCostValue, "int_new_cost_value");

                entity.HasIndex(e => e.IntNewDepValue, "int_new_dep_value");

                entity.HasIndex(e => e.IntNewDesValue, "int_new_des_value");

                entity.HasIndex(e => e.IntNewLocValue, "int_new_loc_value");

                entity.HasIndex(e => e.IntOldCostValue, "int_old_cost_value");

                entity.HasIndex(e => e.IntOldDepValue, "int_old_dep_value");

                entity.HasIndex(e => e.IntOldDesValue, "int_old_des_value");

                entity.HasIndex(e => e.IntOldLocValue, "int_old_loc_value");

                entity.Property(e => e.EmployeeMakerCheckerSeqId).HasColumnName("employee_maker_checker_seq_id");

                entity.Property(e => e.DtCreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_created_date");

                entity.Property(e => e.DtNewDojValue).HasColumnName("dt_new_doj_value");

                entity.Property(e => e.DtOldDojValue).HasColumnName("dt_old_doj_value");

                entity.Property(e => e.DtUpdatedBy)
                    .HasMaxLength(30)
                    .HasColumnName("dt_updated_by");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EffectiveDate).HasColumnName("effective_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId).HasColumnName("int_emp_id");

                entity.Property(e => e.IntNewAbeCode).HasColumnName("int_new_abe_code");

                entity.Property(e => e.IntNewBankName).HasColumnName("int_new_bank_name");

                entity.Property(e => e.IntNewCostValue).HasColumnName("int_new_cost_value");

                entity.Property(e => e.IntNewCtc).HasColumnName("int_new_ctc");

                entity.Property(e => e.IntNewDepValue).HasColumnName("int_new_dep_value");

                entity.Property(e => e.IntNewDesValue).HasColumnName("int_new_des_value");

                entity.Property(e => e.IntNewEmpCatValue).HasColumnName("int_new_emp_cat_value");

                entity.Property(e => e.IntNewItsroleValue).HasColumnName("int_new_itsrole_value");

                entity.Property(e => e.IntNewLocValue).HasColumnName("int_new_loc_value");

                entity.Property(e => e.IntNewProductivityfactor).HasColumnName("int_new_productivityfactor");

                entity.Property(e => e.IntNewRcsLevelValue).HasColumnName("int_new_rcsLevel_value");

                entity.Property(e => e.IntNewSapPositionId)
                    .HasMaxLength(50)
                    .HasColumnName("int_new_sap_Position_id");

                entity.Property(e => e.IntOldAbeCode).HasColumnName("int_old_abe_code");

                entity.Property(e => e.IntOldBankName).HasColumnName("int_old_bank_name");

                entity.Property(e => e.IntOldCostValue).HasColumnName("int_old_cost_value");

                entity.Property(e => e.IntOldCtc).HasColumnName("int_old_ctc");

                entity.Property(e => e.IntOldDepValue).HasColumnName("int_old_dep_value");

                entity.Property(e => e.IntOldDesValue).HasColumnName("int_old_des_value");

                entity.Property(e => e.IntOldEmpCatValue).HasColumnName("int_old_emp_cat_value");

                entity.Property(e => e.IntOldItsroleValue).HasColumnName("int_old_itsrole_value");

                entity.Property(e => e.IntOldLocValue).HasColumnName("int_old_loc_value");

                entity.Property(e => e.IntOldProductivityfactor).HasColumnName("int_old_productivityfactor");

                entity.Property(e => e.IntOldRcsLevelValue).HasColumnName("int_old_rcsLevel_value");

                entity.Property(e => e.IntOldSapPositionId)
                    .HasMaxLength(50)
                    .HasColumnName("int_old_sap_Position_id");

                entity.Property(e => e.IntSalMakerId).HasColumnName("int_sal_maker_id");

                entity.Property(e => e.NewKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("new_kycIfsc");

                entity.Property(e => e.NewOncallAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("new_Oncall_Allowance_Eligibility");

                entity.Property(e => e.NewProfShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("new_prof_shift_Allowance_Eligibility");

                entity.Property(e => e.NewShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("new_Shift_Allowance_Eligibility");

                entity.Property(e => e.NewTypeOfWorker)
                    .HasMaxLength(20)
                    .HasColumnName("new_type_of_worker");

                entity.Property(e => e.OldKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("old_kycIfsc");

                entity.Property(e => e.OldOncallAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("old_Oncall_Allowance_Eligibility");

                entity.Property(e => e.OldProfShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("old_prof_shift_Allowance_Eligibility");

                entity.Property(e => e.OldShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("old_Shift_Allowance_Eligibility");

                entity.Property(e => e.OldTypeOfWorker)
                    .HasMaxLength(20)
                    .HasColumnName("old_type_of_worker");

                entity.Property(e => e.ProbationDays).HasColumnName("probation_days");

                entity.Property(e => e.VchAttributeKey)
                    .HasMaxLength(60)
                    .HasColumnName("vch_attribute_key");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(3)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchPromotionDemotionFlag)
                    .HasMaxLength(4)
                    .HasColumnName("vch_promotion_demotion_flag");

                entity.Property(e => e.VchRollbackStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_rollback_status");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(30)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(150)
                    .HasColumnName("vch_transaction_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeMakerCheckers)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EMP_MK_CK_COM_MAS");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.EmployeeMakerCheckers)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("FK_EMP_MK_CK_EMP_MAS");

                entity.HasOne(d => d.IntNewAbeCodeNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewAbeCodeNavigations)
                    .HasForeignKey(d => d.IntNewAbeCode)
                    .HasConstraintName("FK_EMP_ABE_CODE_NEW");

                entity.HasOne(d => d.IntNewBankNameNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewBankNameNavigations)
                    .HasForeignKey(d => d.IntNewBankName)
                    .HasConstraintName("FK_EMP_BANK_NAME_OLD");

                entity.HasOne(d => d.IntNewCostValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewCostValueNavigations)
                    .HasForeignKey(d => d.IntNewCostValue)
                    .HasConstraintName("FK_EMP_MK_CK_NEW_COS");

                entity.HasOne(d => d.IntNewDepValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewDepValueNavigations)
                    .HasForeignKey(d => d.IntNewDepValue)
                    .HasConstraintName("FK_EMP_MK_CK_NEW_DEP");

                entity.HasOne(d => d.IntNewDesValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewDesValueNavigations)
                    .HasForeignKey(d => d.IntNewDesValue)
                    .HasConstraintName("FK_EMP_MK_CK_NEW_DES");

                entity.HasOne(d => d.IntNewEmpCatValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewEmpCatValueNavigations)
                    .HasForeignKey(d => d.IntNewEmpCatValue)
                    .HasConstraintName("fk_new_emp_cat_key");

                entity.HasOne(d => d.IntNewItsroleValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewItsroleValueNavigations)
                    .HasForeignKey(d => d.IntNewItsroleValue)
                    .HasConstraintName("FK_EMP_ITSROLE_MASTER_NEW");

                entity.HasOne(d => d.IntNewLocValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewLocValueNavigations)
                    .HasForeignKey(d => d.IntNewLocValue)
                    .HasConstraintName("FK_EMP_MK_CK_NEW_LOC");

                entity.HasOne(d => d.IntNewProductivityfactorNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewProductivityfactorNavigations)
                    .HasForeignKey(d => d.IntNewProductivityfactor)
                    .HasConstraintName("FK_EMP_PROD_FACT_NEW");

                entity.HasOne(d => d.IntNewRcsLevelValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntNewRcsLevelValueNavigations)
                    .HasForeignKey(d => d.IntNewRcsLevelValue)
                    .HasConstraintName("FK_EMP_RCS_LEVEL_MASTER");

                entity.HasOne(d => d.IntOldAbeCodeNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldAbeCodeNavigations)
                    .HasForeignKey(d => d.IntOldAbeCode)
                    .HasConstraintName("FK_EMP_ABE_CODE_OLD");

                entity.HasOne(d => d.IntOldBankNameNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldBankNameNavigations)
                    .HasForeignKey(d => d.IntOldBankName)
                    .HasConstraintName("FK_EMP_BANK_NAME_NEW");

                entity.HasOne(d => d.IntOldCostValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldCostValueNavigations)
                    .HasForeignKey(d => d.IntOldCostValue)
                    .HasConstraintName("FK_EMP_MK_CK_OLD_COS");

                entity.HasOne(d => d.IntOldDepValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldDepValueNavigations)
                    .HasForeignKey(d => d.IntOldDepValue)
                    .HasConstraintName("FK_EMP_MK_CK_OLD_DEP");

                entity.HasOne(d => d.IntOldDesValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldDesValueNavigations)
                    .HasForeignKey(d => d.IntOldDesValue)
                    .HasConstraintName("FK_EMP_MK_CK_OLD_DES");

                entity.HasOne(d => d.IntOldEmpCatValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldEmpCatValueNavigations)
                    .HasForeignKey(d => d.IntOldEmpCatValue)
                    .HasConstraintName("fk_old_emp_cat_key");

                entity.HasOne(d => d.IntOldItsroleValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldItsroleValueNavigations)
                    .HasForeignKey(d => d.IntOldItsroleValue)
                    .HasConstraintName("FK_EMP_ITSROLE_MASTER_OLD");

                entity.HasOne(d => d.IntOldLocValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldLocValueNavigations)
                    .HasForeignKey(d => d.IntOldLocValue)
                    .HasConstraintName("FK_EMP_MK_CK_OLD_LOC");

                entity.HasOne(d => d.IntOldProductivityfactorNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldProductivityfactorNavigations)
                    .HasForeignKey(d => d.IntOldProductivityfactor)
                    .HasConstraintName("FK_EMP_PROD_FACT_OLD");

                entity.HasOne(d => d.IntOldRcsLevelValueNavigation)
                    .WithMany(p => p.EmployeeMakerCheckerIntOldRcsLevelValueNavigations)
                    .HasForeignKey(d => d.IntOldRcsLevelValue)
                    .HasConstraintName("FK_RCS_LEVEL_MASTER");

                entity.HasOne(d => d.IntSalMaker)
                    .WithMany(p => p.EmployeeMakerCheckers)
                    .HasForeignKey(d => d.IntSalMakerId)
                    .HasConstraintName("fk_emp_mk_emp_sal_mk");
            });

            modelBuilder.Entity<EmployeeMakerCheckerTmp>(entity =>
            {
                entity.HasKey(e => e.MakerCheckerTmpSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_maker_checker_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.MakerCheckerTmpSeqId).HasColumnName("maker_checker_tmp_seq_id");

                entity.Property(e => e.IntMakerCheckerId).HasColumnName("int_maker_checker_id");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(200)
                    .HasColumnName("vch_transaction_id");
            });

            modelBuilder.Entity<EmployeeMasChecker>(entity =>
            {
                entity.HasKey(e => e.IntEmpMcId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_mas_checker");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmpMcId).HasColumnName("INT_EMP_MC_ID");

                entity.Property(e => e.DateOfJoin)
                    .HasColumnType("datetime")
                    .HasColumnName("DATE_OF_JOIN");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpCode)
                    .HasMaxLength(20)
                    .HasColumnName("EMP_CODE");

                entity.Property(e => e.EmpName)
                    .HasMaxLength(50)
                    .HasColumnName("EMP_NAME");

                entity.Property(e => e.IntFieldValueIndexNew).HasColumnName("INT_FIELD_VALUE_INDEX_NEW");

                entity.Property(e => e.Status)
                    .HasMaxLength(20)
                    .HasColumnName("STATUS");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchFieldName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_FIELD_NAME");

                entity.Property(e => e.VchFieldValueNew)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_FIELD_VALUE_NEW");

                entity.Property(e => e.VchFieldValueOld)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_FIELD_VALUE_OLD");

                entity.Property(e => e.VchInitiatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_INITIATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeMasDetail>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_mas_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.BankName, "FK_EMP_Details_bank_name");

                entity.HasIndex(e => e.IntCompanyId, "FK_EMP_MAS_DET_COMPANY_ID");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_EMP_M_DET_EMP_SEQ_ID");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.BankName).HasColumnName("bank_name");

                entity.Property(e => e.DtConfirmDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CONFIRM_DATE");

                entity.Property(e => e.DtCurDoj)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CUR_DOJ");

                entity.Property(e => e.DtLeaveDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_LEAVE_DATE");

                entity.Property(e => e.DtNomineeFatherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_FATHER_DOB");

                entity.Property(e => e.DtNomineeMotherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_MOTHER_DOB");

                entity.Property(e => e.DtNomineeSpouseDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_SPOUSE_DOB");

                entity.Property(e => e.DtPerDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PER_DOB");

                entity.Property(e => e.DtPrevFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE");

                entity.Property(e => e.DtPrevFromDate1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE1");

                entity.Property(e => e.DtPrevToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE");

                entity.Property(e => e.DtPrevToDate2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE2");

                entity.Property(e => e.DtProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PROBATION_DATE");

                entity.Property(e => e.DtResigDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_RESIG_DATE");

                entity.Property(e => e.DtUpdatedDate).HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpDetailInfoSeq).HasColumnName("EMP_DETAIL_INFO_SEQ");

                entity.Property(e => e.IntCategorySeqId).HasColumnName("INT_CATEGORY_SEQ_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("INT_EMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntObSeqId)
                    .HasColumnName("INT_OB_SEQ_ID")
                    .HasComment("reference with onboard_initiation table");

                entity.Property(e => e.IntPrevCtc).HasColumnName("INT_PREV_CTC");

                entity.Property(e => e.IntPrevCtc1).HasColumnName("INT_PREV_CTC1");

                entity.Property(e => e.IntPreviCtc).HasColumnName("INT_PREVI_CTC");

                entity.Property(e => e.PresentCostCenter).HasColumnName("PRESENT_COST_CENTER");

                entity.Property(e => e.PresentDepartment).HasColumnName("PRESENT_DEPARTMENT");

                entity.Property(e => e.PresentDesignation).HasColumnName("PRESENT_DESIGNATION");

                entity.Property(e => e.PresentGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PRESENT_GRADE");

                entity.Property(e => e.PresentLocation).HasColumnName("PRESENT_LOCATION");

                entity.Property(e => e.ReportingManagerName).HasColumnName("REPORTING_MANAGER_NAME");

                entity.Property(e => e.VarBranch)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_BRANCH");

                entity.Property(e => e.VarDipDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_DEPART");

                entity.Property(e => e.VarDipInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_INSTITUTION");

                entity.Property(e => e.VarDipMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_MEDIUM");

                entity.Property(e => e.VarDipPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_PERCENTAGE");

                entity.Property(e => e.VarDipUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_UNIVERSITY");

                entity.Property(e => e.VarDipYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_FROM");

                entity.Property(e => e.VarDipYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_TO");

                entity.Property(e => e.VarDivision)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_DIVISION");

                entity.Property(e => e.VarHsLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_LOCATION");

                entity.Property(e => e.VarHsPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_PERCENTAGE");

                entity.Property(e => e.VarHsSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_SCH_NAME");

                entity.Property(e => e.VarHsUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_UNIVERSITY");

                entity.Property(e => e.VarHsYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_YR_COMPLETE");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(80)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycDlNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_DL_NO");

                entity.Property(e => e.VarKycEpsNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_EPS_NO");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VarMailId)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_MAIL_ID");

                entity.Property(e => e.VarNomineeFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_FATHER_NAME");

                entity.Property(e => e.VarNomineeMotherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_MOTHER_NAME");

                entity.Property(e => e.VarNomineeNoOfChildren)
                    .HasMaxLength(5)
                    .HasColumnName("VAR_NOMINEE_NO_OF_CHILDREN");

                entity.Property(e => e.VarNomineeSpouseName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_SPOUSE_NAME");

                entity.Property(e => e.VarPerAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS1");

                entity.Property(e => e.VarPerAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS2");

                entity.Property(e => e.VarPerAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_ADDRESS3");

                entity.Property(e => e.VarPerBg)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_BG");

                entity.Property(e => e.VarPerCity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CITY");

                entity.Property(e => e.VarPerCountry)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_COUNTRY");

                entity.Property(e => e.VarPerCurrAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_CURR_ADDRESS1");

                entity.Property(e => e.VarPerCurrAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_CURR_ADDRESS2");

                entity.Property(e => e.VarPerCurrCity)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_CITY");

                entity.Property(e => e.VarPerCurrCountry)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_COUNTRY");

                entity.Property(e => e.VarPerCurrPincode)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_PINCODE");

                entity.Property(e => e.VarPerCurrState)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_STATE");

                entity.Property(e => e.VarPerEmail)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_EMAIL");

                entity.Property(e => e.VarPerFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FATHER_NAME");

                entity.Property(e => e.VarPerFirstName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FIRST_NAME");

                entity.Property(e => e.VarPerGender)
                    .HasMaxLength(6)
                    .HasColumnName("VAR_PER_GENDER");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_LAST_NAME");

                entity.Property(e => e.VarPerMaritialStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_MARITIAL_STATUS");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_MIDDLE_NAME");

                entity.Property(e => e.VarPerMobileNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_MOBILE_NO");

                entity.Property(e => e.VarPerNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_NATIONALITY");

                entity.Property(e => e.VarPerPanNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_PAN_NO");

                entity.Property(e => e.VarPerPincode)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_PER_PINCODE");

                entity.Property(e => e.VarPerReligion)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_RELIGION");

                entity.Property(e => e.VarPerState)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_STATE");

                entity.Property(e => e.VarPgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_DEPART");

                entity.Property(e => e.VarPgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_INSTITUTION");

                entity.Property(e => e.VarPgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_MEDIUM");

                entity.Property(e => e.VarPgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_PERCENTAGE");

                entity.Property(e => e.VarPgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_UNIVERSITY");

                entity.Property(e => e.VarPgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_FROM");

                entity.Property(e => e.VarPgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_TO");

                entity.Property(e => e.VarPreCompany)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_COMPANY");

                entity.Property(e => e.VarPreCurrAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_ADDRESS3");

                entity.Property(e => e.VarPreCurrNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_NATIONALITY");

                entity.Property(e => e.VarPreLocation)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_LOCATION");

                entity.Property(e => e.VarPreRefPersion)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSION");

                entity.Property(e => e.VarPreRefPersions)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSIONS");

                entity.Property(e => e.VarPrevAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS1");

                entity.Property(e => e.VarPrevAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS2");

                entity.Property(e => e.VarPrevEmpName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME");

                entity.Property(e => e.VarPrevEmpName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME1");

                entity.Property(e => e.VarPrevLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION");

                entity.Property(e => e.VarPrevLocation1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION1");

                entity.Property(e => e.VarPrevReferDesig)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG");

                entity.Property(e => e.VarPrevReferDesig1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG1");

                entity.Property(e => e.VarPrevReferId)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID");

                entity.Property(e => e.VarPrevReferId1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID1");

                entity.Property(e => e.VarPrevReferName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME");

                entity.Property(e => e.VarPrevReferName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME1");

                entity.Property(e => e.VarSslcLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_LOCATION");

                entity.Property(e => e.VarSslcPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_PERCENTAGE");

                entity.Property(e => e.VarSslcSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_SCH_NAME");

                entity.Property(e => e.VarSslcUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_UNIVERSITY");

                entity.Property(e => e.VarSslcYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_YR_COMPLETE");

                entity.Property(e => e.VarStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_STATUS");

                entity.Property(e => e.VarUgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_DEPART");

                entity.Property(e => e.VarUgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_INSTITUTION");

                entity.Property(e => e.VarUgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_MEDIUM");

                entity.Property(e => e.VarUgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_PERCENTAGE");

                entity.Property(e => e.VarUgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_UNIVERSITY");

                entity.Property(e => e.VarUgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_FROM");

                entity.Property(e => e.VarUgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_TO");

                entity.Property(e => e.VchAddCheck)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ADD_CHECK");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmpCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_EMP_CODE");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchPhoneNo)
                    .HasMaxLength(15)
                    .HasColumnName("vch_phone_no");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.BankNameNavigation)
                    .WithMany(p => p.EmployeeMasDetails)
                    .HasForeignKey(d => d.BankName)
                    .HasConstraintName("FK_EMP_Details_bank_name");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeMasDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EMP_MAS_DET_COMPANY_ID");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.EmployeeMasDetails)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_EMP_M_DET_EMP_SEQ_ID");
            });

            modelBuilder.Entity<EmployeeMasDtlAuditLog>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_mas_dtl_audit_log");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.DtConfirmDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CONFIRM_DATE");

                entity.Property(e => e.DtCurDoj)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CUR_DOJ");

                entity.Property(e => e.DtLeaveDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_LEAVE_DATE");

                entity.Property(e => e.DtNomineeFatherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_FATHER_DOB");

                entity.Property(e => e.DtNomineeMotherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_MOTHER_DOB");

                entity.Property(e => e.DtNomineeSpouseDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_SPOUSE_DOB");

                entity.Property(e => e.DtPerDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PER_DOB");

                entity.Property(e => e.DtPrevFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE");

                entity.Property(e => e.DtPrevFromDate1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE1");

                entity.Property(e => e.DtPrevToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE");

                entity.Property(e => e.DtPrevToDate2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE2");

                entity.Property(e => e.DtProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PROBATION_DATE");

                entity.Property(e => e.DtResigDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_RESIG_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpDetailInfoSeq).HasColumnName("EMP_DETAIL_INFO_SEQ");

                entity.Property(e => e.IntCategorySeqId).HasColumnName("INT_CATEGORY_SEQ_ID");

                entity.Property(e => e.IntObSeqId)
                    .HasColumnName("INT_OB_SEQ_ID")
                    .HasComment("reference with onboard_initiation table");

                entity.Property(e => e.IntPhoneNo).HasColumnName("INT_PHONE_NO");

                entity.Property(e => e.IntPrevCtc).HasColumnName("INT_PREV_CTC");

                entity.Property(e => e.IntPrevCtc1).HasColumnName("INT_PREV_CTC1");

                entity.Property(e => e.IntPreviCtc).HasColumnName("INT_PREVI_CTC");

                entity.Property(e => e.PresentCostCenter).HasColumnName("PRESENT_COST_CENTER");

                entity.Property(e => e.PresentDepartment).HasColumnName("PRESENT_DEPARTMENT");

                entity.Property(e => e.PresentDesignation).HasColumnName("PRESENT_DESIGNATION");

                entity.Property(e => e.PresentGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PRESENT_GRADE");

                entity.Property(e => e.PresentLocation).HasColumnName("PRESENT_LOCATION");

                entity.Property(e => e.ReportingManagerName).HasColumnName("REPORTING_MANAGER_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VarBranch)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_BRANCH");

                entity.Property(e => e.VarDipDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_DEPART");

                entity.Property(e => e.VarDipInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_INSTITUTION");

                entity.Property(e => e.VarDipMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_MEDIUM");

                entity.Property(e => e.VarDipPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_PERCENTAGE");

                entity.Property(e => e.VarDipUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_UNIVERSITY");

                entity.Property(e => e.VarDipYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_FROM");

                entity.Property(e => e.VarDipYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_TO");

                entity.Property(e => e.VarDivision)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_DIVISION");

                entity.Property(e => e.VarHsLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_LOCATION");

                entity.Property(e => e.VarHsPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_PERCENTAGE");

                entity.Property(e => e.VarHsSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_SCH_NAME");

                entity.Property(e => e.VarHsUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_UNIVERSITY");

                entity.Property(e => e.VarHsYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_YR_COMPLETE");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(70)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycDlNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_DL_NO");

                entity.Property(e => e.VarKycEpsNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_EPS_NO");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VarMailId)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_MAIL_ID");

                entity.Property(e => e.VarNomineeFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_FATHER_NAME");

                entity.Property(e => e.VarNomineeMotherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_MOTHER_NAME");

                entity.Property(e => e.VarNomineeNoOfChildren)
                    .HasMaxLength(5)
                    .HasColumnName("VAR_NOMINEE_NO_OF_CHILDREN");

                entity.Property(e => e.VarNomineeSpouseName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_SPOUSE_NAME");

                entity.Property(e => e.VarPerAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS1");

                entity.Property(e => e.VarPerAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS2");

                entity.Property(e => e.VarPerAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_ADDRESS3");

                entity.Property(e => e.VarPerBg)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_BG");

                entity.Property(e => e.VarPerCity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CITY");

                entity.Property(e => e.VarPerCountry)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_COUNTRY");

                entity.Property(e => e.VarPerCurrAddress1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS1");

                entity.Property(e => e.VarPerCurrAddress2)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS2");

                entity.Property(e => e.VarPerCurrCity)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_CITY");

                entity.Property(e => e.VarPerCurrCountry)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_COUNTRY");

                entity.Property(e => e.VarPerCurrPincode)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_PINCODE");

                entity.Property(e => e.VarPerCurrState)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_STATE");

                entity.Property(e => e.VarPerEmail)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_EMAIL");

                entity.Property(e => e.VarPerFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FATHER_NAME");

                entity.Property(e => e.VarPerFirstName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FIRST_NAME");

                entity.Property(e => e.VarPerGender)
                    .HasMaxLength(6)
                    .HasColumnName("VAR_PER_GENDER");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_LAST_NAME");

                entity.Property(e => e.VarPerMaritialStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_MARITIAL_STATUS");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_MIDDLE_NAME");

                entity.Property(e => e.VarPerMobileNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_MOBILE_NO");

                entity.Property(e => e.VarPerNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_NATIONALITY");

                entity.Property(e => e.VarPerPanNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_PAN_NO");

                entity.Property(e => e.VarPerPincode)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_PER_PINCODE");

                entity.Property(e => e.VarPerReligion)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_RELIGION");

                entity.Property(e => e.VarPerState)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_STATE");

                entity.Property(e => e.VarPgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_DEPART");

                entity.Property(e => e.VarPgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_INSTITUTION");

                entity.Property(e => e.VarPgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_MEDIUM");

                entity.Property(e => e.VarPgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_PERCENTAGE");

                entity.Property(e => e.VarPgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_UNIVERSITY");

                entity.Property(e => e.VarPgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_FROM");

                entity.Property(e => e.VarPgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_TO");

                entity.Property(e => e.VarPreCompany)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_COMPANY");

                entity.Property(e => e.VarPreCurrAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_ADDRESS3");

                entity.Property(e => e.VarPreCurrNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_NATIONALITY");

                entity.Property(e => e.VarPreLocation)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_LOCATION");

                entity.Property(e => e.VarPreRefPersion)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSION");

                entity.Property(e => e.VarPreRefPersions)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSIONS");

                entity.Property(e => e.VarPrevAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS1");

                entity.Property(e => e.VarPrevAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS2");

                entity.Property(e => e.VarPrevEmpName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME");

                entity.Property(e => e.VarPrevEmpName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME1");

                entity.Property(e => e.VarPrevLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION");

                entity.Property(e => e.VarPrevLocation1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION1");

                entity.Property(e => e.VarPrevReferDesig)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG");

                entity.Property(e => e.VarPrevReferDesig1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG1");

                entity.Property(e => e.VarPrevReferId)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID");

                entity.Property(e => e.VarPrevReferId1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID1");

                entity.Property(e => e.VarPrevReferName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME");

                entity.Property(e => e.VarPrevReferName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME1");

                entity.Property(e => e.VarSslcLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_LOCATION");

                entity.Property(e => e.VarSslcPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_PERCENTAGE");

                entity.Property(e => e.VarSslcSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_SCH_NAME");

                entity.Property(e => e.VarSslcUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_UNIVERSITY");

                entity.Property(e => e.VarSslcYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_YR_COMPLETE");

                entity.Property(e => e.VarStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_STATUS");

                entity.Property(e => e.VarUgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_DEPART");

                entity.Property(e => e.VarUgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_INSTITUTION");

                entity.Property(e => e.VarUgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_MEDIUM");

                entity.Property(e => e.VarUgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_PERCENTAGE");

                entity.Property(e => e.VarUgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_UNIVERSITY");

                entity.Property(e => e.VarUgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_FROM");

                entity.Property(e => e.VarUgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_TO");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmpCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_EMP_CODE");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchPhoneNo)
                    .HasMaxLength(15)
                    .HasColumnName("vch_phone_no");

                entity.Property(e => e.VchReptCode)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_REPT_CODE");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeMasNomineeAuditLog>(entity =>
            {
                entity.HasKey(e => e.IntNimineeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_mas_nominee_audit_log");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntNimineeSeqId).HasColumnName("INT_NIMINEE_SEQ_ID");

                entity.Property(e => e.DtDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB");

                entity.Property(e => e.DtDob1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB1");

                entity.Property(e => e.DtDob2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB2");

                entity.Property(e => e.DtDob3)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB3");

                entity.Property(e => e.DtDob4)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB4");

                entity.Property(e => e.IntAge).HasColumnName("INT_AGE");

                entity.Property(e => e.IntAge1).HasColumnName("INT_AGE1");

                entity.Property(e => e.IntAge2).HasColumnName("INT_AGE2");

                entity.Property(e => e.IntAge3).HasColumnName("INT_AGE3");

                entity.Property(e => e.IntAge4).HasColumnName("INT_AGE4");

                entity.Property(e => e.IntEmployeeSeqId)
                    .HasColumnName("INT_EMPLOYEE_SEQ_ID")
                    .HasComment("REFERENCE FROM ONBOARD_EMPLOYEE_DETAILS FOREIGN KEY");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_NAME");

                entity.Property(e => e.VchName1)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NAME1");

                entity.Property(e => e.VchName2)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NAME2");

                entity.Property(e => e.VchName3)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_NAME3");

                entity.Property(e => e.VchName4)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NAME4");

                entity.Property(e => e.VchRelation)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RELATION");

                entity.Property(e => e.VchRelation1)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION1");

                entity.Property(e => e.VchRelation2)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION2");

                entity.Property(e => e.VchRelation3)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION3");

                entity.Property(e => e.VchRelation4)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION4");
            });

            modelBuilder.Entity<EmployeeMasNomineeDetail>(entity =>
            {
                entity.HasKey(e => e.IntNimineeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_mas_nominee_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "FK_EMP_M_NOMINEE_EMP_SEQ_ID");

                entity.Property(e => e.IntNimineeSeqId).HasColumnName("INT_NIMINEE_SEQ_ID");

                entity.Property(e => e.DtDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB");

                entity.Property(e => e.DtDob1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB1");

                entity.Property(e => e.DtDob2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB2");

                entity.Property(e => e.DtDob3)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB3");

                entity.Property(e => e.DtDob4)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB4");

                entity.Property(e => e.IntAge).HasColumnName("INT_AGE");

                entity.Property(e => e.IntAge1).HasColumnName("INT_AGE1");

                entity.Property(e => e.IntAge2).HasColumnName("INT_AGE2");

                entity.Property(e => e.IntAge3).HasColumnName("INT_AGE3");

                entity.Property(e => e.IntAge4).HasColumnName("INT_AGE4");

                entity.Property(e => e.IntEmployeeSeqId)
                    .HasColumnName("INT_EMPLOYEE_SEQ_ID")
                    .HasComment("REFERENCE FROM ONBOARD_EMPLOYEE_DETAILS FOREIGN KEY");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VchName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_NAME");

                entity.Property(e => e.VchName1)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NAME1");

                entity.Property(e => e.VchName2)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NAME2");

                entity.Property(e => e.VchName3)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_NAME3");

                entity.Property(e => e.VchName4)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_NAME4");

                entity.Property(e => e.VchRelation)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RELATION");

                entity.Property(e => e.VchRelation1)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION1");

                entity.Property(e => e.VchRelation2)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION2");

                entity.Property(e => e.VchRelation3)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION3");

                entity.Property(e => e.VchRelation4)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RELATION4");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.EmployeeMasNomineeDetails)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_EMP_M_NOMINEE_EMP_SEQ_ID");
            });

            modelBuilder.Entity<EmployeeMaster>(entity =>
            {
                entity.HasKey(e => e.EmployeeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.AbeCodeValue, "FK_EMP_ABE_CODE");

                entity.HasIndex(e => e.LeaveGroup, "FK_EMP_Leave_Group");

                entity.HasIndex(e => e.Departments, "FK_EMP_MAS_DEPARTMENTS_MASTER");

                entity.HasIndex(e => e.BankName, "FK_EMP_bank_name");

                entity.HasIndex(e => e.EmploymentType, "FK_EMP_employment_type");

                entity.HasIndex(e => e.ItsRoleSfiaValue, "FK_EMP_its_role");

                entity.HasIndex(e => e.MaritalStatus, "FK_EMP_marital_status_type");

                entity.HasIndex(e => e.MidpointValue, "FK_EMP_midpoint_value");

                entity.HasIndex(e => e.PhysicalStatus, "FK_EMP_physical_status");

                entity.HasIndex(e => e.ProductivityFactor, "FK_EMP_productivity_factor");

                entity.HasIndex(e => e.RcslevelValue, "FK_EMP_rcslevel_value");

                entity.HasIndex(e => e.Subdepartment, "FK_EMP_subdepartment");

                entity.HasIndex(e => e.TaxSlabOpted, "FK_EMP_tax_slab");

                entity.HasIndex(e => e.IntCompanyId, "fk_emp_mas_company_id");

                entity.HasIndex(e => e.IntCompanyRoleId, "fk_emp_mas_company_role");

                entity.HasIndex(e => e.IntRcsgradeId, "fk_emp_master_rcs_grade_idx");

                entity.HasIndex(e => e.Designation, "fk_employee_master_1");

                entity.HasIndex(e => e.Costcenter, "fk_employee_master_2");

                entity.HasIndex(e => e.Department, "fk_employee_master_3");

                entity.HasIndex(e => e.Location, "fk_employee_master_4");

                entity.HasIndex(e => e.Category, "fk_employee_master_5");

                entity.HasIndex(e => e.IntGradeId, "fk_empmas_grade_id");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("employee_seq_id");

                entity.Property(e => e.AbeCodeValue).HasColumnName("abe_code_value");

                entity.Property(e => e.ActionCode)
                    .HasMaxLength(5)
                    .HasColumnName("action_code");

                entity.Property(e => e.BankName).HasColumnName("bank_name");

                entity.Property(e => e.Billing)
                    .HasMaxLength(20)
                    .HasColumnName("billing");

                entity.Property(e => e.Branch)
                    .HasMaxLength(45)
                    .HasColumnName("branch");

                entity.Property(e => e.Category).HasColumnName("category");

                entity.Property(e => e.CnfPending)
                    .HasMaxLength(3)
                    .HasColumnName("cnf_pending");

                entity.Property(e => e.Company)
                    .HasMaxLength(45)
                    .HasColumnName("company");

                entity.Property(e => e.ConfirmationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("confirmation_date");

                entity.Property(e => e.Costcenter).HasColumnName("costcenter");

                entity.Property(e => e.CtcAmount).HasColumnName("ctc_amount");

                entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");

                entity.Property(e => e.Department).HasColumnName("department");

                entity.Property(e => e.Departments).HasColumnName("departments");

                entity.Property(e => e.DescFlag)
                    .HasMaxLength(5)
                    .HasColumnName("desc_flag");

                entity.Property(e => e.Designation).HasColumnName("designation");

                entity.Property(e => e.Division)
                    .HasMaxLength(45)
                    .HasColumnName("division");

                entity.Property(e => e.DouCurrCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_curr_ctc");

                entity.Property(e => e.DouNewCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_new_ctc");

                entity.Property(e => e.DpdhlJoining).HasColumnName("DPDHL_JOINING");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EffectiveDate).HasColumnName("effective_date");

                entity.Property(e => e.EmpCode)
                    .HasMaxLength(45)
                    .HasColumnName("emp_code");

                entity.Property(e => e.EmpDetailInfoSeq).HasColumnName("emp_detail_info_seq");

                entity.Property(e => e.EmpName)
                    .HasMaxLength(100)
                    .HasColumnName("emp_name");

                entity.Property(e => e.EmpPhotoBlob)
                    .HasColumnType("mediumblob")
                    .HasColumnName("emp_photo_blob");

                entity.Property(e => e.EmploymentType).HasColumnName("employment_type");

                entity.Property(e => e.ExitInitiationPending)
                    .HasMaxLength(3)
                    .HasColumnName("exit_initiation_pending");

                entity.Property(e => e.Gender)
                    .HasMaxLength(45)
                    .HasColumnName("gender");

                entity.Property(e => e.Grade)
                    .HasMaxLength(45)
                    .HasColumnName("grade");

                entity.Property(e => e.GroupDoj).HasColumnName("group_doj");

                entity.Property(e => e.HireType)
                    .HasMaxLength(20)
                    .HasColumnName("hire_type");

                entity.Property(e => e.IntAppraisalCount).HasColumnName("int_appraisal_count");

                entity.Property(e => e.IntCasualLeave).HasColumnName("int_casual_leave");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("int_company_role_id");

                entity.Property(e => e.IntConfExtendedTimes).HasColumnName("int_conf_extended_times");

                entity.Property(e => e.IntCovaccineLeave).HasColumnName("int_covaccine_leave");

                entity.Property(e => e.IntEmpSalaryDtls)
                    .HasPrecision(20)
                    .HasColumnName("int_emp_salary_dtls");

                entity.Property(e => e.IntGradeId).HasColumnName("int_grade_id");

                entity.Property(e => e.IntMaternityLeave).HasColumnName("int_maternity_leave");

                entity.Property(e => e.IntMiscarriageLeave).HasColumnName("int_miscarriage_leave");

                entity.Property(e => e.IntNimineeSeqId).HasColumnName("int_niminee_seq_id");

                entity.Property(e => e.IntOptionalLeave).HasColumnName("int_optional_leave");

                entity.Property(e => e.IntPaternityLeave).HasColumnName("int_paternity_leave");

                entity.Property(e => e.IntPrivilegeLeave).HasColumnName("int_privilege_leave");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("int_rcsgrade_id");

                entity.Property(e => e.IntSickLeave).HasColumnName("int_sick_leave");

                entity.Property(e => e.ItsRoleSfiaValue).HasColumnName("its_role_sfia_value");

                entity.Property(e => e.JoinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("join_date");

                entity.Property(e => e.Ldap)
                    .HasMaxLength(15)
                    .HasColumnName("ldap");

                entity.Property(e => e.LeaveGroup).HasColumnName("leave_group");

                entity.Property(e => e.LeavingDate)
                    .HasColumnType("datetime")
                    .HasColumnName("leaving_date");

                entity.Property(e => e.Location).HasColumnName("location");

                entity.Property(e => e.MaritalStatus).HasColumnName("marital_status");

                entity.Property(e => e.MidpointValue).HasColumnName("midpoint_value");

                entity.Property(e => e.OncallAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("oncall_allowance_eligibility");

                entity.Property(e => e.PersonalInfo).HasColumnName("personal_info");

                entity.Property(e => e.PhysicalStatus).HasColumnName("physical_status");

                entity.Property(e => e.ProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("probation_date");

                entity.Property(e => e.ProbationDays).HasColumnName("probation_days");

                entity.Property(e => e.ProductivityFactor).HasColumnName("productivity_factor");

                entity.Property(e => e.ProfessionalShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("professional_shift_allowance_eligibility");

                entity.Property(e => e.PtLocation)
                    .HasMaxLength(45)
                    .HasColumnName("pt_location");

                entity.Property(e => e.RcsFlag)
                    .HasMaxLength(5)
                    .HasColumnName("rcs_flag");

                entity.Property(e => e.RcslevelValue).HasColumnName("rcslevel_value");

                entity.Property(e => e.ReasonCode)
                    .HasMaxLength(5)
                    .HasColumnName("reason_code");

                entity.Property(e => e.Reference)
                    .HasMaxLength(45)
                    .HasColumnName("reference");

                entity.Property(e => e.ReportTo)
                    .HasMaxLength(45)
                    .HasColumnName("report_to");

                entity.Property(e => e.ResignationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("resignation_date");

                entity.Property(e => e.Role).HasColumnName("role");

                entity.Property(e => e.RoleChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("role_change_date");

                entity.Property(e => e.SalaryDtl).HasColumnName("salary_dtl");

                entity.Property(e => e.SalaryFlag)
                    .HasMaxLength(5)
                    .HasColumnName("salary_flag");

                entity.Property(e => e.SapEmployeeNo)
                    .HasMaxLength(15)
                    .HasColumnName("sap_employee_no");

                entity.Property(e => e.SapFlag)
                    .HasMaxLength(5)
                    .HasColumnName("sap_flag");

                entity.Property(e => e.SapPositionId)
                    .HasMaxLength(15)
                    .HasColumnName("sap_Position_id");

                entity.Property(e => e.SapSalaryFlag)
                    .HasMaxLength(5)
                    .HasColumnName("sap_salary_flag");

                entity.Property(e => e.ShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("shift_allowance_eligibility");

                entity.Property(e => e.Status)
                    .HasMaxLength(45)
                    .HasColumnName("status");

                entity.Property(e => e.Subdepartment).HasColumnName("subdepartment");

                entity.Property(e => e.TaxSlabOpted).HasColumnName("tax_slab_opted");

                entity.Property(e => e.TotalExperience)
                    .HasMaxLength(15)
                    .HasColumnName("total_experience");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsPwdChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_pwd_change_date");

                entity.Property(e => e.TypeOfWorker)
                    .HasMaxLength(20)
                    .HasColumnName("type_of_worker");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_last_name");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_middle_name");

                entity.Property(e => e.VchBusinessPartner)
                    .HasMaxLength(100)
                    .HasColumnName("vch_business_partner");

                entity.Property(e => e.VchBusinessUnit)
                    .HasMaxLength(100)
                    .HasColumnName("vch_business_unit");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchGroup)
                    .HasMaxLength(100)
                    .HasColumnName("vch_group");

                entity.Property(e => e.VchGroups)
                    .HasMaxLength(50)
                    .HasColumnName("vch_groups");

                entity.Property(e => e.VchMailid)
                    .HasMaxLength(50)
                    .HasColumnName("vch_mailid");

                entity.Property(e => e.VchOldPf)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_OLD_PF");

                entity.Property(e => e.VchOldPwd1)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd1");

                entity.Property(e => e.VchOldPwd2)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd2");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(3)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchPanCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pan_code");

                entity.Property(e => e.VchPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_password");

                entity.Property(e => e.VchProfilePath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_profile_path");

                entity.Property(e => e.VchPwdChangeReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_change_req");

                entity.Property(e => e.VchPwdExpired)
                    .HasMaxLength(2)
                    .HasColumnName("vch_pwd_expired");

                entity.Property(e => e.VchPwdResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pwd_reset_key");

                entity.Property(e => e.VchReptCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_code");

                entity.Property(e => e.VchReptName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_name");

                entity.Property(e => e.VchRmFlag)
                    .HasMaxLength(3)
                    .HasColumnName("vch_rm_flag");

                entity.Property(e => e.VchRoleAssignBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_role_assign_by");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchSignupReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_signup_req");

                entity.Property(e => e.VchSignupResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_signup_reset_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.AbeCodeValueNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.AbeCodeValue)
                    .HasConstraintName("FK_EMP_ABE_CODE");

                entity.HasOne(d => d.BankNameNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.BankName)
                    .HasConstraintName("FK_EMP_bank_name");

                entity.HasOne(d => d.CategoryNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Category)
                    .HasConstraintName("fk_employee_master_5");

                entity.HasOne(d => d.CostcenterNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Costcenter)
                    .HasConstraintName("fk_employee_master_2");

                entity.HasOne(d => d.DepartmentNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Department)
                    .HasConstraintName("fk_employee_master_3");

                entity.HasOne(d => d.DepartmentsNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Departments)
                    .HasConstraintName("FK_EMP_MAS_DEPARTMENTS_MASTER");

                entity.HasOne(d => d.DesignationNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Designation)
                    .HasConstraintName("fk_employee_master_1");

                entity.HasOne(d => d.EmploymentTypeNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.EmploymentType)
                    .HasConstraintName("FK_EMP_employment_type");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_emp_mas_company_id");

                entity.HasOne(d => d.IntCompanyRole)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.IntCompanyRoleId)
                    .HasConstraintName("fk_emp_mas_company_role");

                entity.HasOne(d => d.IntGrade)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.IntGradeId)
                    .HasConstraintName("fk_empmas_grade_id");

                entity.HasOne(d => d.IntRcsgrade)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.IntRcsgradeId)
                    .HasConstraintName("fk_emp_master_rcs_grade_idx");

                entity.HasOne(d => d.ItsRoleSfiaValueNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.ItsRoleSfiaValue)
                    .HasConstraintName("FK_EMP_its_role");

                entity.HasOne(d => d.LeaveGroupNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.LeaveGroup)
                    .HasConstraintName("FK_EMP_Leave_Group");

                entity.HasOne(d => d.LocationNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Location)
                    .HasConstraintName("fk_employee_master_4");

                entity.HasOne(d => d.MaritalStatusNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.MaritalStatus)
                    .HasConstraintName("FK_EMP_marital_status_type");

                entity.HasOne(d => d.MidpointValueNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.MidpointValue)
                    .HasConstraintName("FK_EMP_midpoint_value");

                entity.HasOne(d => d.PhysicalStatusNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.PhysicalStatus)
                    .HasConstraintName("FK_EMP_physical_status");

                entity.HasOne(d => d.ProductivityFactorNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.ProductivityFactor)
                    .HasConstraintName("FK_EMP_productivity_factor");

                entity.HasOne(d => d.RcslevelValueNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.RcslevelValue)
                    .HasConstraintName("FK_EMP_rcslevel_value");

                entity.HasOne(d => d.SubdepartmentNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.Subdepartment)
                    .HasConstraintName("FK_EMP_subdepartment");

                entity.HasOne(d => d.TaxSlabOptedNavigation)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.TaxSlabOpted)
                    .HasConstraintName("FK_EMP_tax_slab");
            });

            modelBuilder.Entity<EmployeeMasterTmp>(entity =>
            {
                entity.HasKey(e => e.EmployeeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("employee_seq_id");

                entity.Property(e => e.Branch)
                    .HasMaxLength(45)
                    .HasColumnName("branch");

                entity.Property(e => e.Category).HasColumnName("category");

                entity.Property(e => e.Company)
                    .HasMaxLength(45)
                    .HasColumnName("company");

                entity.Property(e => e.ConfirmationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("confirmation_date");

                entity.Property(e => e.Costcenter).HasColumnName("costcenter");

                entity.Property(e => e.CtcAmount).HasColumnName("ctc_amount");

                entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");

                entity.Property(e => e.Department).HasColumnName("department");

                entity.Property(e => e.Designation).HasColumnName("designation");

                entity.Property(e => e.Division)
                    .HasMaxLength(45)
                    .HasColumnName("division");

                entity.Property(e => e.DouCurrCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_curr_ctc");

                entity.Property(e => e.DouNewCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_new_ctc");

                entity.Property(e => e.DtConfirmDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CONFIRM_DATE");

                entity.Property(e => e.DtCurDoj)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CUR_DOJ");

                entity.Property(e => e.DtLeaveDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_LEAVE_DATE");

                entity.Property(e => e.DtNomineeFatherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_FATHER_DOB");

                entity.Property(e => e.DtNomineeMotherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_MOTHER_DOB");

                entity.Property(e => e.DtNomineeSpouseDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_SPOUSE_DOB");

                entity.Property(e => e.DtPerDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PER_DOB");

                entity.Property(e => e.DtPrevFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE");

                entity.Property(e => e.DtPrevFromDate1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE1");

                entity.Property(e => e.DtPrevToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE");

                entity.Property(e => e.DtPrevToDate2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE2");

                entity.Property(e => e.DtProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PROBATION_DATE");

                entity.Property(e => e.DtResigDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_RESIG_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EmpCode)
                    .HasMaxLength(45)
                    .HasColumnName("emp_code");

                entity.Property(e => e.EmpDetailInfoSeq).HasColumnName("emp_detail_info_seq");

                entity.Property(e => e.EmpName)
                    .HasMaxLength(100)
                    .HasColumnName("emp_name");

                entity.Property(e => e.Gender)
                    .HasMaxLength(45)
                    .HasColumnName("gender");

                entity.Property(e => e.Grade)
                    .HasMaxLength(45)
                    .HasColumnName("grade");

                entity.Property(e => e.IntAppraisalCount).HasColumnName("int_appraisal_count");

                entity.Property(e => e.IntCategorySeqId).HasColumnName("INT_CATEGORY_SEQ_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("int_company_role_id");

                entity.Property(e => e.IntEmpSalaryDtls)
                    .HasPrecision(20)
                    .HasColumnName("int_emp_salary_dtls");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("INT_EMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntGradeId).HasColumnName("int_grade_id");

                entity.Property(e => e.IntNimineeSeqId).HasColumnName("int_niminee_seq_id");

                entity.Property(e => e.IntPrevCtc).HasColumnName("INT_PREV_CTC");

                entity.Property(e => e.IntPrevCtc1).HasColumnName("INT_PREV_CTC1");

                entity.Property(e => e.IntPreviCtc).HasColumnName("INT_PREVI_CTC");

                entity.Property(e => e.JoinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("join_date");

                entity.Property(e => e.LeavingDate)
                    .HasColumnType("datetime")
                    .HasColumnName("leaving_date");

                entity.Property(e => e.Location).HasColumnName("location");

                entity.Property(e => e.PersonalInfo).HasColumnName("personal_info");

                entity.Property(e => e.PresentCostCenter).HasColumnName("PRESENT_COST_CENTER");

                entity.Property(e => e.PresentDepartment).HasColumnName("PRESENT_DEPARTMENT");

                entity.Property(e => e.PresentDesignation).HasColumnName("PRESENT_DESIGNATION");

                entity.Property(e => e.PresentGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PRESENT_GRADE");

                entity.Property(e => e.PresentLocation).HasColumnName("PRESENT_LOCATION");

                entity.Property(e => e.ProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("probation_date");

                entity.Property(e => e.PtLocation)
                    .HasMaxLength(45)
                    .HasColumnName("pt_location");

                entity.Property(e => e.Reference)
                    .HasMaxLength(45)
                    .HasColumnName("reference");

                entity.Property(e => e.ReportTo)
                    .HasMaxLength(45)
                    .HasColumnName("report_to");

                entity.Property(e => e.ReportingManagerName).HasColumnName("REPORTING_MANAGER_NAME");

                entity.Property(e => e.ResignationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("resignation_date");

                entity.Property(e => e.Role).HasColumnName("role");

                entity.Property(e => e.RoleChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("role_change_date");

                entity.Property(e => e.SalaryDtl).HasColumnName("salary_dtl");

                entity.Property(e => e.Status)
                    .HasMaxLength(45)
                    .HasColumnName("status");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VarBranch)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_BRANCH");

                entity.Property(e => e.VarDipDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_DEPART");

                entity.Property(e => e.VarDipInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_INSTITUTION");

                entity.Property(e => e.VarDipMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_MEDIUM");

                entity.Property(e => e.VarDipPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_PERCENTAGE");

                entity.Property(e => e.VarDipUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_UNIVERSITY");

                entity.Property(e => e.VarDipYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_FROM");

                entity.Property(e => e.VarDipYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_TO");

                entity.Property(e => e.VarDivision)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_DIVISION");

                entity.Property(e => e.VarHsLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_LOCATION");

                entity.Property(e => e.VarHsPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_PERCENTAGE");

                entity.Property(e => e.VarHsSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_SCH_NAME");

                entity.Property(e => e.VarHsUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_UNIVERSITY");

                entity.Property(e => e.VarHsYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_YR_COMPLETE");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(80)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycDlNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_DL_NO");

                entity.Property(e => e.VarKycEpsNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_EPS_NO");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VarMailId)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_MAIL_ID");

                entity.Property(e => e.VarNomineeFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_FATHER_NAME");

                entity.Property(e => e.VarNomineeMotherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_MOTHER_NAME");

                entity.Property(e => e.VarNomineeNoOfChildren)
                    .HasMaxLength(5)
                    .HasColumnName("VAR_NOMINEE_NO_OF_CHILDREN");

                entity.Property(e => e.VarNomineeSpouseName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_SPOUSE_NAME");

                entity.Property(e => e.VarPerAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS1");

                entity.Property(e => e.VarPerAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS2");

                entity.Property(e => e.VarPerAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_ADDRESS3");

                entity.Property(e => e.VarPerBg)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_BG");

                entity.Property(e => e.VarPerCity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CITY");

                entity.Property(e => e.VarPerCountry)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_COUNTRY");

                entity.Property(e => e.VarPerCurrAddress1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS1");

                entity.Property(e => e.VarPerCurrAddress2)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS2");

                entity.Property(e => e.VarPerCurrCity)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_CITY");

                entity.Property(e => e.VarPerCurrCountry)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_COUNTRY");

                entity.Property(e => e.VarPerCurrPincode)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_PINCODE");

                entity.Property(e => e.VarPerCurrState)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_STATE");

                entity.Property(e => e.VarPerEmail)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_EMAIL");

                entity.Property(e => e.VarPerFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FATHER_NAME");

                entity.Property(e => e.VarPerGender)
                    .HasMaxLength(6)
                    .HasColumnName("VAR_PER_GENDER");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_last_name");

                entity.Property(e => e.VarPerMaritialStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_MARITIAL_STATUS");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_middle_name");

                entity.Property(e => e.VarPerMobileNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_MOBILE_NO");

                entity.Property(e => e.VarPerNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_NATIONALITY");

                entity.Property(e => e.VarPerPanNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_PAN_NO");

                entity.Property(e => e.VarPerPincode)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_PER_PINCODE");

                entity.Property(e => e.VarPerReligion)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_RELIGION");

                entity.Property(e => e.VarPerState)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_STATE");

                entity.Property(e => e.VarPgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_DEPART");

                entity.Property(e => e.VarPgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_INSTITUTION");

                entity.Property(e => e.VarPgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_MEDIUM");

                entity.Property(e => e.VarPgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_PERCENTAGE");

                entity.Property(e => e.VarPgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_UNIVERSITY");

                entity.Property(e => e.VarPgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_FROM");

                entity.Property(e => e.VarPgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_TO");

                entity.Property(e => e.VarPreCompany)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_COMPANY");

                entity.Property(e => e.VarPreCurrAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_ADDRESS3");

                entity.Property(e => e.VarPreCurrNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_NATIONALITY");

                entity.Property(e => e.VarPreLocation)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_LOCATION");

                entity.Property(e => e.VarPreRefPersion)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSION");

                entity.Property(e => e.VarPreRefPersions)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSIONS");

                entity.Property(e => e.VarPrevAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS1");

                entity.Property(e => e.VarPrevAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS2");

                entity.Property(e => e.VarPrevEmpName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME");

                entity.Property(e => e.VarPrevEmpName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME1");

                entity.Property(e => e.VarPrevLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION");

                entity.Property(e => e.VarPrevLocation1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION1");

                entity.Property(e => e.VarPrevReferDesig)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG");

                entity.Property(e => e.VarPrevReferDesig1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG1");

                entity.Property(e => e.VarPrevReferId)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID");

                entity.Property(e => e.VarPrevReferId1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID1");

                entity.Property(e => e.VarPrevReferName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME");

                entity.Property(e => e.VarPrevReferName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME1");

                entity.Property(e => e.VarSslcLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_LOCATION");

                entity.Property(e => e.VarSslcPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_PERCENTAGE");

                entity.Property(e => e.VarSslcSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_SCH_NAME");

                entity.Property(e => e.VarSslcUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_UNIVERSITY");

                entity.Property(e => e.VarSslcYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_YR_COMPLETE");

                entity.Property(e => e.VarStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_STATUS");

                entity.Property(e => e.VarUgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_DEPART");

                entity.Property(e => e.VarUgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_INSTITUTION");

                entity.Property(e => e.VarUgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_MEDIUM");

                entity.Property(e => e.VarUgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_PERCENTAGE");

                entity.Property(e => e.VarUgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_UNIVERSITY");

                entity.Property(e => e.VarUgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_FROM");

                entity.Property(e => e.VarUgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_TO");

                entity.Property(e => e.VchCostcenterName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_costcenter_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDepartmentName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_department_name");

                entity.Property(e => e.VchDesignationName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_designation_name");

                entity.Property(e => e.VchEmpCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_EMP_CODE");

                entity.Property(e => e.VchEmpcategoryName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_empcategory_name");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_location_name");

                entity.Property(e => e.VchMailid)
                    .HasMaxLength(50)
                    .HasColumnName("vch_mailid");

                entity.Property(e => e.VchPanCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pan_code");

                entity.Property(e => e.VchPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_password");

                entity.Property(e => e.VchPhoneNo)
                    .HasMaxLength(15)
                    .HasColumnName("vch_phone_no");

                entity.Property(e => e.VchReptCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_code");

                entity.Property(e => e.VchReptName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_name");

                entity.Property(e => e.VchRoleAssignBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_role_assign_by");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_role_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(50)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<EmployeeMasterUniqueUploadTmp>(entity =>
            {
                entity.HasKey(e => e.EmployeeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_master_unique_upload_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("employee_seq_id");

                entity.Property(e => e.Attribute)
                    .HasMaxLength(50)
                    .HasColumnName("ATTRIBUTE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(50)
                    .HasColumnName("EMPLOYEE_CODE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.NewValue)
                    .HasMaxLength(500)
                    .HasColumnName("NEW_VALUE");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeMasterUploadTmp>(entity =>
            {
                entity.HasKey(e => e.EmployeeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_master_upload_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("employee_seq_id");

                entity.Property(e => e.Branch)
                    .HasMaxLength(45)
                    .HasColumnName("branch");

                entity.Property(e => e.Category).HasColumnName("category");

                entity.Property(e => e.Company)
                    .HasMaxLength(45)
                    .HasColumnName("company");

                entity.Property(e => e.ConfirmationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("confirmation_date");

                entity.Property(e => e.Costcenter).HasColumnName("costcenter");

                entity.Property(e => e.CtcAmount).HasColumnName("ctc_amount");

                entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");

                entity.Property(e => e.Department).HasColumnName("department");

                entity.Property(e => e.Designation).HasColumnName("designation");

                entity.Property(e => e.Division)
                    .HasMaxLength(45)
                    .HasColumnName("division");

                entity.Property(e => e.DouCurrCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_curr_ctc");

                entity.Property(e => e.DouNewCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_new_ctc");

                entity.Property(e => e.DtConfirmDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CONFIRM_DATE");

                entity.Property(e => e.DtCurDoj)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CUR_DOJ");

                entity.Property(e => e.DtLeaveDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_LEAVE_DATE");

                entity.Property(e => e.DtNomineeFatherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_FATHER_DOB");

                entity.Property(e => e.DtNomineeMotherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_MOTHER_DOB");

                entity.Property(e => e.DtNomineeSpouseDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_SPOUSE_DOB");

                entity.Property(e => e.DtPerDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PER_DOB");

                entity.Property(e => e.DtPrevFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE");

                entity.Property(e => e.DtPrevFromDate1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE1");

                entity.Property(e => e.DtPrevToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE");

                entity.Property(e => e.DtPrevToDate2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE2");

                entity.Property(e => e.DtProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PROBATION_DATE");

                entity.Property(e => e.DtResigDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_RESIG_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EmpCode)
                    .HasMaxLength(45)
                    .HasColumnName("emp_code");

                entity.Property(e => e.EmpDetailInfoSeq).HasColumnName("emp_detail_info_seq");

                entity.Property(e => e.EmpName)
                    .HasMaxLength(100)
                    .HasColumnName("emp_name");

                entity.Property(e => e.Gender)
                    .HasMaxLength(45)
                    .HasColumnName("gender");

                entity.Property(e => e.Grade)
                    .HasMaxLength(45)
                    .HasColumnName("grade");

                entity.Property(e => e.IntAppraisalCount).HasColumnName("int_appraisal_count");

                entity.Property(e => e.IntCategorySeqId).HasColumnName("INT_CATEGORY_SEQ_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("int_company_role_id");

                entity.Property(e => e.IntEmpSalaryDtls)
                    .HasPrecision(20)
                    .HasColumnName("int_emp_salary_dtls");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("INT_EMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntGradeId).HasColumnName("int_grade_id");

                entity.Property(e => e.IntNimineeSeqId).HasColumnName("int_niminee_seq_id");

                entity.Property(e => e.IntPrevCtc).HasColumnName("INT_PREV_CTC");

                entity.Property(e => e.IntPrevCtc1).HasColumnName("INT_PREV_CTC1");

                entity.Property(e => e.IntPreviCtc).HasColumnName("INT_PREVI_CTC");

                entity.Property(e => e.JoinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("join_date");

                entity.Property(e => e.LeavingDate)
                    .HasColumnType("datetime")
                    .HasColumnName("leaving_date");

                entity.Property(e => e.Location).HasColumnName("location");

                entity.Property(e => e.PersonalInfo).HasColumnName("personal_info");

                entity.Property(e => e.PresentCostCenter).HasColumnName("PRESENT_COST_CENTER");

                entity.Property(e => e.PresentDepartment).HasColumnName("PRESENT_DEPARTMENT");

                entity.Property(e => e.PresentDesignation).HasColumnName("PRESENT_DESIGNATION");

                entity.Property(e => e.PresentGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PRESENT_GRADE");

                entity.Property(e => e.PresentLocation).HasColumnName("PRESENT_LOCATION");

                entity.Property(e => e.ProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("probation_date");

                entity.Property(e => e.PtLocation)
                    .HasMaxLength(45)
                    .HasColumnName("pt_location");

                entity.Property(e => e.Reference)
                    .HasMaxLength(45)
                    .HasColumnName("reference");

                entity.Property(e => e.ReportTo)
                    .HasMaxLength(45)
                    .HasColumnName("report_to");

                entity.Property(e => e.ReportingManagerName).HasColumnName("REPORTING_MANAGER_NAME");

                entity.Property(e => e.ResignationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("resignation_date");

                entity.Property(e => e.Role).HasColumnName("role");

                entity.Property(e => e.RoleChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("role_change_date");

                entity.Property(e => e.SalaryDtl).HasColumnName("salary_dtl");

                entity.Property(e => e.Status)
                    .HasMaxLength(45)
                    .HasColumnName("status");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VarBranch)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_BRANCH");

                entity.Property(e => e.VarDipDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_DEPART");

                entity.Property(e => e.VarDipInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_INSTITUTION");

                entity.Property(e => e.VarDipMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_MEDIUM");

                entity.Property(e => e.VarDipPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_PERCENTAGE");

                entity.Property(e => e.VarDipUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_UNIVERSITY");

                entity.Property(e => e.VarDipYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_FROM");

                entity.Property(e => e.VarDipYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_TO");

                entity.Property(e => e.VarDivision)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_DIVISION");

                entity.Property(e => e.VarHsLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_LOCATION");

                entity.Property(e => e.VarHsPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_PERCENTAGE");

                entity.Property(e => e.VarHsSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_SCH_NAME");

                entity.Property(e => e.VarHsUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_UNIVERSITY");

                entity.Property(e => e.VarHsYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_YR_COMPLETE");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(80)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycDlNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_DL_NO");

                entity.Property(e => e.VarKycEpsNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_EPS_NO");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VarMailId)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_MAIL_ID");

                entity.Property(e => e.VarNomineeFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_FATHER_NAME");

                entity.Property(e => e.VarNomineeMotherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_MOTHER_NAME");

                entity.Property(e => e.VarNomineeNoOfChildren)
                    .HasMaxLength(5)
                    .HasColumnName("VAR_NOMINEE_NO_OF_CHILDREN");

                entity.Property(e => e.VarNomineeSpouseName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_SPOUSE_NAME");

                entity.Property(e => e.VarPerAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS1");

                entity.Property(e => e.VarPerAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS2");

                entity.Property(e => e.VarPerAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_ADDRESS3");

                entity.Property(e => e.VarPerBg)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_BG");

                entity.Property(e => e.VarPerCity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CITY");

                entity.Property(e => e.VarPerCountry)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_COUNTRY");

                entity.Property(e => e.VarPerCurrAddress1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS1");

                entity.Property(e => e.VarPerCurrAddress2)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS2");

                entity.Property(e => e.VarPerCurrCity)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_CITY");

                entity.Property(e => e.VarPerCurrCountry)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_COUNTRY");

                entity.Property(e => e.VarPerCurrPincode)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_PINCODE");

                entity.Property(e => e.VarPerCurrState)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_STATE");

                entity.Property(e => e.VarPerEmail)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_EMAIL");

                entity.Property(e => e.VarPerFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FATHER_NAME");

                entity.Property(e => e.VarPerGender)
                    .HasMaxLength(6)
                    .HasColumnName("VAR_PER_GENDER");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_last_name");

                entity.Property(e => e.VarPerMaritialStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_MARITIAL_STATUS");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_middle_name");

                entity.Property(e => e.VarPerMobileNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_MOBILE_NO");

                entity.Property(e => e.VarPerNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PER_NATIONALITY");

                entity.Property(e => e.VarPerPanNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_PAN_NO");

                entity.Property(e => e.VarPerPincode)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_PER_PINCODE");

                entity.Property(e => e.VarPerReligion)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_RELIGION");

                entity.Property(e => e.VarPerState)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_STATE");

                entity.Property(e => e.VarPgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_DEPART");

                entity.Property(e => e.VarPgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_INSTITUTION");

                entity.Property(e => e.VarPgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_MEDIUM");

                entity.Property(e => e.VarPgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_PERCENTAGE");

                entity.Property(e => e.VarPgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_UNIVERSITY");

                entity.Property(e => e.VarPgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_FROM");

                entity.Property(e => e.VarPgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_TO");

                entity.Property(e => e.VarPreCompany)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_COMPANY");

                entity.Property(e => e.VarPreCurrAddress3)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_ADDRESS3");

                entity.Property(e => e.VarPreCurrNationality)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_CURR_NATIONALITY");

                entity.Property(e => e.VarPreLocation)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_LOCATION");

                entity.Property(e => e.VarPreRefPersion)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSION");

                entity.Property(e => e.VarPreRefPersions)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_PRE_REF_PERSIONS");

                entity.Property(e => e.VarPrevAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS1");

                entity.Property(e => e.VarPrevAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS2");

                entity.Property(e => e.VarPrevEmpName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME");

                entity.Property(e => e.VarPrevEmpName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME1");

                entity.Property(e => e.VarPrevLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION");

                entity.Property(e => e.VarPrevLocation1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION1");

                entity.Property(e => e.VarPrevReferDesig)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG");

                entity.Property(e => e.VarPrevReferDesig1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG1");

                entity.Property(e => e.VarPrevReferId)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID");

                entity.Property(e => e.VarPrevReferId1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID1");

                entity.Property(e => e.VarPrevReferName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME");

                entity.Property(e => e.VarPrevReferName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME1");

                entity.Property(e => e.VarSslcLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_LOCATION");

                entity.Property(e => e.VarSslcPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_PERCENTAGE");

                entity.Property(e => e.VarSslcSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_SCH_NAME");

                entity.Property(e => e.VarSslcUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_UNIVERSITY");

                entity.Property(e => e.VarSslcYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_YR_COMPLETE");

                entity.Property(e => e.VarStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_STATUS");

                entity.Property(e => e.VarUgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_DEPART");

                entity.Property(e => e.VarUgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_INSTITUTION");

                entity.Property(e => e.VarUgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_MEDIUM");

                entity.Property(e => e.VarUgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_PERCENTAGE");

                entity.Property(e => e.VarUgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_UNIVERSITY");

                entity.Property(e => e.VarUgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_FROM");

                entity.Property(e => e.VarUgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_TO");

                entity.Property(e => e.VchCostcenterName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_costcenter_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDepartmentName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_department_name");

                entity.Property(e => e.VchDesignationName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_designation_name");

                entity.Property(e => e.VchEmpCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_EMP_CODE");

                entity.Property(e => e.VchEmpcategoryName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_empcategory_name");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_location_name");

                entity.Property(e => e.VchMailid)
                    .HasMaxLength(50)
                    .HasColumnName("vch_mailid");

                entity.Property(e => e.VchPanCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pan_code");

                entity.Property(e => e.VchPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_password");

                entity.Property(e => e.VchPhoneNo)
                    .HasMaxLength(15)
                    .HasColumnName("vch_phone_no");

                entity.Property(e => e.VchReptCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_code");

                entity.Property(e => e.VchReptName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_name");

                entity.Property(e => e.VchRoleAssignBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_role_assign_by");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_role_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(50)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<EmployeeSalaryAuditLog>(entity =>
            {
                entity.HasKey(e => e.IntEmpSalDtlId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_salary_audit_log");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_sal_audit_comp_id");

                entity.Property(e => e.IntEmpSalDtlId).HasColumnName("INT_EMP_SAL_DTL_ID");

                entity.Property(e => e.DtEffictiveFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_EFFICTIVE_FROM");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntCtcDiff).HasColumnName("INT_CTC_DIFF");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("INT_EMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntNewBasic).HasColumnName("INT_NEW_BASIC");

                entity.Property(e => e.IntNewConveyance).HasColumnName("INT_NEW_CONVEYANCE");

                entity.Property(e => e.IntNewCtc).HasColumnName("INT_NEW_CTC");

                entity.Property(e => e.IntNewDa).HasColumnName("INT_NEW_DA");

                entity.Property(e => e.IntNewHra).HasColumnName("INT_NEW_HRA");

                entity.Property(e => e.IntNewSplAllowance).HasColumnName("INT_NEW_SPL_ALLOWANCE");

                entity.Property(e => e.IntOldBasic).HasColumnName("INT_OLD_BASIC");

                entity.Property(e => e.IntOldConveyance).HasColumnName("INT_OLD_CONVEYANCE");

                entity.Property(e => e.IntOldCtc).HasColumnName("INT_OLD_CTC");

                entity.Property(e => e.IntOldDa).HasColumnName("INT_OLD_DA");

                entity.Property(e => e.IntOldHra).HasColumnName("INT_OLD_HRA");

                entity.Property(e => e.IntOldSplAllowance).HasColumnName("INT_OLD_SPL_ALLOWANCE");

                entity.Property(e => e.IntReimCar1).HasColumnName("INT_REIM_CAR1");

                entity.Property(e => e.IntReimCar2).HasColumnName("INT_REIM_CAR2");

                entity.Property(e => e.IntReimDriver1).HasColumnName("INT_REIM_DRIVER1");

                entity.Property(e => e.IntReimDriver2).HasColumnName("INT_REIM_DRIVER2");

                entity.Property(e => e.IntReimMedical1).HasColumnName("INT_REIM_MEDICAL1");

                entity.Property(e => e.IntReimMedical2).HasColumnName("INT_REIM_MEDICAL2");

                entity.Property(e => e.IntReimTelephone1).HasColumnName("INT_REIM_TELEPHONE1");

                entity.Property(e => e.IntReimTelephone2).HasColumnName("INT_REIM_TELEPHONE2");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_OPERATION");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeSalaryAuditLogs)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_sal_audit_comp_id");
            });

            modelBuilder.Entity<EmployeeSalaryDetail>(entity =>
            {
                entity.HasKey(e => e.IntEmpSalDtlId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_salary_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_emp_m_salary_emp_seq_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_emp_sal_det_company_id");

                entity.Property(e => e.IntEmpSalDtlId).HasColumnName("int_emp_sal_dtl_id");

                entity.Property(e => e.DtEffictiveFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_effictive_from");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCtcDiff).HasColumnName("int_ctc_diff");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNewBasic).HasColumnName("int_new_basic");

                entity.Property(e => e.IntNewConveyance).HasColumnName("int_new_conveyance");

                entity.Property(e => e.IntNewCtc).HasColumnName("int_new_ctc");

                entity.Property(e => e.IntNewDa).HasColumnName("int_new_da");

                entity.Property(e => e.IntNewHra).HasColumnName("int_new_hra");

                entity.Property(e => e.IntNewSplAllowance).HasColumnName("int_new_spl_allowance");

                entity.Property(e => e.IntOldBasic).HasColumnName("int_old_basic");

                entity.Property(e => e.IntOldConveyance).HasColumnName("int_old_conveyance");

                entity.Property(e => e.IntOldCtc).HasColumnName("int_old_ctc");

                entity.Property(e => e.IntOldDa).HasColumnName("int_old_da");

                entity.Property(e => e.IntOldHra).HasColumnName("int_old_hra");

                entity.Property(e => e.IntOldSplAllowance).HasColumnName("int_old_spl_allowance");

                entity.Property(e => e.IntOnboardInitiationSeqId).HasColumnName("int_onboard_initiation_seq_id");

                entity.Property(e => e.IntReimCar1).HasColumnName("int_reim_car1");

                entity.Property(e => e.IntReimCar2).HasColumnName("int_reim_car2");

                entity.Property(e => e.IntReimDriver1).HasColumnName("int_reim_driver1");

                entity.Property(e => e.IntReimDriver2).HasColumnName("int_reim_driver2");

                entity.Property(e => e.IntReimMedical1).HasColumnName("int_reim_medical1");

                entity.Property(e => e.IntReimMedical2).HasColumnName("int_reim_medical2");

                entity.Property(e => e.IntReimTelephone1).HasColumnName("int_reim_telephone1");

                entity.Property(e => e.IntReimTelephone2).HasColumnName("int_reim_telephone2");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeSalaryDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_emp_sal_det_company_id");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.EmployeeSalaryDetails)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_emp_m_salary_emp_seq_id");
            });

            modelBuilder.Entity<EmployeeSalaryDetailsMakerChecker>(entity =>
            {
                entity.HasKey(e => e.IntEmpSalDtlId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_salary_details_maker_checker");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_emp_m_salary_emp_seq_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_emp_sal_det_company_id");

                entity.Property(e => e.IntEmpSalDtlId).HasColumnName("int_emp_sal_dtl_id");

                entity.Property(e => e.DtEffictiveFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_effictive_from");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntAnnuVariablePay1).HasColumnName("int_annu_variable_pay1");

                entity.Property(e => e.IntAnnuVariablePay2).HasColumnName("int_annu_variable_pay2");

                entity.Property(e => e.IntBooksPeriodic1).HasColumnName("int_books_periodic1");

                entity.Property(e => e.IntBooksPeriodic2).HasColumnName("int_books_periodic2");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCtcDiff).HasColumnName("int_ctc_diff");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntFoodAllovance1).HasColumnName("int_food_allovance1");

                entity.Property(e => e.IntFoodAllovance2).HasColumnName("int_food_allovance2");

                entity.Property(e => e.IntNewBasic).HasColumnName("int_new_basic");

                entity.Property(e => e.IntNewConveyance).HasColumnName("int_new_conveyance");

                entity.Property(e => e.IntNewCtc).HasColumnName("int_new_ctc");

                entity.Property(e => e.IntNewDa).HasColumnName("int_new_da");

                entity.Property(e => e.IntNewHra).HasColumnName("int_new_hra");

                entity.Property(e => e.IntNewSplAllowance).HasColumnName("int_new_spl_allowance");

                entity.Property(e => e.IntOldBasic).HasColumnName("int_old_basic");

                entity.Property(e => e.IntOldConveyance).HasColumnName("int_old_conveyance");

                entity.Property(e => e.IntOldCtc).HasColumnName("int_old_ctc");

                entity.Property(e => e.IntOldDa).HasColumnName("int_old_da");

                entity.Property(e => e.IntOldHra).HasColumnName("int_old_hra");

                entity.Property(e => e.IntOldSplAllowance).HasColumnName("int_old_spl_allowance");

                entity.Property(e => e.IntOnboardInitiationSeqId).HasColumnName("int_onboard_initiation_seq_id");

                entity.Property(e => e.IntReimAttire1).HasColumnName("int_reim_attire1");

                entity.Property(e => e.IntReimAttire2).HasColumnName("int_reim_attire2");

                entity.Property(e => e.IntReimCar1).HasColumnName("int_reim_car1");

                entity.Property(e => e.IntReimCar2).HasColumnName("int_reim_car2");

                entity.Property(e => e.IntReimDriver1).HasColumnName("int_reim_driver1");

                entity.Property(e => e.IntReimDriver2).HasColumnName("int_reim_driver2");

                entity.Property(e => e.IntReimMedical1).HasColumnName("int_reim_medical1");

                entity.Property(e => e.IntReimMedical2).HasColumnName("int_reim_medical2");

                entity.Property(e => e.IntReimTelephone1).HasColumnName("int_reim_telephone1");

                entity.Property(e => e.IntReimTelephone2).HasColumnName("int_reim_telephone2");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.EmployeeSalaryDetailsMakerCheckers)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_emp_sal_maker_det_company_id");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.EmployeeSalaryDetailsMakerCheckers)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_emp_m_salary_maker_emp_seq_id");
            });

            modelBuilder.Entity<EmploymentTypeMaster>(entity =>
            {
                entity.HasKey(e => e.IntEmploymentTypeId)
                    .HasName("PRIMARY");

                entity.ToTable("employment_type_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmploymentTypeId).HasColumnName("INT_EMPLOYMENT_TYPE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmploymentTypeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_EMPLOYMENT_TYPE_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmploymentTypeMasterTmp>(entity =>
            {
                entity.HasKey(e => e.IntEmploymentTypeId)
                    .HasName("PRIMARY");

                entity.ToTable("employment_type_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmploymentTypeId).HasColumnName("INT_EMPLOYMENT_TYPE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmploymentTypeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_EMPLOYMENT_TYPE_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ExitMasAn>(entity =>
            {
                entity.HasKey(e => e.IntAnsId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_mas_ans");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntExEmpreqId, "FK_EXIT_EMP_REQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "fk_exit_ans_companyid");

                entity.HasIndex(e => e.ExitTemplateItemId, "fk_exit_ans_template_items");

                entity.HasIndex(e => e.ExitTemplateId, "fk_exit_template");

                entity.Property(e => e.IntAnsId).HasColumnName("INT_ANS_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.ExitTemplateId).HasColumnName("exit_template_id");

                entity.Property(e => e.ExitTemplateItemId).HasColumnName("exit_template_item_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntExEmpreqId).HasColumnName("INT_EX_EMPREQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchAnswer)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_ANSWER");

                entity.Property(e => e.VchAnsweredStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_answered_status");

                entity.Property(e => e.VchComments)
                    .HasMaxLength(1000)
                    .HasColumnName("VCH_COMMENTS");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchQuesType)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_QUES_TYPE");

                entity.Property(e => e.VchQuestDesc)
                    .HasMaxLength(166)
                    .HasColumnName("VCH_QUEST_DESC");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.ExitTemplate)
                    .WithMany(p => p.ExitMasAns)
                    .HasForeignKey(d => d.ExitTemplateId)
                    .HasConstraintName("fk_exit_template");

                

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitMasAns)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_exit_ansitem_companyid");

                entity.HasOne(d => d.IntExEmpreq)
                    .WithMany(p => p.ExitMasAns)
                    .HasForeignKey(d => d.IntExEmpreqId)
                    .HasConstraintName("FK_EXIT_EMP_REQ_ID");
            });

            modelBuilder.Entity<ExitMasEmployeeMap>(entity =>
            {
                entity.HasKey(e => e.IntEmpMapId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_mas_employee_map");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_exit_map_companyid");

                entity.HasIndex(e => e.IntEmpId, "fk_exit_map_confreq_emp_id");

                entity.HasIndex(e => e.ExitTemplateId, "fk_exit_map_template");

                entity.Property(e => e.IntEmpMapId).HasColumnName("INT_EMP_MAP_ID");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update_date");

                entity.Property(e => e.ExitTemplateId).HasColumnName("exit_template_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId).HasColumnName("int_emp_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.HasOne(d => d.ExitTemplate)
                    .WithMany(p => p.ExitMasEmployeeMaps)
                    .HasForeignKey(d => d.ExitTemplateId)
                    .HasConstraintName("fk_exit_map_template");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitMasEmployeeMaps)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_exit_map_companyid");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.ExitMasEmployeeMaps)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("fk_exit_map_confreq_emp_id");
            });

            modelBuilder.Entity<ExitMasQuestion>(entity =>
            {
                entity.HasKey(e => e.IntQuestionId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_mas_question");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_exit_mas_ques");

                entity.Property(e => e.IntQuestionId).HasColumnName("INT_QUESTION_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntNoOfChars).HasColumnName("INT_NO_OF_CHARS");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchChoices)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_choices");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchKeyName1)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_KEY_NAME1");

                entity.Property(e => e.VchKeyName2)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_KEY_NAME2");

                entity.Property(e => e.VchQuestionDesc)
                    .HasMaxLength(166)
                    .HasColumnName("VCH_QUESTION_DESC");

                entity.Property(e => e.VchQuestionName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_QUESTION_NAME");

                entity.Property(e => e.VchQuestionType)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_QUESTION_TYPE")
                    .HasComment("O - Open ended,C - Close ended,S - Single choice,R - Rating");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitMasQuestions)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_exit_mas_ques");
            });

            modelBuilder.Entity<ExitMasQuestionTemplate>(entity =>
            {
                entity.HasKey(e => e.ExitTemplateId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_mas_question_template");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_exit_questemplate_companyid");

                entity.Property(e => e.ExitTemplateId).HasColumnName("exit_template_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntNoOfQuestions).HasColumnName("int_no_of_questions");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDefaultTemp)
                    .HasMaxLength(3)
                    .HasColumnName("vch_default_temp");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchQuestionTemplName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_question_templ_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitMasQuestionTemplates)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_exit_questemplate_companyid");
            });

            modelBuilder.Entity<ExitMasQuestionTemplateItem>(entity =>
            {
                entity.HasKey(e => e.ExitTemplateItemId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_mas_question_template_items");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntQuestionId, "fk_exit_quest_questionid");

                entity.HasIndex(e => e.IntCompanyId, "fk_exit_questemplate_int_company_id_idx");

                entity.HasIndex(e => e.ExitTemplateId, "fk_exit_questemplate_templateid");

                entity.Property(e => e.ExitTemplateItemId).HasColumnName("exit_template_item_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.ExitTemplateId).HasColumnName("exit_template_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntQuestionId).HasColumnName("INT_QUESTION_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchQuesDesc)
                    .HasMaxLength(166)
                    .HasColumnName("vch_ques_desc");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                
            });

            modelBuilder.Entity<ExitMasResignation>(entity =>
            {
                entity.HasKey(e => e.IntResigId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_mas_resignation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_EXIT_M_RESIGNATION");

                entity.Property(e => e.IntResigId)
                    .HasColumnName("INT_RESIG_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DtUpdateDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchReasonResignation)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_REASON_RESIGNATION")
                    .HasComment("Reason for resignations");

                entity.Property(e => e.VchResignationType)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_RESIGNATION_TYPE")
                    .HasComment("V-voluntary,I-Invaluntary");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitMasResignations)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EXIT_M_RESIGNATION");
            });

            modelBuilder.Entity<ExitTransClearance>(entity =>
            {
                entity.HasKey(e => e.IntExClearanceId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_trans_clearance");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_EX_T_CLEARANCE_COMPANY_ID_idx");

                entity.HasIndex(e => e.IntExEmpreqId, "FK_EX_T_CLEARANCE_EMPREQ_ID");

                entity.Property(e => e.IntExClearanceId)
                    .HasColumnName("INT_EX_CLEARANCE_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntExEmpreqId)
                    .HasColumnName("INT_EX_EMPREQ_ID")
                    .HasComment("Reference from ExitRequest table(EXIT_TRANS_EMPREQUEST)");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchAmount)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_AMOUNT");

                entity.Property(e => e.VchClearanceDept)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_CLEARANCE_DEPT")
                    .HasComment("A-Admin,F-Finance,I-It,H-HR");

                entity.Property(e => e.VchItem)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_ITEM");

                entity.Property(e => e.VchRemark)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_REMARK");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitTransClearances)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EX_T_CLEARANCE_COMPANY_ID");

                entity.HasOne(d => d.IntExEmpreq)
                    .WithMany(p => p.ExitTransClearances)
                    .HasForeignKey(d => d.IntExEmpreqId)
                    .HasConstraintName("FK_EX_T_CLEARANCE_EMPREQ_ID");
            });

            modelBuilder.Entity<ExitTransEmprequest>(entity =>
            {
                entity.HasKey(e => e.IntExEmpreqId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_trans_emprequest");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_EXIT_T_EMP_REQ");

                entity.HasIndex(e => e.IntEmpId, "FK_EX_M_EMPREQ_EMP_ID");

                entity.HasIndex(e => e.IntResigId, "FK_EX_M_EMPREQ_RESIG_ID");

                entity.HasIndex(e => e.IntResignacceptLetterId, "fk_resignation_temp_idx");

                entity.Property(e => e.IntExEmpreqId)
                    .HasColumnName("INT_EX_EMPREQ_ID")
                    .HasComment("PRIMARY KEY OF A TABLE");

                entity.Property(e => e.DtChequeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CHEQUE_DATE");

                entity.Property(e => e.DtDol)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOL")
                    .HasComment("Storing temporaraly Date of leave\n");

                entity.Property(e => e.DtDor)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOR")
                    .HasComment("Storing temporaraly Date of resignation\n");

                entity.Property(e => e.DtInitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_INIT_DATE");

                entity.Property(e => e.DtLetterGenDate).HasColumnName("dt_letter_gen_date");

                entity.Property(e => e.DtRequestedDol)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_REQUESTED_DOL");

                entity.Property(e => e.DtResignationLetterGenDate).HasColumnName("dt_resignation_letter_gen_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("INT_EMP_ID")
                    .HasComment("REFERENCE FROM EMPLOYEE MASTER(employee_master)");

                entity.Property(e => e.IntNoticePeriodRecovery).HasColumnName("INT_NOTICE_PERIOD_RECOVERY");

                entity.Property(e => e.IntNoticePeriodToBeWaved).HasColumnName("INT_NOTICE_PERIOD_TO_BE_WAVED");

                entity.Property(e => e.IntNoticePeriodToServe).HasColumnName("INT_NOTICE_PERIOD_TO_SERVE");

                entity.Property(e => e.IntResigId)
                    .HasColumnName("INT_RESIG_ID")
                    .HasComment("REFERENCE FROM rESIGNATION TABLE(EXIT_MAS_RESIGNATION)");

                entity.Property(e => e.IntResignacceptLetterId).HasColumnName("int_resignaccept_letter_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchAdminStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ADMIN_STATUS")
                    .HasComment("DEFAULT N-NO,Y-YES");

                entity.Property(e => e.VchAnswered)
                    .HasMaxLength(3)
                    .HasColumnName("vch_answered");

                entity.Property(e => e.VchApproveHr)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_APPROVE_HR");

                entity.Property(e => e.VchApproveRm)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_APPROVE_RM");

                entity.Property(e => e.VchChkNumber)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_CHK_NUMBER");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmployeeCommnets)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_EMPLOYEE_COMMNETS")
                    .HasComment("FOR EMPLOYEE COMMENTS");

                entity.Property(e => e.VchExitStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_EXIT_STATUS")
                    .HasComment("EXIT STATUS( MAIN STATUS)");

                entity.Property(e => e.VchFinanceStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_FINANCE_STATUS")
                    .HasComment("DEFAULT N-NO,Y-YES");

                entity.Property(e => e.VchFnfAmt)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_FNF_AMT");

                entity.Property(e => e.VchFnfPaymentComment)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_FNF_PAYMENT_COMMENT");

                entity.Property(e => e.VchHrComments)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_HR_COMMENTS")
                    .HasComment("FOR HR COMMENTS");

                entity.Property(e => e.VchHrFnfComment)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_HR_FNF_COMMENT");

                entity.Property(e => e.VchItStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_IT_STATUS")
                    .HasComment("DEFAULT N-NO,Y-YES");

                entity.Property(e => e.VchLearningStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_LEARNING_STATUS");

                entity.Property(e => e.VchLetterGenPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_letter_gen_path");

                entity.Property(e => e.VchResignationLetterGenPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_resignation_letter_gen_path")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.VchRmComments)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_RM_COMMENTS")
                    .HasComment("FOR RM COMMENTS");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitTransEmprequests)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EXIT_T_EMP_REQ");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.ExitTransEmprequests)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("FK_EX_M_EMPREQ_EMP_ID");

                entity.HasOne(d => d.IntResig)
                    .WithMany(p => p.ExitTransEmprequests)
                    .HasForeignKey(d => d.IntResigId)
                    .HasConstraintName("FK_EX_M_EMPREQ_RESIG_ID");

                entity.HasOne(d => d.IntResignacceptLetter)
                    .WithMany(p => p.ExitTransEmprequests)
                    .HasForeignKey(d => d.IntResignacceptLetterId)
                    .HasConstraintName("fk_resignation_temp_idx");
            });

            modelBuilder.Entity<ExitTransEmprequestAuditLog>(entity =>
            {
                entity.HasKey(e => e.IntExEmpreqAuditId)
                    .HasName("PRIMARY");

                entity.ToTable("exit_trans_emprequest_audit_log");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_EXIT_T_EMP_REQ_AUDIT");

                entity.HasIndex(e => e.IntEmpId, "FK_EX_M_EMPREQ_EMP_ID_AUDIT");

                entity.HasIndex(e => e.IntResigId, "FK_EX_M_EMPREQ_RESIG_ID_AUDIT");

                entity.HasIndex(e => e.IntResignacceptLetterId, "fk_resignation_temp_idx_AUDIT");

                entity.Property(e => e.IntExEmpreqAuditId)
                    .HasColumnName("INT_EX_EMPREQ_AUDIT_ID")
                    .HasComment("PRIMARY KEY OF A TABLE");

                entity.Property(e => e.DtChequeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CHEQUE_DATE");

                entity.Property(e => e.DtDol)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOL")
                    .HasComment("Storing temporaraly Date of leave\n");

                entity.Property(e => e.DtDor)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOR")
                    .HasComment("Storing temporaraly Date of resignation\n");

                entity.Property(e => e.DtInitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_INIT_DATE");

                entity.Property(e => e.DtLetterGenDate).HasColumnName("dt_letter_gen_date");

                entity.Property(e => e.DtRequestedDol)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_REQUESTED_DOL");

                entity.Property(e => e.DtResignationLetterGenDate).HasColumnName("dt_resignation_letter_gen_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("INT_EMP_ID")
                    .HasComment("REFERENCE FROM EMPLOYEE MASTER(employee_master)");

                entity.Property(e => e.IntNoticePeriodRecovery).HasColumnName("INT_NOTICE_PERIOD_RECOVERY");

                entity.Property(e => e.IntNoticePeriodToBeWaved).HasColumnName("INT_NOTICE_PERIOD_TO_BE_WAVED");

                entity.Property(e => e.IntNoticePeriodToServe).HasColumnName("INT_NOTICE_PERIOD_TO_SERVE");

                entity.Property(e => e.IntResigId)
                    .HasColumnName("INT_RESIG_ID")
                    .HasComment("REFERENCE FROM rESIGNATION TABLE(EXIT_MAS_RESIGNATION)");

                entity.Property(e => e.IntResignacceptLetterId).HasColumnName("int_resignaccept_letter_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchAdminStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ADMIN_STATUS")
                    .HasComment("DEFAULT N-NO,Y-YES");

                entity.Property(e => e.VchAnswered)
                    .HasMaxLength(3)
                    .HasColumnName("vch_answered");

                entity.Property(e => e.VchApproveHr)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_APPROVE_HR");

                entity.Property(e => e.VchApproveRm)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_APPROVE_RM");

                entity.Property(e => e.VchChkNumber)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_CHK_NUMBER");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmployeeCommnets)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_EMPLOYEE_COMMNETS")
                    .HasComment("FOR EMPLOYEE COMMENTS");

                entity.Property(e => e.VchExitStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_EXIT_STATUS")
                    .HasComment("EXIT STATUS( MAIN STATUS)");

                entity.Property(e => e.VchFinanceStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_FINANCE_STATUS")
                    .HasComment("DEFAULT N-NO,Y-YES");

                entity.Property(e => e.VchFnfAmt)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_FNF_AMT");

                entity.Property(e => e.VchFnfPaymentComment)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_FNF_PAYMENT_COMMENT");

                entity.Property(e => e.VchHrComments)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_HR_COMMENTS")
                    .HasComment("FOR HR COMMENTS");

                entity.Property(e => e.VchHrFnfComment)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_HR_FNF_COMMENT");

                entity.Property(e => e.VchItStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_IT_STATUS")
                    .HasComment("DEFAULT N-NO,Y-YES");

                entity.Property(e => e.VchLearningStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_LEARNING_STATUS");

                entity.Property(e => e.VchLetterGenPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_letter_gen_path");

                entity.Property(e => e.VchResignationLetterGenPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_resignation_letter_gen_path")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.VchRmComments)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_RM_COMMENTS")
                    .HasComment("FOR RM COMMENTS");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ExitTransEmprequestAuditLogs)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_EXIT_T_EMP_REQ_AUDIT");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.ExitTransEmprequestAuditLogs)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("FK_EX_M_EMPREQ_EMP_ID_AUDIT");

                entity.HasOne(d => d.IntResig)
                    .WithMany(p => p.ExitTransEmprequestAuditLogs)
                    .HasForeignKey(d => d.IntResigId)
                    .HasConstraintName("FK_EX_M_EMPREQ_RESIG_ID_AUDIT");

                entity.HasOne(d => d.IntResignacceptLetter)
                    .WithMany(p => p.ExitTransEmprequestAuditLogs)
                    .HasForeignKey(d => d.IntResignacceptLetterId)
                    .HasConstraintName("fk_resignation_temp_idx_AUDIT");
            });

            modelBuilder.Entity<GenerateSeqNum>(entity =>
            {
                entity.HasKey(e => e.SeqClientAdminNoGenerate)
                    .HasName("PRIMARY");

                entity.ToTable("generate_seq_num");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.SeqClientAdminNoGenerate)
                    .ValueGeneratedNever()
                    .HasColumnName("Seq_client_admin_no_generate");
            });

            modelBuilder.Entity<GenericEmployeeCodeHistory>(entity =>
            {
                entity.HasKey(e => e.GenEmpId)
                    .HasName("PRIMARY");

                entity.ToTable("generic_employee_code_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_gen_emp_code_his_companyid");

                entity.Property(e => e.GenEmpId).HasColumnName("gen_emp_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntIncrementBy).HasColumnName("int_increment_by");

                entity.Property(e => e.IntLastEmpCodeNo).HasColumnName("int_last_emp_code_no");

                entity.Property(e => e.VchEmpCodeFormula)
                    .HasMaxLength(4000)
                    .HasColumnName("vch_emp_code_formula");

                entity.Property(e => e.VchEmployeeCode)
                    .HasMaxLength(100)
                    .HasColumnName("vch_employee_code");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.GenericEmployeeCodeHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_gen_emp_code_his_companyid");
            });

            modelBuilder.Entity<HashOnboardSalaryStructure>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("hash_onboard_salary_structure");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntOnboardInitiationSeqId, "FK_OBST_HASH_OB_INIT_SEQ_ID");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.IntCtcDiff).HasColumnName("INT_CTC_DIFF");

                entity.Property(e => e.IntNewBasic).HasColumnName("INT_NEW_BASIC");

                entity.Property(e => e.IntNewConveyance).HasColumnName("INT_NEW_CONVEYANCE");

                entity.Property(e => e.IntNewCtc).HasColumnName("INT_NEW_CTC");

                entity.Property(e => e.IntNewDa).HasColumnName("INT_NEW_DA");

                entity.Property(e => e.IntNewHra).HasColumnName("INT_NEW_HRA");

                entity.Property(e => e.IntNewSplAllowance).HasColumnName("INT_NEW_SPL_ALLOWANCE");

                entity.Property(e => e.IntOldBasic).HasColumnName("INT_OLD_BASIC");

                entity.Property(e => e.IntOldConveyance).HasColumnName("INT_OLD_CONVEYANCE");

                entity.Property(e => e.IntOldCtc).HasColumnName("INT_OLD_CTC");

                entity.Property(e => e.IntOldDa).HasColumnName("INT_OLD_DA");

                entity.Property(e => e.IntOldHra).HasColumnName("INT_OLD_HRA");

                entity.Property(e => e.IntOldSplAllowance).HasColumnName("INT_OLD_SPL_ALLOWANCE");

                entity.Property(e => e.IntOnboardInitiationSeqId).HasColumnName("INT_ONBOARD_INITIATION_SEQ_ID");

                entity.Property(e => e.IntReimCar1).HasColumnName("INT_REIM_CAR1");

                entity.Property(e => e.IntReimCar2).HasColumnName("INT_REIM_CAR2");

                entity.Property(e => e.IntReimDriver1).HasColumnName("INT_REIM_DRIVER1");

                entity.Property(e => e.IntReimDriver2).HasColumnName("INT_REIM_DRIVER2");

                entity.Property(e => e.IntReimMedical1).HasColumnName("INT_REIM_MEDICAL1");

                entity.Property(e => e.IntReimMedical2).HasColumnName("INT_REIM_MEDICAL2");

                entity.Property(e => e.IntReimTelephone1).HasColumnName("INT_REIM_TELEPHONE1");

                entity.Property(e => e.IntReimTelephone2).HasColumnName("INT_REIM_TELEPHONE2");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CREATED_BY");

                entity.HasOne(d => d.IntOnboardInitiationSeq)
                    .WithMany(p => p.HashOnboardSalaryStructures)
                    .HasForeignKey(d => d.IntOnboardInitiationSeqId)
                    .HasConstraintName("FK_OBST_HASH_OB_INIT_SEQ_ID");
            });

            modelBuilder.Entity<HashOnboardingInitiation>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("hash_onboarding_initiation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.PresentCostCenter, "FK_HASH_OB_PRE_COST_CENTER");

                entity.HasIndex(e => e.PresentDepartment, "FK_HASH_OB_PRE_DEPART");

                entity.HasIndex(e => e.PresentDesignation, "FK_HASH_OB_PRE_DESIG");

                entity.HasIndex(e => e.PresentLocation, "FK_HASH_OB_PRE_LOCATION");

                entity.HasIndex(e => e.MidPoints, "FK_HASH_ONB_MIDPOINT");

                entity.HasIndex(e => e.ReportingManagerName, "FK_HASH_ON_INI_REP_MAN_NAME");

                entity.HasIndex(e => e.Departments, "FK_hash_MAS_DEPARTMENTS_MASTER");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.Departments).HasColumnName("departments");

                entity.Property(e => e.IntCategoryId).HasColumnName("int_category_id");

                entity.Property(e => e.IntCtcDifference).HasColumnName("int_ctc_difference");

                entity.Property(e => e.IntNewCtc).HasColumnName("int_new_ctc");

                entity.Property(e => e.MidPoints).HasColumnName("mid_points");

                entity.Property(e => e.PersonalAadharCard)
                    .HasMaxLength(15)
                    .HasColumnName("personal_aadhar_card");

                entity.Property(e => e.PersonalAddress1)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_ADDRESS1");

                entity.Property(e => e.PersonalAddress2)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_ADDRESS2");

                entity.Property(e => e.PersonalAddress3)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_ADDRESS3");

                entity.Property(e => e.PersonalDob)
                    .HasColumnType("datetime")
                    .HasColumnName("PERSONAL_DOB");

                entity.Property(e => e.PersonalEmailId)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_EMAIL_ID");

                entity.Property(e => e.PersonalFirstName)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_FIRST_NAME");

                entity.Property(e => e.PersonalLastName)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_LAST_NAME");

                entity.Property(e => e.PersonalLocation)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_LOCATION");

                entity.Property(e => e.PersonalMiddleName)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_MIDDLE_NAME");

                entity.Property(e => e.PersonalMobileNum)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_MOBILE_NUM");

                entity.Property(e => e.PersonalPanNum)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_PAN_NUM");

                entity.Property(e => e.PersonalRefId)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_REF_ID");

                entity.Property(e => e.PresentCostCenter).HasColumnName("PRESENT_COST_CENTER");

                entity.Property(e => e.PresentDepartment).HasColumnName("PRESENT_DEPARTMENT");

                entity.Property(e => e.PresentDesignation).HasColumnName("PRESENT_DESIGNATION");

                entity.Property(e => e.PresentDoj)
                    .HasColumnType("datetime")
                    .HasColumnName("PRESENT_DOJ");

                entity.Property(e => e.PresentGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PRESENT_GRADE");

                entity.Property(e => e.PresentLocation).HasColumnName("PRESENT_LOCATION");

                entity.Property(e => e.PreviousAddress1)
                    .HasMaxLength(300)
                    .HasColumnName("PREVIOUS_ADDRESS1");

                entity.Property(e => e.PreviousAddress2)
                    .HasMaxLength(300)
                    .HasColumnName("PREVIOUS_ADDRESS2");

                entity.Property(e => e.PreviousCompanyName)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_COMPANY_NAME");

                entity.Property(e => e.PreviousCtc)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_CTC");

                entity.Property(e => e.PreviousDepartment)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_DEPARTMENT");

                entity.Property(e => e.PreviousDesignation)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_DESIGNATION");

                entity.Property(e => e.PreviousGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_GRADE");

                entity.Property(e => e.PreviousLocation)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_LOCATION");

                entity.Property(e => e.PreviousReferralMobile)
                    .HasMaxLength(13)
                    .HasColumnName("PREVIOUS_REFERRAL_MOBILE");

                entity.Property(e => e.PreviousReferralPerson)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_REFERRAL_PERSON");

                entity.Property(e => e.RaisedByPerson)
                    .HasMaxLength(50)
                    .HasColumnName("RAISED_BY_PERSON");

                entity.Property(e => e.RejectionRemark)
                    .HasMaxLength(50)
                    .HasColumnName("REJECTION_REMARK");

                entity.Property(e => e.ReportingManagerDesi)
                    .HasMaxLength(80)
                    .HasColumnName("REPORTING_MANAGER_DESI");

                entity.Property(e => e.ReportingManagerName).HasColumnName("REPORTING_MANAGER_NAME");

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .HasColumnName("STATUS");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.HasOne(d => d.DepartmentsNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.Departments)
                    .HasConstraintName("FK_hash_MAS_DEPARTMENTS_MASTER");

                entity.HasOne(d => d.MidPointsNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.MidPoints)
                    .HasConstraintName("FK_HASH_ONB_MIDPOINT");

                entity.HasOne(d => d.PresentCostCenterNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.PresentCostCenter)
                    .HasConstraintName("FK_HASH_OB_PRE_COST_CENTER");

                entity.HasOne(d => d.PresentDepartmentNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.PresentDepartment)
                    .HasConstraintName("FK_HASH_OB_PRE_DEPART");

                entity.HasOne(d => d.PresentDesignationNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.PresentDesignation)
                    .HasConstraintName("FK_HASH_OB_PRE_DESIG");

                entity.HasOne(d => d.PresentLocationNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.PresentLocation)
                    .HasConstraintName("FK_HASH_OB_PRE_LOCATION");

                entity.HasOne(d => d.ReportingManagerNameNavigation)
                    .WithMany(p => p.HashOnboardingInitiations)
                    .HasForeignKey(d => d.ReportingManagerName)
                    .HasConstraintName("FK_HASH_ON_INI_REP_MAN_NAME");
            });

            modelBuilder.Entity<ItsRoleSfiaMaster>(entity =>
            {
                entity.HasKey(e => e.IntItsRoleSfiaId)
                    .HasName("PRIMARY");

                entity.ToTable("its_role_sfia_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntItsRoleSfiaId).HasColumnName("INT_ITS_ROLE_SFIA_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchItsRoleSfiaValue)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_ITS_ROLE_SFIA_VALUE");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ItsRoleSfiaMasterTmp>(entity =>
            {
                entity.HasKey(e => e.IntItsRoleSfiaId)
                    .HasName("PRIMARY");

                entity.ToTable("its_role_sfia_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntItsRoleSfiaId).HasColumnName("INT_ITS_ROLE_SFIA_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchItsRoleSfiaValue)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_ITS_ROLE_SFIA_VALUE");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<JhiAuthority>(entity =>
            {
                entity.HasKey(e => e.Name)
                    .HasName("PRIMARY");

                entity.ToTable("jhi_authority");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<JhiPersistentAuditEvent>(entity =>
            {
                entity.HasKey(e => e.EventId)
                    .HasName("PRIMARY");

                entity.ToTable("jhi_persistent_audit_event");

                entity.HasIndex(e => new { e.Principal, e.EventDate }, "idx_persistent_audit_event");

                entity.Property(e => e.EventId).HasColumnName("event_id");

                entity.Property(e => e.EventDate)
                    .HasColumnType("timestamp")
                    .HasColumnName("event_date");

                entity.Property(e => e.EventType)
                    .HasMaxLength(255)
                    .HasColumnName("event_type");

                entity.Property(e => e.Principal)
                    .HasMaxLength(50)
                    .HasColumnName("principal");
            });

            modelBuilder.Entity<JhiPersistentAuditEvtDatum>(entity =>
            {
                entity.HasKey(e => new { e.EventId, e.Name })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                entity.ToTable("jhi_persistent_audit_evt_data");

                entity.HasIndex(e => e.EventId, "idx_persistent_audit_evt_data");

                entity.Property(e => e.EventId).HasColumnName("event_id");

                entity.Property(e => e.Name)
                    .HasMaxLength(150)
                    .HasColumnName("name");

                entity.Property(e => e.Value)
                    .HasMaxLength(255)
                    .HasColumnName("value");

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.JhiPersistentAuditEvtData)
                    .HasForeignKey(d => d.EventId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_evt_pers_audit_evt_data");
            });

            modelBuilder.Entity<JhiUser>(entity =>
            {
                entity.ToTable("jhi_user");

                entity.HasIndex(e => e.Email, "ux_user_email")
                    .IsUnique();

                entity.HasIndex(e => e.Login, "ux_user_login")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Activated)
                    .HasColumnType("bit(1)")
                    .HasColumnName("activated");

                entity.Property(e => e.ActivationKey)
                    .HasMaxLength(20)
                    .HasColumnName("activation_key");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("created_by");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("timestamp")
                    .HasColumnName("created_date");

                entity.Property(e => e.Email)
                    .HasMaxLength(191)
                    .HasColumnName("email");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .HasColumnName("first_name");

                entity.Property(e => e.ImageUrl)
                    .HasMaxLength(256)
                    .HasColumnName("image_url");

                entity.Property(e => e.LangKey)
                    .HasMaxLength(10)
                    .HasColumnName("lang_key");

                entity.Property(e => e.LastModifiedBy)
                    .HasMaxLength(50)
                    .HasColumnName("last_modified_by");

                entity.Property(e => e.LastModifiedDate)
                    .HasColumnType("timestamp")
                    .HasColumnName("last_modified_date");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .HasColumnName("last_name");

                entity.Property(e => e.Login)
                    .HasMaxLength(50)
                    .HasColumnName("login");

                entity.Property(e => e.PasswordHash)
                    .HasMaxLength(60)
                    .HasColumnName("password_hash");

                entity.Property(e => e.ResetDate)
                    .HasColumnType("timestamp")
                    .HasColumnName("reset_date");

                entity.Property(e => e.ResetKey)
                    .HasMaxLength(20)
                    .HasColumnName("reset_key");

                entity.HasMany(d => d.AuthorityNames)
                    .WithMany(p => p.Users)
                    .UsingEntity<Dictionary<string, object>>(
                        "JhiUserAuthority",
                        l => l.HasOne<JhiAuthority>().WithMany().HasForeignKey("AuthorityName").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("fk_authority_name"),
                        r => r.HasOne<JhiUser>().WithMany().HasForeignKey("UserId").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("fk_user_id"),
                        j =>
                        {
                            j.HasKey("UserId", "AuthorityName").HasName("PRIMARY").HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

                            j.ToTable("jhi_user_authority");

                            j.HasIndex(new[] { "AuthorityName" }, "fk_authority_name");

                            j.IndexerProperty<long>("UserId").HasColumnName("user_id");

                            j.IndexerProperty<string>("AuthorityName").HasMaxLength(50).HasColumnName("authority_name");
                        });
            });

            modelBuilder.Entity<JsonConstantAttribute>(entity =>
            {
                entity.HasKey(e => e.IntConstId)
                    .HasName("PRIMARY");

                entity.ToTable("json_constant_attributes");

                entity.Property(e => e.IntConstId).HasColumnName("int_const_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(1)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDatatype)
                    .HasMaxLength(50)
                    .HasColumnName("vch_datatype");

                entity.Property(e => e.VchDefaultValue)
                    .HasMaxLength(50)
                    .HasColumnName("vch_default_value");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(500)
                    .HasColumnName("vch_description");

                entity.Property(e => e.VchName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<JsonEmployeeAllowance>(entity =>
            {
                entity.HasKey(e => e.IntAllowanceId)
                    .HasName("PRIMARY");

                entity.ToTable("json_employee_allowance");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.EmployeeSeqId, "fk_emp_allowance_employeeid");

                entity.Property(e => e.IntAllowanceId).HasColumnName("int_allowance_id");

                entity.Property(e => e.Amount).HasColumnName("amount");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpCode)
                    .HasMaxLength(100)
                    .HasColumnName("emp_code");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("EMPLOYEE_SEQ_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.PayHead)
                    .HasMaxLength(100)
                    .HasColumnName("pay_head");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.EmployeeSeq)
                    .WithMany(p => p.JsonEmployeeAllowances)
                    .HasForeignKey(d => d.EmployeeSeqId)
                    .HasConstraintName("fk_emp_allowance_employeeid");
            });

            modelBuilder.Entity<JsonMasDatatype>(entity =>
            {
                entity.HasKey(e => e.IntDtId)
                    .HasName("PRIMARY");

                entity.ToTable("json_mas_datatype");

                entity.Property(e => e.IntDtId).HasColumnName("int_dt_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(1)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDtName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_dt_name");

                entity.Property(e => e.VchDtValue)
                    .HasMaxLength(50)
                    .HasColumnName("vch_dt_value");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<JsonMasFieldManagement>(entity =>
            {
                entity.HasKey(e => e.IntManageId)
                    .HasName("PRIMARY");

                entity.ToTable("json_mas_field_management");

                entity.Property(e => e.IntManageId).HasColumnName("int_manage_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntOrder).HasColumnName("int_order");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(1)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchChanged)
                    .HasMaxLength(1)
                    .HasColumnName("vch_changed");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDatatype)
                    .HasMaxLength(50)
                    .HasColumnName("vch_datatype");

                entity.Property(e => e.VchDefaultValue)
                    .HasMaxLength(100)
                    .HasColumnName("vch_default_value");

                entity.Property(e => e.VchFinalPropertyName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_final_property_name");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchPropertyName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_property_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<JsonTreeStructureElement>(entity =>
            {
                entity.HasKey(e => e.IntJsontreeEleId)
                    .HasName("PRIMARY");

                entity.ToTable("json_tree_structure_elements");

                entity.Property(e => e.IntJsontreeEleId).HasColumnName("int_jsontree_ele_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntJsonTreeId).HasColumnName("int_json_tree_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(1)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDatatype)
                    .HasMaxLength(50)
                    .HasColumnName("vch_datatype");

                entity.Property(e => e.VchObjType)
                    .HasMaxLength(50)
                    .HasColumnName("vch_obj_type");

                entity.Property(e => e.VchPropertyName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_property_name");

                entity.Property(e => e.VchPropertyValue)
                    .HasMaxLength(100)
                    .HasColumnName("vch_property_value");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<JsonTreeStructureManagement>(entity =>
            {
                entity.HasKey(e => e.IntJsonTreeId)
                    .HasName("PRIMARY");

                entity.ToTable("json_tree_structure_management");

                entity.Property(e => e.IntJsonTreeId).HasColumnName("int_json_tree_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(1)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchChanged)
                    .HasMaxLength(1)
                    .HasColumnName("vch_changed");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchJsonTreeName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_json_tree_name");

                entity.Property(e => e.VchJsonTreeStructure)
                    .HasColumnType("mediumtext")
                    .HasColumnName("vch_json_tree_structure");

                entity.Property(e => e.VchSelected)
                    .HasMaxLength(1)
                    .HasColumnName("vch_selected");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<LeaveGroupMaster>(entity =>
            {
                entity.HasKey(e => e.LeaveGroupSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("leave_group_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LeaveGroupSeqId).HasColumnName("LEAVE_GROUP_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LeaveGroupName)
                    .HasMaxLength(100)
                    .HasColumnName("LEAVE_GROUP_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<LeaveGroupMasterTmp>(entity =>
            {
                entity.HasKey(e => e.LeaveGroupSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("leave_group_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LeaveGroupSeqId).HasColumnName("LEAVE_GROUP_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LeaveGroupName)
                    .HasMaxLength(100)
                    .HasColumnName("LEAVE_GROUP_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<LetterMasGenerationMapping>(entity =>
            {
                entity.HasKey(e => e.IntLetterGenMapId)
                    .HasName("PRIMARY");

                entity.ToTable("letter_mas_generation_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_letter_gen_mapping");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_emp_letter_gen_mapping");

                entity.HasIndex(e => e.IntLetterHtmlId, "fk_html_letter_gen_mapping");

                entity.Property(e => e.IntLetterGenMapId).HasColumnName("int_letter_gen_map_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntLetterHtmlId).HasColumnName("int_letter_html_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchFilePath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_file_path");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.LetterMasGenerationMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_comp_letter_gen_mapping");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.LetterMasGenerationMappings)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_emp_letter_gen_mapping");

                entity.HasOne(d => d.IntLetterHtml)
                    .WithMany(p => p.LetterMasGenerationMappings)
                    .HasForeignKey(d => d.IntLetterHtmlId)
                    .HasConstraintName("fk_html_letter_gen_mapping");
            });

            modelBuilder.Entity<LetterMasHtmlTemplate>(entity =>
            {
                entity.HasKey(e => e.IntLetterHtmlId)
                    .HasName("PRIMARY");

                entity.ToTable("letter_mas_html_template");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_let_html_temp_companyid");

                entity.Property(e => e.IntLetterHtmlId).HasColumnName("int_letter_html_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchAppraisalAnnexure)
                    .HasMaxLength(3)
                    .HasColumnName("vch_appraisal_annexure");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchHtmlPath)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_html_path");

                entity.Property(e => e.VchLogoUrl)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_logo_url");

                entity.Property(e => e.VchModuleFlag)
                    .HasMaxLength(5)
                    .HasColumnName("vch_module_flag");

                entity.Property(e => e.VchModuleLog)
                    .HasMaxLength(5)
                    .HasColumnName("vch_module_log");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchSignatureUrl)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_signature_url");

                entity.Property(e => e.VchTemplateName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_template_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.LetterMasHtmlTemplates)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_let_html_temp_companyid");
            });

            modelBuilder.Entity<LetterMasLogo>(entity =>
            {
                entity.HasKey(e => e.IntLetterLogoId)
                    .HasName("PRIMARY");

                entity.ToTable("letter_mas_logo");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntLetterLogoId).HasColumnName("int_letter_logo_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchLogoName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_logo_name");

                entity.Property(e => e.VchLogoUrl)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_logo_url");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<LetterMasSignature>(entity =>
            {
                entity.HasKey(e => e.IntLetterSignatureId)
                    .HasName("PRIMARY");

                entity.ToTable("letter_mas_signature");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntLetterSignatureId).HasColumnName("int_letter_signature_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchSignatureName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_signature_name");

                entity.Property(e => e.VchSignatureUrl)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_signature_url");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<LetterTemplateType>(entity =>
            {
                entity.HasKey(e => e.LettertypeId)
                    .HasName("PRIMARY");

                entity.ToTable("letter_template_type");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LettertypeId).HasColumnName("LETTERTYPE_ID");

                entity.Property(e => e.BlobImgSig)
                    .HasColumnType("blob")
                    .HasColumnName("BLOB_IMG_SIG");

                entity.Property(e => e.BlobLetterType).HasColumnName("BLOB_LETTER_TYPE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LetterTemplate)
                    .HasMaxLength(50)
                    .HasColumnName("LETTER_TEMPLATE");

                entity.Property(e => e.LetterTypeDownload)
                    .HasMaxLength(45)
                    .HasColumnName("LETTER_TYPE_DOWNLOAD");

                entity.Property(e => e.TemplateName)
                    .HasMaxLength(45)
                    .HasColumnName("TEMPLATE_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchSigName)
                    .HasMaxLength(45)
                    .HasColumnName("VCH_SIG_NAME");
            });

            modelBuilder.Entity<LocationMaster>(entity =>
            {
                entity.HasKey(e => e.LocationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("location_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.CityId).HasColumnName("CITY_ID");

                entity.Property(e => e.CountryId).HasColumnName("COUNTRY_ID");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EsisubCode)
                    .HasMaxLength(50)
                    .HasColumnName("ESISUB_CODE");

                entity.Property(e => e.FacRegNo)
                    .HasMaxLength(50)
                    .HasColumnName("FAC_REG_NO");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationName)
                    .HasMaxLength(100)
                    .HasColumnName("LOCATION_NAME");

                entity.Property(e => e.LwfRegCode)
                    .HasMaxLength(50)
                    .HasColumnName("LWF_REG_CODE");

                entity.Property(e => e.PanCode)
                    .HasMaxLength(45)
                    .HasColumnName("PAN_CODE");

                entity.Property(e => e.PfsubCode)
                    .HasMaxLength(50)
                    .HasColumnName("PFSUB_CODE");

                entity.Property(e => e.ProftaxRegCode)
                    .HasMaxLength(50)
                    .HasColumnName("PROFTAX_REG_CODE");

                entity.Property(e => e.ShopEstRegNo)
                    .HasMaxLength(50)
                    .HasColumnName("SHOP_EST_REG_NO");

                entity.Property(e => e.StateId).HasColumnName("STATE_ID");

                entity.Property(e => e.TanCode)
                    .HasMaxLength(45)
                    .HasColumnName("TAN_CODE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCityName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_city_name");

                entity.Property(e => e.VchCountryName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_country_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchLocShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_LOC_SHORT_NAME");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchStateName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_state_name");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<LocationMasterTmp>(entity =>
            {
                entity.HasKey(e => e.LocationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("location_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.CityId).HasColumnName("CITY_ID");

                entity.Property(e => e.CountryId).HasColumnName("COUNTRY_ID");

                entity.Property(e => e.DtFromDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasMaxLength(50)
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EsisubCode)
                    .HasMaxLength(50)
                    .HasColumnName("ESISUB_CODE");

                entity.Property(e => e.FacRegNo)
                    .HasMaxLength(50)
                    .HasColumnName("FAC_REG_NO");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationName)
                    .HasColumnType("text")
                    .HasColumnName("LOCATION_NAME");

                entity.Property(e => e.LwfRegCode)
                    .HasMaxLength(50)
                    .HasColumnName("LWF_REG_CODE");

                entity.Property(e => e.PanCode)
                    .HasMaxLength(45)
                    .HasColumnName("PAN_CODE");

                entity.Property(e => e.PfsubCode)
                    .HasMaxLength(50)
                    .HasColumnName("PFSUB_CODE");

                entity.Property(e => e.ProftaxRegCode)
                    .HasMaxLength(50)
                    .HasColumnName("PROFTAX_REG_CODE");

                entity.Property(e => e.ShopEstRegNo)
                    .HasMaxLength(50)
                    .HasColumnName("SHOP_EST_REG_NO");

                entity.Property(e => e.StateId).HasColumnName("STATE_ID");

                entity.Property(e => e.TanCode)
                    .HasMaxLength(45)
                    .HasColumnName("TAN_CODE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCityName)
                    .HasColumnType("text")
                    .HasColumnName("vch_city_name");

                entity.Property(e => e.VchCountryName)
                    .HasColumnType("text")
                    .HasColumnName("vch_country_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchLocShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_LOC_SHORT_NAME");

                entity.Property(e => e.VchStateName)
                    .HasColumnType("text")
                    .HasColumnName("vch_state_name");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<MaritalStatusMaster>(entity =>
            {
                entity.HasKey(e => e.MaritalStatusSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("marital_status_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.MaritalStatusSeqId).HasColumnName("MARITAL_STATUS_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.MaritalStatusName)
                    .HasMaxLength(100)
                    .HasColumnName("MARITAL_STATUS_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<MaritalStatusMasterTmp>(entity =>
            {
                entity.HasKey(e => e.MaritalStatusSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("marital_status_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.MaritalStatusSeqId).HasColumnName("MARITAL_STATUS_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.MaritalStatusName)
                    .HasMaxLength(100)
                    .HasColumnName("MARITAL_STATUS_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<MidpointMaster>(entity =>
            {
                entity.HasKey(e => e.MidpointSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("midpoint_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.MidpointSeqId).HasColumnName("MIDPOINT_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.MidpointValue)
                    .HasMaxLength(100)
                    .HasColumnName("MIDPOINT_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<MidpointMasterTmp>(entity =>
            {
                entity.HasKey(e => e.MidpointSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("midpoint_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.MidpointSeqId).HasColumnName("MIDPOINT_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.MidpointValue)
                    .HasMaxLength(100)
                    .HasColumnName("MIDPOINT_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<OnboardDocumentDetail>(entity =>
            {
                entity.HasKey(e => e.IntOnbDocId)
                    .HasName("PRIMARY");

                entity.ToTable("onboard_document_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDocId, "FK_DOC_MASTER");

                entity.HasIndex(e => e.IntCompanyId, "fk_onb_doc_int_company_id_idx");

                entity.HasIndex(e => e.OnboardInitiationSeqId, "fk_onb_document");

                entity.Property(e => e.IntOnbDocId).HasColumnName("int_onb_doc_id");

                entity.Property(e => e.BlobDocument)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_document");

                entity.Property(e => e.FlagOnbDoc)
                    .HasColumnName("flag_onb_doc")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntDocId).HasColumnName("int_doc_id");

                entity.Property(e => e.MandatoryDoc)
                    .HasColumnName("mandatory_doc")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.OnboardInitiationSeqId).HasColumnName("ONBOARD_INITIATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(5)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchComments)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_comments");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocumentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_document_name");

                entity.Property(e => e.VchDocumentPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_path");

                entity.Property(e => e.VchExtension)
                    .HasMaxLength(10)
                    .HasColumnName("vch_extension");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchVerifyStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_verify_status");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardDocumentDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_onb_doc_int_company_id");

                entity.HasOne(d => d.IntDoc)
                    .WithMany(p => p.OnboardDocumentDetails)
                    .HasForeignKey(d => d.IntDocId)
                    .HasConstraintName("FK_DOC_MASTER");

                entity.HasOne(d => d.OnboardInitiationSeq)
                    .WithMany(p => p.OnboardDocumentDetails)
                    .HasForeignKey(d => d.OnboardInitiationSeqId)
                    .HasConstraintName("fk_onb_document");
            });

            modelBuilder.Entity<OnboardEmployeeDetail>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("onboard_employee_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_OB_EMP_DET_COMPID_idx");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.DpdhlJoining).HasColumnName("DPDHL_JOINING");

                entity.Property(e => e.DtNomineeFatherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_FATHER_DOB");

                entity.Property(e => e.DtNomineeMotherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_MOTHER_DOB");

                entity.Property(e => e.DtNomineeSpouseDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_SPOUSE_DOB");

                entity.Property(e => e.DtPerDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PER_DOB");

                entity.Property(e => e.DtPrevFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE");

                entity.Property(e => e.DtPrevFromDate1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE1");

                entity.Property(e => e.DtPrevFromDate3)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE3");

                entity.Property(e => e.DtPrevToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE");

                entity.Property(e => e.DtPrevToDate2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE2");

                entity.Property(e => e.DtPrevToDate3)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE3");

                entity.Property(e => e.GroupDoj).HasColumnName("group_doj");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntObSeqId)
                    .HasColumnName("INT_OB_SEQ_ID")
                    .HasComment("reference with onboard_initiation table");

                entity.Property(e => e.IntPrevCtc).HasColumnName("INT_PREV_CTC");

                entity.Property(e => e.IntPrevCtc1).HasColumnName("INT_PREV_CTC1");

                entity.Property(e => e.IntPrevCtc3).HasColumnName("INT_PREV_CTC3");

                entity.Property(e => e.IntPrevFixedCtc1).HasColumnName("INT_PREV_FIXED_CTC1");

                entity.Property(e => e.IntPrevNoticePeriodReq1).HasColumnName("INT_PREV_NOTICE_PERIOD_REQ1");

                entity.Property(e => e.IntPrevVariableCtc1).HasColumnName("INT_PREV_VARIABLE_CTC1");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VarDipDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_DEPART");

                entity.Property(e => e.VarDipInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_INSTITUTION");

                entity.Property(e => e.VarDipMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_MEDIUM");

                entity.Property(e => e.VarDipPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_PERCENTAGE");

                entity.Property(e => e.VarDipUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_UNIVERSITY");

                entity.Property(e => e.VarDipYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_FROM");

                entity.Property(e => e.VarDipYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_TO");

                entity.Property(e => e.VarHsLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_LOCATION");

                entity.Property(e => e.VarHsPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_PERCENTAGE");

                entity.Property(e => e.VarHsSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_SCH_NAME");

                entity.Property(e => e.VarHsUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_UNIVERSITY");

                entity.Property(e => e.VarHsYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_YR_COMPLETE");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(70)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VarNomineeFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_FATHER_NAME");

                entity.Property(e => e.VarNomineeMotherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_MOTHER_NAME");

                entity.Property(e => e.VarNomineeNoOfChildren)
                    .HasMaxLength(5)
                    .HasColumnName("VAR_NOMINEE_NO_OF_CHILDREN");

                entity.Property(e => e.VarNomineeSpouseName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_SPOUSE_NAME");

                entity.Property(e => e.VarPerAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS1");

                entity.Property(e => e.VarPerAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS2");

                entity.Property(e => e.VarPerAddress3)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS3");

                entity.Property(e => e.VarPerAdharNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_ADHAR_NO");

                entity.Property(e => e.VarPerBg)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_BG");

                entity.Property(e => e.VarPerCity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CITY");

                entity.Property(e => e.VarPerCountry)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_COUNTRY");

                entity.Property(e => e.VarPerCurrAddress1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS1");

                entity.Property(e => e.VarPerCurrAddress2)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS2");

                entity.Property(e => e.VarPerCurrCity)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_CITY");

                entity.Property(e => e.VarPerCurrCountry)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_COUNTRY");

                entity.Property(e => e.VarPerCurrPincode)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_PINCODE");

                entity.Property(e => e.VarPerCurrState)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_STATE");

                entity.Property(e => e.VarPerEmail)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_EMAIL");

                entity.Property(e => e.VarPerFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FATHER_NAME");

                entity.Property(e => e.VarPerFirstName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FIRST_NAME");

                entity.Property(e => e.VarPerGender)
                    .HasMaxLength(6)
                    .HasColumnName("VAR_PER_GENDER");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_LAST_NAME");

                entity.Property(e => e.VarPerMaritialStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_MARITIAL_STATUS");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_MIDDLE_NAME");

                entity.Property(e => e.VarPerMobileNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_MOBILE_NO");

                entity.Property(e => e.VarPerPanNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_PAN_NO");

                entity.Property(e => e.VarPerPincode)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_PER_PINCODE");

                entity.Property(e => e.VarPerReligion)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_RELIGION");

                entity.Property(e => e.VarPerState)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_STATE");

                entity.Property(e => e.VarPgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_DEPART");

                entity.Property(e => e.VarPgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_INSTITUTION");

                entity.Property(e => e.VarPgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_MEDIUM");

                entity.Property(e => e.VarPgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_PERCENTAGE");

                entity.Property(e => e.VarPgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_UNIVERSITY");

                entity.Property(e => e.VarPgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_FROM");

                entity.Property(e => e.VarPgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_TO");

                entity.Property(e => e.VarPrevAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS1");

                entity.Property(e => e.VarPrevAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS2");

                entity.Property(e => e.VarPrevEmpName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME");

                entity.Property(e => e.VarPrevEmpName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME1");

                entity.Property(e => e.VarPrevEmpName3)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME3");

                entity.Property(e => e.VarPrevLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION");

                entity.Property(e => e.VarPrevLocation1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION1");

                entity.Property(e => e.VarPrevLocation3)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION3");

                entity.Property(e => e.VarPrevReferDesig)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG");

                entity.Property(e => e.VarPrevReferDesig1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG1");

                entity.Property(e => e.VarPrevReferDesig3)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG3");

                entity.Property(e => e.VarPrevReferId)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID");

                entity.Property(e => e.VarPrevReferId1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID1");

                entity.Property(e => e.VarPrevReferId3)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID3");

                entity.Property(e => e.VarPrevReferName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME");

                entity.Property(e => e.VarPrevReferName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME1");

                entity.Property(e => e.VarPrevReferName3)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME3");

                entity.Property(e => e.VarSslcLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_LOCATION");

                entity.Property(e => e.VarSslcPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_PERCENTAGE");

                entity.Property(e => e.VarSslcSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_SCH_NAME");

                entity.Property(e => e.VarSslcUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_UNIVERSITY");

                entity.Property(e => e.VarSslcYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_YR_COMPLETE");

                entity.Property(e => e.VarUgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_DEPART");

                entity.Property(e => e.VarUgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_INSTITUTION");

                entity.Property(e => e.VarUgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_MEDIUM");

                entity.Property(e => e.VarUgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_PERCENTAGE");

                entity.Property(e => e.VarUgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_UNIVERSITY");

                entity.Property(e => e.VarUgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_FROM");

                entity.Property(e => e.VarUgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_TO");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardEmployeeDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_OB_EMP_DET_COMPID");
            });

            modelBuilder.Entity<OnboardEmployeeDetailsHash>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("onboard_employee_details_hash");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_OB_EMP_DET_HASH_COMPID_idx");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.DtNomineeFatherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_FATHER_DOB");

                entity.Property(e => e.DtNomineeMotherDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_MOTHER_DOB");

                entity.Property(e => e.DtNomineeSpouseDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_NOMINEE_SPOUSE_DOB");

                entity.Property(e => e.DtPerDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PER_DOB");

                entity.Property(e => e.DtPrevFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE");

                entity.Property(e => e.DtPrevFromDate1)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_FROM_DATE1");

                entity.Property(e => e.DtPrevToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE");

                entity.Property(e => e.DtPrevToDate2)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_PREV_TO_DATE2");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntObSeqId).HasColumnName("INT_OB_SEQ_ID");

                entity.Property(e => e.IntPrevCtc).HasColumnName("INT_PREV_CTC");

                entity.Property(e => e.IntPrevCtc1).HasColumnName("INT_PREV_CTC1");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VarDipDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_DEPART");

                entity.Property(e => e.VarDipInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_INSTITUTION");

                entity.Property(e => e.VarDipMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_MEDIUM");

                entity.Property(e => e.VarDipPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_PERCENTAGE");

                entity.Property(e => e.VarDipUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_DIP_UNIVERSITY");

                entity.Property(e => e.VarDipYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_FROM");

                entity.Property(e => e.VarDipYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_DIP_YR_TO");

                entity.Property(e => e.VarHsLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_LOCATION");

                entity.Property(e => e.VarHsPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_PERCENTAGE");

                entity.Property(e => e.VarHsSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_SCH_NAME");

                entity.Property(e => e.VarHsUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_HS_UNIVERSITY");

                entity.Property(e => e.VarHsYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_HS_YR_COMPLETE");

                entity.Property(e => e.VarKycAadhar)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_AADHAR");

                entity.Property(e => e.VarKycAccNo)
                    .HasMaxLength(50)
                    .HasColumnName("VAR_KYC_ACC_NO");

                entity.Property(e => e.VarKycBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_KYC_BANK_NAME");

                entity.Property(e => e.VarKycBranch)
                    .HasMaxLength(70)
                    .HasColumnName("VAR_KYC_BRANCH");

                entity.Property(e => e.VarKycIfsc)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_KYC_IFSC");

                entity.Property(e => e.VarKycPan)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_KYC_PAN");

                entity.Property(e => e.VarKycPassport)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_PASSPORT");

                entity.Property(e => e.VarKycUan)
                    .HasMaxLength(40)
                    .HasColumnName("VAR_KYC_UAN");

                entity.Property(e => e.VarNomineeFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_FATHER_NAME");

                entity.Property(e => e.VarNomineeMotherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_MOTHER_NAME");

                entity.Property(e => e.VarNomineeNoOfChildren)
                    .HasMaxLength(5)
                    .HasColumnName("VAR_NOMINEE_NO_OF_CHILDREN");

                entity.Property(e => e.VarNomineeSpouseName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_NOMINEE_SPOUSE_NAME");

                entity.Property(e => e.VarPerAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS1");

                entity.Property(e => e.VarPerAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PER_ADDRESS2");

                entity.Property(e => e.VarPerAdharNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_ADHAR_NO");

                entity.Property(e => e.VarPerBg)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_BG");

                entity.Property(e => e.VarPerCity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CITY");

                entity.Property(e => e.VarPerCountry)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_COUNTRY");

                entity.Property(e => e.VarPerCurrAddress1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS1");

                entity.Property(e => e.VarPerCurrAddress2)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_CURR_ADDRESS2");

                entity.Property(e => e.VarPerCurrCity)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_CITY");

                entity.Property(e => e.VarPerCurrCountry)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_COUNTRY");

                entity.Property(e => e.VarPerCurrPincode)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_PINCODE");

                entity.Property(e => e.VarPerCurrState)
                    .HasMaxLength(60)
                    .HasColumnName("VAR_PER_CURR_STATE");

                entity.Property(e => e.VarPerEmail)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_EMAIL");

                entity.Property(e => e.VarPerFatherName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FATHER_NAME");

                entity.Property(e => e.VarPerFirstName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_FIRST_NAME");

                entity.Property(e => e.VarPerGender)
                    .HasMaxLength(6)
                    .HasColumnName("VAR_PER_GENDER");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_LAST_NAME");

                entity.Property(e => e.VarPerMaritialStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_MARITIAL_STATUS");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_MIDDLE_NAME");

                entity.Property(e => e.VarPerMobileNo)
                    .HasMaxLength(15)
                    .HasColumnName("VAR_PER_MOBILE_NO");

                entity.Property(e => e.VarPerPanNo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_PAN_NO");

                entity.Property(e => e.VarPerPincode)
                    .HasMaxLength(30)
                    .HasColumnName("VAR_PER_PINCODE");

                entity.Property(e => e.VarPerReligion)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PER_RELIGION");

                entity.Property(e => e.VarPerState)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PER_STATE");

                entity.Property(e => e.VarPgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_DEPART");

                entity.Property(e => e.VarPgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_INSTITUTION");

                entity.Property(e => e.VarPgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_MEDIUM");

                entity.Property(e => e.VarPgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_PERCENTAGE");

                entity.Property(e => e.VarPgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PG_UNIVERSITY");

                entity.Property(e => e.VarPgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_FROM");

                entity.Property(e => e.VarPgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_PG_YR_TO");

                entity.Property(e => e.VarPrevAddress1)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS1");

                entity.Property(e => e.VarPrevAddress2)
                    .HasMaxLength(500)
                    .HasColumnName("VAR_PREV_ADDRESS2");

                entity.Property(e => e.VarPrevEmpName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME");

                entity.Property(e => e.VarPrevEmpName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_EMP_NAME1");

                entity.Property(e => e.VarPrevLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION");

                entity.Property(e => e.VarPrevLocation1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_LOCATION1");

                entity.Property(e => e.VarPrevReferDesig)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG");

                entity.Property(e => e.VarPrevReferDesig1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_DESIG1");

                entity.Property(e => e.VarPrevReferId)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID");

                entity.Property(e => e.VarPrevReferId1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_ID1");

                entity.Property(e => e.VarPrevReferName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME");

                entity.Property(e => e.VarPrevReferName1)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_PREV_REFER_NAME1");

                entity.Property(e => e.VarSslcLocation)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_LOCATION");

                entity.Property(e => e.VarSslcPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_PERCENTAGE");

                entity.Property(e => e.VarSslcSchName)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_SCH_NAME");

                entity.Property(e => e.VarSslcUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_SSLC_UNIVERSITY");

                entity.Property(e => e.VarSslcYrComplete)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_SSLC_YR_COMPLETE");

                entity.Property(e => e.VarUgDepart)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_DEPART");

                entity.Property(e => e.VarUgInstitution)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_INSTITUTION");

                entity.Property(e => e.VarUgMedium)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_MEDIUM");

                entity.Property(e => e.VarUgPercentage)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_PERCENTAGE");

                entity.Property(e => e.VarUgUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("VAR_UG_UNIVERSITY");

                entity.Property(e => e.VarUgYrFrom)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_FROM");

                entity.Property(e => e.VarUgYrTo)
                    .HasMaxLength(20)
                    .HasColumnName("VAR_UG_YR_TO");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardEmployeeDetailsHashes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_OB_EMP_DET_HASH_COMPID");
            });

            modelBuilder.Entity<OnboardNomineeDetail>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("onboard_nominee_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_OB_NOM_DET_COMPID_idx");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DtDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB");

                entity.Property(e => e.IntAge).HasColumnName("INT_AGE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId)
                    .HasColumnName("INT_EMPLOYEE_SEQ_ID")
                    .HasComment("REFERENCE FROM ONBOARD_EMPLOYEE_DETAILS FOREIGN KEY");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.VchName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_NAME");

                entity.Property(e => e.VchRelation)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RELATION");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardNomineeDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_OB_NOM_DET_COMPID");
            });

            modelBuilder.Entity<OnboardNomineeDetailsHash>(entity =>
            {
                entity.HasKey(e => e.IntSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("onboard_nominee_details_hash");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_Nominee_Details_Company_Id_idx");

                entity.Property(e => e.IntSeqId).HasColumnName("INT_SEQ_ID");

                entity.Property(e => e.DtDob)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DOB");

                entity.Property(e => e.IntAge).HasColumnName("INT_AGE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("INT_EMPLOYEE_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_NAME");

                entity.Property(e => e.VchRelation)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RELATION");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardNomineeDetailsHashes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_Nominee_Details_Company_Id");
            });

            modelBuilder.Entity<OnboardSalaryStructure>(entity =>
            {
                entity.HasKey(e => e.IntOnboardSalStucId)
                    .HasName("PRIMARY");

                entity.ToTable("onboard_salary_structure");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_ob_int_company_id_idx");

                entity.Property(e => e.IntOnboardSalStucId).HasColumnName("INT_ONBOARD_SAL_STUC_ID");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("created_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCtcDiff).HasColumnName("INT_CTC_DIFF");

                entity.Property(e => e.IntNewBasic).HasColumnName("INT_NEW_BASIC");

                entity.Property(e => e.IntNewConveyance).HasColumnName("INT_NEW_CONVEYANCE");

                entity.Property(e => e.IntNewCtc).HasColumnName("INT_NEW_CTC");

                entity.Property(e => e.IntNewDa).HasColumnName("INT_NEW_DA");

                entity.Property(e => e.IntNewHra).HasColumnName("INT_NEW_HRA");

                entity.Property(e => e.IntNewSplAllowance).HasColumnName("INT_NEW_SPL_ALLOWANCE");

                entity.Property(e => e.IntOldBasic).HasColumnName("INT_OLD_BASIC");

                entity.Property(e => e.IntOldConveyance).HasColumnName("INT_OLD_CONVEYANCE");

                entity.Property(e => e.IntOldCtc).HasColumnName("INT_OLD_CTC");

                entity.Property(e => e.IntOldDa).HasColumnName("INT_OLD_DA");

                entity.Property(e => e.IntOldHra).HasColumnName("INT_OLD_HRA");

                entity.Property(e => e.IntOldSplAllowance).HasColumnName("INT_OLD_SPL_ALLOWANCE");

                entity.Property(e => e.IntOnboardInitiationSeqId)
                    .HasColumnName("INT_ONBOARD_INITIATION_SEQ_ID")
                    .HasComment("REFERENCE FROM ONBOARD INITIATION");

                entity.Property(e => e.IntReimCar1).HasColumnName("INT_REIM_CAR1");

                entity.Property(e => e.IntReimCar2).HasColumnName("INT_REIM_CAR2");

                entity.Property(e => e.IntReimDriver1).HasColumnName("INT_REIM_DRIVER1");

                entity.Property(e => e.IntReimDriver2).HasColumnName("INT_REIM_DRIVER2");

                entity.Property(e => e.IntReimMedical1).HasColumnName("INT_REIM_MEDICAL1");

                entity.Property(e => e.IntReimMedical2).HasColumnName("INT_REIM_MEDICAL2");

                entity.Property(e => e.IntReimTelephone1).HasColumnName("INT_REIM_TELEPHONE1");

                entity.Property(e => e.IntReimTelephone2).HasColumnName("INT_REIM_TELEPHONE2");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("updated_date");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardSalaryStructures)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_ob_int_company_id");
            });

            modelBuilder.Entity<OnboardingInitChecklist>(entity =>
            {
                entity.HasKey(e => e.OnbChecklistId)
                    .HasName("PRIMARY");

                entity.ToTable("onboarding_init_checklist");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDocId, "fk_onbchklist_docid");

                entity.HasIndex(e => e.OnboardInitiationSeqId, "fk_onbchklist_onbinitseqid");

                entity.Property(e => e.OnbChecklistId).HasColumnName("onb_checklist_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntDocId).HasColumnName("int_doc_id");

                entity.Property(e => e.OnboardInitiationSeqId).HasColumnName("ONBOARD_INITIATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchChecked)
                    .HasMaxLength(3)
                    .HasColumnName("vch_checked");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntDoc)
                    .WithMany(p => p.OnboardingInitChecklists)
                    .HasForeignKey(d => d.IntDocId)
                    .HasConstraintName("fk_onbchklist_docid");

                entity.HasOne(d => d.OnboardInitiationSeq)
                    .WithMany(p => p.OnboardingInitChecklists)
                    .HasForeignKey(d => d.OnboardInitiationSeqId)
                    .HasConstraintName("fk_onbchklist_onbinitseqid");
            });

            modelBuilder.Entity<OnboardingInitChecklistHash>(entity =>
            {
                entity.HasKey(e => e.OnbChecklisthashId)
                    .HasName("PRIMARY");

                entity.ToTable("onboarding_init_checklist_hash");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_ONB_INIT_CHKLST_HASH_compID_idx");

                entity.HasIndex(e => e.IntDocId, "fk_onbchklisthash_docid");

                entity.Property(e => e.OnbChecklisthashId).HasColumnName("onb_checklisthash_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntDocId).HasColumnName("int_doc_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchChecked)
                    .HasMaxLength(3)
                    .HasColumnName("vch_checked");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardingInitChecklistHashes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_ONB_INIT_CHKLST_HASH_compID");

                entity.HasOne(d => d.IntDoc)
                    .WithMany(p => p.OnboardingInitChecklistHashes)
                    .HasForeignKey(d => d.IntDocId)
                    .HasConstraintName("fk_onbchklisthash_docid");
            });

            modelBuilder.Entity<OnboardingInitiation>(entity =>
            {
                entity.HasKey(e => e.OnboardInitiationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("onboarding_initiation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_ONB_INIT_COMPANY_ID");

                entity.HasIndex(e => e.MidPoints, "FK_ONB_MIDPOINT");

                entity.HasIndex(e => e.ReportingManagerName, "FK_ON_INI_REP_MAN_NAME");

                entity.HasIndex(e => e.PresentCostCenter, "FK_PRE_COST_CENTER");

                entity.HasIndex(e => e.PresentDepartment, "FK_PRE_DEPARTMENT");

                entity.HasIndex(e => e.PresentDesignation, "FK_PRE_DESIGNATION");

                entity.HasIndex(e => e.PresentLocation, "FK_PRE_LOCATION");

                entity.HasIndex(e => e.Departments, "FK_init_MAS_DEPARTMENTS_MASTER");

                entity.HasIndex(e => e.IntCategoryId, "fk_onb_init_categoryid");

                entity.Property(e => e.OnboardInitiationSeqId)
                    .HasColumnName("ONBOARD_INITIATION_SEQ_ID")
                    .HasComment("Primary Key Of onboard iniation");

                entity.Property(e => e.BlobAppointmentLetter)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_appointment_letter");

                entity.Property(e => e.BlobOfferLetter)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_offer_letter");

                entity.Property(e => e.CtcRanges)
                    .HasMaxLength(25)
                    .HasColumnName("ctc_ranges");

                entity.Property(e => e.Departments).HasColumnName("departments");

                entity.Property(e => e.DpdhlJoining).HasColumnName("DPDHL_JOINING");

                entity.Property(e => e.DtInitApproveTime)
                    .HasMaxLength(6)
                    .HasColumnName("DT_INIT_APPROVE_TIME");

                entity.Property(e => e.DtObApprovalTime)
                    .HasMaxLength(6)
                    .HasColumnName("DT_OB_APPROVAL_TIME");

                entity.Property(e => e.DtObApproveTime1)
                    .HasMaxLength(6)
                    .HasColumnName("DT_OB_APPROVE_TIME1");

                entity.Property(e => e.DtSecApproveTime)
                    .HasMaxLength(6)
                    .HasColumnName("DT_SEC_APPROVE_TIME");

                entity.Property(e => e.GroupDoj).HasColumnName("group_doj");

                entity.Property(e => e.IntCategoryId).HasColumnName("int_category_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntComparatorsRatio).HasColumnName("int_comparators_ratio");

                entity.Property(e => e.IntCtcDifference).HasColumnName("int_ctc_difference");

                entity.Property(e => e.IntMidPoints).HasColumnName("int_mid_points");

                entity.Property(e => e.IntNewCtc).HasColumnName("int_new_ctc");

                entity.Property(e => e.MidPoints).HasColumnName("mid_points");

                entity.Property(e => e.PersonalAadharCard)
                    .HasMaxLength(15)
                    .HasColumnName("personal_aadhar_card");

                entity.Property(e => e.PersonalAddress1)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_ADDRESS1");

                entity.Property(e => e.PersonalAddress2)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_ADDRESS2");

                entity.Property(e => e.PersonalAddress3)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_ADDRESS3");

                entity.Property(e => e.PersonalDob)
                    .HasColumnType("datetime")
                    .HasColumnName("PERSONAL_DOB");

                entity.Property(e => e.PersonalEmailId)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_EMAIL_ID");

                entity.Property(e => e.PersonalFirstName)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_FIRST_NAME");

                entity.Property(e => e.PersonalLastName)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_LAST_NAME");

                entity.Property(e => e.PersonalLocation)
                    .HasMaxLength(300)
                    .HasColumnName("PERSONAL_LOCATION");

                entity.Property(e => e.PersonalMiddleName)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_MIDDLE_NAME");

                entity.Property(e => e.PersonalMobileNum)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_MOBILE_NUM");

                entity.Property(e => e.PersonalPanNum)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_PAN_NUM");

                entity.Property(e => e.PersonalRefId)
                    .HasMaxLength(50)
                    .HasColumnName("PERSONAL_REF_ID");

                entity.Property(e => e.PresentCostCenter).HasColumnName("PRESENT_COST_CENTER");

                entity.Property(e => e.PresentDepartment).HasColumnName("PRESENT_DEPARTMENT");

                entity.Property(e => e.PresentDesignation).HasColumnName("PRESENT_DESIGNATION");

                entity.Property(e => e.PresentDoj)
                    .HasColumnType("datetime")
                    .HasColumnName("PRESENT_DOJ");

                entity.Property(e => e.PresentGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PRESENT_GRADE");

                entity.Property(e => e.PresentLocation).HasColumnName("PRESENT_LOCATION");

                entity.Property(e => e.PreviousAddress1)
                    .HasMaxLength(300)
                    .HasColumnName("PREVIOUS_ADDRESS1");

                entity.Property(e => e.PreviousAddress2)
                    .HasMaxLength(300)
                    .HasColumnName("PREVIOUS_ADDRESS2");

                entity.Property(e => e.PreviousCompanyName)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_COMPANY_NAME");

                entity.Property(e => e.PreviousCtc)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_CTC");

                entity.Property(e => e.PreviousDepartment)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_DEPARTMENT");

                entity.Property(e => e.PreviousDesignation)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_DESIGNATION");

                entity.Property(e => e.PreviousGrade)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_GRADE");

                entity.Property(e => e.PreviousLocation)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_LOCATION");

                entity.Property(e => e.PreviousReferralMobile)
                    .HasMaxLength(15)
                    .HasColumnName("PREVIOUS_REFERRAL_MOBILE");

                entity.Property(e => e.PreviousReferralPerson)
                    .HasMaxLength(50)
                    .HasColumnName("PREVIOUS_REFERRAL_PERSON");

                entity.Property(e => e.ReportingManagerDesi)
                    .HasMaxLength(80)
                    .HasColumnName("REPORTING_MANAGER_DESI");

                entity.Property(e => e.ReportingManagerName).HasColumnName("REPORTING_MANAGER_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsRaisedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_RAISED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchAppointmentLetterPath)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_appointment_letter_path");

                entity.Property(e => e.VchBgv)
                    .HasMaxLength(3)
                    .HasColumnName("vch_bgv");

                entity.Property(e => e.VchEmpcode)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_EMPCODE");

                entity.Property(e => e.VchExperience)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_EXPERIENCE");

                entity.Property(e => e.VchFivePagerPword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_five_pager_pword");

                entity.Property(e => e.VchFivePagerUname)
                    .HasMaxLength(50)
                    .HasColumnName("vch_five_pager_uname");

                entity.Property(e => e.VchInitApproveBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_INIT_APPROVE_BY");

                entity.Property(e => e.VchInitRejectionMark)
                    .HasMaxLength(200)
                    .HasColumnName("VCH_INIT_REJECTION_MARK");

                entity.Property(e => e.VchInitiationStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_INITIATION_STATUS");

                entity.Property(e => e.VchObApprovalBy1)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_OB_APPROVAL_BY1");

                entity.Property(e => e.VchObApproveBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_OB_APPROVE_BY");

                entity.Property(e => e.VchObRejectionMark1)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_OB_REJECTION_MARK1");

                entity.Property(e => e.VchObRejectionMark2)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_OB_REJECTION_MARK2");

                entity.Property(e => e.VchOfferLetterPath)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_offer_letter_path");

                entity.Property(e => e.VchOnboardStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ONBOARD_STATUS");

                entity.Property(e => e.VchRaisedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_RAISED_BY");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchSecApproveBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_SEC_APPROVE_BY");

                entity.Property(e => e.VchSecRejectionMark)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_SEC_REJECTION_MARK");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.DepartmentsNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.Departments)
                    .HasConstraintName("FK_init_MAS_DEPARTMENTS_MASTER");

                entity.HasOne(d => d.IntCategory)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.IntCategoryId)
                    .HasConstraintName("fk_onb_init_categoryid");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_ONB_INIT_COMPANY_ID");

                entity.HasOne(d => d.MidPointsNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.MidPoints)
                    .HasConstraintName("FK_ONB_MIDPOINT");

                entity.HasOne(d => d.PresentCostCenterNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.PresentCostCenter)
                    .HasConstraintName("FK_PRE_COST_CENTER");

                entity.HasOne(d => d.PresentDepartmentNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.PresentDepartment)
                    .HasConstraintName("FK_PRE_DEPARTMENT");

                entity.HasOne(d => d.PresentDesignationNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.PresentDesignation)
                    .HasConstraintName("FK_PRE_DESIGNATION");

                entity.HasOne(d => d.PresentLocationNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.PresentLocation)
                    .HasConstraintName("FK_PRE_LOCATION");

                entity.HasOne(d => d.ReportingManagerNameNavigation)
                    .WithMany(p => p.OnboardingInitiations)
                    .HasForeignKey(d => d.ReportingManagerName)
                    .HasConstraintName("FK_ON_INI_REP_MAN_NAME");
            });

            modelBuilder.Entity<OnboardingRefIdHistory>(entity =>
            {
                entity.HasKey(e => e.IntRefCode)
                    .HasName("PRIMARY");

                entity.ToTable("onboarding_ref_id_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_ref_history_Company_Id_idx");

                entity.Property(e => e.IntRefCode).HasColumnName("INT_REF_CODE");

                entity.Property(e => e.CreatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("CREATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.UpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("UPDATED_DATE");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.OnboardingRefIdHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_ref_history_Company_Id");
            });

            modelBuilder.Entity<PfDetailMaster>(entity =>
            {
                entity.HasKey(e => e.IntPfId)
                    .HasName("PRIMARY");

                entity.ToTable("pf_detail_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_mas_pf_company_id");

                entity.HasIndex(e => e.IntEmpId, "fk_ex_pf_details_emp_id");

                entity.Property(e => e.IntPfId).HasColumnName("int_pf_id");

                entity.Property(e => e.BankAccountNo)
                    .HasMaxLength(50)
                    .HasColumnName("Bank_Account_No");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(100)
                    .HasColumnName("Email_ID");

                entity.Property(e => e.FreshMembership)
                    .HasMaxLength(5)
                    .HasColumnName("Fresh_Membership");

                entity.Property(e => e.IfscCode)
                    .HasMaxLength(20)
                    .HasColumnName("IFSC_code");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("int_emp_id")
                    .HasComment("reference from employee master(employee_master)");

                entity.Property(e => e.InternationalWorker)
                    .HasMaxLength(50)
                    .HasColumnName("International_Worker");

                entity.Property(e => e.MobileNo)
                    .HasMaxLength(14)
                    .HasColumnName("Mobile_NO");

                entity.Property(e => e.NameAsPerAadharCard)
                    .HasMaxLength(50)
                    .HasColumnName("Name_As_Per_AadharCard");

                entity.Property(e => e.NameAsPerBank)
                    .HasMaxLength(50)
                    .HasColumnName("Name_As_Per_Bank");

                entity.Property(e => e.NameAsPerPancard)
                    .HasMaxLength(50)
                    .HasColumnName("Name_As_Per_PANCard");

                entity.Property(e => e.Nationality).HasMaxLength(5);

                entity.Property(e => e.PrevEpfMember)
                    .HasMaxLength(5)
                    .HasColumnName("Prev_EPF_Member");

                entity.Property(e => e.PrevPensionMember)
                    .HasMaxLength(5)
                    .HasColumnName("prev_Pension_Member");

                entity.Property(e => e.PreviousUanNumber)
                    .HasMaxLength(50)
                    .HasColumnName("Previous_UAN_Number");

                entity.Property(e => e.Relation)
                    .HasMaxLength(15)
                    .HasColumnName("relation");

                entity.Property(e => e.RelationName)
                    .HasMaxLength(50)
                    .HasColumnName("Relation_Name");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.WithdrawnPrevEpfpensionAmt)
                    .HasMaxLength(5)
                    .HasColumnName("Withdrawn_Prev_EPFPension_Amt");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.PfDetailMasters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_doc_mas_pf_company_id");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.PfDetailMasters)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("fk_ex_pf_details_emp_id");
            });

            modelBuilder.Entity<PhysicalStatusMaster>(entity =>
            {
                entity.HasKey(e => e.PhysicalStatusSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("physical_status_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.PhysicalStatusSeqId).HasColumnName("PHYSICAL_STATUS_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.PhysicalStatusName)
                    .HasMaxLength(100)
                    .HasColumnName("PHYSICAL_STATUS_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<PhysicalStatusMasterTmp>(entity =>
            {
                entity.HasKey(e => e.PhysicalStatusSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("physical_status_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.PhysicalStatusSeqId).HasColumnName("PHYSICAL_STATUS_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.PhysicalStatusName)
                    .HasMaxLength(100)
                    .HasColumnName("PHYSICAL_STATUS_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ProductivityFactorMaster>(entity =>
            {
                entity.HasKey(e => e.ProductivityFactorSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("productivity_factor_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.ProductivityFactorSeqId).HasColumnName("PRODUCTIVITY_FACTOR_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.ProductivityFactorValue)
                    .HasMaxLength(100)
                    .HasColumnName("PRODUCTIVITY_FACTOR_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<ProductivityFactorMasterTmp>(entity =>
            {
                entity.HasKey(e => e.ProductivityFactorSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("productivity_factor_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.ProductivityFactorSeqId).HasColumnName("PRODUCTIVITY_FACTOR_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.ProductivityFactorValue)
                    .HasMaxLength(100)
                    .HasColumnName("PRODUCTIVITY_FACTOR_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<QualificationMaster>(entity =>
            {
                entity.HasKey(e => e.QualificationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("qualification_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.QualificationSeqId).HasColumnName("QUALIFICATION_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.QualificationName)
                    .HasMaxLength(100)
                    .HasColumnName("QUALIFICATION_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<QualificationMasterTmp>(entity =>
            {
                entity.HasKey(e => e.QualificationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("qualification_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.QualificationSeqId).HasColumnName("QUALIFICATION_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.QualificationName)
                    .HasColumnType("text")
                    .HasColumnName("QUALIFICATION_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<RcsgradeMaster>(entity =>
            {
                entity.HasKey(e => e.IntRcsgradeId)
                    .HasName("PRIMARY");

                entity.ToTable("rcsgrade_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("INT_RCSGRADE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchRcsgradeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RCSGRADE_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<RcsgradeTmp>(entity =>
            {
                entity.HasKey(e => e.IntRcsgradeId)
                    .HasName("PRIMARY");

                entity.ToTable("rcsgrade_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("INT_RCSGRADE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchRcsgradeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RCSGRADE_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<RcslevelMaster>(entity =>
            {
                entity.HasKey(e => e.RcslevelSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rcslevel_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.RcslevelSeqId).HasColumnName("RCSLEVEL_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.RcslevelName)
                    .HasMaxLength(100)
                    .HasColumnName("RCSLEVEL_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<RcslevelMasterTmp>(entity =>
            {
                entity.HasKey(e => e.RcslevelSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rcslevel_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.RcslevelSeqId).HasColumnName("RCSLEVEL_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.RcslevelName)
                    .HasMaxLength(100)
                    .HasColumnName("RCSLEVEL_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<RecMasAddCandidate>(entity =>
            {
                entity.HasKey(e => e.IntCandidateSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_add_candidate");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDomainId, "FK_RC_MAS_NEW_CAND_DOMAIN");

                entity.HasIndex(e => e.IntSkillId, "FK_RC_MAS_NEW_CAND_SKILL");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_MAS_NEW_CAND_COMP_ID");

                entity.HasIndex(e => e.IntVendorSeqId, "IDX_RC_MAS_NEW_CAND_VENDOR_ID");

                entity.Property(e => e.IntCandidateSeqId)
                    .HasColumnName("int_candidate_seq_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.BlobResume)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_resume");

                entity.Property(e => e.DtDob).HasColumnName("dt_dob");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from company_detail_master");

                entity.Property(e => e.IntCurrentSal).HasColumnName("int_current_sal");

                entity.Property(e => e.IntDomainId).HasColumnName("int_domain_id");

                entity.Property(e => e.IntExpMonth).HasColumnName("int_exp_month");

                entity.Property(e => e.IntExpYear).HasColumnName("int_exp_year");

                entity.Property(e => e.IntSkillId).HasColumnName("int_skill_id");

                entity.Property(e => e.IntVendorSeqId)
                    .HasColumnName("int_vendor_seq_id")
                    .HasComment("Reference from vendor_master");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCandidateId)
                    .HasMaxLength(40)
                    .HasColumnName("vch_candidate_id");

                entity.Property(e => e.VchCandidateName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_candidate_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocumentPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_path");

                entity.Property(e => e.VchGender)
                    .HasMaxLength(20)
                    .HasColumnName("vch_gender");

                entity.Property(e => e.VchJobId)
                    .HasMaxLength(20)
                    .HasColumnName("vch_jobId");

                entity.Property(e => e.VchLastName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_last_name");

                entity.Property(e => e.VchMailId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_mail_id");

                entity.Property(e => e.VchMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_middle_name");

                entity.Property(e => e.VchPhoneNo)
                    .HasMaxLength(50)
                    .HasColumnName("vch_phone_no");

                entity.Property(e => e.VchProfileSource)
                    .HasMaxLength(10)
                    .HasColumnName("vch_profile_source");

                entity.Property(e => e.VchReferralCode)
                    .HasMaxLength(70)
                    .HasColumnName("vch_referral_code");

                entity.Property(e => e.VchReferralName)
                    .HasMaxLength(80)
                    .HasColumnName("vch_referral_name");

                entity.Property(e => e.VchResumeFlag)
                    .HasMaxLength(100)
                    .HasColumnName("vch_resume_flag");

                entity.Property(e => e.VchSecretKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_secret_key");

                entity.Property(e => e.VchSkills)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_skills");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasAddCandidates)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_CREATE_CAND_COMP_ID");

                entity.HasOne(d => d.IntDomain)
                    .WithMany(p => p.RecMasAddCandidates)
                    .HasForeignKey(d => d.IntDomainId)
                    .HasConstraintName("FK_RC_CREATE_CAND_DOMAIN");

                entity.HasOne(d => d.IntSkill)
                    .WithMany(p => p.RecMasAddCandidates)
                    .HasForeignKey(d => d.IntSkillId)
                    .HasConstraintName("FK_RC_CREATE_CAND_SKILL");

                entity.HasOne(d => d.IntVendorSeq)
                    .WithMany(p => p.RecMasAddCandidates)
                    .HasForeignKey(d => d.IntVendorSeqId)
                    .HasConstraintName("FK_RC_CREATE_CAND_VENDOR_ID");
            });

            modelBuilder.Entity<RecMasCandidateIdHistory>(entity =>
            {
                entity.ToTable("rec_mas_candidate_id_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_rec_mas_id_hist_company_id_idx");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("created_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("updated_date");

                entity.Property(e => e.VchCandidateCode)
                    .HasMaxLength(30)
                    .HasColumnName("vch_candidate_code");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasCandidateIdHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_rec_mas_id_hist_company_id");
            });

            modelBuilder.Entity<RecMasCompetManpowreqMapping>(entity =>
            {
                entity.HasKey(e => e.IntComptManpowreqMapId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_compet_manpowreq_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_company_id_idx");

                entity.HasIndex(e => e.IntRecCompetListSeqid, "FK_rec_comptmanpowreq_comlistid");

                entity.HasIndex(e => e.IntManpowerReqId, "FK_rec_comptmanpowreq_manpowreqid");

                entity.Property(e => e.IntComptManpowreqMapId).HasColumnName("int_compt_manpowreq_map_id");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntManpowerReqId).HasColumnName("int_manpower_req_id");

                entity.Property(e => e.IntRecCompetListSeqid).HasColumnName("INT_REC_COMPET_LIST_SEQID");

                entity.Property(e => e.IntWeightage)
                    .HasPrecision(5, 2)
                    .HasColumnName("INT_WEIGHTAGE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasCompetManpowreqMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_company_id");

                entity.HasOne(d => d.IntManpowerReq)
                    .WithMany(p => p.RecMasCompetManpowreqMappings)
                    .HasForeignKey(d => d.IntManpowerReqId)
                    .HasConstraintName("FK_rec_comptmanpowreq_manpowreqid");

                entity.HasOne(d => d.IntRecCompetListSeq)
                    .WithMany(p => p.RecMasCompetManpowreqMappings)
                    .HasForeignKey(d => d.IntRecCompetListSeqid)
                    .HasConstraintName("FK_rec_comptmanpowreq_comlistid");
            });

            modelBuilder.Entity<RecMasCompetencyList>(entity =>
            {
                entity.HasKey(e => e.IntRecCompetListSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_competency_list");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_REC_M_COMP_LIST_COMP_ID");

                entity.Property(e => e.IntRecCompetListSeqid).HasColumnName("INT_REC_COMPET_LIST_SEQID");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDescription)
                    .HasMaxLength(1000)
                    .HasColumnName("VCH_DESCRIPTION");

                entity.Property(e => e.VchShortname)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_SHORTNAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasCompetencyLists)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_REC_M_COMP_LIST_COMP_ID");
            });

            modelBuilder.Entity<RecMasInterviewCompRating>(entity =>
            {
                entity.HasKey(e => e.IntInterviewCompRatingId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_interview_comp_rating");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_company_id_idx");

                entity.HasIndex(e => e.IntNewCandidateSeqId, "FK_rec_interview_feedback_candidate_id");

                entity.HasIndex(e => e.IntRecCompetListSeqid, "FK_rec_interview_feedback_comlistid");

                entity.HasIndex(e => e.IntManpowerReqId, "FK_rec_interview_feedback_manpowreqid");

                entity.Property(e => e.IntInterviewCompRatingId).HasColumnName("int_interview_comp_rating_id");

                entity.Property(e => e.DtUpdateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATE_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntManpowerReqId).HasColumnName("int_manpower_req_id");

                entity.Property(e => e.IntNewCandidateSeqId).HasColumnName("int_new_candidate_seq_id");

                entity.Property(e => e.IntRecCompetListSeqid).HasColumnName("INT_REC_COMPET_LIST_SEQID");

                entity.Property(e => e.IntWeightage)
                    .HasPrecision(5, 2)
                    .HasColumnName("INT_WEIGHTAGE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasInterviewCompRatings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FKrec_mas_comprating_company_id");

                entity.HasOne(d => d.IntManpowerReq)
                    .WithMany(p => p.RecMasInterviewCompRatings)
                    .HasForeignKey(d => d.IntManpowerReqId)
                    .HasConstraintName("FK_rec_interview_feedback_manpowreqid");

                entity.HasOne(d => d.IntNewCandidateSeq)
                    .WithMany(p => p.RecMasInterviewCompRatings)
                    .HasForeignKey(d => d.IntNewCandidateSeqId)
                    .HasConstraintName("FK_rec_interview_feedback_candidate_id");

                entity.HasOne(d => d.IntRecCompetListSeq)
                    .WithMany(p => p.RecMasInterviewCompRatings)
                    .HasForeignKey(d => d.IntRecCompetListSeqid)
                    .HasConstraintName("FK_rec_interview_feedback_comlistid");
            });

            modelBuilder.Entity<RecMasJobIdNoHistory>(entity =>
            {
                entity.HasKey(e => e.IntJobIdHisId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_job_id_no_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "idx_job_id_history_comp_id");

                entity.Property(e => e.IntJobIdHisId).HasColumnName("int_job_id_his_id");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("created_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("updated_date");

                entity.Property(e => e.VchJobId)
                    .HasMaxLength(45)
                    .HasColumnName("vch_job_id");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasJobIdNoHistories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_job_id_history_comp_id");
            });

            modelBuilder.Entity<RecMasManpowerPlan>(entity =>
            {
                entity.HasKey(e => e.IntPlanId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_manpower_plan");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_MAN_PLAN_COMP_ID");

                entity.HasIndex(e => e.IntDepartId, "IDX_RC_MAN_PLAN_DEPT_ID");

                entity.HasIndex(e => e.IntDesigId, "IDX_RC_MAN_PLAN_DESG_ID");

                entity.HasIndex(e => e.IntLocationId, "IDX_RC_MAN_PLAN_LOC_ID");

                entity.Property(e => e.IntPlanId)
                    .HasColumnName("int_plan_id")
                    .HasComment("Primary key of rec_mas_manpower_plan");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from company_detail_master");

                entity.Property(e => e.IntDepartId)
                    .HasColumnName("int_depart_id")
                    .HasComment("Reference from DepartmentMaster");

                entity.Property(e => e.IntDesigId)
                    .HasColumnName("int_desig_id")
                    .HasComment("Reference from DesignationMaster");

                entity.Property(e => e.IntLocationId)
                    .HasColumnName("int_location_id")
                    .HasComment("Reference from LocationMaster");

                entity.Property(e => e.IntOnroll).HasColumnName("int_onroll");

                entity.Property(e => e.IntPosRequired).HasColumnName("int_pos_required");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedby)
                    .HasMaxLength(100)
                    .HasColumnName("vch_createdby");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasManpowerPlans)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_MAN_PLAN_COMP_ID");

                entity.HasOne(d => d.IntDepart)
                    .WithMany(p => p.RecMasManpowerPlans)
                    .HasForeignKey(d => d.IntDepartId)
                    .HasConstraintName("FK_RC_MAN_PLAN_DEPT_ID");

                entity.HasOne(d => d.IntDesig)
                    .WithMany(p => p.RecMasManpowerPlans)
                    .HasForeignKey(d => d.IntDesigId)
                    .HasConstraintName("FK_RC_MAN_PLAN_DESG_ID");

                entity.HasOne(d => d.IntLocation)
                    .WithMany(p => p.RecMasManpowerPlans)
                    .HasForeignKey(d => d.IntLocationId)
                    .HasConstraintName("FK_RC_MAN_PLAN_LOC_ID");
            });

            modelBuilder.Entity<RecMasManpowerPlanJobid>(entity =>
            {
                entity.HasKey(e => e.IntMpPlanJobId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_manpower_plan_jobids");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_MAN_PLAN_JOB_COMPANY_ID");

                entity.HasIndex(e => e.IntDepartmentId, "IDX_RC_MAN_PLAN_JOB_DEPT_ID");

                entity.HasIndex(e => e.IntDesignationId, "IDX_RC_MAN_PLAN_JOB_DESIG_ID");

                entity.HasIndex(e => e.IntEmployeeSeqId, "IDX_RC_MAN_PLAN_JOB_EMP_ID");

                entity.HasIndex(e => e.IntLocationId, "IDX_RC_MAN_PLAN_JOB_LOC_ID");

                entity.HasIndex(e => e.IntPlanId, "IDX_RC_MAN_PLAN_JOB_PLAN_ID");

                entity.Property(e => e.IntMpPlanJobId)
                    .HasColumnName("int_mp_plan_job_id")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from CompanyMaster");

                entity.Property(e => e.IntDepartmentId)
                    .HasColumnName("int_department_id")
                    .HasComment("Reference from DepartmentMaster");

                entity.Property(e => e.IntDesignationId)
                    .HasColumnName("int_designation_id")
                    .HasComment("Reference from DesignationMaster");

                entity.Property(e => e.IntEmployeeSeqId)
                    .HasColumnName("int_employee_seq_id")
                    .HasComment("Reference from EmployeeMaster");

                entity.Property(e => e.IntLocationId)
                    .HasColumnName("int_location_id")
                    .HasComment("Reference from LocationMaster");

                entity.Property(e => e.IntPlanId)
                    .HasColumnName("int_plan_id")
                    .HasComment("Reference from rec_mas_manpower plan");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchJobId)
                    .HasMaxLength(50)
                    .HasColumnName("vch_job_id")
                    .HasComment("Combination of location,department and designations designation name ");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasManpowerPlanJobids)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_MAN_PLAN_JOB_COMPANY_ID");

                entity.HasOne(d => d.IntDepartment)
                    .WithMany(p => p.RecMasManpowerPlanJobids)
                    .HasForeignKey(d => d.IntDepartmentId)
                    .HasConstraintName("FK_RC_MAN_PLAN_JOB_DEPT_ID");

                entity.HasOne(d => d.IntDesignation)
                    .WithMany(p => p.RecMasManpowerPlanJobids)
                    .HasForeignKey(d => d.IntDesignationId)
                    .HasConstraintName("FK_RC_MAN_PLAN_JOB_DESIG_ID");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.RecMasManpowerPlanJobids)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_RC_MAN_PLAN_JOB_EMP_SEQ_ID");

                entity.HasOne(d => d.IntLocation)
                    .WithMany(p => p.RecMasManpowerPlanJobids)
                    .HasForeignKey(d => d.IntLocationId)
                    .HasConstraintName("FK_RC_MAN_PLAN_JOB_LOC_ID");

                entity.HasOne(d => d.IntPlan)
                    .WithMany(p => p.RecMasManpowerPlanJobids)
                    .HasForeignKey(d => d.IntPlanId)
                    .HasConstraintName("FK_RC_MAN_PLAN_JOB_PLAN_ID");
            });

            modelBuilder.Entity<RecMasNewCandidate>(entity =>
            {
                entity.HasKey(e => e.IntNewCandidateSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_new_candidate");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDomainId, "FK_RC_MAS_NEW_CAND_DOMAIN");

                entity.HasIndex(e => e.IntSkillId, "FK_RC_MAS_NEW_CAND_SKILL");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_MAS_NEW_CAND_COMP_ID");

                entity.HasIndex(e => e.VchInterviewRound1, "IDX_RC_MAS_NEW_CAND_INTER_ROUND1");

                entity.HasIndex(e => e.VchInterviewRound2, "IDX_RC_MAS_NEW_CAND_INTER_ROUND2");

                entity.HasIndex(e => e.IntManpowerReqId, "IDX_RC_MAS_NEW_CAND_MP_REQ_ID");

                entity.HasIndex(e => e.IntVendorSeqId, "IDX_RC_MAS_NEW_CAND_VENDOR_ID");

                entity.Property(e => e.IntNewCandidateSeqId)
                    .HasColumnName("int_new_candidate_seq_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.BlobResume)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_resume");

                entity.Property(e => e.DtDob).HasColumnName("dt_dob");

                entity.Property(e => e.DtShortlistDate).HasColumnName("dt_shortlist_date");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from company_detail_master");

                entity.Property(e => e.IntCurrentSal).HasColumnName("int_current_sal");

                entity.Property(e => e.IntDomainId).HasColumnName("int_domain_id");

                entity.Property(e => e.IntExpMonth).HasColumnName("int_exp_month");

                entity.Property(e => e.IntExpYear).HasColumnName("int_exp_year");

                entity.Property(e => e.IntManpowerReqId)
                    .HasColumnName("int_manpower_req_id")
                    .HasComment("Reference from rec_trans_manpower_request");

                entity.Property(e => e.IntSkillId).HasColumnName("int_skill_id");

                entity.Property(e => e.IntVendorSeqId)
                    .HasColumnName("int_vendor_seq_id")
                    .HasComment("Reference from vendor_master");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCandidateId)
                    .HasMaxLength(40)
                    .HasColumnName("vch_candidate_id");

                entity.Property(e => e.VchCandidateName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_candidate_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocumentPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_document_path");

                entity.Property(e => e.VchGender)
                    .HasMaxLength(20)
                    .HasColumnName("vch_gender");

                entity.Property(e => e.VchInterview1Completed)
                    .HasMaxLength(10)
                    .HasColumnName("vch_interview1_completed");

                entity.Property(e => e.VchInterview1Feedback)
                    .HasColumnType("mediumblob")
                    .HasColumnName("vch_interview1_feedback");

                entity.Property(e => e.VchInterview1FeedbackPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_interview1_feedback_path");

                entity.Property(e => e.VchInterview2Completed)
                    .HasMaxLength(10)
                    .HasColumnName("vch_interview2_completed");

                entity.Property(e => e.VchInterview2Feedback)
                    .HasColumnType("mediumblob")
                    .HasColumnName("vch_interview2_feedback");

                entity.Property(e => e.VchInterview2FeedbackPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_interview2_feedback_path");

                entity.Property(e => e.VchInterviewRound1)
                    .HasMaxLength(10)
                    .HasColumnName("vch_interview_round1");

                entity.Property(e => e.VchInterviewRound2)
                    .HasMaxLength(10)
                    .HasColumnName("vch_interview_round2");

                entity.Property(e => e.VchLastName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_last_name");

                entity.Property(e => e.VchMailId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_mail_id");

                entity.Property(e => e.VchMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_middle_name");

                entity.Property(e => e.VchNotAttendInterComments1)
                    .HasMaxLength(500)
                    .HasColumnName("vch_not_attend_inter_comments1");

                entity.Property(e => e.VchNotAttendInterComments2)
                    .HasMaxLength(500)
                    .HasColumnName("vch_not_attend_inter_comments2");

                entity.Property(e => e.VchPhoneNo)
                    .HasMaxLength(50)
                    .HasColumnName("vch_phone_no");

                entity.Property(e => e.VchProfileSource)
                    .HasMaxLength(10)
                    .HasColumnName("vch_profile_source");

                entity.Property(e => e.VchReferralCode)
                    .HasMaxLength(70)
                    .HasColumnName("vch_referral_code");

                entity.Property(e => e.VchReferralName)
                    .HasMaxLength(80)
                    .HasColumnName("vch_referral_name");

                entity.Property(e => e.VchRescheduleStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_reschedule_status");

                entity.Property(e => e.VchResumeFlag)
                    .HasMaxLength(100)
                    .HasColumnName("vch_resume_flag");

                entity.Property(e => e.VchSecretKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_secret_key");

                entity.Property(e => e.VchSkills)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_skills");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasNewCandidates)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_MAS_NEW_CAND_COMP_ID");

                entity.HasOne(d => d.IntDomain)
                    .WithMany(p => p.RecMasNewCandidates)
                    .HasForeignKey(d => d.IntDomainId)
                    .HasConstraintName("FK_RC_MAS_NEW_CAND_DOMAIN");

                entity.HasOne(d => d.IntManpowerReq)
                    .WithMany(p => p.RecMasNewCandidates)
                    .HasForeignKey(d => d.IntManpowerReqId)
                    .HasConstraintName("FK_RC_MAS_NEW_CAND_MP_REQ_ID");

                entity.HasOne(d => d.IntSkill)
                    .WithMany(p => p.RecMasNewCandidates)
                    .HasForeignKey(d => d.IntSkillId)
                    .HasConstraintName("FK_RC_MAS_NEW_CAND_SKILL");

                entity.HasOne(d => d.IntVendorSeq)
                    .WithMany(p => p.RecMasNewCandidates)
                    .HasForeignKey(d => d.IntVendorSeqId)
                    .HasConstraintName("FK_RC_MAS_NEW_CAND_VENDOR_ID");
            });

            modelBuilder.Entity<RecMasNewcanEdudet>(entity =>
            {
                entity.HasKey(e => e.IntNewCanEmpdetSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_newcan_edudet");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntNewCandidateSeqId, "IDX_REC_MAS_NEWCAN_EDUDET_NEW_CAND_SEQ_ID");

                entity.HasIndex(e => e.IntQualificationId, "IDX_REC_MAS_NEWCAN_EDUDET_QUALF_ID");

                entity.HasIndex(e => e.IntCompanyId, "rec_mas_newcan_edudet_int_company_id_idx");

                entity.Property(e => e.IntNewCanEmpdetSeqId)
                    .HasColumnName("int_new_can_empdet_seq_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntNewCandidateSeqId)
                    .HasColumnName("int_new_candidate_seq_id")
                    .HasComment("Reference from rec_mas_new_candidate");

                entity.Property(e => e.IntQualificationId)
                    .HasColumnName("int_qualification_id")
                    .HasComment("Reference from qualification_master");

                entity.Property(e => e.IntYearOfPassing)
                    .HasPrecision(30)
                    .HasColumnName("int_year_of_passing");

                entity.Property(e => e.TsCreatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_date");

                entity.Property(e => e.TsUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchGrade)
                    .HasMaxLength(50)
                    .HasColumnName("vch_grade");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(90)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasNewcanEdudets)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("rec_mas_newcan_edudet_int_company_id");

                entity.HasOne(d => d.IntNewCandidateSeq)
                    .WithMany(p => p.RecMasNewcanEdudets)
                    .HasForeignKey(d => d.IntNewCandidateSeqId)
                    .HasConstraintName("rec_mas_newcan_edudet_fk1");

                entity.HasOne(d => d.IntQualification)
                    .WithMany(p => p.RecMasNewcanEdudets)
                    .HasForeignKey(d => d.IntQualificationId)
                    .HasConstraintName("rec_mas_newcan_edudet_fk2");
            });

            modelBuilder.Entity<RecMasNewcanEmpdet>(entity =>
            {
                entity.HasKey(e => e.IntNewCanEmpdetSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_mas_newcan_empdet");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntNewCandidateSeqId, "IDX_REC_MAS_NEWCAN_EMPDET_NEW_CAND_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "rec_mas_newcan_int_company_id_idx");

                entity.Property(e => e.IntNewCanEmpdetSeqId)
                    .HasColumnName("int_new_can_empdet_seq_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntNewCandidateSeqId)
                    .HasColumnName("int_new_candidate_seq_id")
                    .HasComment("Reference from rec_mas_new_candidate");

                entity.Property(e => e.TsEmpFromdate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_emp_fromdate");

                entity.Property(e => e.TsEmpTodate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_emp_todate");

                entity.Property(e => e.TsUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("ts_updated_date");

                entity.Property(e => e.VchCompanyName)
                    .HasMaxLength(300)
                    .HasColumnName("vch_company_name");

                entity.Property(e => e.VchDesignationName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_designation_name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(90)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecMasNewcanEmpdets)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("rec_mas_newcan_int_company_id");

                entity.HasOne(d => d.IntNewCandidateSeq)
                    .WithMany(p => p.RecMasNewcanEmpdets)
                    .HasForeignKey(d => d.IntNewCandidateSeqId)
                    .HasConstraintName("rec_mas_newcan_empdet_fk1");
            });

            modelBuilder.Entity<RecMasReqIdHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("rec_mas_req_id_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_rec_mas_id_history_companyid");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntReqCode).HasColumnName("int_req_code");

                entity.HasOne(d => d.IntCompany)
                    .WithMany()
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_rec_mas_id_history_companyid");
            });

            modelBuilder.Entity<RecOfferLetterManagement>(entity =>
            {
                entity.HasKey(e => e.IntRecOfferManageId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_offer_letter_management");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "IDX_REC_TRANS_OFFLTR_MANG_COMP_ID");

                entity.HasIndex(e => e.IntCandidateSeqId, "IDX_REC_TRANS_OFFLTR_MANG_CREATE_CANDIDATE_SEQ_ID");

                entity.Property(e => e.IntRecOfferManageId)
                    .HasColumnName("int_rec_offer_manage_id")
                    .HasComment("Primary key of  table");

                entity.Property(e => e.BlobOfferLetter)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_offer_letter");

                entity.Property(e => e.DtExpectedDoj).HasColumnName("dt_expected_doj");

                entity.Property(e => e.DtOfferValidity).HasColumnName("dt_offer_validity");

                entity.Property(e => e.IntCandidateSeqId)
                    .HasColumnName("int_candidate_seq_id")
                    .HasComment("Reference from RecCreateNewCandidate");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from company_detail_master");

                entity.Property(e => e.IntCtcAmount).HasColumnName("int_ctc_amount");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_comments");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOfferLetterPath)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_offer_letter_path");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCandidateSeq)
                    .WithMany(p => p.RecOfferLetterManagements)
                    .HasForeignKey(d => d.IntCandidateSeqId)
                    .HasConstraintName("FK_CREATE_NEW_CAND");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecOfferLetterManagements)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_REC_TRANS_OFF_LTR_MANG_COMP_ID");
            });

            modelBuilder.Entity<RecTransManpowerRequest>(entity =>
            {
                entity.HasKey(e => e.IntManpowerReqId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_trans_manpower_request");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntEmpCategoryId, "IDX_RC_MAN_POWER_PLAN_REQ_CATEG_ID");

                entity.HasIndex(e => e.IntDomainId, "IDX_RC_MAN_POWER_PLAN_REQ_DOMAIN_ID");

                entity.HasIndex(e => e.IntPlanId, "IDX_RC_MAN_POWER_PLAN_REQ_PLAN_JOB_ID");

                entity.HasIndex(e => e.IntQualificationId, "IDX_RC_MAN_POWER_PLAN_REQ_QUAL_ID");

                entity.HasIndex(e => e.IntSkillId, "IDX_RC_MAN_POWER_PLAN_REQ_SKILL_ID");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_MAN_POWER_REQ_COMP_ID");

                entity.Property(e => e.IntManpowerReqId)
                    .HasColumnName("int_manpower_req_id")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DtClosedDate).HasColumnName("dt_closed_date");

                entity.Property(e => e.DtTenureFromDate).HasColumnName("dt_tenure_from_date");

                entity.Property(e => e.DtTenureToDate).HasColumnName("dt_tenure_to_date");

                entity.Property(e => e.IntAgeFrom).HasColumnName("int_age_from");

                entity.Property(e => e.IntAgeTo).HasColumnName("int_age_to");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference for company_detail_master");

                entity.Property(e => e.IntCompletedJobCount).HasColumnName("int_completed_job_count");

                entity.Property(e => e.IntDomainId)
                    .HasColumnName("int_domain_id")
                    .HasComment("Reference from DomainMaster");

                entity.Property(e => e.IntEmpCategoryId)
                    .HasColumnName("int_emp_category_id")
                    .HasComment("Reference from EmployeeCategoryMaster");

                entity.Property(e => e.IntPendingJobCount).HasColumnName("int_pending_job_count");

                entity.Property(e => e.IntPlanId)
                    .HasColumnName("int_plan_id")
                    .HasComment("Reference from rec_mas_manpower_plan");

                entity.Property(e => e.IntQualificationId)
                    .HasColumnName("int_qualification_id")
                    .HasComment("Reference from QualificationMaster");

                entity.Property(e => e.IntSalaryBandFrom).HasColumnName("int_salary_band_from");

                entity.Property(e => e.IntSalaryBandTo).HasColumnName("int_salary_band_to");

                entity.Property(e => e.IntSkillId)
                    .HasColumnName("int_skill_id")
                    .HasComment("Reference from SkillMaster");

                entity.Property(e => e.IntYearsexpFrom).HasColumnName("int_yearsexp_from");

                entity.Property(e => e.IntYearsexpTo).HasColumnName("int_yearsexp_to");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchGenderPref)
                    .HasMaxLength(6)
                    .HasColumnName("vch_gender_pref");

                entity.Property(e => e.VchImportance)
                    .HasMaxLength(5)
                    .HasColumnName("vch_importance");

                entity.Property(e => e.VchJobDescription)
                    .HasMaxLength(100)
                    .HasColumnName("vch_job_description");

                entity.Property(e => e.VchPublished)
                    .HasMaxLength(5)
                    .HasColumnName("vch_published");

                entity.Property(e => e.VchQualifications)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_qualifications");

                entity.Property(e => e.VchReferred)
                    .HasMaxLength(5)
                    .HasColumnName("vch_referred");

                entity.Property(e => e.VchRequestId)
                    .HasMaxLength(10)
                    .HasColumnName("vch_request_id");

                entity.Property(e => e.VchSkills)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_skills");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(5)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecTransManpowerRequests)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_MAN_POWER_REQ_COMP_ID");

                entity.HasOne(d => d.IntDomain)
                    .WithMany(p => p.RecTransManpowerRequests)
                    .HasForeignKey(d => d.IntDomainId)
                    .HasConstraintName("FK_RC_MAN_POWER_PLAN_REQ_DOMAIN_ID");

                entity.HasOne(d => d.IntEmpCategory)
                    .WithMany(p => p.RecTransManpowerRequests)
                    .HasForeignKey(d => d.IntEmpCategoryId)
                    .HasConstraintName("FK_RC_MAN_POWER_REQ_CATEG_ID");

                entity.HasOne(d => d.IntPlan)
                    .WithMany(p => p.RecTransManpowerRequests)
                    .HasForeignKey(d => d.IntPlanId)
                    .HasConstraintName("FK_RC_MAN_POWER_PLAN_REQ_PLAN_JOB_ID");

                entity.HasOne(d => d.IntQualification)
                    .WithMany(p => p.RecTransManpowerRequests)
                    .HasForeignKey(d => d.IntQualificationId)
                    .HasConstraintName("FK_RC_MAN_POWER_PLAN_REQ_QUAL_ID");

                entity.HasOne(d => d.IntSkill)
                    .WithMany(p => p.RecTransManpowerRequests)
                    .HasForeignKey(d => d.IntSkillId)
                    .HasConstraintName("FK_RC_MAN_POWER_PLAN_REQ_SKILL_ID");
            });

            modelBuilder.Entity<RecTransOfferletterManagement>(entity =>
            {
                entity.HasKey(e => e.IntRecOfferManageId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_trans_offerletter_management");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntNewCandidateSeqId, "IDX_REC_TRANS_OFFLTR_MANG_CANDIDATE_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "IDX_REC_TRANS_OFFLTR_MANG_COMP_ID");

                entity.HasIndex(e => e.IntMpPlanJobId, "IDX_REC_TRANS_OFFLTR_MANG_PLAN_JOB_ID");

                entity.Property(e => e.IntRecOfferManageId)
                    .HasColumnName("int_rec_offer_manage_id")
                    .HasComment("Primary key of  table");

                entity.Property(e => e.BlobOfferLetter)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_offer_letter");

                entity.Property(e => e.DtExpectedDoj).HasColumnName("dt_expected_doj");

                entity.Property(e => e.DtOfferValidity).HasColumnName("dt_offer_validity");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference from company_detail_master");

                entity.Property(e => e.IntCtcAmount).HasColumnName("int_ctc_amount");

                entity.Property(e => e.IntMpPlanJobId)
                    .HasColumnName("int_mp_plan_job_id")
                    .HasComment("Reference from RecMasManpowerPlanJobIds");

                entity.Property(e => e.IntNewCandidateSeqId)
                    .HasColumnName("int_new_candidate_seq_id")
                    .HasComment("Reference from RecMasNewCandidate");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchComments)
                    .HasMaxLength(1000)
                    .HasColumnName("vch_comments");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchOfferLetterPath)
                    .HasMaxLength(1500)
                    .HasColumnName("vch_offer_letter_path");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecTransOfferletterManagements)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_REC_TRANS_OFFLTR_MANG_COMP_ID");

                entity.HasOne(d => d.IntMpPlanJob)
                    .WithMany(p => p.RecTransOfferletterManagements)
                    .HasForeignKey(d => d.IntMpPlanJobId)
                    .HasConstraintName("FK_REC_TRANS_OFFLTR_MANG_PLAN_JOB_ID");

                entity.HasOne(d => d.IntNewCandidateSeq)
                    .WithMany(p => p.RecTransOfferletterManagements)
                    .HasForeignKey(d => d.IntNewCandidateSeqId)
                    .HasConstraintName("FK_REC_TRANS_OFFLTR_MANG_CAND_SEQ_ID");
            });

            modelBuilder.Entity<RecTransReferPublishRequest>(entity =>
            {
                entity.HasKey(e => e.IntPublishReqId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_trans_refer_publish_requests");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_TRANS_REFER_PUB_REQS_COMP_ID");

                entity.HasIndex(e => e.IntManpowerReqId, "IDX_RC_TRANS_REFER_PUB_REQS_REQ_ID");

                entity.Property(e => e.IntPublishReqId)
                    .HasColumnName("int_publish_req_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference for company_detail_master");

                entity.Property(e => e.IntManpowerReqId)
                    .HasColumnName("int_manpower_req_id")
                    .HasComment("Reference from rec_trans_manpower_request");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchMode)
                    .HasMaxLength(5)
                    .HasColumnName("vch_mode")
                    .HasComment("Contain either Refer(R) or Publish(P)");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchVendorDesignationIds)
                    .HasMaxLength(300)
                    .HasColumnName("vch_vendor_designation_ids");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecTransReferPublishRequests)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_TRANS_REFER_PUB_REQS_COMP_ID");

                entity.HasOne(d => d.IntManpowerReq)
                    .WithMany(p => p.RecTransReferPublishRequests)
                    .HasForeignKey(d => d.IntManpowerReqId)
                    .HasConstraintName("FK_RC_TRANS_REFER_PUB_REQS_REQ_ID");
            });

            modelBuilder.Entity<RecTransScheduleInterCandidate>(entity =>
            {
                entity.HasKey(e => e.IntTScIntCandId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_trans_schedule_inter_candidates");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_rc_t_sc_int_can_company_id_idx");

                entity.HasIndex(e => e.IntNewCandidateSeqId, "idx_rc_t_sc_int_can_can_seq_id");

                entity.HasIndex(e => e.IntEmployeeSeqId, "idx_rc_t_sc_int_can_emp_sq_id");

                entity.HasIndex(e => e.RecTransScheduleInterview, "idx_rc_t_sc_int_can_sch_int");

                entity.Property(e => e.IntTScIntCandId)
                    .HasColumnName("int_t_sc_int_cand_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId)
                    .HasColumnName("int_employee_seq_id")
                    .HasComment("Reference from employee_master");

                entity.Property(e => e.IntInterRoundNum).HasColumnName("int_inter_round_num");

                entity.Property(e => e.IntNewCandidateSeqId)
                    .HasColumnName("int_new_candidate_seq_id")
                    .HasComment("Reference from rec_mas_new_candidate");

                entity.Property(e => e.RecTransScheduleInterview)
                    .HasColumnName("rec_trans_schedule_interview")
                    .HasComment("Reference from rec_trans_schedule_interview");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("vch_status");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecTransScheduleInterCandidates)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("fk_rc_t_sc_int_can_company_id");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.RecTransScheduleInterCandidates)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("fk_rc_t_sc_int_can_emp_sq_id");

                entity.HasOne(d => d.IntNewCandidateSeq)
                    .WithMany(p => p.RecTransScheduleInterCandidates)
                    .HasForeignKey(d => d.IntNewCandidateSeqId)
                    .HasConstraintName("fk_rc_t_sc_int_can_can_seq_id");

                entity.HasOne(d => d.RecTransScheduleInterviewNavigation)
                    .WithMany(p => p.RecTransScheduleInterCandidates)
                    .HasForeignKey(d => d.RecTransScheduleInterview)
                    .HasConstraintName("fk_rc_t_sc_int_can_sch_int");
            });

            modelBuilder.Entity<RecTransScheduleInterview>(entity =>
            {
                entity.HasKey(e => e.IntScheduleInterId)
                    .HasName("PRIMARY");

                entity.ToTable("rec_trans_schedule_interview");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "IDX_RC_TRANS_SCHED_INTER_COMP_ID");

                entity.HasIndex(e => e.IntEmployeeSeqId, "IDX_RC_TRANS_SCHED_INTER_EMP_SEQ_ID");

                entity.Property(e => e.IntScheduleInterId)
                    .HasColumnName("int_schedule_inter_id")
                    .HasComment("Primary key of table");

                entity.Property(e => e.DtInterviewDateFrom).HasColumnName("dt_interview_date_from");

                entity.Property(e => e.DtInterviewDateTo).HasColumnName("dt_interview_date_to");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_time");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("int_company_id")
                    .HasComment("Reference for company_detail_master");

                entity.Property(e => e.IntEmployeeSeqId)
                    .HasColumnName("int_employee_seq_id")
                    .HasComment("Reference from Employee_Master");

                entity.Property(e => e.TsInterviewTimeFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_interview_time_from");

                entity.Property(e => e.TsInterviewTimeTo)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_interview_time_to");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("vch_created_time");

                entity.Property(e => e.VchInterviewType)
                    .HasMaxLength(50)
                    .HasColumnName("vch_interview_type");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchVenue)
                    .HasMaxLength(500)
                    .HasColumnName("vch_venue");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.RecTransScheduleInterviews)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_RC_TRANS_SCHED_INTER_COMP_ID");

                entity.HasOne(d => d.IntEmployeeSeq)
                    .WithMany(p => p.RecTransScheduleInterviews)
                    .HasForeignKey(d => d.IntEmployeeSeqId)
                    .HasConstraintName("FK_RC_TRANS_SCHED_INTER_EMP_SEQ_ID");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreAppraisal>(entity =>
            {
                entity.HasKey(e => e.IntApprReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_appraisal");

                entity.Property(e => e.IntApprReptId).HasColumnName("int_appr_rept_id");

                entity.Property(e => e.AppraisalStatus)
                    .HasMaxLength(100)
                    .HasColumnName("Appraisal_Status");

                entity.Property(e => e.CompetencyPeer1AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Peer1_Avg_Score");

                entity.Property(e => e.CompetencyPeer2AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Peer2_Avg_Score");

                entity.Property(e => e.CompetencyPeer3AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Peer3_Avg_Score");

                entity.Property(e => e.CompetencySelfAvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Self_Avg_Score");

                entity.Property(e => e.CompetencySkipSuperiorAvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Skip_Superior_Avg_Score");

                entity.Property(e => e.CompetencySubordinate1AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Subordinate1_Avg_Score");

                entity.Property(e => e.CompetencySubordinate2AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Subordinate2_Avg_Score");

                entity.Property(e => e.CompetencySubordinate3AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Subordinate3_Avg_Score");

                entity.Property(e => e.CompetencySuperiorAvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Competency_Superior_Avg_Score");

                entity.Property(e => e.DepartmentName)
                    .HasMaxLength(100)
                    .HasColumnName("Department_Name");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(100)
                    .HasColumnName("Designation_Name");

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_ID");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.GoalPeer1AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Peer1_Avg_Score");

                entity.Property(e => e.GoalPeer2AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Peer2_Avg_Score");

                entity.Property(e => e.GoalPeer3AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Peer3_Avg_Score");

                entity.Property(e => e.GoalSelfAvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Self_Avg_Score");

                entity.Property(e => e.GoalSubordinate1AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Subordinate1_Avg_Score");

                entity.Property(e => e.GoalSubordinate2AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Subordinate2_Avg_Score");

                entity.Property(e => e.GoalSubordinate3AvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Subordinate3_Avg_Score");

                entity.Property(e => e.GoalSuperiorAvgScore)
                    .HasMaxLength(20)
                    .HasColumnName("Goal_Superior_Avg_Score");

                entity.Property(e => e.IncrementAmount)
                    .HasMaxLength(50)
                    .HasColumnName("Increment_Amount");

                entity.Property(e => e.IncrementPercentage)
                    .HasMaxLength(100)
                    .HasColumnName("Increment_Percentage");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeId).HasColumnName("INT_EMPLOYEE_ID");

                entity.Property(e => e.IntReviewSeqid).HasColumnName("INT_REVIEW_SEQID");

                entity.Property(e => e.KraGroupName)
                    .HasMaxLength(100)
                    .HasColumnName("KRA_Group_Name");

                entity.Property(e => e.LetterGenerationStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Letter_Generation_Status");

                entity.Property(e => e.LocationName)
                    .HasMaxLength(100)
                    .HasColumnName("Location_Name");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.OriginalCtc)
                    .HasMaxLength(50)
                    .HasColumnName("Original_CTC");

                entity.Property(e => e.PerformancePeriodEndDate).HasColumnName("Performance_Period_End_Date");

                entity.Property(e => e.PerformancePeriodStartDate).HasColumnName("Performance_Period_Start_Date");

                entity.Property(e => e.ReviewCycleDescription)
                    .HasMaxLength(500)
                    .HasColumnName("Review_Cycle_Description");

                entity.Property(e => e.ReviewPeriodRoleChangeDate).HasColumnName("Review_Period_Role_Change_Date");

                entity.Property(e => e.ReviewPeriodStatus)
                    .HasMaxLength(100)
                    .HasColumnName("Review_Period_Status");

                entity.Property(e => e.ReviewStartDate).HasColumnName("Review_Start_Date");

                entity.Property(e => e.ReviewType)
                    .HasMaxLength(100)
                    .HasColumnName("Review_Type");

                entity.Property(e => e.RmEmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("RM_Employee_ID");

                entity.Property(e => e.RmName)
                    .HasMaxLength(100)
                    .HasColumnName("RM_Name");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreConfAttribute>(entity =>
            {
                entity.HasKey(e => e.IntConfReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_conf_attributes");

                entity.Property(e => e.IntConfReptId).HasColumnName("int_conf_rept_id");

                entity.Property(e => e.ApproverAction)
                    .HasMaxLength(100)
                    .HasColumnName("Approver_Action");

                entity.Property(e => e.ConfirmationDueDate).HasColumnName("Confirmation_Due_Date");

                entity.Property(e => e.ConfirmationStatus)
                    .HasMaxLength(100)
                    .HasColumnName("Confirmation_Status");

                entity.Property(e => e.DateOfJoining).HasColumnName("Date_Of_Joining");

                entity.Property(e => e.DaysExtended).HasColumnName("Days_Extended");

                entity.Property(e => e.Designation).HasMaxLength(100);

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Code");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.ExtendedFrom).HasColumnName("Extended_From");

                entity.Property(e => e.ExtendedTo).HasColumnName("Extended_To");

                entity.Property(e => e.HrComment)
                    .HasMaxLength(100)
                    .HasColumnName("HR_Comment");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.RcsGrade)
                    .HasMaxLength(100)
                    .HasColumnName("RCS_Grade");

                entity.Property(e => e.RmCode)
                    .HasMaxLength(100)
                    .HasColumnName("RM_Code");

                entity.Property(e => e.RmComment)
                    .HasMaxLength(100)
                    .HasColumnName("RM_Comment");

                entity.Property(e => e.RmName)
                    .HasMaxLength(100)
                    .HasColumnName("RM_Name");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreDhlAttribute>(entity =>
            {
                entity.HasKey(e => e.IntDhlReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_dhl_attributes");

                entity.Property(e => e.IntDhlReptId).HasColumnName("int_dhl_rept_id");

                entity.Property(e => e.AbeCode)
                    .HasMaxLength(100)
                    .HasColumnName("ABE_Code");

                entity.Property(e => e.BankName)
                    .HasMaxLength(100)
                    .HasColumnName("Bank_Name");

                entity.Property(e => e.Billing).HasMaxLength(100);

                entity.Property(e => e.BusinessPartner)
                    .HasMaxLength(100)
                    .HasColumnName("Business_Partner");

                entity.Property(e => e.BusinessUnit)
                    .HasMaxLength(100)
                    .HasColumnName("Business_Unit");

                entity.Property(e => e.CasualLeave).HasColumnName("Casual_Leave");

                entity.Property(e => e.CovaccineLeave).HasColumnName("Covaccine_Leave");

                entity.Property(e => e.DateOfJoining).HasColumnName("Date_Of_Joining");

                entity.Property(e => e.DateOfLeaving).HasColumnName("Date_Of_Leaving");

                entity.Property(e => e.Departments).HasMaxLength(100);

                entity.Property(e => e.Designation).HasMaxLength(100);

                entity.Property(e => e.DpdhlJoining).HasColumnName("DPDHL_Joining");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Code");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.EmploymentType)
                    .HasMaxLength(100)
                    .HasColumnName("Employment_Type");

                entity.Property(e => e.GroupDoj).HasColumnName("Group_DOJ");

                entity.Property(e => e.GroupName)
                    .HasMaxLength(100)
                    .HasColumnName("Group_Name");

                entity.Property(e => e.HireType)
                    .HasMaxLength(100)
                    .HasColumnName("Hire_Type");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ItsRoleSfia)
                    .HasMaxLength(100)
                    .HasColumnName("ITS_Role_SFIA");

                entity.Property(e => e.Ldap)
                    .HasMaxLength(100)
                    .HasColumnName("LDAP");

                entity.Property(e => e.LeaveGroup)
                    .HasMaxLength(100)
                    .HasColumnName("Leave_Group");

                entity.Property(e => e.MaritalStatus)
                    .HasMaxLength(100)
                    .HasColumnName("Marital_Status");

                entity.Property(e => e.MaternityLeave).HasColumnName("Maternity_Leave");

                entity.Property(e => e.MidPoint)
                    .HasMaxLength(100)
                    .HasColumnName("Mid_Point");

                entity.Property(e => e.MiscarriageLeave).HasColumnName("Miscarriage_Leave");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.OnCallAllowanceEligibility)
                    .HasMaxLength(100)
                    .HasColumnName("On_Call_Allowance_Eligibility");

                entity.Property(e => e.OptionalLeave).HasColumnName("Optional_Leave");

                entity.Property(e => e.PaternityLeave).HasColumnName("Paternity_Leave");

                entity.Property(e => e.PhysicalStatus)
                    .HasMaxLength(100)
                    .HasColumnName("Physical_Status");

                entity.Property(e => e.PrivilegeLeave).HasColumnName("Privilege_Leave");

                entity.Property(e => e.ProductivityFactor)
                    .HasMaxLength(100)
                    .HasColumnName("Productivity_Factor");

                entity.Property(e => e.ProfessionalShiftAllowanceEligibility)
                    .HasMaxLength(100)
                    .HasColumnName("Professional_Shift_Allowance_Eligibility");

                entity.Property(e => e.RcsGrade)
                    .HasMaxLength(100)
                    .HasColumnName("RCS_Grade");

                entity.Property(e => e.RcsLevel)
                    .HasMaxLength(100)
                    .HasColumnName("RCS_Level");

                entity.Property(e => e.SapActionCode)
                    .HasMaxLength(100)
                    .HasColumnName("SAP_Action_Code");

                entity.Property(e => e.SapEmployeeNo)
                    .HasMaxLength(100)
                    .HasColumnName("SAP_Employee_NO");

                entity.Property(e => e.SapPositionId)
                    .HasMaxLength(100)
                    .HasColumnName("SAP_Position_ID");

                entity.Property(e => e.SapReasonCode)
                    .HasMaxLength(100)
                    .HasColumnName("SAP_Reason_Code");

                entity.Property(e => e.ShiftAllowanceEligibility)
                    .HasMaxLength(100)
                    .HasColumnName("Shift_Allowance_Eligibility");

                entity.Property(e => e.SickLeave).HasColumnName("Sick_Leave");

                entity.Property(e => e.SubDepartment)
                    .HasMaxLength(100)
                    .HasColumnName("Sub_Department");

                entity.Property(e => e.TaxSlabOptedFor)
                    .HasMaxLength(100)
                    .HasColumnName("Tax_Slab_Opted_for");

                entity.Property(e => e.TotalExperience)
                    .HasMaxLength(100)
                    .HasColumnName("Total_Experience");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TypeOfWorker)
                    .HasMaxLength(100)
                    .HasColumnName("Type_Of_Worker");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreEmpSignupAttribute>(entity =>
            {
                entity.HasKey(e => e.IntEmpSignupId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_emp_signup_attributes");

                entity.Property(e => e.IntEmpSignupId).HasColumnName("int_emp_signup_id");

                entity.Property(e => e.DateOfJoining).HasColumnName("Date_Of_Joining");

                entity.Property(e => e.Designation).HasMaxLength(100);

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Code");

                entity.Property(e => e.EmployeeMail)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Mail");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.RcsGrade)
                    .HasMaxLength(100)
                    .HasColumnName("RCS_Grade");

                entity.Property(e => e.ReportDate)
                    .HasColumnType("datetime")
                    .HasColumnName("Report_Date");

                entity.Property(e => e.SignupRequest)
                    .HasMaxLength(100)
                    .HasColumnName("Signup_Request");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreEmployeeAllowance>(entity =>
            {
                entity.HasKey(e => e.IntAllowanceReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_employee_allowance");

                entity.Property(e => e.IntAllowanceReptId).HasColumnName("int_allowance_rept_id");

                entity.Property(e => e.Amount).HasMaxLength(100);

                entity.Property(e => e.CreatedDate).HasColumnName("Created_Date");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_Code");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.PayHead)
                    .HasMaxLength(100)
                    .HasColumnName("Pay_Head");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreExit>(entity =>
            {
                entity.HasKey(e => e.IntExitReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_exit");

                entity.Property(e => e.IntExitReptId).HasColumnName("int_exit_rept_id");

                entity.Property(e => e.AdminStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Admin_Status");

                entity.Property(e => e.ChequeDate).HasColumnName("Cheque_Date");

                entity.Property(e => e.ChequeNumber)
                    .HasMaxLength(20)
                    .HasColumnName("Cheque_Number");

                entity.Property(e => e.DateOfJoining).HasColumnName("Date_Of_Joining");

                entity.Property(e => e.DateOfLeaving).HasColumnName("Date_of_Leaving");

                entity.Property(e => e.DateOfResignation).HasColumnName("Date_of_Resignation");

                entity.Property(e => e.Department).HasMaxLength(100);

                entity.Property(e => e.Designation).HasMaxLength(100);

                entity.Property(e => e.EmployeeComments)
                    .HasMaxLength(400)
                    .HasColumnName("Employee_Comments");

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_ID");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.FinanceStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Finance_Status");

                entity.Property(e => e.FnfAmount)
                    .HasMaxLength(100)
                    .HasColumnName("FNF_amount");

                entity.Property(e => e.HrComments)
                    .HasMaxLength(400)
                    .HasColumnName("HR_Comments");

                entity.Property(e => e.HrEmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("HR_Employee_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ItStatus)
                    .HasMaxLength(50)
                    .HasColumnName("IT_Status");

                entity.Property(e => e.LearningStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Learning_Status");

                entity.Property(e => e.Location).HasMaxLength(100);

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.NoticePeriodRecoveryDays).HasColumnName("Notice_Period_Recovery_Days");

                entity.Property(e => e.NoticePeriodToBeRecoveredWaived).HasColumnName("Notice_Period_to_be_recovered_Waived");

                entity.Property(e => e.NoticePeriodToBeServed).HasColumnName("Notice_Period_To_Be_Served");

                entity.Property(e => e.RequestedDateOfLeaving)
                    .HasColumnType("datetime")
                    .HasColumnName("Requested_Date_of_Leaving");

                entity.Property(e => e.ResignationReason)
                    .HasMaxLength(500)
                    .HasColumnName("Resignation_Reason");

                entity.Property(e => e.ResignationRequestDate).HasColumnName("Resignation_Request_Date");

                entity.Property(e => e.ResignationRequestStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Resignation_Request_Status");

                entity.Property(e => e.ResignationType)
                    .HasMaxLength(100)
                    .HasColumnName("Resignation_Type");

                entity.Property(e => e.RmComments)
                    .HasMaxLength(400)
                    .HasColumnName("RM_Comments");

                entity.Property(e => e.RmEmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("RM_Employee_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreExitclrAttribute>(entity =>
            {
                entity.HasKey(e => e.IntExitclrReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_exitclr_attributes");

                entity.Property(e => e.IntExitclrReptId).HasColumnName("int_exitclr_rept_id");

                entity.Property(e => e.DateOfLeaving).HasColumnName("Date_of_Leaving");

                entity.Property(e => e.DateOfResignation).HasColumnName("Date_of_Resignation");

                entity.Property(e => e.Department).HasMaxLength(100);

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_ID");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.Items).HasMaxLength(100);

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.Remark).HasMaxLength(100);

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreKycAttribute>(entity =>
            {
                entity.HasKey(e => e.IntKycId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_kyc_attributes");

                entity.Property(e => e.IntKycId).HasColumnName("int_kyc_id");

                entity.Property(e => e.AadhaarNumber)
                    .HasMaxLength(40)
                    .HasColumnName("Aadhaar_Number");

                entity.Property(e => e.AccountNumber)
                    .HasMaxLength(50)
                    .HasColumnName("Account_Number");

                entity.Property(e => e.BankName)
                    .HasMaxLength(100)
                    .HasColumnName("Bank_Name");

                entity.Property(e => e.Branch).HasMaxLength(80);

                entity.Property(e => e.DlNumber)
                    .HasMaxLength(20)
                    .HasColumnName("DL_Number");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Code");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.EsiNumber)
                    .HasMaxLength(20)
                    .HasColumnName("ESI_Number");

                entity.Property(e => e.IfscCode)
                    .HasMaxLength(30)
                    .HasColumnName("IFSC_Code");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.PanNumber)
                    .HasMaxLength(20)
                    .HasColumnName("PAN_Number");

                entity.Property(e => e.PassportNumber)
                    .HasMaxLength(40)
                    .HasColumnName("Passport_Number");

                entity.Property(e => e.PfNumber)
                    .HasMaxLength(25)
                    .HasColumnName("PF_Number");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.UanNumber)
                    .HasMaxLength(40)
                    .HasColumnName("UAN_Number");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreNomineeAttribute>(entity =>
            {
                entity.HasKey(e => e.IntNomineeId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_nominee_attributes");

                entity.Property(e => e.IntNomineeId).HasColumnName("int_nominee_id");

                entity.Property(e => e.DateOfBirth)
                    .HasColumnType("datetime")
                    .HasColumnName("Date_Of_Birth");

                entity.Property(e => e.EmployeeCode)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Code");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Name");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.NomineeName)
                    .HasMaxLength(100)
                    .HasColumnName("Nominee_Name");

                entity.Property(e => e.Relation).HasMaxLength(60);

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreOnboarding>(entity =>
            {
                entity.HasKey(e => e.IntOnbReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_onboarding");

                entity.Property(e => e.IntOnbReptId).HasColumnName("int_onb_rept_id");

                entity.Property(e => e.CostCenter)
                    .HasMaxLength(100)
                    .HasColumnName("Cost_Center");

                entity.Property(e => e.Department).HasMaxLength(100);

                entity.Property(e => e.Designation).HasMaxLength(100);

                entity.Property(e => e.EmployeeAadhar)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_Aadhar");

                entity.Property(e => e.EmployeeBankAccountNumber)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Bank_Account_Number");

                entity.Property(e => e.EmployeeBankBranch)
                    .HasMaxLength(50)
                    .HasColumnName("Employee_Bank_Branch");

                entity.Property(e => e.EmployeeBankIfsc)
                    .HasMaxLength(50)
                    .HasColumnName("Employee_Bank_IFSC");

                entity.Property(e => e.EmployeeBankName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Bank_Name");

                entity.Property(e => e.EmployeeCategory)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Category");

                entity.Property(e => e.EmployeeCity)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_City");

                entity.Property(e => e.EmployeeCountry)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Country");

                entity.Property(e => e.EmployeeCurrentCtc)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Current_CTC");

                entity.Property(e => e.EmployeeDob).HasColumnName("Employee_DOB");

                entity.Property(e => e.EmployeeDoj).HasColumnName("Employee_DOJ");

                entity.Property(e => e.EmployeeExperience)
                    .HasMaxLength(5)
                    .HasColumnName("Employee_Experience");

                entity.Property(e => e.EmployeeFirstName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_First_Name");

                entity.Property(e => e.EmployeeGender)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_Gender");

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(30)
                    .HasColumnName("Employee_ID");

                entity.Property(e => e.EmployeeLastName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Last_Name");

                entity.Property(e => e.EmployeeMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Middle_Name");

                entity.Property(e => e.EmployeeMobileNo)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_Mobile_No");

                entity.Property(e => e.EmployeePan)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_PAN");

                entity.Property(e => e.EmployeePassport)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_Passport");

                entity.Property(e => e.EmployeePinCode)
                    .HasMaxLength(10)
                    .HasColumnName("Employee_PIN_Code");

                entity.Property(e => e.EmployeePreviousCtc)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Previous_CTC");

                entity.Property(e => e.EmployeePreviousDesignation)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Previous_Designation");

                entity.Property(e => e.EmployeePreviousEmployerName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_Previous_Employer_Name");

                entity.Property(e => e.EmployeeSchoolName)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_School_Name");

                entity.Property(e => e.EmployeeSchoolPassOutYear)
                    .HasMaxLength(10)
                    .HasColumnName("Employee_School_Pass_Out_Year");

                entity.Property(e => e.EmployeeState)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_State");

                entity.Property(e => e.EmployeeUan)
                    .HasMaxLength(20)
                    .HasColumnName("Employee_UAN");

                entity.Property(e => e.EmployeeUniversity)
                    .HasMaxLength(100)
                    .HasColumnName("Employee_University");

                entity.Property(e => e.EmployeeUniversityPassOutYear)
                    .HasMaxLength(10)
                    .HasColumnName("Employee_University_Pass_Out_Year");

                entity.Property(e => e.Grade).HasMaxLength(100);

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.Location).HasMaxLength(100);

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.OnboardingInitiatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("Onboarding_Initiated_By");

                entity.Property(e => e.OnboardingInitiatedDate).HasColumnName("Onboarding_Initiated_Date");

                entity.Property(e => e.OnboardingInitiationReferenceNumber)
                    .HasMaxLength(50)
                    .HasColumnName("Onboarding_Initiation_Reference_Number");

                entity.Property(e => e.OnboardingRequestApprover)
                    .HasMaxLength(80)
                    .HasColumnName("Onboarding_Request_Approver");

                entity.Property(e => e.OnboardingRequestStatus)
                    .HasMaxLength(100)
                    .HasColumnName("Onboarding_Request_Status");

                entity.Property(e => e.ReportingManagerId)
                    .HasMaxLength(100)
                    .HasColumnName("Reporting_Manager_ID");

                entity.Property(e => e.ReportingManagerName)
                    .HasMaxLength(100)
                    .HasColumnName("Reporting_Manager_Name");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreRecruitment>(entity =>
            {
                entity.HasKey(e => e.IntRecReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_recruitment");

                entity.Property(e => e.IntRecReptId).HasColumnName("int_rec_rept_id");

                entity.Property(e => e.CandidateDob).HasColumnName("Candidate_DOB");

                entity.Property(e => e.CandidateExperience).HasColumnName("Candidate_Experience");

                entity.Property(e => e.CandidateGender)
                    .HasMaxLength(20)
                    .HasColumnName("Candidate_Gender");

                entity.Property(e => e.CandidateId)
                    .HasMaxLength(40)
                    .HasColumnName("Candidate_ID");

                entity.Property(e => e.CandidateMailId)
                    .HasMaxLength(100)
                    .HasColumnName("Candidate_Mail_ID");

                entity.Property(e => e.CandidateName)
                    .HasMaxLength(100)
                    .HasColumnName("Candidate_Name");

                entity.Property(e => e.CandidatePhoneNumber)
                    .HasMaxLength(50)
                    .HasColumnName("Candidate_Phone_Number");

                entity.Property(e => e.CandidatePreviousEmployerName)
                    .HasMaxLength(100)
                    .HasColumnName("Candidate_Previous_Employer_Name");

                entity.Property(e => e.ClosedRequest).HasColumnName("closed_request");

                entity.Property(e => e.CtcOffered)
                    .HasMaxLength(50)
                    .HasColumnName("CTC_Offered");

                entity.Property(e => e.Department).HasMaxLength(100);

                entity.Property(e => e.Designation).HasMaxLength(100);

                entity.Property(e => e.Domain).HasMaxLength(100);

                entity.Property(e => e.ExpectedDoj).HasColumnName("Expected_DOJ");

                entity.Property(e => e.HighImportance)
                    .HasMaxLength(5)
                    .HasColumnName("High_Importance");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.InternalReferralByName)
                    .HasMaxLength(100)
                    .HasColumnName("Internal_Referral_by_Name");

                entity.Property(e => e.InterviewDate).HasColumnName("Interview_Date");

                entity.Property(e => e.InterviewVenue)
                    .HasMaxLength(100)
                    .HasColumnName("Interview_Venue");

                entity.Property(e => e.InterviewerEmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("Interviewer_Employee_ID");

                entity.Property(e => e.InterviewerName)
                    .HasMaxLength(100)
                    .HasColumnName("Interviewer_Name");

                entity.Property(e => e.JobRequestCreatedDate).HasColumnName("Job_Request_Created_Date");

                entity.Property(e => e.JobRequestId)
                    .HasMaxLength(10)
                    .HasColumnName("Job_Request_ID");

                entity.Property(e => e.JobRequestStatus)
                    .HasMaxLength(10)
                    .HasColumnName("Job_Request_Status");

                entity.Property(e => e.Location).HasMaxLength(100);

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.OfferLetterGenerationDate).HasColumnName("Offer_Letter_Generation_Date");

                entity.Property(e => e.OpenRequest).HasColumnName("open_request");

                entity.Property(e => e.ProfileSource)
                    .HasMaxLength(10)
                    .HasColumnName("Profile_Source");

                entity.Property(e => e.PublishedRequest)
                    .HasMaxLength(5)
                    .HasColumnName("Published_Request");

                entity.Property(e => e.ReferredRequest)
                    .HasMaxLength(5)
                    .HasColumnName("Referred_Request");

                entity.Property(e => e.RequestClosedDate).HasColumnName("Request_Closed_Date");

                entity.Property(e => e.Skill).HasMaxLength(100);

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VendorName)
                    .HasMaxLength(100)
                    .HasColumnName("Vendor_Name");
            });

            modelBuilder.Entity<ReportToolGenericDataStoreTraining>(entity =>
            {
                entity.HasKey(e => e.IntTrainReptId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_data_store_training");

                entity.Property(e => e.IntTrainReptId).HasColumnName("int_train_rept_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.ModifiedDate).HasColumnName("Modified_Date");

                entity.Property(e => e.TrainingAttended)
                    .HasMaxLength(50)
                    .HasColumnName("Training_Attended");

                entity.Property(e => e.TrainingAttendedEmployeeTrainingCode)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Attended_Employee_Training_Code");

                entity.Property(e => e.TrainingCategoryName)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Category_Name");

                entity.Property(e => e.TrainingDepartment)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Department");

                entity.Property(e => e.TrainingFromDate).HasColumnName("Training_From_Date");

                entity.Property(e => e.TrainingInitiatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Initiated_By");

                entity.Property(e => e.TrainingLocation)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Location");

                entity.Property(e => e.TrainingRequestedDate).HasColumnName("Training_Requested_Date");

                entity.Property(e => e.TrainingRequestedEmployeeDepartment)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Requested_Employee_Department");

                entity.Property(e => e.TrainingRequestedEmployeeDesignation)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Requested_Employee_Designation");

                entity.Property(e => e.TrainingRequestedEmployeeId)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Requested_Employee_ID");

                entity.Property(e => e.TrainingRequestedEmployeeLocation)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Requested_Employee_Location");

                entity.Property(e => e.TrainingRequestedEmployeeRmId)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Requested_Employee_RM_ID");

                entity.Property(e => e.TrainingStatus)
                    .HasMaxLength(50)
                    .HasColumnName("Training_Status");

                entity.Property(e => e.TrainingToDate).HasColumnName("Training_To_Date");

                entity.Property(e => e.TrainingType)
                    .HasMaxLength(50)
                    .HasColumnName("Training_Type");

                entity.Property(e => e.TrainingVendorAddress)
                    .HasMaxLength(400)
                    .HasColumnName("Training_Vendor_Address");

                entity.Property(e => e.TrainingVendorEmail)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Vendor_Email");

                entity.Property(e => e.TrainingVendorMobile)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Vendor_Mobile");

                entity.Property(e => e.TrainingVendorName)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Vendor_Name");

                entity.Property(e => e.TrainingVenue)
                    .HasMaxLength(100)
                    .HasColumnName("Training_Venue");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");
            });

            modelBuilder.Entity<ReportToolGenericFieldName>(entity =>
            {
                entity.HasKey(e => e.IntGenFieldId)
                    .HasName("PRIMARY");

                entity.ToTable("report_tool_generic_field_names");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntGenFieldId).HasColumnName("int_gen_field_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDataType)
                    .HasMaxLength(10)
                    .HasColumnName("vch_data_type");

                entity.Property(e => e.VchFieldFor)
                    .HasMaxLength(5)
                    .HasColumnName("vch_field_for");

                entity.Property(e => e.VchFieldName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_field_name");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(5)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ReportsDomainMaster>(entity =>
            {
                entity.HasKey(e => e.IntId)
                    .HasName("PRIMARY");

                entity.ToTable("reports_domain_masters");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntId)
                    .ValueGeneratedNever()
                    .HasColumnName("int_id");

                entity.Property(e => e.VchDomainName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_DOMAIN_NAME");

                entity.Property(e => e.VchPackageName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_PACKAGE_NAME");
            });

            modelBuilder.Entity<ReportsFieldValue>(entity =>
            {
                entity.HasKey(e => e.IntReportsFieldValue)
                    .HasName("PRIMARY");

                entity.ToTable("reports_field_value");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntReportsQueryId, "fk_reports_query_field");

                entity.Property(e => e.IntReportsFieldValue).HasColumnName("INT_REPORTS_FIELD_VALUE");

                entity.Property(e => e.IntReportsQueryId).HasColumnName("INT_REPORTS_QUERY_ID");

                entity.Property(e => e.VchFieldName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_FIELD_NAME");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_OPERATION");

                entity.Property(e => e.VchValue)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_VALUE");

                entity.HasOne(d => d.IntReportsQuery)
                    .WithMany(p => p.ReportsFieldValues)
                    .HasForeignKey(d => d.IntReportsQueryId)
                    .HasConstraintName("fk_reports_query_field");
            });

            modelBuilder.Entity<ReportsGenericFieldValue>(entity =>
            {
                entity.HasKey(e => e.IntReportsFieldValue)
                    .HasName("PRIMARY");

                entity.ToTable("reports_generic_field_value");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntReportsQueryId, "RQMAS_RFVMAS_ID");

                entity.Property(e => e.IntReportsFieldValue).HasColumnName("INT_REPORTS_FIELD_VALUE");

                entity.Property(e => e.IntReportsQueryId).HasColumnName("INT_REPORTS_QUERY_ID");

                entity.Property(e => e.VchFieldName)
                    .HasMaxLength(200)
                    .HasColumnName("VCH_FIELD_NAME");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_OPERATION");

                entity.Property(e => e.VchValue)
                    .HasMaxLength(800)
                    .HasColumnName("VCH_VALUE");

                entity.HasOne(d => d.IntReportsQuery)
                    .WithMany(p => p.ReportsGenericFieldValues)
                    .HasForeignKey(d => d.IntReportsQueryId)
                    .HasConstraintName("RQMAS_RFVMAS_GENERIC_ID");
            });

            modelBuilder.Entity<ReportsGenericQuery>(entity =>
            {
                entity.HasKey(e => e.ReportsSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("reports_generic_query");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_REPORTS_QUERY_HIS_COMP_ID");

                entity.Property(e => e.ReportsSeqid).HasColumnName("REPORTS_SEQID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Query).HasColumnName("QUERY");

                entity.Property(e => e.QueryName)
                    .HasMaxLength(500)
                    .HasColumnName("QUERY_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchModeOfOperation)
                    .HasMaxLength(45)
                    .HasColumnName("vch_mode_of_operation");

                entity.Property(e => e.VchPackageName)
                    .HasMaxLength(200)
                    .HasColumnName("vch_package_name");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ReportsGenericQueries)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_REPORTS_GENERIC_QUERY_HIS_COMP_ID");
            });

            modelBuilder.Entity<ReportsGenericQueryField>(entity =>
            {
                entity.HasKey(e => e.IntReportsField)
                    .HasName("PRIMARY");

                entity.ToTable("reports_generic_query_fields");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntReportsQueryId, "RQFMAS_RQMAS_GENERIC");

                entity.Property(e => e.IntReportsField).HasColumnName("INT_REPORTS_FIELD");

                entity.Property(e => e.FieldName)
                    .HasMaxLength(100)
                    .HasColumnName("FIELD_NAME");

                entity.Property(e => e.IntReportsQueryId).HasColumnName("INT_REPORTS_QUERY_ID");

                entity.HasOne(d => d.IntReportsQuery)
                    .WithMany(p => p.ReportsGenericQueryFields)
                    .HasForeignKey(d => d.IntReportsQueryId)
                    .HasConstraintName("RQFMAS_RQMAS_GENERIC");
            });

            modelBuilder.Entity<ReportsMasStandardReportsList>(entity =>
            {
                entity.HasKey(e => e.IntRepStanRepListId)
                    .HasName("PRIMARY");

                entity.ToTable("reports_mas_standard_reports_list");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntRepStanRepListId).HasColumnName("int_rep_stan_rep_list_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchReportLabel)
                    .HasMaxLength(45)
                    .HasColumnName("vch_report_label");

                entity.Property(e => e.VchReportValue)
                    .HasMaxLength(45)
                    .HasColumnName("vch_report_value");

                entity.Property(e => e.VchShow)
                    .HasMaxLength(45)
                    .HasColumnName("vch_show");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ReportsQuery>(entity =>
            {
                entity.HasKey(e => e.ReportsSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("reports_query");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_REPORTS_QUERY_HIS_COMP_ID");

                entity.Property(e => e.ReportsSeqid).HasColumnName("REPORTS_SEQID");

                entity.Property(e => e.DtFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_to_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Query).HasColumnName("QUERY");

                entity.Property(e => e.QueryName)
                    .HasMaxLength(300)
                    .HasColumnName("QUERY_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(50)
                    .HasColumnName("vch_status");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ReportsQueries)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_REPORTS_QUERY_HIS_COMP_ID");
            });

            modelBuilder.Entity<ReportsQueryField>(entity =>
            {
                entity.HasKey(e => e.IntReportsField)
                    .HasName("PRIMARY");

                entity.ToTable("reports_query_fields");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntReportsQueryId, "fk_reports_query");

                entity.Property(e => e.IntReportsField).HasColumnName("INT_REPORTS_FIELD");

                entity.Property(e => e.FieldName)
                    .HasMaxLength(100)
                    .HasColumnName("FIELD_NAME");

                entity.Property(e => e.IntReportsQueryId).HasColumnName("INT_REPORTS_QUERY_ID");

                entity.HasOne(d => d.IntReportsQuery)
                    .WithMany(p => p.ReportsQueryFields)
                    .HasForeignKey(d => d.IntReportsQueryId)
                    .HasConstraintName("fk_reports_query");
            });

            modelBuilder.Entity<ReportsToolConditionValue>(entity =>
            {
                entity.HasKey(e => e.ReportsToolCondId)
                    .HasName("PRIMARY");

                entity.ToTable("reports_tool_condition_value");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntReportsToolQuerySeqid, "fk_reports_tool_condition_query");

                entity.Property(e => e.ReportsToolCondId).HasColumnName("REPORTS_TOOL_COND_ID");

                entity.Property(e => e.IntReportsToolQuerySeqid).HasColumnName("INT_REPORTS_TOOL_QUERY_SEQID");

                entity.Property(e => e.VchFieldName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_FIELD_NAME");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_OPERATION");

                entity.Property(e => e.VchOperator)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_OPERATOR");

                entity.Property(e => e.VchValue)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_VALUE");

                entity.HasOne(d => d.IntReportsToolQuerySeq)
                    .WithMany(p => p.ReportsToolConditionValues)
                    .HasForeignKey(d => d.IntReportsToolQuerySeqid)
                    .HasConstraintName("fk_reports_tool_condition_query");
            });

            modelBuilder.Entity<ReportsToolFieldStatusValue>(entity =>
            {
                entity.HasKey(e => e.IntGenFieldStatusId)
                    .HasName("PRIMARY");

                entity.ToTable("reports_tool_field_status_value");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntGenFieldStatusId).HasColumnName("int_gen_field_status_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchFieldName)
                    .HasMaxLength(64)
                    .HasColumnName("vch_field_name");

                entity.Property(e => e.VchFieldValue)
                    .HasMaxLength(100)
                    .HasColumnName("vch_field_value");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(5)
                    .HasColumnName("vch_module_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ReportsToolQuery>(entity =>
            {
                entity.HasKey(e => e.ReportsToolQuerySeqid)
                    .HasName("PRIMARY");

                entity.ToTable("reports_tool_query");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_REPORTS_TOOL_QUERY_COMP_ID");

                entity.Property(e => e.ReportsToolQuerySeqid).HasColumnName("REPORTS_TOOL_QUERY_SEQID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.QueryName)
                    .HasMaxLength(300)
                    .HasColumnName("QUERY_NAME");

                entity.Property(e => e.QueryValue).HasColumnName("QUERY_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchFieldNames)
                    .HasColumnType("text")
                    .HasColumnName("VCH_FIELD_NAMES");

                entity.Property(e => e.VchModuleName)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_MODULE_NAME");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_STATUS");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.ReportsToolQueries)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_REPORTS_TOOL_QUERY_COMP_ID");
            });

            modelBuilder.Entity<RoleMClientAdminNoHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("role_m_client_admin_no_history");

                entity.HasComment("Using for generating client admin number")
                    .HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VarLastAdminId)
                    .HasMaxLength(20)
                    .HasColumnName("var_last_admin_id");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<RoleMClientUserNoHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("role_m_client_user_no_history");

                entity.HasComment("Using for generating client user number")
                    .HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VarLastClUserId)
                    .HasMaxLength(20)
                    .HasColumnName("var_last_cl_user_id");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<RoleMCompanyNoHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("role_m_company_no_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VarLastCompanyId)
                    .HasMaxLength(20)
                    .HasColumnName("var_last_company_id");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");
            });

            modelBuilder.Entity<RoleMTmiNoHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("role_m_tmi_no_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VarLastTmiId)
                    .HasMaxLength(20)
                    .HasColumnName("var_last_tmi_id");
            });

            modelBuilder.Entity<SkillMaster>(entity =>
            {
                entity.HasKey(e => e.SkillSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("skill_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.SkillSeqId).HasColumnName("SKILL_SEQ_ID");

                entity.Property(e => e.DomainNameId)
                    .HasPrecision(20)
                    .HasColumnName("DOMAIN_NAME_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.SkillName)
                    .HasMaxLength(100)
                    .HasColumnName("SKILL_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDomainName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_domain_name");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<SkillMasterTmp>(entity =>
            {
                entity.HasKey(e => e.SkillSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("skill_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.SkillSeqId).HasColumnName("SKILL_SEQ_ID");

                entity.Property(e => e.DomainNameId)
                    .HasPrecision(20)
                    .HasColumnName("DOMAIN_NAME_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.SkillName)
                    .HasColumnType("text")
                    .HasColumnName("SKILL_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDomainName)
                    .HasColumnType("text")
                    .HasColumnName("vch_domain_name");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.HasKey(e => e.StateSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("state");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.StateSeqId).HasColumnName("STATE_SEQ_ID");

                entity.Property(e => e.CountryId).HasColumnName("COUNTRY_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.StateName)
                    .HasMaxLength(100)
                    .HasColumnName("STATE_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCountryName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_country_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(50)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<StateTmp>(entity =>
            {
                entity.HasKey(e => e.StateSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("state_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.StateSeqId).HasColumnName("STATE_SEQ_ID");

                entity.Property(e => e.CountryId).HasColumnName("COUNTRY_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.StateName)
                    .HasColumnType("text")
                    .HasColumnName("state_name");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCountryName)
                    .HasColumnType("text")
                    .HasColumnName("vch_country_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(50)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<SubdepartmentMaster>(entity =>
            {
                entity.HasKey(e => e.SubdepartmentSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("subdepartment_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.SubdepartmentSeqId).HasColumnName("SUBDEPARTMENT_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.SubdepartmentName)
                    .HasMaxLength(100)
                    .HasColumnName("SUBDEPARTMENT_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<SubdepartmentMasterTmp>(entity =>
            {
                entity.HasKey(e => e.SubdepartmentSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("subdepartment_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.SubdepartmentSeqId).HasColumnName("SUBDEPARTMENT_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.SubdepartmentName)
                    .HasMaxLength(100)
                    .HasColumnName("SUBDEPARTMENT_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<TaxSlabOptedforMaster>(entity =>
            {
                entity.HasKey(e => e.IntTaxSlabOptedforId)
                    .HasName("PRIMARY");

                entity.ToTable("tax_slab_optedfor_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTaxSlabOptedforId).HasColumnName("INT_TAX_SLAB_OPTEDFOR_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTaxSlabOptedforName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_TAX_SLAB_OPTEDFOR_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<TaxSlabOptedforMasterTmp>(entity =>
            {
                entity.HasKey(e => e.IntTaxSlabOptedforId)
                    .HasName("PRIMARY");

                entity.ToTable("tax_slab_optedfor_master_tmp");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTaxSlabOptedforId).HasColumnName("INT_TAX_SLAB_OPTEDFOR_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTaxSlabOptedforName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_TAX_SLAB_OPTEDFOR_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<TrainMasCategory>(entity =>
            {
                entity.HasKey(e => e.IntCategoryId)
                    .HasName("PRIMARY");

                entity.ToTable("train_mas_category");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_M_CATE_COMP_ID");

                entity.Property(e => e.IntCategoryId).HasColumnName("INT_CATEGORY_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCategoryDesc)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_CATEGORY_DESC");

                entity.Property(e => e.VchCategoryName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CATEGORY_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainMasCategories)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_M_CATE_COMP_ID");
            });

            modelBuilder.Entity<TrainMasQuestion>(entity =>
            {
                entity.HasKey(e => e.IntQuestionId)
                    .HasName("PRIMARY");

                entity.ToTable("train_mas_question");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_M_QUES_COMP_ID");

                entity.Property(e => e.IntQuestionId)
                    .HasColumnName("INT_QUESTION_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchAnsQuest1)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST1");

                entity.Property(e => e.VchAnsQuest10)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST10");

                entity.Property(e => e.VchAnsQuest2)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST2");

                entity.Property(e => e.VchAnsQuest3)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST3");

                entity.Property(e => e.VchAnsQuest4)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST4");

                entity.Property(e => e.VchAnsQuest5)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST5");

                entity.Property(e => e.VchAnsQuest6)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST6");

                entity.Property(e => e.VchAnsQuest7)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST7");

                entity.Property(e => e.VchAnsQuest8)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST8");

                entity.Property(e => e.VchAnsQuest9)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ANS_QUEST9");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchQuestion1)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION1");

                entity.Property(e => e.VchQuestion10)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION10");

                entity.Property(e => e.VchQuestion2)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION2");

                entity.Property(e => e.VchQuestion3)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION3");

                entity.Property(e => e.VchQuestion4)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION4");

                entity.Property(e => e.VchQuestion5)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION5");

                entity.Property(e => e.VchQuestion6)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION6");

                entity.Property(e => e.VchQuestion7)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION7");

                entity.Property(e => e.VchQuestion8)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION8");

                entity.Property(e => e.VchQuestion9)
                    .HasMaxLength(500)
                    .HasColumnName("VCH_QUESTION9");

                entity.Property(e => e.VchQuestionTmpName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_QUESTION_TMP_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainMasQuestions)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_M_QUES_COMP_ID");
            });

            modelBuilder.Entity<TrainMasTrCodeHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("train_mas_tr_code_history");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_M_COD_HIS_COMP_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTrainCode)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_TRAIN_CODE");

                entity.HasOne(d => d.IntCompany)
                    .WithMany()
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_M_COD_HIS_COMP_ID");
            });

            modelBuilder.Entity<TrainMasType>(entity =>
            {
                entity.HasKey(e => e.IntTypeId)
                    .HasName("PRIMARY");

                entity.ToTable("train_mas_types");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_M_TYPES_COMP_ID");

                entity.Property(e => e.IntTypeId).HasColumnName("INT_TYPE_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCategoryId).HasColumnName("int_category_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTrainingDesc)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_TRAINING_DESC");

                entity.Property(e => e.VchTrainingName)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_TRAINING_NAME");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainMasTypes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_M_TYPES_COMP_ID");
            });

            modelBuilder.Entity<TrainMasVendor>(entity =>
            {
                entity.HasKey(e => e.IntTrainingVendSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("train_mas_vendor");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_M_VEN_COMP_ID");

                entity.Property(e => e.IntTrainingVendSeqid)
                    .HasColumnName("INT_TRAINING_VEND_SEQID")
                    .HasComment("Primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchPostalAddress)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_POSTAL_ADDRESS")
                    .HasComment("postal address");

                entity.Property(e => e.VchTrainVendorMail)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_TRAIN_VENDOR_MAIL");

                entity.Property(e => e.VchTrainVendorMobile)
                    .HasMaxLength(12)
                    .HasColumnName("VCH_TRAIN_VENDOR_MOBILE");

                entity.Property(e => e.VchTrainVendorName)
                    .HasMaxLength(52)
                    .HasColumnName("VCH_TRAIN_VENDOR_NAME")
                    .HasComment("trianer Name");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainMasVendors)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_M_VEN_COMP_ID");
            });

            modelBuilder.Entity<TrainMasVendorMapping>(entity =>
            {
                entity.HasKey(e => e.IntTrainingVendmapSeqid)
                    .HasName("PRIMARY");

                entity.ToTable("train_mas_vendor_mapping");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntTrainigVendorId, "FK_VENDOR_MAPPING_VENDOR_MAS");

                entity.HasIndex(e => e.IntCompanyId, "FK_tr_M_ven_map_COM_ID");

                entity.Property(e => e.IntTrainingVendmapSeqid)
                    .HasColumnName("INT_TRAINING_VENDMAP_SEQID")
                    .HasComment("Primary key");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntTrainigVendorId)
                    .HasColumnName("INT_TRAINIG_VENDOR_ID")
                    .HasComment("Vendor fk");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchTrainerMailid)
                    .HasMaxLength(62)
                    .HasColumnName("VCH_TRAINER_MAILID")
                    .HasComment("Mail id");

                entity.Property(e => e.VchTrainerMobile)
                    .HasMaxLength(12)
                    .HasColumnName("VCH_TRAINER_MOBILE")
                    .HasComment("Mobile number");

                entity.Property(e => e.VchTrainerName)
                    .HasMaxLength(52)
                    .HasColumnName("VCH_TRAINER_NAME")
                    .HasComment("Vendor name");

                entity.Property(e => e.VchTrainerPostalAddress)
                    .HasMaxLength(300)
                    .HasColumnName("VCH_TRAINER_POSTAL_ADDRESS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(40)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainMasVendorMappings)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_tr_M_ven_map_COM_ID");

                entity.HasOne(d => d.IntTrainigVendor)
                    .WithMany(p => p.TrainMasVendorMappings)
                    .HasForeignKey(d => d.IntTrainigVendorId)
                    .HasConstraintName("FK_VENDOR_MAPPING_VENDOR_MAS");
            });

            modelBuilder.Entity<TrainTransAnswer>(entity =>
            {
                entity.HasKey(e => e.IntTrAnswerId)
                    .HasName("PRIMARY");

                entity.ToTable("train_trans_answers");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_INT_COMPANY_ID");

                entity.HasIndex(e => e.IntQuestionId, "FK_TR_M_ANS_QUESTION_ID");

                entity.HasIndex(e => e.IntTRequestId, "FK_TR_T_ANS_REQ_ID");

                entity.Property(e => e.IntTrAnswerId)
                    .HasColumnName("INT_TR_ANSWER_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DouTotalMark)
                    .HasColumnName("DOU_TOTAL_MARK")
                    .HasComment("Final mark of the employee");

                entity.Property(e => e.DtCreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CREATED_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntQuestionId)
                    .HasColumnName("INT_QUESTION_ID")
                    .HasComment("Reference from questions table(train_mas_questions)");

                entity.Property(e => e.IntTRequestId)
                    .HasColumnName("INT_T_REQUEST_ID")
                    .HasComment("Reference from training table(TRAIN_TRANS_REQUEST)");

                entity.Property(e => e.VchAnswer1)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER1")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer10)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER10")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer2)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER2")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer3)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER3")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer4)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER4")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer5)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER5")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer6)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER6")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer7)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER7")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer8)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER8")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchAnswer9)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ANSWER9")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainTransAnswers)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_INT_COMPANY_ID");

                entity.HasOne(d => d.IntQuestion)
                    .WithMany(p => p.TrainTransAnswers)
                    .HasForeignKey(d => d.IntQuestionId)
                    .HasConstraintName("FK_TR_M_ANS_QUESTION_ID");

                entity.HasOne(d => d.IntTRequest)
                    .WithMany(p => p.TrainTransAnswers)
                    .HasForeignKey(d => d.IntTRequestId)
                    .HasConstraintName("FK_TR_T_ANS_REQ_ID");
            });

            modelBuilder.Entity<TrainTransHrInitiation>(entity =>
            {
                entity.HasKey(e => e.IntInitiationId)
                    .HasName("PRIMARY");

                entity.ToTable("train_trans_hr_initiation");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_T_HR_INIT_COMP_ID");

                entity.HasIndex(e => e.IntQuestionId, "FK_TR_T_HR_INIT_QUES_ID");

                entity.HasIndex(e => e.IntCategoryId, "FK_TR_T_HR_INT_CATEGORY");

                entity.HasIndex(e => e.IntTypeId, "FK_TR_T_HR_INT_TYPE");

                entity.Property(e => e.IntInitiationId)
                    .HasColumnName("INT_INITIATION_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCategoryId).HasColumnName("INT_CATEGORY_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntQuestionId).HasColumnName("INT_QUESTION_ID");

                entity.Property(e => e.IntTypeId).HasColumnName("INT_TYPE_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchFeedbackStatus)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_FEEDBACK_STATUS");

                entity.Property(e => e.VchTrainCode)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_TRAIN_CODE")
                    .HasComment("Auto generated training code");

                entity.Property(e => e.VchTrainerType)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TRAINER_TYPE");

                entity.Property(e => e.VchTrainingStatus)
                    .HasMaxLength(2)
                    .HasColumnName("VCH_TRAINING_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCategory)
                    .WithMany(p => p.TrainTransHrInitiations)
                    .HasForeignKey(d => d.IntCategoryId)
                    .HasConstraintName("FK_TR_T_HR_INT_CATEGORY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainTransHrInitiations)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_T_HR_INIT_COMP_ID");

                entity.HasOne(d => d.IntQuestion)
                    .WithMany(p => p.TrainTransHrInitiations)
                    .HasForeignKey(d => d.IntQuestionId)
                    .HasConstraintName("FK_TR_T_HR_INIT_QUES_ID");

                entity.HasOne(d => d.IntType)
                    .WithMany(p => p.TrainTransHrInitiations)
                    .HasForeignKey(d => d.IntTypeId)
                    .HasConstraintName("FK_TR_T_HR_INT_TYPE");
            });

            modelBuilder.Entity<TrainTransRequest>(entity =>
            {
                entity.HasKey(e => e.IntTRequestId)
                    .HasName("PRIMARY");

                entity.ToTable("train_trans_request");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCategoryId, "FK_TR_T_REQUEST_CATEGORY");

                entity.HasIndex(e => e.IntEmpId, "FK_TR_T_REQUEST_EMPID");

                entity.HasIndex(e => e.IntInitiationId, "FK_TR_T_REQUEST_INIT_ID");

                entity.HasIndex(e => e.IntTypeId, "FK_TR_T_REQUEST_TYPE");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_T_REQ_COMP_ID");

                entity.Property(e => e.IntTRequestId)
                    .HasColumnName("INT_T_REQUEST_ID")
                    .HasComment("Primark Key Of a table");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCategoryId)
                    .HasColumnName("INT_CATEGORY_ID")
                    .HasComment("Reference from training category(TRAIN_MAS_CATEGORY)");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("INT_EMP_ID")
                    .HasComment("Reference from employee master table(employee_master)");

                entity.Property(e => e.IntInitiationId).HasColumnName("INT_INITIATION_ID");

                entity.Property(e => e.IntTypeId)
                    .HasColumnName("INT_TYPE_ID")
                    .HasComment("Reference from training type(TRAIN_MAS_TYPES)");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchAttenance)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ATTENANCE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDeletable)
                    .HasMaxLength(4)
                    .HasColumnName("VCH_DELETABLE")
                    .HasComment("Y -- Deleted");

                entity.Property(e => e.VchFinalTotal)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_FINAL_TOTAL");

                entity.Property(e => e.VchInitiatedBy)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_INITIATED_BY")
                    .HasComment("S-self,H-HR,RMS-Rm Self,RMR-RM to Reporties");

                entity.Property(e => e.VchRmCode)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_RM_CODE");

                entity.Property(e => e.VchRmComments)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_RM_COMMENTS")
                    .HasComment("For Rm employee comments");

                entity.Property(e => e.VchRmRejectionRemark)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_RM_REJECTION_REMARK");

                entity.Property(e => e.VchSelfComments)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_SELF_COMMENTS")
                    .HasComment("For Self employee commetns");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_STATUS")
                    .HasComment("RMP-RM  Pending,");

                entity.Property(e => e.VchTrainingScheduled)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TRAINING_SCHEDULED")
                    .HasComment("Y-Yes,N-No");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCategory)
                    .WithMany(p => p.TrainTransRequests)
                    .HasForeignKey(d => d.IntCategoryId)
                    .HasConstraintName("FK_TR_T_REQUEST_CATEGORY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainTransRequests)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_T_REQ_COMP_ID");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.TrainTransRequests)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("train_trans_request_ibfk_1");

                entity.HasOne(d => d.IntInitiation)
                    .WithMany(p => p.TrainTransRequests)
                    .HasForeignKey(d => d.IntInitiationId)
                    .HasConstraintName("FK_TR_T_REQUEST_INIT_ID");

                entity.HasOne(d => d.IntType)
                    .WithMany(p => p.TrainTransRequests)
                    .HasForeignKey(d => d.IntTypeId)
                    .HasConstraintName("FK_TR_T_REQUEST_TYPE");
            });

            modelBuilder.Entity<TrainTransTrainerdetExter>(entity =>
            {
                entity.HasKey(e => e.IntTExternalId)
                    .HasName("PRIMARY");

                entity.ToTable("train_trans_trainerdet_exter");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TRAIN_T_TRDETEXTER_COMPANY_ID_idx");

                entity.HasIndex(e => e.IntTrainingVendmapSeqid, "FK_TRAIN_T_TRDETEXTER_VENDMAP");

                entity.HasIndex(e => e.IntInitiationId, "FK_TR_T_TRAINERDETEXT_INIT_ID");

                entity.Property(e => e.IntTExternalId)
                    .HasColumnName("INT_T_EXTERNAL_ID")
                    .HasComment("primary key of table");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntInitiationId)
                    .HasColumnName("INT_INITIATION_ID")
                    .HasComment("Reference from train_trans_hr_initaition");

                entity.Property(e => e.IntTrainingVendmapSeqid)
                    .HasColumnName("INT_TRAINING_VENDMAP_SEQID")
                    .HasComment("reference from TRAIN_MAS_VENDOR_MAPPING table");

                entity.Property(e => e.TsCreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_DATE");

                entity.Property(e => e.VchComponent1)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT1");

                entity.Property(e => e.VchComponent2)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT2");

                entity.Property(e => e.VchComponent3)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT3");

                entity.Property(e => e.VchComponent4)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT4");

                entity.Property(e => e.VchComponent5)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT5");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainTransTrainerdetExters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TRAIN_T_TRDETEXTER_COMPANY_ID");

                entity.HasOne(d => d.IntInitiation)
                    .WithMany(p => p.TrainTransTrainerdetExters)
                    .HasForeignKey(d => d.IntInitiationId)
                    .HasConstraintName("FK_TR_T_TRAINERDETEXT_INIT_ID");

                entity.HasOne(d => d.IntTrainingVendmapSeq)
                    .WithMany(p => p.TrainTransTrainerdetExters)
                    .HasForeignKey(d => d.IntTrainingVendmapSeqid)
                    .HasConstraintName("FK_TRAIN_T_TRDETEXTER_VENDMAP");
            });

            modelBuilder.Entity<TrainTransTrainerdetInter>(entity =>
            {
                entity.HasKey(e => e.IntTInternalId)
                    .HasName("PRIMARY");

                entity.ToTable("train_trans_trainerdet_inter");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_TRAINERDET_INTER_COMPANY_ID_idx");

                entity.HasIndex(e => e.IntEmpId, "FK_TR_T_TRAINERDETINT_EMP_ID");

                entity.HasIndex(e => e.IntInitiationId, "FK_TR_T_TRAINERDETINT_INIT_ID");

                entity.Property(e => e.IntTInternalId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("INT_T_INTERNAL_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("INT_EMP_ID")
                    .HasComment("Reference from employee master(employee_master table)");

                entity.Property(e => e.IntInitiationId)
                    .HasColumnName("INT_INITIATION_ID")
                    .HasComment("Reference from hr initiation table (train_trans_hr_initiation)");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchEmailId)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_EMAIL_ID");

                entity.Property(e => e.VchMobile)
                    .HasMaxLength(15)
                    .HasColumnName("VCH_MOBILE");

                entity.Property(e => e.VchPostalAddr)
                    .HasMaxLength(200)
                    .HasColumnName("VCH_POSTAL_ADDR");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainTransTrainerdetInters)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_TRAINERDET_INTER_COMPANY_ID");

                entity.HasOne(d => d.IntEmp)
                    .WithMany(p => p.TrainTransTrainerdetInters)
                    .HasForeignKey(d => d.IntEmpId)
                    .HasConstraintName("train_trans_trainerdet_inter_ibfk_1");

                entity.HasOne(d => d.IntInitiation)
                    .WithMany(p => p.TrainTransTrainerdetInters)
                    .HasForeignKey(d => d.IntInitiationId)
                    .HasConstraintName("FK_TR_T_TRAINERDETINT_INIT_ID");
            });

            modelBuilder.Entity<TrainTransTrainingDetail>(entity =>
            {
                entity.HasKey(e => e.IntTTrainingDetailsId)
                    .HasName("PRIMARY");

                entity.ToTable("train_trans_training_details");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntDepartmentId, "FK_TR_T_TRAINDET_DEPT_ID");

                entity.HasIndex(e => e.IntInitiationId, "FK_TR_T_TRAINDET_INIT_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_TR_T_TRAINDET_INT_COMPANY_ID_idx");

                entity.HasIndex(e => e.IntLocationId, "FK_TR_T_TRAINDET_LOC_ID");

                entity.Property(e => e.IntTTrainingDetailsId)
                    .HasColumnName("INT_T_TRAINING_DETAILS_ID")
                    .HasComment("Primary key of a table ");

                entity.Property(e => e.DtCreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_CREATED_DATE");

                entity.Property(e => e.DtDateFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DATE_FROM");

                entity.Property(e => e.DtDateTo)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_DATE_TO");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntDepartmentId)
                    .HasColumnName("INT_DEPARTMENT_ID")
                    .HasComment("Reference from department master(department_master)");

                entity.Property(e => e.IntInitiationId)
                    .HasColumnName("INT_INITIATION_ID")
                    .HasComment("Reference from Hr initiation table(train_trans_hr_initiation)");

                entity.Property(e => e.IntLocationId)
                    .HasColumnName("INT_LOCATION_ID")
                    .HasComment("Reference from location master(location_master)");

                entity.Property(e => e.TsTimeFrom)
                    .HasMaxLength(6)
                    .HasColumnName("TS_TIME_FROM");

                entity.Property(e => e.TsTimeTo)
                    .HasMaxLength(6)
                    .HasColumnName("TS_TIME_TO");

                entity.Property(e => e.VchComponent1)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT1");

                entity.Property(e => e.VchComponent2)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT2");

                entity.Property(e => e.VchComponent3)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT3");

                entity.Property(e => e.VchComponent4)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT4");

                entity.Property(e => e.VchComponent5)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_COMPONENT5");

                entity.Property(e => e.VchDetail)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_DETAIL")
                    .HasComment("Training name or project name workshop name");

                entity.Property(e => e.VchDuration)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_DURATION");

                entity.Property(e => e.VchTrainingDesc)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_TRAINING_DESC");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchVenueDetails)
                    .HasMaxLength(110)
                    .HasColumnName("VCH_VENUE_DETAILS");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.TrainTransTrainingDetails)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_TR_T_TRAINDET_INT_COMPANY_ID");

                entity.HasOne(d => d.IntDepartment)
                    .WithMany(p => p.TrainTransTrainingDetails)
                    .HasForeignKey(d => d.IntDepartmentId)
                    .HasConstraintName("FK_TR_T_TRAINDET_DEPT_ID");

                entity.HasOne(d => d.IntInitiation)
                    .WithMany(p => p.TrainTransTrainingDetails)
                    .HasForeignKey(d => d.IntInitiationId)
                    .HasConstraintName("FK_TR_T_TRAINDET_INIT_ID");

                entity.HasOne(d => d.IntLocation)
                    .WithMany(p => p.TrainTransTrainingDetails)
                    .HasForeignKey(d => d.IntLocationId)
                    .HasConstraintName("FK_TR_T_TRAINDET_LOC_ID");
            });

            modelBuilder.Entity<UserMaster>(entity =>
            {
                entity.HasKey(e => e.UserSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("user_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.UserSeqId).HasColumnName("USER_SEQ_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedTs)
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_TS");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.FileSeqid).HasColumnName("FILE_SEQID");

                entity.Property(e => e.IntLocationSeqId).HasColumnName("INT_LOCATION_SEQ_ID");

                entity.Property(e => e.Isproxy).HasColumnName("ISPROXY");

                entity.Property(e => e.ProxyFor)
                    .HasMaxLength(45)
                    .HasColumnName("PROXY_FOR");

                entity.Property(e => e.RoleSeqid).HasColumnName("ROLE_SEQID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedTs)
                    .HasMaxLength(6)
                    .HasColumnName("UPDATED_TS");

                entity.Property(e => e.UserEmail)
                    .HasMaxLength(60)
                    .HasColumnName("USER_EMAIL");

                entity.Property(e => e.UserFirstname)
                    .HasMaxLength(50)
                    .HasColumnName("USER_FIRSTNAME");

                entity.Property(e => e.UserId)
                    .HasMaxLength(20)
                    .HasColumnName("USER_ID");

                entity.Property(e => e.UserLastname)
                    .HasMaxLength(50)
                    .HasColumnName("USER_LASTNAME");

                entity.Property(e => e.UserMobileNo)
                    .HasMaxLength(20)
                    .HasColumnName("USER_MOBILE_NO");

                entity.Property(e => e.UserPassword)
                    .HasMaxLength(45)
                    .HasColumnName("USER_PASSWORD");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<VendorCategoryMaster>(entity =>
            {
                entity.HasKey(e => e.VendorCategorySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("vendor_category_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VendorCategorySeqId).HasColumnName("VENDOR_CATEGORY_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VendorCategoryName)
                    .HasMaxLength(100)
                    .HasColumnName("VENDOR_CATEGORY_NAME");
            });

            modelBuilder.Entity<VendorMaster>(entity =>
            {
                entity.HasKey(e => e.VendorSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("vendor_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VendorSeqId).HasColumnName("VENDOR_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(100)
                    .HasColumnName("EMAIL_ID");

                entity.Property(e => e.EmailId1)
                    .HasMaxLength(100)
                    .HasColumnName("EMAIL_ID1");

                entity.Property(e => e.EmailId2)
                    .HasMaxLength(100)
                    .HasColumnName("EMAIL_ID2");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Name1)
                    .HasMaxLength(50)
                    .HasColumnName("NAME1");

                entity.Property(e => e.Name2)
                    .HasMaxLength(50)
                    .HasColumnName("NAME2");

                entity.Property(e => e.Phone1)
                    .HasMaxLength(45)
                    .HasColumnName("PHONE_1");

                entity.Property(e => e.Phone2)
                    .HasMaxLength(45)
                    .HasColumnName("PHONE_2");

                entity.Property(e => e.Preferred)
                    .HasMaxLength(40)
                    .HasColumnName("PREFERRED");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VendorAddress)
                    .HasMaxLength(50)
                    .HasColumnName("VENDOR_ADDRESS");

                entity.Property(e => e.VendorCategoryId).HasColumnName("VENDOR_CATEGORY_ID");

                entity.Property(e => e.VendorCode)
                    .HasMaxLength(50)
                    .HasColumnName("VENDOR_CODE");

                entity.Property(e => e.VendorName)
                    .HasMaxLength(100)
                    .HasColumnName("VENDOR_NAME");
            });

            modelBuilder.Entity<ViewDocumentCompanyLevelDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("view_document_company_level_details");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("company_id")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(50)
                    .HasColumnName("company_name")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8mb3");

                entity.Property(e => e.DocumentSize)
                    .HasColumnType("double(19,2)")
                    .HasColumnName("document_size");

                entity.Property(e => e.EmployeeCount).HasColumnName("employee_count");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8mb3");
            });

            modelBuilder.Entity<ViewEmployeeMasterValue>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("view_employee_master_value");

                entity.Property(e => e.ColName).HasColumnName("col_name");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("employee_seq_id");

                entity.Property(e => e.MasterValue).HasColumnName("master_value");
            });

            modelBuilder.Entity<ViewOverallTraining>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("view_overall_training");

                entity.HasComment("View 'client10.view_overall_training' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them");
            });

            modelBuilder.Entity<ViewTrainingDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("view_training_details");

                entity.HasComment("View 'client10.view_training_details' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them");
            });

            modelBuilder.Entity<WttMCompanyType>(entity =>
            {
                entity.HasKey(e => e.IntWttComTypeId)
                    .HasName("PRIMARY");

                entity.ToTable("wtt_m_company_type");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_WTT_M_COMP_TYP_COM_ID");

                entity.Property(e => e.IntWttComTypeId)
                    .HasColumnName("INT_WTT_COM_TYPE_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.IntCompanyId)
                    .HasColumnName("INT_COMPANY_ID")
                    .HasComment("Referece from company master");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchType)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_TYPE")
                    .HasComment("A-Annual,M-Monthly");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.WttMCompanyTypes)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_WTT_M_COMP_TYP_COM_ID");
            });

            modelBuilder.Entity<WttMakerChecker>(entity =>
            {
                entity.HasKey(e => e.IntWttMakerId)
                    .HasName("PRIMARY");

                entity.ToTable("wtt_maker_checker");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntWttAnnSeqId, "FK_WTT_MAK_CHECK_ANN_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "FK_WTT_MAK_CHECK_COMPANY_ID");

                entity.HasIndex(e => e.IntWttMonSeqId, "FK_WTT_MAK_CHECK_MON_SEQ_ID");

                entity.Property(e => e.IntWttMakerId)
                    .HasColumnName("INT_WTT_MAKER_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.DtFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_FROM_DATE");

                entity.Property(e => e.DtMakerDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_MAKER_DATE");

                entity.Property(e => e.DtRequestDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_REQUEST_DATE");

                entity.Property(e => e.DtSrcFromDate).HasColumnName("DT_SRC_FROM_DATE");

                entity.Property(e => e.DtSrcToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_SRC_TO_DATE");

                entity.Property(e => e.DtToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_TO_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntWttAnnSeqId)
                    .HasColumnName("INT_WTT_ANN_SEQ_ID")
                    .HasComment("Reference From WTT_TRANS_ANNUAL_REPORT");

                entity.Property(e => e.IntWttMonSeqId)
                    .HasColumnName("INT_WTT_MON_SEQ_ID")
                    .HasComment("Reference From WTT_TRANS_MONTHLY_REPORT");

                entity.Property(e => e.VchAttribute)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_ATTRIBUTE");

                entity.Property(e => e.VchMakerStatus)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_MAKER_STATUS");

                entity.Property(e => e.VchMode)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_MODE");

                entity.Property(e => e.VchMonth)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_MONTH");

                entity.Property(e => e.VchRequestBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_REQUEST_BY");

                entity.Property(e => e.VchSrcMonth)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_SRC_MONTH");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntCompany)
                    .WithMany(p => p.WttMakerCheckers)
                    .HasForeignKey(d => d.IntCompanyId)
                    .HasConstraintName("FK_WTT_MAK_CHECK_COMPANY_ID");

                entity.HasOne(d => d.IntWttAnnSeq)
                    .WithMany(p => p.WttMakerCheckers)
                    .HasForeignKey(d => d.IntWttAnnSeqId)
                    .HasConstraintName("FK_WTT_MAK_CHECK_ANN_SEQ_ID");

                entity.HasOne(d => d.IntWttMonSeq)
                    .WithMany(p => p.WttMakerCheckers)
                    .HasForeignKey(d => d.IntWttMonSeqId)
                    .HasConstraintName("FK_WTT_MAK_CHECK_MON_SEQ_ID");
            });

            modelBuilder.Entity<WttTransAnnualReport>(entity =>
            {
                entity.HasKey(e => e.IntWttAnnSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("wtt_trans_annual_report");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntWttComTypeId, "FK_WTT_T_ANN_COM_TYPE_ID");

                entity.Property(e => e.IntWttAnnSeqId)
                    .HasColumnName("INT_WTT_ANN_SEQ_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.DtFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_FROM_DATE")
                    .HasComment("Starting Date of given month");

                entity.Property(e => e.DtToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_TO_DATE")
                    .HasComment("Ending Date of given month");

                entity.Property(e => e.IntReportNo).HasColumnName("int_report_no");

                entity.Property(e => e.IntWttComTypeId)
                    .HasColumnName("INT_WTT_COM_TYPE_ID")
                    .HasComment("Reference From wtt_m_company_type");

                entity.Property(e => e.IntYear)
                    .HasColumnName("INT_YEAR")
                    .HasComment("Name of Year");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDownloadPath)
                    .HasMaxLength(2000)
                    .HasColumnName("VCH_DOWNLOAD_PATH");

                entity.Property(e => e.VchDownloadStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_DOWNLOAD_STATUS");

                entity.Property(e => e.VchEnable)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ENABLE")
                    .HasComment("Y-Enable,N-Disable");

                entity.Property(e => e.VchMonth)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_MONTH")
                    .HasComment("Name Of month");

                entity.Property(e => e.VchReportType)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_REPORT_TYPE");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntWttComType)
                    .WithMany(p => p.WttTransAnnualReports)
                    .HasForeignKey(d => d.IntWttComTypeId)
                    .HasConstraintName("FK_WTT_T_ANN_COM_TYPE_ID");
            });

            modelBuilder.Entity<WttTransAnnualReportDetail>(entity =>
            {
                entity.HasKey(e => e.IntAnnRepDetId)
                    .HasName("PRIMARY");

                entity.ToTable("wtt_trans_annual_report_detail");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntWttAnnSeqId, "FK_WTT_T_ANN_REP_DET_ANN_ID");

                entity.Property(e => e.IntAnnRepDetId)
                    .HasColumnName("INT_ANN_REP_DET_ID")
                    .HasComment("Primary key of a table");

                entity.Property(e => e.DtFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_FROM_DATE");

                entity.Property(e => e.DtToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_TO_DATE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntReportNo).HasColumnName("int_report_no");

                entity.Property(e => e.IntWttAnnSeqId)
                    .HasColumnName("INT_WTT_ANN_SEQ_ID")
                    .HasComment("Reference From WTT_TRANS_ANNUAL_REPORT");

                entity.Property(e => e.VchDownloadPath)
                    .HasMaxLength(400)
                    .HasColumnName("VCH_DOWNLOAD_PATH");

                entity.Property(e => e.VchDownloadStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_DOWNLOAD_STATUS");

                entity.Property(e => e.VchProcessStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_PROCESS_STATUS");

                entity.Property(e => e.VchReportType)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_REPORT_TYPE");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntWttAnnSeq)
                    .WithMany(p => p.WttTransAnnualReportDetails)
                    .HasForeignKey(d => d.IntWttAnnSeqId)
                    .HasConstraintName("FK_WTT_T_ANN_REP_DET_ANN_ID");
            });

            modelBuilder.Entity<WttTransMonthlyReport>(entity =>
            {
                entity.HasKey(e => e.IntWttMonSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("wtt_trans_monthly_report");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntWttComTypeId, "FK_WTT_T_MON_COM_TYPE_ID");

                entity.Property(e => e.IntWttMonSeqId)
                    .HasColumnName("INT_WTT_MON_SEQ_ID")
                    .HasComment("primary key of a table");

                entity.Property(e => e.DtFromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_FROM_DATE")
                    .HasComment("Starting Date of given month");

                entity.Property(e => e.DtToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_TO_DATE")
                    .HasComment("Ending Date of given month");

                entity.Property(e => e.IntWttComTypeId)
                    .HasColumnName("INT_WTT_COM_TYPE_ID")
                    .HasComment("Reference From wtt_m_company_type");

                entity.Property(e => e.IntYear)
                    .HasColumnName("INT_YEAR")
                    .HasComment("Name of Year");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDownloadPath)
                    .HasMaxLength(200)
                    .HasColumnName("VCH_DOWNLOAD_PATH");

                entity.Property(e => e.VchDownloadStatus)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_DOWNLOAD_STATUS");

                entity.Property(e => e.VchEnable)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_ENABLE")
                    .HasComment("Y-Enable,N-Disable");

                entity.Property(e => e.VchMonth)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_MONTH")
                    .HasComment("Name Of month");

                entity.Property(e => e.VchReportType)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_REPORT_TYPE");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(10)
                    .HasColumnName("VCH_STATUS")
                    .HasComment("G-Generated,R-Reset");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasOne(d => d.IntWttComType)
                    .WithMany(p => p.WttTransMonthlyReports)
                    .HasForeignKey(d => d.IntWttComTypeId)
                    .HasConstraintName("FK_WTT_T_MON_COM_TYPE_ID");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
