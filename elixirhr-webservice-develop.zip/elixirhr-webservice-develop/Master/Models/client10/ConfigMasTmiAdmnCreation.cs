﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasTmiAdmnCreation
    {
        public ConfigMasTmiAdmnCreation()
        {
            AuthMasTmiAdminDetails = new HashSet<AuthMasTmiAdminDetail>();
            ConfigMasTmiAdmClientAssigns = new HashSet<ConfigMasTmiAdmClientAssign>();
        }

        public long IntTmiAdmId { get; set; }
        public string? VchTmiAdmEmpCode { get; set; }
        public string? VchTmiAdmName { get; set; }
        public string? VchTmiAdmCode { get; set; }
        public string? VchTmiAdmPassword { get; set; }
        public string? VchTmiEmailid { get; set; }
        public string? VchTmiPhoneno { get; set; }
        public string? VchActive { get; set; }
        public string? VchClientAssign { get; set; }
        public string? VchTmiAdmClients { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchPwdChangeReq { get; set; }
        public string? VchPwdResetKey { get; set; }
        public string? VchOldPwd1 { get; set; }
        public string? VchOldPwd2 { get; set; }
        public DateTime? TsPwdChangeDate { get; set; }
        public string? VchPwdExpired { get; set; }

        public virtual ICollection<AuthMasTmiAdminDetail> AuthMasTmiAdminDetails { get; set; }
        public virtual ICollection<ConfigMasTmiAdmClientAssign> ConfigMasTmiAdmClientAssigns { get; set; }
    }
}
