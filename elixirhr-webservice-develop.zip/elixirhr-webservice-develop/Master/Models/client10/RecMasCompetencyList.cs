﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasCompetencyList
    {
        public RecMasCompetencyList()
        {
            RecMasCompetManpowreqMappings = new HashSet<RecMasCompetManpowreqMapping>();
            RecMasInterviewCompRatings = new HashSet<RecMasInterviewCompRating>();
        }

        public long IntRecCompetListSeqid { get; set; }
        public string? VchShortname { get; set; }
        public string? VchDescription { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<RecMasCompetManpowreqMapping> RecMasCompetManpowreqMappings { get; set; }
        public virtual ICollection<RecMasInterviewCompRating> RecMasInterviewCompRatings { get; set; }
    }
}
