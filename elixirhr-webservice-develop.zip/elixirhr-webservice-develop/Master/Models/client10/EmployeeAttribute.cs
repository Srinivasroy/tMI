﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeAttribute
    {
        public long EmpAttrId { get; set; }
        public string? VchLabelName { get; set; }
        public string? VchLabelValue { get; set; }
        public string? VchType { get; set; }
        public string? VchQuery { get; set; }
        public string? VchShow { get; set; }
    }
}
