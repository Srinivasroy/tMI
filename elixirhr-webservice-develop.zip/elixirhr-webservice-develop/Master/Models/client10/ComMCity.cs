﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComMCity
    {
        public long IntCityId { get; set; }
        /// <summary>
        /// Reference from state table
        /// </summary>
        public long? IntStateId { get; set; }
        public string? VchCityName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchStateName { get; set; }
        public string? VchTransactionId { get; set; }
    }
}
