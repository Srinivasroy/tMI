﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class DomainMaster
    {
        public DomainMaster()
        {
            RecMasAddCandidates = new HashSet<RecMasAddCandidate>();
            RecMasNewCandidates = new HashSet<RecMasNewCandidate>();
            RecTransManpowerRequests = new HashSet<RecTransManpowerRequest>();
        }

        public long DomainSeqId { get; set; }
        public string? DomainName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchTransactionId { get; set; }

        public virtual ICollection<RecMasAddCandidate> RecMasAddCandidates { get; set; }
        public virtual ICollection<RecMasNewCandidate> RecMasNewCandidates { get; set; }
        public virtual ICollection<RecTransManpowerRequest> RecTransManpowerRequests { get; set; }
    }
}
