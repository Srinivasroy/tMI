﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ExitMasQuestionTemplate
    {
        public ExitMasQuestionTemplate()
        {
            ConfirmationAssessmentAns = new HashSet<ConfirmationAssessmentAn>();
            ConfirmationQuestionEmployeeMaps = new HashSet<ConfirmationQuestionEmployeeMap>();
            ExitMasAns = new HashSet<ExitMasAn>();
            ExitMasEmployeeMaps = new HashSet<ExitMasEmployeeMap>();
            ExitMasQuestionTemplateItems = new HashSet<ExitMasQuestionTemplateItem>();
        }

        public long ExitTemplateId { get; set; }
        public string? VchQuestionTemplName { get; set; }
        public int? IntNoOfQuestions { get; set; }
        public string? VchActive { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchDefaultTemp { get; set; }
        public string? VchModuleName { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ConfirmationAssessmentAn> ConfirmationAssessmentAns { get; set; }
        public virtual ICollection<ConfirmationQuestionEmployeeMap> ConfirmationQuestionEmployeeMaps { get; set; }
        public virtual ICollection<ExitMasAn> ExitMasAns { get; set; }
        public virtual ICollection<ExitMasEmployeeMap> ExitMasEmployeeMaps { get; set; }
        public virtual ICollection<ExitMasQuestionTemplateItem> ExitMasQuestionTemplateItems { get; set; }
    }
}
