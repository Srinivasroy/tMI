﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ExitMasResignation
    {
        public ExitMasResignation()
        {
            ExitTransEmprequestAuditLogs = new HashSet<ExitTransEmprequestAuditLog>();
            ExitTransEmprequests = new HashSet<ExitTransEmprequest>();
        }

        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntResigId { get; set; }
        /// <summary>
        /// V-voluntary,I-Invaluntary
        /// </summary>
        public string? VchResignationType { get; set; }
        /// <summary>
        /// Reason for resignations
        /// </summary>
        public string? VchReasonResignation { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ExitTransEmprequestAuditLog> ExitTransEmprequestAuditLogs { get; set; }
        public virtual ICollection<ExitTransEmprequest> ExitTransEmprequests { get; set; }
    }
}
