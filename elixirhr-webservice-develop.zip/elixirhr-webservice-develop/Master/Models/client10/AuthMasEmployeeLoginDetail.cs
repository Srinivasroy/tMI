﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuthMasEmployeeLoginDetail
    {
        public long IntEmployeeLoginId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntLoginSuccessCount { get; set; }
        public long? IntLoginFailedCount { get; set; }
        public DateTime? TsLastLoginTime { get; set; }
        public DateTime? TsLastFailLoginTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
