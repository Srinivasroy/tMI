﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasOrgAttribute
    {
        public long IntAttributeId { get; set; }
        public string? VchAttributeName { get; set; }
        public string? VchHqlQuery { get; set; }
        public string? VchTableName { get; set; }
        public string? VchNativeQuery { get; set; }
        public string? VchSeqIdFieldName { get; set; }
        public string? VchSeqIdInEmployee { get; set; }
        public string? VchOrgFieldName { get; set; }
    }
}
