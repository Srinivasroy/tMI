﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ExitMasQuestionTemplateItem
    {
        //public ExitMasQuestionTemplateItem()
        //{
        //    ConfirmationAssessmentAns = new HashSet<ConfirmationAssessmentAn>();
        //    ExitMasAns = new HashSet<ExitMasAn>();
        //}

        public long ExitTemplateItemId { get; set; }
        public long? ExitTemplateId { get; set; }
        public long? IntQuestionId { get; set; }
        public string? VchQuesDesc { get; set; }
        public string? VchActive { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        //public virtual ExitMasQuestionTemplate? ExitTemplate { get; set; }
        //public virtual CompanyDetailMaster? IntCompany { get; set; }
        //public virtual ExitMasQuestion? IntQuestion { get; set; }
        //public virtual ICollection<ConfirmationAssessmentAn> ConfirmationAssessmentAns { get; set; }
        //public virtual ICollection<ExitMasAn> ExitMasAns { get; set; }
    }
}
