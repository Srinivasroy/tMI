﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentTransCriteriaComponentAssign
    {
        public long IntCompCretSeqId { get; set; }
        /// <summary>
        /// REFERENCE FROM company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public long? IntCompCreteriaSeqId { get; set; }
        public long? IntCompSeqId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        /// <summary>
        /// Store Component Values
        /// </summary>
        public string? VchValue { get; set; }
        /// <summary>
        /// Store sequence numbers for display
        /// </summary>
        public int? IntSeqId { get; set; }
        /// <summary>
        /// For Storing component name
        /// </summary>
        public string? VchComponentName { get; set; }
        public bool? IntCompoAssign { get; set; }
        public string? VchShowView { get; set; }
        public string? VchShowPayslip { get; set; }
        public string? VchGrossProcessFormula { get; set; }

        public virtual ComponentMasCriterion? IntCompCreteriaSeq { get; set; }
        public virtual ComponentMasCreation? IntCompSeq { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
