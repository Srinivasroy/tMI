﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsDomainMaster
    {
        public long IntId { get; set; }
        public string? VchDomainName { get; set; }
        public string? VchPackageName { get; set; }
    }
}
