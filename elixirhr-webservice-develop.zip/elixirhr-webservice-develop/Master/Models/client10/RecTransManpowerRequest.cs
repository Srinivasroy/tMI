﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecTransManpowerRequest
    {
        public RecTransManpowerRequest()
        {
            RecMasCompetManpowreqMappings = new HashSet<RecMasCompetManpowreqMapping>();
            RecMasInterviewCompRatings = new HashSet<RecMasInterviewCompRating>();
            RecMasNewCandidates = new HashSet<RecMasNewCandidate>();
            RecTransReferPublishRequests = new HashSet<RecTransReferPublishRequest>();
        }

        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntManpowerReqId { get; set; }
        /// <summary>
        /// Reference from rec_mas_manpower_plan
        /// </summary>
        public long? IntPlanId { get; set; }
        /// <summary>
        /// Reference from QualificationMaster
        /// </summary>
        public long? IntQualificationId { get; set; }
        /// <summary>
        /// Reference from EmployeeCategoryMaster
        /// </summary>
        public long? IntEmpCategoryId { get; set; }
        /// <summary>
        /// Reference from DomainMaster
        /// </summary>
        public long? IntDomainId { get; set; }
        /// <summary>
        /// Reference from SkillMaster
        /// </summary>
        public long? IntSkillId { get; set; }
        /// <summary>
        /// Reference for company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public string? VchRequestId { get; set; }
        public DateOnly? DtTenureFromDate { get; set; }
        public DateOnly? DtTenureToDate { get; set; }
        public string? VchJobDescription { get; set; }
        public sbyte? IntAgeFrom { get; set; }
        public sbyte? IntAgeTo { get; set; }
        public sbyte? IntYearsexpFrom { get; set; }
        public sbyte? IntYearsexpTo { get; set; }
        public long? IntSalaryBandFrom { get; set; }
        public long? IntSalaryBandTo { get; set; }
        public string? VchGenderPref { get; set; }
        public string? VchImportance { get; set; }
        public DateOnly? DtClosedDate { get; set; }
        public string? VchSkills { get; set; }
        public string? VchQualifications { get; set; }
        public string? VchReferred { get; set; }
        public string? VchPublished { get; set; }
        public string? VchStatus { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public int? IntPendingJobCount { get; set; }
        public int? IntCompletedJobCount { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DomainMaster? IntDomain { get; set; }
        public virtual EmployeeCategoryMaster? IntEmpCategory { get; set; }
        public virtual RecMasManpowerPlan? IntPlan { get; set; }
        public virtual QualificationMaster? IntQualification { get; set; }
        public virtual SkillMaster? IntSkill { get; set; }
        public virtual ICollection<RecMasCompetManpowreqMapping> RecMasCompetManpowreqMappings { get; set; }
        public virtual ICollection<RecMasInterviewCompRating> RecMasInterviewCompRatings { get; set; }
        public virtual ICollection<RecMasNewCandidate> RecMasNewCandidates { get; set; }
        public virtual ICollection<RecTransReferPublishRequest> RecTransReferPublishRequests { get; set; }
    }
}
