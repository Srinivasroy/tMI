﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class CostcenterMasterTmp
    {
        public long CostcenterSeqId { get; set; }
        public string? CostcenterName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchActive { get; set; }
        public string? DtFromDate { get; set; }
        public string? DtToDate { get; set; }
        public string? VchTransactionId { get; set; }
    }
}
