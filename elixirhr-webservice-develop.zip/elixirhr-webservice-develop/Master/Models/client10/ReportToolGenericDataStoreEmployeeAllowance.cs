﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreEmployeeAllowance
    {
        public long IntAllowanceReptId { get; set; }
        public string? EmployeeCode { get; set; }
        public string? PayHead { get; set; }
        public string? Amount { get; set; }
        public DateOnly? CreatedDate { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
