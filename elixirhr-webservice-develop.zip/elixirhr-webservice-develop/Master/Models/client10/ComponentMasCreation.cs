﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasCreation
    {
        public ComponentMasCreation()
        {
            ComponentTransCriteriaComponentAssigns = new HashSet<ComponentTransCriteriaComponentAssign>();
            ComponentTransEmpSalMasterValues = new HashSet<ComponentTransEmpSalMasterValue>();
            ComponentTransEmpSalaryValuesHistories = new HashSet<ComponentTransEmpSalaryValuesHistory>();
        }

        /// <summary>
        /// primary key of component_mas_creation
        /// </summary>
        public long IntCompSeqId { get; set; }
        /// <summary>
        /// Unique identification for each component
        /// </summary>
        public string? VchCompId { get; set; }
        public string? VchSysShortname { get; set; }
        /// <summary>
        /// Reference from company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// Store Component Name
        /// </summary>
        public string? VchComponentName { get; set; }
        /// <summary>
        /// To describe the component
        /// </summary>
        public string? VchDescription { get; set; }
        /// <summary>
        /// C-Ctc,N-Non-ctc
        /// </summary>
        public string? VchCtcType { get; set; }
        /// <summary>
        /// E-Earnings,D-Detuctions,O-Others
        /// </summary>
        public string? VchNature { get; set; }
        /// <summary>
        /// F-fixed,V-variable,P-Perquisites,REIM-Reimburstment,RET-Retrials
        /// </summary>
        public string? VchType { get; set; }
        public string? VchCalcMode { get; set; }
        /// <summary>
        /// N-Number,L-List,D-Date,C-Character,B-Boolean
        /// </summary>
        public string? VchDataType { get; set; }
        /// <summary>
        /// O - Open,S - Standard
        /// </summary>
        public string? VchFormulaType { get; set; }
        /// <summary>
        /// Y - Yes,N - No
        /// </summary>
        public string? VchCompensationPlan { get; set; }
        public long? IntSequenceNo { get; set; }
        /// <summary>
        /// Y - Yes,N - No
        /// </summary>
        public string? VchYtdValidations { get; set; }
        /// <summary>
        /// D - Default,C - Customize
        /// </summary>
        public string? VchBooleanType { get; set; }
        /// <summary>
        /// Minimun Money Range
        /// </summary>
        public long? IntRangeFrom { get; set; }
        /// <summary>
        /// Maximun money range
        /// </summary>
        public long? IntRangeTo { get; set; }
        /// <summary>
        /// It will stored currency type
        /// </summary>
        public string? VchCurrency { get; set; }
        public string? VchFormulaText { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchGrossProcessFormula { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ComponentTransCriteriaComponentAssign> ComponentTransCriteriaComponentAssigns { get; set; }
        public virtual ICollection<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; }
        public virtual ICollection<ComponentTransEmpSalaryValuesHistory> ComponentTransEmpSalaryValuesHistories { get; set; }
    }
}
