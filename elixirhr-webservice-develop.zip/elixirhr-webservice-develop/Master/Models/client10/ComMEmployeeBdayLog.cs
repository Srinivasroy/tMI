﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComMEmployeeBdayLog
    {
        public long IntEmpBdayId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public string? VchEmpCode { get; set; }
        public string? VchEmpName { get; set; }
        public string? VchLocationName { get; set; }
        public string? VchDepartmentName { get; set; }
        public string? VchDesignationName { get; set; }
        public string? VchGender { get; set; }
        public string? VchProfile { get; set; }
        public string? VchProfileUrl { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
