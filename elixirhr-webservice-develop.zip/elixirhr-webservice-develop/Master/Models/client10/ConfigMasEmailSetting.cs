﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasEmailSetting
    {
        public long IntEmailConfigId { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchHost { get; set; }
        public int? IntPort { get; set; }
        public string? VchUsername { get; set; }
        public string? VchPassword { get; set; }
        public string? VchEnable { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
