﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecTransScheduleInterview
    {
        public RecTransScheduleInterview()
        {
            RecTransScheduleInterCandidates = new HashSet<RecTransScheduleInterCandidate>();
        }

        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntScheduleInterId { get; set; }
        /// <summary>
        /// Reference from Employee_Master
        /// </summary>
        public long? IntEmployeeSeqId { get; set; }
        /// <summary>
        /// Reference for company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public string? VchInterviewType { get; set; }
        public DateOnly? DtInterviewDateFrom { get; set; }
        public DateOnly? DtInterviewDateTo { get; set; }
        public DateTime? TsInterviewTimeFrom { get; set; }
        public DateTime? TsInterviewTimeTo { get; set; }
        public string? VchVenue { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? VchCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual ICollection<RecTransScheduleInterCandidate> RecTransScheduleInterCandidates { get; set; }
    }
}
