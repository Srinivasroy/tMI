﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigQuicklinkEmployee
    {
        public long IntEmpQlSeqId { get; set; }
        public long? IntEmpSeqId { get; set; }
        public string? VchQlName { get; set; }
        public string? VchQuickLinkUrl { get; set; }

        public virtual EmployeeMaster? IntEmpSeq { get; set; }
    }
}
