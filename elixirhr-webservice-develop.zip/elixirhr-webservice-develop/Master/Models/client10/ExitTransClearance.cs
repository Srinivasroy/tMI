﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ExitTransClearance
    {
        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntExClearanceId { get; set; }
        /// <summary>
        /// Reference from ExitRequest table(EXIT_TRANS_EMPREQUEST)
        /// </summary>
        public long? IntExEmpreqId { get; set; }
        /// <summary>
        /// A-Admin,F-Finance,I-It,H-HR
        /// </summary>
        public string? VchClearanceDept { get; set; }
        public string? VchItem { get; set; }
        public string? VchRemark { get; set; }
        public string? VchAmount { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ExitTransEmprequest? IntExEmpreq { get; set; }
    }
}
