﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasDynamicEmpMasterField
    {
        public long IntDynamicEmpMasId { get; set; }
        public string? VchRoleName { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchSchemaUsed { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? TsCreatedBy { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
