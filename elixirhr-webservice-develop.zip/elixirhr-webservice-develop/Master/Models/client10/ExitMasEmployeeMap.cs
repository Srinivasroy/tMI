﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ExitMasEmployeeMap
    {
        public long IntEmpMapId { get; set; }
        public long? ExitTemplateId { get; set; }
        public long? IntCompanyId { get; set; }
        public long? IntEmpId { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual ExitMasQuestionTemplate? ExitTemplate { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
    }
}
