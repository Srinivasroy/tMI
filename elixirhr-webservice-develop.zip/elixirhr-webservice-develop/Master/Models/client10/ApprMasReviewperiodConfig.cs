﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasReviewperiodConfig
    {
        public ApprMasReviewperiodConfig()
        {
            ApprTransEmptoappMappingHistories = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappings = new HashSet<ApprTransEmptoappMapping>();
            ApprTransProcessHistories = new HashSet<ApprTransProcessHistory>();
            ApprTransProcesses = new HashSet<ApprTransProcess>();
        }

        public long IntReviewSeqid { get; set; }
        public string? VchDescription { get; set; }
        public string? VchReviewtype { get; set; }
        public DateTime? DtPerfStart { get; set; }
        public DateTime? DtPerfEnd { get; set; }
        public DateTime? DtReviewStart { get; set; }
        public DateTime? DtRoleChg { get; set; }
        public DateTime? DtConfirmCutoff { get; set; }
        public string? VchStatus { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistories { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappings { get; set; }
        public virtual ICollection<ApprTransProcessHistory> ApprTransProcessHistories { get; set; }
        public virtual ICollection<ApprTransProcess> ApprTransProcesses { get; set; }
    }
}
