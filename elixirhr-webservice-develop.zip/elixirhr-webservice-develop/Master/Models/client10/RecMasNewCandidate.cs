﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasNewCandidate
    {
        public RecMasNewCandidate()
        {
            RecMasInterviewCompRatings = new HashSet<RecMasInterviewCompRating>();
            RecMasNewcanEdudets = new HashSet<RecMasNewcanEdudet>();
            RecMasNewcanEmpdets = new HashSet<RecMasNewcanEmpdet>();
            RecTransOfferletterManagements = new HashSet<RecTransOfferletterManagement>();
            RecTransScheduleInterCandidates = new HashSet<RecTransScheduleInterCandidate>();
        }

        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntNewCandidateSeqId { get; set; }
        /// <summary>
        /// Reference from rec_trans_manpower_request
        /// </summary>
        public long? IntManpowerReqId { get; set; }
        public string? VchInterviewRound1 { get; set; }
        public string? VchInterviewRound2 { get; set; }
        /// <summary>
        /// Reference from vendor_master
        /// </summary>
        public long? IntVendorSeqId { get; set; }
        /// <summary>
        /// Reference from company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public string? VchCandidateName { get; set; }
        public DateOnly? DtDob { get; set; }
        public string? VchGender { get; set; }
        public string? VchMailId { get; set; }
        public string? VchPhoneNo { get; set; }
        public long? IntExpYear { get; set; }
        public long? IntCurrentSal { get; set; }
        public string? VchProfileSource { get; set; }
        public long? IntDomainId { get; set; }
        public long? IntSkillId { get; set; }
        public string? VchSkills { get; set; }
        public string? VchCandidateId { get; set; }
        public long? IntExpMonth { get; set; }
        public string? VchResumeFlag { get; set; }
        public byte[]? BlobResume { get; set; }
        public string? VchReferralCode { get; set; }
        public string? VchReferralName { get; set; }
        public string? VchMiddleName { get; set; }
        public string? VchLastName { get; set; }
        public string? VchStatus { get; set; }
        public string? VchSecretKey { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchInterview1Completed { get; set; }
        public string? VchInterview2Completed { get; set; }
        public byte[]? VchInterview1Feedback { get; set; }
        public byte[]? VchInterview2Feedback { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchRescheduleStatus { get; set; }
        public string? VchNotAttendInterComments1 { get; set; }
        public string? VchNotAttendInterComments2 { get; set; }
        public DateOnly? DtShortlistDate { get; set; }
        public string? VchDocumentPath { get; set; }
        public string? VchInterview1FeedbackPath { get; set; }
        public string? VchInterview2FeedbackPath { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DomainMaster? IntDomain { get; set; }
        public virtual RecTransManpowerRequest? IntManpowerReq { get; set; }
        public virtual SkillMaster? IntSkill { get; set; }
        public virtual VendorMaster? IntVendorSeq { get; set; }
        public virtual ICollection<RecMasInterviewCompRating> RecMasInterviewCompRatings { get; set; }
        public virtual ICollection<RecMasNewcanEdudet> RecMasNewcanEdudets { get; set; }
        public virtual ICollection<RecMasNewcanEmpdet> RecMasNewcanEmpdets { get; set; }
        public virtual ICollection<RecTransOfferletterManagement> RecTransOfferletterManagements { get; set; }
        public virtual ICollection<RecTransScheduleInterCandidate> RecTransScheduleInterCandidates { get; set; }
    }
}
