﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasRatingParaMapping
    {
        public ApprMasRatingParaMapping()
        {
            ApprTransCompetencyRatingHashIntP1Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntP2Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntP3Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntSelfRatings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntSo1Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntSo2Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntSo3Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntSup1Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHashIntSup2Ratings = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHistoryIntP1Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntP2Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntP3Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntSelfRatings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntSo1Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntSo2Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntSo3Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntSup1Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingHistoryIntSup2Ratings = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatingIntP1Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntP2Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntP3Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntSelfRatings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntSo1Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntSo2Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntSo3Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntSup1Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransCompetencyRatingIntSup2Ratings = new HashSet<ApprTransCompetencyRating>();
            ApprTransGolesRatingHashes = new HashSet<ApprTransGolesRatingHash>();
            ApprTransGolesRatingHistories = new HashSet<ApprTransGolesRatingHistory>();
            ApprTransGolesRatings = new HashSet<ApprTransGolesRating>();
        }

        /// <summary>
        /// PRIMARK KEY
        /// </summary>
        public long IntRatingMappingId { get; set; }
        /// <summary>
        /// REFERENCE FROM RATING ORDER TABLE
        /// </summary>
        public long? IntRatingOrderId { get; set; }
        /// <summary>
        /// REFERENCE FROM RATING DESCRIPTION TABLE
        /// </summary>
        public long? IntDesId { get; set; }
        public sbyte? IntRatingNo { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasRatingDescription? IntDes { get; set; }
        public virtual ApprMasRatingOrder? IntRatingOrder { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntP1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntP2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntP3Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntSelfRatings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntSo1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntSo2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntSo3Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntSup1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashIntSup2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntP1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntP2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntP3Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntSelfRatings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntSo1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntSo2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntSo3Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntSup1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistoryIntSup2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntP1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntP2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntP3Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntSelfRatings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntSo1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntSo2Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntSo3Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntSup1Ratings { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatingIntSup2Ratings { get; set; }
        public virtual ICollection<ApprTransGolesRatingHash> ApprTransGolesRatingHashes { get; set; }
        public virtual ICollection<ApprTransGolesRatingHistory> ApprTransGolesRatingHistories { get; set; }
        public virtual ICollection<ApprTransGolesRating> ApprTransGolesRatings { get; set; }
    }
}
