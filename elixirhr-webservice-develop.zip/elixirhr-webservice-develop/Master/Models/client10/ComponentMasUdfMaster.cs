﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasUdfMaster
    {
        public long IntUdfSeqId { get; set; }
        public string? VchFunctionName { get; set; }
        public string? VchSysFunctionName { get; set; }
    }
}
