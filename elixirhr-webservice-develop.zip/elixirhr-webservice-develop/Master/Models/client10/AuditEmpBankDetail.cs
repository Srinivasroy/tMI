﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuditEmpBankDetail
    {
        public long IntBankDetailsId { get; set; }
        public long? IntCompanyId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public string? VchOperation { get; set; }
        public string? VarKycBankName { get; set; }
        public string? VarKycAccNo { get; set; }
        public string? VarKycBranch { get; set; }
        public string? VarKycIfsc { get; set; }
        public string? VarKycPan { get; set; }
        public string? VarKycAadhar { get; set; }
        public string? VarKycPassport { get; set; }
        public string? VarKycUan { get; set; }
        public string? VarKycDlNo { get; set; }
        public string? VarKycEpsNo { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateOnly? DtUpdatedDate { get; set; }
        public DateOnly? DtFromDate { get; set; }
        public DateOnly? DtToDate { get; set; }
        public string? VchStatus { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateOnly? DtCreatedDate { get; set; }
        public string? VarKycPfNo { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
