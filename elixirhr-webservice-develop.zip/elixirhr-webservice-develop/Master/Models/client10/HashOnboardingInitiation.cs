﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class HashOnboardingInitiation
    {
        public HashOnboardingInitiation()
        {
            HashOnboardSalaryStructures = new HashSet<HashOnboardSalaryStructure>();
        }

        public long IntSeqId { get; set; }
        public string? PersonalFirstName { get; set; }
        public string? PersonalLastName { get; set; }
        public string? PersonalMiddleName { get; set; }
        public string? PersonalRefId { get; set; }
        public DateTime? PersonalDob { get; set; }
        public string? PersonalPanNum { get; set; }
        public string? PersonalAadharCard { get; set; }
        public string? PersonalAddress1 { get; set; }
        public string? PersonalAddress2 { get; set; }
        public string? PersonalAddress3 { get; set; }
        public string? PersonalLocation { get; set; }
        public string? PersonalMobileNum { get; set; }
        public string? PersonalEmailId { get; set; }
        public string? PreviousCompanyName { get; set; }
        public string? PreviousDesignation { get; set; }
        public string? PreviousGrade { get; set; }
        public string? PreviousDepartment { get; set; }
        public string? PreviousReferralPerson { get; set; }
        public string? PreviousCtc { get; set; }
        public string? PreviousAddress1 { get; set; }
        public string? PreviousAddress2 { get; set; }
        public string? PreviousLocation { get; set; }
        public long? PresentDesignation { get; set; }
        public long? PresentDepartment { get; set; }
        public string? PresentGrade { get; set; }
        public DateTime? PresentDoj { get; set; }
        public long? PresentCostCenter { get; set; }
        public long? PresentLocation { get; set; }
        public string? ReportingManagerDesi { get; set; }
        public long? ReportingManagerName { get; set; }
        public string? Status { get; set; }
        public string? RaisedByPerson { get; set; }
        public string? RejectionRemark { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? PreviousReferralMobile { get; set; }
        public string? VchExperience { get; set; }
        public long? IntNewCtc { get; set; }
        public long? IntCtcDifference { get; set; }
        public string? VchSchemaKey { get; set; }
        public long? IntCategoryId { get; set; }
        public long? Departments { get; set; }
        public long? MidPoints { get; set; }

        public virtual DepartmentsMaster? DepartmentsNavigation { get; set; }
        public virtual MidpointMaster? MidPointsNavigation { get; set; }
        public virtual CostcenterMaster? PresentCostCenterNavigation { get; set; }
        public virtual DepartmentMaster? PresentDepartmentNavigation { get; set; }
        public virtual DesignationMaster? PresentDesignationNavigation { get; set; }
        public virtual LocationMaster? PresentLocationNavigation { get; set; }
        public virtual EmployeeMaster? ReportingManagerNameNavigation { get; set; }
        public virtual ICollection<HashOnboardSalaryStructure> HashOnboardSalaryStructures { get; set; }
    }
}
