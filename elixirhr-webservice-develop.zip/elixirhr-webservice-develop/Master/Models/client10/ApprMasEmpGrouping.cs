﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasEmpGrouping
    {
        public ApprMasEmpGrouping()
        {
            ApprMasAppraiserMappingKras = new HashSet<ApprMasAppraiserMappingKra>();
            ApprMasCompetKraMappings = new HashSet<ApprMasCompetKraMapping>();
            ApprMasEmpGroupingAssigns = new HashSet<ApprMasEmpGroupingAssign>();
            ApprMasGoalKraMappings = new HashSet<ApprMasGoalKraMapping>();
            ApprMasRatingOrders = new HashSet<ApprMasRatingOrder>();
            ApprTransEmptoappMappingHistories = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappings = new HashSet<ApprTransEmptoappMapping>();
            ApprTransIncrementalGrids = new HashSet<ApprTransIncrementalGrid>();
            ApprTransProcessHistories = new HashSet<ApprTransProcessHistory>();
            ApprTransProcesses = new HashSet<ApprTransProcess>();
        }

        /// <summary>
        /// Primary key column of a table
        /// </summary>
        public long IntEmpgroupId { get; set; }
        public string? VchGroupName { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ApprMasAppraiserMappingKra> ApprMasAppraiserMappingKras { get; set; }
        public virtual ICollection<ApprMasCompetKraMapping> ApprMasCompetKraMappings { get; set; }
        public virtual ICollection<ApprMasEmpGroupingAssign> ApprMasEmpGroupingAssigns { get; set; }
        public virtual ICollection<ApprMasGoalKraMapping> ApprMasGoalKraMappings { get; set; }
        public virtual ICollection<ApprMasRatingOrder> ApprMasRatingOrders { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistories { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappings { get; set; }
        public virtual ICollection<ApprTransIncrementalGrid> ApprTransIncrementalGrids { get; set; }
        public virtual ICollection<ApprTransProcessHistory> ApprTransProcessHistories { get; set; }
        public virtual ICollection<ApprTransProcess> ApprTransProcesses { get; set; }
    }
}
