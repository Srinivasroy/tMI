﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class OnboardNomineeDetail
    {
        public long IntSeqId { get; set; }
        /// <summary>
        /// REFERENCE FROM ONBOARD_EMPLOYEE_DETAILS FOREIGN KEY
        /// </summary>
        public long? IntEmployeeSeqId { get; set; }
        public string? VchName { get; set; }
        public DateTime? DtDob { get; set; }
        public short? IntAge { get; set; }
        public string? VchRelation { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
