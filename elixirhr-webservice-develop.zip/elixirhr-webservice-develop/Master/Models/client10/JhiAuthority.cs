﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JhiAuthority
    {
        public JhiAuthority()
        {
            Users = new HashSet<JhiUser>();
        }

        public string Name { get; set; } = null!;

        public virtual ICollection<JhiUser> Users { get; set; }
    }
}
