﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class Databasechangeloglock
    {
        public int Id { get; set; }
        public ulong Locked { get; set; }
        public DateTime? Lockgranted { get; set; }
        public string? Lockedby { get; set; }
    }
}
