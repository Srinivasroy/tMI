﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfirmationAssessmentQuestion
    {
        public long IntConfirmasseQuesId { get; set; }
        /// <summary>
        /// reference from confirmation_assessment_request(int_confirm_req_id)
        /// </summary>
        public long? IntConfirmReqId { get; set; }
        public string? VchQuestion { get; set; }
        public string? VchAnswer { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ConfirmationAssessmentRequest? IntConfirmReq { get; set; }
    }
}
