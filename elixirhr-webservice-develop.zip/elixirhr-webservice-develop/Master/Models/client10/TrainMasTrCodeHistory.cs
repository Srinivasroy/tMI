﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainMasTrCodeHistory
    {
        public string? VchTrainCode { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
