﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreNomineeAttribute
    {
        public long IntNomineeId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? EmployeeCode { get; set; }
        public string? EmployeeName { get; set; }
        public string? NomineeName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public int? Age { get; set; }
        public string? Relation { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
    }
}
