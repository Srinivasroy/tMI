﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmpNoHistory
    {
        public long IntSeqId { get; set; }
        public string? VchCompanyCode { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
