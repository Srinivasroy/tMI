﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComMCompanyRolesAssign
    {
        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntCompRolesAssiId { get; set; }
        /// <summary>
        /// Reference from company_details_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// Reference from com_m_company_role
        /// </summary>
        public long? IntCompanyRoleId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchAssignedBy { get; set; }
        public string? VchDeleted { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ComMCompanyRole? IntCompanyRole { get; set; }
    }
}
