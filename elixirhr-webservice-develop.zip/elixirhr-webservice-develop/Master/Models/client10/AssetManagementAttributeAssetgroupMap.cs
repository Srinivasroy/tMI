﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementAttributeAssetgroupMap
    {
        public AssetManagementAttributeAssetgroupMap()
        {
            AssetManagementAssetRegisters = new HashSet<AssetManagementAssetRegister>();
        }

        public int IntAttributeAssetGroupMapId { get; set; }
        public int? AssetAttributeId { get; set; }
        public int? AssetGroupId { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual AssetManagementAssetAttribute? AssetAttribute { get; set; }
        public virtual AssetManagementAssetGroup? AssetGroup { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<AssetManagementAssetRegister> AssetManagementAssetRegisters { get; set; }
    }
}
