﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentTransEmpSalMaster
    {
        public long IntCompSalMasSeqId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntCompanyId { get; set; }
        public long? IntComMCtcMasId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
