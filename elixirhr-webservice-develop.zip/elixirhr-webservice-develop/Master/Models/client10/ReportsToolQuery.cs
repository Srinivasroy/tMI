﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsToolQuery
    {
        public ReportsToolQuery()
        {
            ReportsToolConditionValues = new HashSet<ReportsToolConditionValue>();
        }

        public long ReportsToolQuerySeqid { get; set; }
        public string? QueryName { get; set; }
        public string? QueryValue { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchStatus { get; set; }
        public string? VchModuleName { get; set; }
        public string? VchFieldNames { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ReportsToolConditionValue> ReportsToolConditionValues { get; set; }
    }
}
