﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JsonTreeStructureElement
    {
        public long IntJsontreeEleId { get; set; }
        public long? IntJsonTreeId { get; set; }
        public string? VchPropertyName { get; set; }
        public string? VchObjType { get; set; }
        public string? VchPropertyValue { get; set; }
        public string? VchActive { get; set; }
        public string? VchDatatype { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
