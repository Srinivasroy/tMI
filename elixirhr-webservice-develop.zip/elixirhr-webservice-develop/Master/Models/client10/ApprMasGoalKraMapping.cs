﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasGoalKraMapping
    {
        public long IntGoalMappingSeqid { get; set; }
        public long? IntGoalId { get; set; }
        public long? IntEmpgroupId { get; set; }
        public decimal? IntWeightage { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasEmpGrouping? IntEmpgroup { get; set; }
        public virtual ApprMasGoal? IntGoal { get; set; }
    }
}
