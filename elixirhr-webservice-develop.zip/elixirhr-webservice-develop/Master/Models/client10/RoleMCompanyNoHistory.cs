﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RoleMCompanyNoHistory
    {
        public string? VarLastCompanyId { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
