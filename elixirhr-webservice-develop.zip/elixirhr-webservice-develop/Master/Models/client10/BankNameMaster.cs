﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class BankNameMaster
    {
        public BankNameMaster()
        {
            EmployeeMakerCheckerIntNewBankNameNavigations = new HashSet<EmployeeMakerChecker>();
            EmployeeMakerCheckerIntOldBankNameNavigations = new HashSet<EmployeeMakerChecker>();
            EmployeeMasDetails = new HashSet<EmployeeMasDetail>();
            EmployeeMasters = new HashSet<EmployeeMaster>();
        }

        public long BankNameSeqId { get; set; }
        public string? VchBankName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchTransactionId { get; set; }

        public virtual ICollection<EmployeeMakerChecker> EmployeeMakerCheckerIntNewBankNameNavigations { get; set; }
        public virtual ICollection<EmployeeMakerChecker> EmployeeMakerCheckerIntOldBankNameNavigations { get; set; }
        public virtual ICollection<EmployeeMasDetail> EmployeeMasDetails { get; set; }
        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
    }
}
