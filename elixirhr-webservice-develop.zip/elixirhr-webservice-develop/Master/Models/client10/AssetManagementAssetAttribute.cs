﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementAssetAttribute
    {
        public AssetManagementAssetAttribute()
        {
            AssetManagementAssetRegisters = new HashSet<AssetManagementAssetRegister>();
            AssetManagementAttributeAssetgroupMaps = new HashSet<AssetManagementAttributeAssetgroupMap>();
        }

        public int IntAssetAttributeId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchAssetAttributeName { get; set; }
        public string? VchAssetType { get; set; }
        public string? VchMandatory { get; set; }
        public string? VchStatus { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<AssetManagementAssetRegister> AssetManagementAssetRegisters { get; set; }
        public virtual ICollection<AssetManagementAttributeAssetgroupMap> AssetManagementAttributeAssetgroupMaps { get; set; }
    }
}
