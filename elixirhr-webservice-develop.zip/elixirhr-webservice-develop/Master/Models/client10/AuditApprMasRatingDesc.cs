﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuditApprMasRatingDesc
    {
        /// <summary>
        /// PRIMARY KEY
        /// </summary>
        public long IntDesId { get; set; }
        public string? VchDescription { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchShortName { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchOperation { get; set; }
        public long IntAuditId { get; set; }
    }
}
