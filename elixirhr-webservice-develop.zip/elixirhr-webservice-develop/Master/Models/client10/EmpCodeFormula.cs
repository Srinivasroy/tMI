﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmpCodeFormula
    {
        public long FormulaId { get; set; }
        public string? VchFormula { get; set; }
    }
}
