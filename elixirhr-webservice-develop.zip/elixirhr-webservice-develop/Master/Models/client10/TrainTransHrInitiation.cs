﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainTransHrInitiation
    {
        public TrainTransHrInitiation()
        {
            TrainTransRequests = new HashSet<TrainTransRequest>();
            TrainTransTrainerdetExters = new HashSet<TrainTransTrainerdetExter>();
            TrainTransTrainerdetInters = new HashSet<TrainTransTrainerdetInter>();
            TrainTransTrainingDetails = new HashSet<TrainTransTrainingDetail>();
        }

        /// <summary>
        /// primary key of a table
        /// </summary>
        public long IntInitiationId { get; set; }
        /// <summary>
        /// Auto generated training code
        /// </summary>
        public string? VchTrainCode { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCategoryId { get; set; }
        public long? IntTypeId { get; set; }
        public string? VchTrainerType { get; set; }
        public string? VchFeedbackStatus { get; set; }
        public string? VchTrainingStatus { get; set; }
        public long? IntQuestionId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual TrainMasCategory? IntCategory { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual TrainMasQuestion? IntQuestion { get; set; }
        public virtual TrainMasType? IntType { get; set; }
        public virtual ICollection<TrainTransRequest> TrainTransRequests { get; set; }
        public virtual ICollection<TrainTransTrainerdetExter> TrainTransTrainerdetExters { get; set; }
        public virtual ICollection<TrainTransTrainerdetInter> TrainTransTrainerdetInters { get; set; }
        public virtual ICollection<TrainTransTrainingDetail> TrainTransTrainingDetails { get; set; }
    }
}
