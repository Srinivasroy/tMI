﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsGenericQueryField
    {
        public long IntReportsField { get; set; }
        public string? FieldName { get; set; }
        public long? IntReportsQueryId { get; set; }

        public virtual ReportsGenericQuery? IntReportsQuery { get; set; }
    }
}
