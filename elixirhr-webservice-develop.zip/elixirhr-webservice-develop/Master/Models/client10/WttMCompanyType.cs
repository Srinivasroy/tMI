﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class WttMCompanyType
    {
        public WttMCompanyType()
        {
            WttTransAnnualReports = new HashSet<WttTransAnnualReport>();
            WttTransMonthlyReports = new HashSet<WttTransMonthlyReport>();
        }

        /// <summary>
        /// primary key of a table
        /// </summary>
        public long IntWttComTypeId { get; set; }
        /// <summary>
        /// Referece from company master
        /// </summary>
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// A-Annual,M-Monthly
        /// </summary>
        public string? VchType { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<WttTransAnnualReport> WttTransAnnualReports { get; set; }
        public virtual ICollection<WttTransMonthlyReport> WttTransMonthlyReports { get; set; }
    }
}
