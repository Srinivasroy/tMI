﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprTransProcessHistory
    {
        public long IntProcessId { get; set; }
        public long? IntReviewSeqid { get; set; }
        public long? IntEmpId { get; set; }
        public long? IntEmpgroupId { get; set; }
        public long? DouCurrentCtc { get; set; }
        public double? DouRating { get; set; }
        public double? DouIncreasing { get; set; }
        public long? DouRevisedCtc { get; set; }
        public double? DouRevisedPer { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchStatus { get; set; }
        public string? VchAdjustMode { get; set; }
        public byte[]? BlobAppraisalLetter { get; set; }
        public string? VchLetterGenStatus { get; set; }
        public string? VchRatingPoint { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual ApprMasEmpGrouping? IntEmpgroup { get; set; }
        public virtual ApprMasReviewperiodConfig? IntReviewSeq { get; set; }
    }
}
