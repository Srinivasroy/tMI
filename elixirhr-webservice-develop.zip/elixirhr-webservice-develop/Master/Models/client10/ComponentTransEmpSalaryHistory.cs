﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentTransEmpSalaryHistory
    {
        public ComponentTransEmpSalaryHistory()
        {
            ComponentTransEmpSalaryValuesHistories = new HashSet<ComponentTransEmpSalaryValuesHistory>();
        }

        public long IntEmpSalHisId { get; set; }
        public double? DouCtcAmount { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchTransactionId { get; set; }
        public DateOnly? DtFromDate { get; set; }
        public string? DtToDate { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual ICollection<ComponentTransEmpSalaryValuesHistory> ComponentTransEmpSalaryValuesHistories { get; set; }
    }
}
