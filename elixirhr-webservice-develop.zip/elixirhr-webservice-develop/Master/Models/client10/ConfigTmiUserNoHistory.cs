﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigTmiUserNoHistory
    {
        public string? VchLastId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
