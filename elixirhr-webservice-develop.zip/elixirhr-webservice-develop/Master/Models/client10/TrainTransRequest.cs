﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainTransRequest
    {
        public TrainTransRequest()
        {
            ApprTransEmptoappMappingHistories = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappings = new HashSet<ApprTransEmptoappMapping>();
            TrainTransAnswers = new HashSet<TrainTransAnswer>();
        }

        /// <summary>
        /// Primark Key Of a table
        /// </summary>
        public long IntTRequestId { get; set; }
        /// <summary>
        /// Reference from employee master table(employee_master)
        /// </summary>
        public long? IntEmpId { get; set; }
        /// <summary>
        /// Reference from training category(TRAIN_MAS_CATEGORY)
        /// </summary>
        public long? IntCategoryId { get; set; }
        /// <summary>
        /// Reference from training type(TRAIN_MAS_TYPES)
        /// </summary>
        public long? IntTypeId { get; set; }
        /// <summary>
        /// S-self,H-HR,RMS-Rm Self,RMR-RM to Reporties
        /// </summary>
        public string? VchInitiatedBy { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchTrainingScheduled { get; set; }
        /// <summary>
        /// RMP-RM  Pending,
        /// </summary>
        public string? VchStatus { get; set; }
        /// <summary>
        /// For Self employee commetns
        /// </summary>
        public string? VchSelfComments { get; set; }
        /// <summary>
        /// For Rm employee comments
        /// </summary>
        public string? VchRmComments { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchRmCode { get; set; }
        public string? VchRmRejectionRemark { get; set; }
        public long? IntInitiationId { get; set; }
        public string? VchAttenance { get; set; }
        public string? VchFinalTotal { get; set; }
        /// <summary>
        /// Y -- Deleted
        /// </summary>
        public string? VchDeletable { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual TrainMasCategory? IntCategory { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual TrainTransHrInitiation? IntInitiation { get; set; }
        public virtual TrainMasType? IntType { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistories { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappings { get; set; }
        public virtual ICollection<TrainTransAnswer> TrainTransAnswers { get; set; }
    }
}
