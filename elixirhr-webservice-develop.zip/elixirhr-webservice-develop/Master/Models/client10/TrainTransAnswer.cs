﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainTransAnswer
    {
        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntTrAnswerId { get; set; }
        /// <summary>
        /// Reference from questions table(train_mas_questions)
        /// </summary>
        public long? IntQuestionId { get; set; }
        /// <summary>
        /// Reference from training table(TRAIN_TRANS_REQUEST)
        /// </summary>
        public long? IntTRequestId { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer1 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer2 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer3 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer4 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer5 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer6 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer7 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer8 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer9 { get; set; }
        /// <summary>
        /// Y-Yes,N-No
        /// </summary>
        public string? VchAnswer10 { get; set; }
        /// <summary>
        /// Final mark of the employee
        /// </summary>
        public long? DouTotalMark { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtCreatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual TrainMasQuestion? IntQuestion { get; set; }
        public virtual TrainTransRequest? IntTRequest { get; set; }
    }
}
