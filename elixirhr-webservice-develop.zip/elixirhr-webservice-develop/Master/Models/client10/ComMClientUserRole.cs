﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComMClientUserRole
    {
        public ComMClientUserRole()
        {
            ClientUserMasters = new HashSet<ClientUserMaster>();
        }

        public long IntClientUserRoleId { get; set; }
        public string? VchRoleName { get; set; }
        public string? VchCompanyAdmin { get; set; }
        public string? VchRecuirement { get; set; }
        public string? VchOnboarding { get; set; }
        public string? VchTraining { get; set; }
        public string? VchAppraisal { get; set; }
        public string? VchCareer { get; set; }
        public string? VchExit { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchClientAdminCode { get; set; }
        public string? VchEmployeeMaster { get; set; }
        public string? VchDynamicEmployeeMaster { get; set; }
        public string? VchSalaryMaster { get; set; }
        public string? VchAppraisalGoal { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchReports { get; set; }
        public string? VchLetterGeneration { get; set; }
        public string? VchModuleNames { get; set; }
        public string? VchEss { get; set; }

        public virtual ICollection<ClientUserMaster> ClientUserMasters { get; set; }
    }
}
