﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainMasCategory
    {
        public TrainMasCategory()
        {
            ApprMasEmptoappMappingHashes = new HashSet<ApprMasEmptoappMappingHash>();
            TrainTransHrInitiations = new HashSet<TrainTransHrInitiation>();
            TrainTransRequests = new HashSet<TrainTransRequest>();
        }

        public long IntCategoryId { get; set; }
        public string? VchCategoryName { get; set; }
        public string? VchCategoryDesc { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ApprMasEmptoappMappingHash> ApprMasEmptoappMappingHashes { get; set; }
        public virtual ICollection<TrainTransHrInitiation> TrainTransHrInitiations { get; set; }
        public virtual ICollection<TrainTransRequest> TrainTransRequests { get; set; }
    }
}
