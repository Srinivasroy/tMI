﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasEmpGroupingAssign
    {
        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntEmpGrpAssignId { get; set; }
        /// <summary>
        /// Reference from employee group table
        /// </summary>
        public long? IntEmpgroupId { get; set; }
        /// <summary>
        /// Reference From Location master table
        /// </summary>
        public long? IntLocationSeqId { get; set; }
        /// <summary>
        /// Reference From dept master table
        /// </summary>
        public long? IntDeptSeqId { get; set; }
        /// <summary>
        /// Reference from Designation master table
        /// </summary>
        public long? IntDesigSeqId { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasEmpGrouping? IntEmpgroup { get; set; }
    }
}
