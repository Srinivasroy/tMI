﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComTransClientUserCompany
    {
        public long IntClUserCompanyId { get; set; }
        /// <summary>
        /// Reference from company_detail_master table
        /// </summary>
        public long? IntCompanySeqId { get; set; }
        /// <summary>
        /// Reference from client_user_mastertable
        /// </summary>
        public long? IntClientSeqId { get; set; }
        public DateTime? DtUpdatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchRoleAssigned { get; set; }
        public string? VchUserCreatedBy { get; set; }
    }
}
