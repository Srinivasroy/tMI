﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasManpowerPlanJobid
    {
        public RecMasManpowerPlanJobid()
        {
            RecTransOfferletterManagements = new HashSet<RecTransOfferletterManagement>();
        }

        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntMpPlanJobId { get; set; }
        /// <summary>
        /// Reference from rec_mas_manpower plan
        /// </summary>
        public long? IntPlanId { get; set; }
        /// <summary>
        /// Reference from EmployeeMaster
        /// </summary>
        public long? IntEmployeeSeqId { get; set; }
        /// <summary>
        /// Reference from LocationMaster
        /// </summary>
        public long? IntLocationId { get; set; }
        /// <summary>
        /// Reference from DepartmentMaster
        /// </summary>
        public long? IntDepartmentId { get; set; }
        /// <summary>
        /// Reference from DesignationMaster
        /// </summary>
        public long? IntDesignationId { get; set; }
        /// <summary>
        /// Reference from CompanyMaster
        /// </summary>
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// Combination of location,department and designations designation name 
        /// </summary>
        public string? VchJobId { get; set; }
        public string? VchStatus { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DepartmentMaster? IntDepartment { get; set; }
        public virtual DesignationMaster? IntDesignation { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual LocationMaster? IntLocation { get; set; }
        public virtual RecMasManpowerPlan? IntPlan { get; set; }
        public virtual ICollection<RecTransOfferletterManagement> RecTransOfferletterManagements { get; set; }
    }
}
