﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class OnboardDocumentDetail
    {
        public long IntOnbDocId { get; set; }
        public long? OnboardInitiationSeqId { get; set; }
        public int? IntDocId { get; set; }
        public string? VchVerifyStatus { get; set; }
        public bool? FlagOnbDoc { get; set; }
        public string? VchDocumentName { get; set; }
        public string? VchDocumentPath { get; set; }
        public byte[]? BlobDocument { get; set; }
        public string? VchExtension { get; set; }
        public string? VchActive { get; set; }
        public bool? MandatoryDoc { get; set; }
        public string? VchComments { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DocumentMaster? IntDoc { get; set; }
        public virtual OnboardingInitiation? OnboardInitiationSeq { get; set; }
    }
}
