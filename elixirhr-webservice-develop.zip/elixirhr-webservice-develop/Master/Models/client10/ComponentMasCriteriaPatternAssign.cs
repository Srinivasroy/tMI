﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasCriteriaPatternAssign
    {
        public long IntCriteriaPatternId { get; set; }
        public long? IntCompCreteriaSeqId { get; set; }
        public string? VchAttributeName { get; set; }
        public string? VchOperator { get; set; }
        public string? VchAttributeValue { get; set; }
        public long? IntOrgId { get; set; }
        public string? VchPattern { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }

        public virtual ComponentMasCriterion? IntCompCreteriaSeq { get; set; }
    }
}
