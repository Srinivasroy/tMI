﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasClientModulesGrpRole
    {
        public long IntClientModuleRoleId { get; set; }
        public long? IntClientModuleGrpId { get; set; }
        public string? VchRoleName { get; set; }
        public string? VchModuleName { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public int? IntExitClearanceOrder { get; set; }
    }
}
