﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ViewEmployeeMasterValue
    {
        public int EmployeeSeqId { get; set; }
        public int ColName { get; set; }
        public int MasterValue { get; set; }
    }
}
