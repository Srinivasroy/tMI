﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainTransTrainerdetExter
    {
        /// <summary>
        /// primary key of table
        /// </summary>
        public long IntTExternalId { get; set; }
        /// <summary>
        /// Reference from train_trans_hr_initaition
        /// </summary>
        public long? IntInitiationId { get; set; }
        /// <summary>
        /// reference from TRAIN_MAS_VENDOR_MAPPING table
        /// </summary>
        public long? IntTrainingVendmapSeqid { get; set; }
        public string? VchComponent1 { get; set; }
        public string? VchComponent2 { get; set; }
        public string? VchComponent3 { get; set; }
        public string? VchComponent4 { get; set; }
        public string? VchComponent5 { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual TrainTransHrInitiation? IntInitiation { get; set; }
        public virtual TrainMasVendorMapping? IntTrainingVendmapSeq { get; set; }
    }
}
