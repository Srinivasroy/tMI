﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class OnboardingRefIdHistory
    {
        public long IntRefCode { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
