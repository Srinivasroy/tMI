﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class LetterMasHtmlTemplate
    {
        public LetterMasHtmlTemplate()
        {
            ExitTransEmprequestAuditLogs = new HashSet<ExitTransEmprequestAuditLog>();
            ExitTransEmprequests = new HashSet<ExitTransEmprequest>();
            LetterMasGenerationMappings = new HashSet<LetterMasGenerationMapping>();
        }

        public long IntLetterHtmlId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchTemplateName { get; set; }
        public string? VchModuleName { get; set; }
        public string? VchHtmlPath { get; set; }
        public string? VchSignatureUrl { get; set; }
        public string? VchLogoUrl { get; set; }
        public string? VchAppraisalAnnexure { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchModuleLog { get; set; }
        public string? VchModuleFlag { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ExitTransEmprequestAuditLog> ExitTransEmprequestAuditLogs { get; set; }
        public virtual ICollection<ExitTransEmprequest> ExitTransEmprequests { get; set; }
        public virtual ICollection<LetterMasGenerationMapping> LetterMasGenerationMappings { get; set; }
    }
}
