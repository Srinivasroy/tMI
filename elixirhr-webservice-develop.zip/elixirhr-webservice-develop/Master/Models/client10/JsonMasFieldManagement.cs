﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JsonMasFieldManagement
    {
        public long IntManageId { get; set; }
        public string? VchPropertyName { get; set; }
        public string? VchFinalPropertyName { get; set; }
        public string? VchDatatype { get; set; }
        public string? VchDefaultValue { get; set; }
        public int? IntOrder { get; set; }
        public string? VchModuleName { get; set; }
        public string? VchActive { get; set; }
        public string? VchChanged { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
