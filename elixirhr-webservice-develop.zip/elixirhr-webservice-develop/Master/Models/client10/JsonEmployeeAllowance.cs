﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JsonEmployeeAllowance
    {
        public long IntAllowanceId { get; set; }
        public string EmpCode { get; set; } = null!;
        public long? EmployeeSeqId { get; set; }
        public string? PayHead { get; set; }
        public long? Amount { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }

        public virtual EmployeeMaster? EmployeeSeq { get; set; }
    }
}
