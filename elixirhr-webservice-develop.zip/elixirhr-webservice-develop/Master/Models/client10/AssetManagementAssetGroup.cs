﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementAssetGroup
    {
        public AssetManagementAssetGroup()
        {
            AssetManagementAssetNames = new HashSet<AssetManagementAssetName>();
            AssetManagementAssetRegisters = new HashSet<AssetManagementAssetRegister>();
            AssetManagementAttributeAssetgroupMaps = new HashSet<AssetManagementAttributeAssetgroupMap>();
        }

        public int IntAssetGroupId { get; set; }
        public string? VchAssetGroupName { get; set; }
        public string? VchAssetGroupDescription { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<AssetManagementAssetName> AssetManagementAssetNames { get; set; }
        public virtual ICollection<AssetManagementAssetRegister> AssetManagementAssetRegisters { get; set; }
        public virtual ICollection<AssetManagementAttributeAssetgroupMap> AssetManagementAttributeAssetgroupMaps { get; set; }
    }
}
