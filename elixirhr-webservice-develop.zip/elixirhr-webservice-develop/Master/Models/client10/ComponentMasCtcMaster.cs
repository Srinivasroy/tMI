﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasCtcMaster
    {
        public ComponentMasCtcMaster()
        {
            ComponentTransEmpSalMasterValues = new HashSet<ComponentTransEmpSalMasterValue>();
        }

        public long IntComMCtcMasId { get; set; }
        public double? DouCtcAmount { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public string? VchCtcModified { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchTransactionId { get; set; }
        public DateOnly? DtEffectiveDate { get; set; }
        public string? VchMoveView { get; set; }
        public DateOnly? DtSalUpdatedDate { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual ICollection<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; }
    }
}
