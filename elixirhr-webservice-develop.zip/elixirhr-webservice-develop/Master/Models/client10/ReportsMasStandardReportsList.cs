﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsMasStandardReportsList
    {
        public int IntRepStanRepListId { get; set; }
        public string? VchReportLabel { get; set; }
        public string? VchReportValue { get; set; }
        public string? VchShow { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
