﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    /// <summary>
    /// View &apos;client10.view_training_details&apos; references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them
    /// </summary>
    public partial class ViewTrainingDetail
    {
    }
}
