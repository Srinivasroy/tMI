﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class OnboardNomineeDetailsHash
    {
        public long IntSeqId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public string? VchName { get; set; }
        public DateTime? DtDob { get; set; }
        public short? IntAge { get; set; }
        public string? VchRelation { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
