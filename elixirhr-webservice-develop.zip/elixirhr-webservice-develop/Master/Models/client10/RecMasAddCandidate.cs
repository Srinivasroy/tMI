﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasAddCandidate
    {
        public RecMasAddCandidate()
        {
            RecOfferLetterManagements = new HashSet<RecOfferLetterManagement>();
        }

        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntCandidateSeqId { get; set; }
        /// <summary>
        /// Reference from vendor_master
        /// </summary>
        public long? IntVendorSeqId { get; set; }
        /// <summary>
        /// Reference from company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public string? VchCandidateName { get; set; }
        public DateOnly? DtDob { get; set; }
        public string? VchGender { get; set; }
        public string? VchJobId { get; set; }
        public string? VchMailId { get; set; }
        public string? VchPhoneNo { get; set; }
        public long? IntExpYear { get; set; }
        public long? IntCurrentSal { get; set; }
        public string? VchProfileSource { get; set; }
        public long? IntDomainId { get; set; }
        public long? IntSkillId { get; set; }
        public string? VchSkills { get; set; }
        public string? VchCandidateId { get; set; }
        public long? IntExpMonth { get; set; }
        public string? VchResumeFlag { get; set; }
        public byte[]? BlobResume { get; set; }
        public string? VchReferralCode { get; set; }
        public string? VchReferralName { get; set; }
        public string? VchMiddleName { get; set; }
        public string? VchLastName { get; set; }
        public string? VchStatus { get; set; }
        public string? VchSecretKey { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchDocumentPath { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DomainMaster? IntDomain { get; set; }
        public virtual SkillMaster? IntSkill { get; set; }
        public virtual VendorMaster? IntVendorSeq { get; set; }
        public virtual ICollection<RecOfferLetterManagement> RecOfferLetterManagements { get; set; }
    }
}
