﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class DocumentMaster
    {
        public DocumentMaster()
        {
            ComAdmEmpDocuments = new HashSet<ComAdmEmpDocument>();
            OnboardDocumentDetails = new HashSet<OnboardDocumentDetail>();
            OnboardingInitChecklistHashes = new HashSet<OnboardingInitChecklistHash>();
            OnboardingInitChecklists = new HashSet<OnboardingInitChecklist>();
        }

        public int IntDocId { get; set; }
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// HRP,HRA,HRR,LG
        /// </summary>
        public string? VchDocName { get; set; }
        public string? VchDocDescription { get; set; }
        public string? VchActive { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ComAdmEmpDocument> ComAdmEmpDocuments { get; set; }
        public virtual ICollection<OnboardDocumentDetail> OnboardDocumentDetails { get; set; }
        public virtual ICollection<OnboardingInitChecklistHash> OnboardingInitChecklistHashes { get; set; }
        public virtual ICollection<OnboardingInitChecklist> OnboardingInitChecklists { get; set; }
    }
}
