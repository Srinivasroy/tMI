﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    /// <summary>
    /// Using for generating client user number
    /// </summary>
    public partial class RoleMClientUserNoHistory
    {
        public string? VarLastClUserId { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
