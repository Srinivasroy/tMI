﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class LetterMasLogo
    {
        public long IntLetterLogoId { get; set; }
        public string? VchLogoName { get; set; }
        public string? VchLogoUrl { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
