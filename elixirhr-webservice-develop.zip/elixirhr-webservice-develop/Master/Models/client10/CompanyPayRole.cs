﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class CompanyPayRole
    {
        public long PayroleSeqid { get; set; }
        public string? ComponentName { get; set; }
        public string? ComponentCode { get; set; }
        public string? PaymentFrequency { get; set; }
        public string? ComponentType { get; set; }
        public string? ReimbursementProcedureAnnual { get; set; }
        public string? UnclaimedAmount { get; set; }
        public string? ReimbursementSetting { get; set; }
        public string? UnprocessedBillStatus { get; set; }
        public string? ComponentsequenceOrder { get; set; }
        public string? Taxable { get; set; }
        public long? ExemptionLimit { get; set; }
        public string? PerquisitesApplicable { get; set; }
        public string? FormulaType { get; set; }
        public long? FormulaFixedValue { get; set; }
        public string? FormulaOpen { get; set; }
        public string? FormulaAction { get; set; }
        public string? ResultFormula { get; set; }
        public string? ComponentRoundingOff { get; set; }
        public string? ComponentRoundingValue { get; set; }
        public string? FormulaTypes { get; set; }
        public short? PfEligibility { get; set; }
        public short? EsiEligibility { get; set; }
        public short? EsiDeduction { get; set; }
        public short? PtEligibility { get; set; }
        public short? StatutoryBonus { get; set; }
        public short? Gratuity { get; set; }
        public short? NoticePayPayment { get; set; }
        public short? NoticePayRecovery { get; set; }
        public short? LeaveEncashment { get; set; }
        public short? LopApplicabilty { get; set; }
        public short? Prorate { get; set; }
        public short? Arrear { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
    }
}
