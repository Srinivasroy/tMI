﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasCriteriaOperator
    {
        public long IntOperatorId { get; set; }
        public string? VchOperator { get; set; }
        public string? VchOperatorName { get; set; }
        public string? VchInput { get; set; }
    }
}
