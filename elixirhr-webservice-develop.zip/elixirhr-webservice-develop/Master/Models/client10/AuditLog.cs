﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuditLog
    {
        public long LogId { get; set; }
        public string? Author { get; set; }
        public string? Event { get; set; }
        public DateTime? EventDate { get; set; }
        public string? StringAttribute1 { get; set; }
        public string? StringAttribute2 { get; set; }
        public string? StringAttribute3 { get; set; }
    }
}
