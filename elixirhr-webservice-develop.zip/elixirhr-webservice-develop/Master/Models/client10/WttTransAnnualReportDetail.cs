﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class WttTransAnnualReportDetail
    {
        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntAnnRepDetId { get; set; }
        /// <summary>
        /// Reference From WTT_TRANS_ANNUAL_REPORT
        /// </summary>
        public long? IntWttAnnSeqId { get; set; }
        public string? VchReportType { get; set; }
        public DateTime? DtFromDate { get; set; }
        public DateTime? DtToDate { get; set; }
        public string? VchStatus { get; set; }
        public string? VchProcessStatus { get; set; }
        public string? VchDownloadStatus { get; set; }
        public string? VchDownloadPath { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public int? IntReportNo { get; set; }

        public virtual WttTransAnnualReport? IntWttAnnSeq { get; set; }
    }
}
