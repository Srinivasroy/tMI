﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ExitTransEmprequestAuditLog
    {
        /// <summary>
        /// PRIMARY KEY OF A TABLE
        /// </summary>
        public long IntExEmpreqAuditId { get; set; }
        /// <summary>
        /// REFERENCE FROM EMPLOYEE MASTER(employee_master)
        /// </summary>
        public long? IntEmpId { get; set; }
        /// <summary>
        /// REFERENCE FROM rESIGNATION TABLE(EXIT_MAS_RESIGNATION)
        /// </summary>
        public long? IntResigId { get; set; }
        /// <summary>
        /// FOR EMPLOYEE COMMENTS
        /// </summary>
        public string? VchEmployeeCommnets { get; set; }
        /// <summary>
        /// FOR RM COMMENTS
        /// </summary>
        public string? VchRmComments { get; set; }
        /// <summary>
        /// FOR HR COMMENTS
        /// </summary>
        public string? VchHrComments { get; set; }
        /// <summary>
        /// EXIT STATUS( MAIN STATUS)
        /// </summary>
        public string? VchExitStatus { get; set; }
        /// <summary>
        /// DEFAULT N-NO,Y-YES
        /// </summary>
        public string? VchAdminStatus { get; set; }
        /// <summary>
        /// DEFAULT N-NO,Y-YES
        /// </summary>
        public string? VchItStatus { get; set; }
        /// <summary>
        /// DEFAULT N-NO,Y-YES
        /// </summary>
        public string? VchFinanceStatus { get; set; }
        public string? VchLearningStatus { get; set; }
        public string? VchAnswered { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? DtInitDate { get; set; }
        public string? VchApproveRm { get; set; }
        public string? VchApproveHr { get; set; }
        public string? VchHrFnfComment { get; set; }
        /// <summary>
        /// Storing temporaraly Date of resignation
        /// 
        /// </summary>
        public DateTime? DtDor { get; set; }
        /// <summary>
        /// Storing temporaraly Date of leave
        /// 
        /// </summary>
        public DateTime? DtDol { get; set; }
        public string? VchFnfAmt { get; set; }
        public string? VchChkNumber { get; set; }
        public DateTime? DtChequeDate { get; set; }
        public string? VchFnfPaymentComment { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public DateTime? DtRequestedDol { get; set; }
        public int? IntNoticePeriodRecovery { get; set; }
        public int? IntNoticePeriodToServe { get; set; }
        public string? VchStatus { get; set; }
        public DateOnly? DtLetterGenDate { get; set; }
        public string? VchLetterGenPath { get; set; }
        public int? IntNoticePeriodToBeWaved { get; set; }
        public DateOnly? DtResignationLetterGenDate { get; set; }
        public string? VchResignationLetterGenPath { get; set; }
        public long? IntResignacceptLetterId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual ExitMasResignation? IntResig { get; set; }
        public virtual LetterMasHtmlTemplate? IntResignacceptLetter { get; set; }
    }
}
