﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class DepartmentsMaster
    {
        public DepartmentsMaster()
        {
            EmployeeMasters = new HashSet<EmployeeMaster>();
            HashOnboardingInitiations = new HashSet<HashOnboardingInitiation>();
            OnboardingInitiations = new HashSet<OnboardingInitiation>();
        }

        public long DeptsSeqId { get; set; }
        public string? DeptsName { get; set; }
        public long? LocationSeqId { get; set; }
        public string? VchLocationName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchActive { get; set; }
        public string? VchDeptsShortName { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateOnly? DtFromDate { get; set; }
        public DateOnly? DtToDate { get; set; }
        public string? VchTransactionId { get; set; }
        public string? VchModified { get; set; }

        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
        public virtual ICollection<HashOnboardingInitiation> HashOnboardingInitiations { get; set; }
        public virtual ICollection<OnboardingInitiation> OnboardingInitiations { get; set; }
    }
}
