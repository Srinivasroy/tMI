﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementAssetRequest
    {
        public int IntAssetRequestId { get; set; }
        public long? IntCompanyId { get; set; }
        public int? IntAssetNameId { get; set; }
        public string? VchPurpose { get; set; }
        public string? VchRemarks { get; set; }
        public DateOnly? VchFromDate { get; set; }
        public DateOnly? VchToDate { get; set; }

        public virtual AssetManagementAssetName? IntAssetName { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
