﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainMasVendorMapping
    {
        public TrainMasVendorMapping()
        {
            TrainTransTrainerdetExters = new HashSet<TrainTransTrainerdetExter>();
        }

        /// <summary>
        /// Primary key
        /// </summary>
        public long IntTrainingVendmapSeqid { get; set; }
        /// <summary>
        /// Vendor fk
        /// </summary>
        public long? IntTrainigVendorId { get; set; }
        /// <summary>
        /// Vendor name
        /// </summary>
        public string? VchTrainerName { get; set; }
        /// <summary>
        /// Mail id
        /// </summary>
        public string? VchTrainerMailid { get; set; }
        /// <summary>
        /// Mobile number
        /// </summary>
        public string? VchTrainerMobile { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchTrainerPostalAddress { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual TrainMasVendor? IntTrainigVendor { get; set; }
        public virtual ICollection<TrainTransTrainerdetExter> TrainTransTrainerdetExters { get; set; }
    }
}
