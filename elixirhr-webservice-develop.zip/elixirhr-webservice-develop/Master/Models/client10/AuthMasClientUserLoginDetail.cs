﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuthMasClientUserLoginDetail
    {
        public long IntClientUserLoginId { get; set; }
        public long? IntClientId { get; set; }
        public long? IntLoginSuccessCount { get; set; }
        public long? IntLoginFailedCount { get; set; }
        public DateTime? TsLastLoginTime { get; set; }
        public DateTime? TsLastFailLoginTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual ClientUserMaster? IntClient { get; set; }
    }
}
