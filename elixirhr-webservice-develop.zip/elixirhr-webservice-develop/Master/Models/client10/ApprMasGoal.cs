﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasGoal
    {
        public ApprMasGoal()
        {
            ApprMasGoalKraMappings = new HashSet<ApprMasGoalKraMapping>();
            ApprTransGolesRatingHashes = new HashSet<ApprTransGolesRatingHash>();
            ApprTransGolesRatingHistories = new HashSet<ApprTransGolesRatingHistory>();
            ApprTransGolesRatings = new HashSet<ApprTransGolesRating>();
        }

        public long IntGoalId { get; set; }
        public string? VchGoalShortname { get; set; }
        public string? VchGoalDescription { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ApprMasGoalKraMapping> ApprMasGoalKraMappings { get; set; }
        public virtual ICollection<ApprTransGolesRatingHash> ApprTransGolesRatingHashes { get; set; }
        public virtual ICollection<ApprTransGolesRatingHistory> ApprTransGolesRatingHistories { get; set; }
        public virtual ICollection<ApprTransGolesRating> ApprTransGolesRatings { get; set; }
    }
}
