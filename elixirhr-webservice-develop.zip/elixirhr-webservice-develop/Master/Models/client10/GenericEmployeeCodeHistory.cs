﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class GenericEmployeeCodeHistory
    {
        public long GenEmpId { get; set; }
        public string? VchEmployeeCode { get; set; }
        public string? VchEmpCodeFormula { get; set; }
        public long? IntLastEmpCodeNo { get; set; }
        public long? IntIncrementBy { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
