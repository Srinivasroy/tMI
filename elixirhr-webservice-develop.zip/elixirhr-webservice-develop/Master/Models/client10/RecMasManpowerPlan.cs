﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasManpowerPlan
    {
        public RecMasManpowerPlan()
        {
            RecMasManpowerPlanJobids = new HashSet<RecMasManpowerPlanJobid>();
            RecTransManpowerRequests = new HashSet<RecTransManpowerRequest>();
        }

        /// <summary>
        /// Primary key of rec_mas_manpower_plan
        /// </summary>
        public long IntPlanId { get; set; }
        /// <summary>
        /// Reference from LocationMaster
        /// </summary>
        public long? IntLocationId { get; set; }
        /// <summary>
        /// Reference from DepartmentMaster
        /// </summary>
        public long? IntDepartId { get; set; }
        /// <summary>
        /// Reference from DesignationMaster
        /// </summary>
        public long? IntDesigId { get; set; }
        /// <summary>
        /// Reference from company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public int? IntOnroll { get; set; }
        public int? IntPosRequired { get; set; }
        public string? VchStatus { get; set; }
        public string? VchCreatedby { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DepartmentMaster? IntDepart { get; set; }
        public virtual DesignationMaster? IntDesig { get; set; }
        public virtual LocationMaster? IntLocation { get; set; }
        public virtual ICollection<RecMasManpowerPlanJobid> RecMasManpowerPlanJobids { get; set; }
        public virtual ICollection<RecTransManpowerRequest> RecTransManpowerRequests { get; set; }
    }
}
