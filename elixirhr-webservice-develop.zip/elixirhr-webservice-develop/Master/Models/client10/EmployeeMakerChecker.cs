﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeMakerChecker
    {
        public long EmployeeMakerCheckerSeqId { get; set; }
        public long? IntEmpId { get; set; }
        public string? VchAttributeKey { get; set; }
        public string? VchPromotionDemotionFlag { get; set; }
        public long? IntOldCostValue { get; set; }
        public long? IntNewCostValue { get; set; }
        public long? IntOldDepValue { get; set; }
        public long? IntNewDepValue { get; set; }
        public long? IntOldLocValue { get; set; }
        public long? IntNewLocValue { get; set; }
        public long? IntOldDesValue { get; set; }
        public long? IntNewDesValue { get; set; }
        public DateOnly? DtOldDojValue { get; set; }
        public DateOnly? DtNewDojValue { get; set; }
        public long? IntOldItsroleValue { get; set; }
        public long? IntNewItsroleValue { get; set; }
        public long? IntNewAbeCode { get; set; }
        public long? IntOldAbeCode { get; set; }
        public long? IntOldRcsLevelValue { get; set; }
        public long? IntNewRcsLevelValue { get; set; }
        public string? IntNewSapPositionId { get; set; }
        public string? OldProfShiftAllowanceEligibility { get; set; }
        public string? NewProfShiftAllowanceEligibility { get; set; }
        public string? OldShiftAllowanceEligibility { get; set; }
        public string? NewShiftAllowanceEligibility { get; set; }
        public string? OldOncallAllowanceEligibility { get; set; }
        public string? NewOncallAllowanceEligibility { get; set; }
        public string? IntOldSapPositionId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? DtCreatedDate { get; set; }
        public string? DtUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string VchStatus { get; set; } = null!;
        public long? IntOldCtc { get; set; }
        public long? IntSalMakerId { get; set; }
        public long? IntNewCtc { get; set; }
        public DateOnly? EffectiveDate { get; set; }
        public long? IntNewEmpCatValue { get; set; }
        public long? IntOldEmpCatValue { get; set; }
        public string? VchTransactionId { get; set; }
        public string? VchOperation { get; set; }
        public string? VchRollbackStatus { get; set; }
        public long? IntNewProductivityfactor { get; set; }
        public string? NewKycIfsc { get; set; }
        public long? IntNewBankName { get; set; }
        public long? IntOldBankName { get; set; }
        public string? OldKycIfsc { get; set; }
        public string? NewTypeOfWorker { get; set; }
        public long? IntOldProductivityfactor { get; set; }
        public string? OldTypeOfWorker { get; set; }
        public int? ProbationDays { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual AbeCodeMaster? IntNewAbeCodeNavigation { get; set; }
        public virtual BankNameMaster? IntNewBankNameNavigation { get; set; }
        public virtual CostcenterMaster? IntNewCostValueNavigation { get; set; }
        public virtual DepartmentMaster? IntNewDepValueNavigation { get; set; }
        public virtual DesignationMaster? IntNewDesValueNavigation { get; set; }
        public virtual EmployeeCategoryMaster? IntNewEmpCatValueNavigation { get; set; }
        public virtual ItsRoleSfiaMaster? IntNewItsroleValueNavigation { get; set; }
        public virtual LocationMaster? IntNewLocValueNavigation { get; set; }
        public virtual ProductivityFactorMaster? IntNewProductivityfactorNavigation { get; set; }
        public virtual RcslevelMaster? IntNewRcsLevelValueNavigation { get; set; }
        public virtual AbeCodeMaster? IntOldAbeCodeNavigation { get; set; }
        public virtual BankNameMaster? IntOldBankNameNavigation { get; set; }
        public virtual CostcenterMaster? IntOldCostValueNavigation { get; set; }
        public virtual DepartmentMaster? IntOldDepValueNavigation { get; set; }
        public virtual DesignationMaster? IntOldDesValueNavigation { get; set; }
        public virtual EmployeeCategoryMaster? IntOldEmpCatValueNavigation { get; set; }
        public virtual ItsRoleSfiaMaster? IntOldItsroleValueNavigation { get; set; }
        public virtual LocationMaster? IntOldLocValueNavigation { get; set; }
        public virtual ProductivityFactorMaster? IntOldProductivityfactorNavigation { get; set; }
        public virtual RcslevelMaster? IntOldRcsLevelValueNavigation { get; set; }
        public virtual EmployeeSalaryDetailsMakerChecker? IntSalMaker { get; set; }
    }
}
