﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class LetterTemplateType
    {
        public long LettertypeId { get; set; }
        public string? LetterTemplate { get; set; }
        public string? TemplateName { get; set; }
        public string? LetterTypeDownload { get; set; }
        public byte[]? BlobLetterType { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public byte[]? BlobImgSig { get; set; }
        public string? VchSigName { get; set; }
    }
}
