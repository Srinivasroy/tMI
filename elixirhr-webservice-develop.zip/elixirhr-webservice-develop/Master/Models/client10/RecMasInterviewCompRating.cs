﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasInterviewCompRating
    {
        public long IntInterviewCompRatingId { get; set; }
        public long? IntRecCompetListSeqid { get; set; }
        public long? IntManpowerReqId { get; set; }
        public long? IntNewCandidateSeqId { get; set; }
        public decimal? IntWeightage { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual RecTransManpowerRequest? IntManpowerReq { get; set; }
        public virtual RecMasNewCandidate? IntNewCandidateSeq { get; set; }
        public virtual RecMasCompetencyList? IntRecCompetListSeq { get; set; }
    }
}
