﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsQueryField
    {
        public long IntReportsField { get; set; }
        public string? FieldName { get; set; }
        public long? IntReportsQueryId { get; set; }

        public virtual ReportsQuery? IntReportsQuery { get; set; }
    }
}
