﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasCompetencyList
    {
        public ApprMasCompetencyList()
        {
            ApprMasCompetKraMappings = new HashSet<ApprMasCompetKraMapping>();
            ApprTransCompetencyRatingHashes = new HashSet<ApprTransCompetencyRatingHash>();
            ApprTransCompetencyRatingHistories = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatings = new HashSet<ApprTransCompetencyRating>();
        }

        public long IntCompetListSeqid { get; set; }
        public string? VchShortname { get; set; }
        public string? VchDescription { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchBehaviour { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ApprMasCompetKraMapping> ApprMasCompetKraMappings { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHash> ApprTransCompetencyRatingHashes { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistories { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatings { get; set; }
    }
}
