﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class OnboardEmployeeDetail
    {
        public long IntSeqId { get; set; }
        /// <summary>
        /// reference with onboard_initiation table
        /// </summary>
        public double? IntObSeqId { get; set; }
        public string? VarPerFirstName { get; set; }
        public string? VarPerMiddleName { get; set; }
        public string? VarPerLastName { get; set; }
        public string? VarPerFatherName { get; set; }
        public DateTime? DtPerDob { get; set; }
        public string? VarPerPanNo { get; set; }
        public string? VarPerAdharNo { get; set; }
        public string? VarPerGender { get; set; }
        public string? VarPerMaritialStatus { get; set; }
        public string? VarPerReligion { get; set; }
        public string? VarPerMobileNo { get; set; }
        public string? VarPerAddress1 { get; set; }
        public string? VarPerAddress2 { get; set; }
        public string? VarPerCity { get; set; }
        public string? VarPerState { get; set; }
        public string? VarPerPincode { get; set; }
        public string? VarPerCountry { get; set; }
        public string? VarPrevEmpName { get; set; }
        public string? VarPrevAddress1 { get; set; }
        public string? VarPrevLocation { get; set; }
        public DateTime? DtPrevFromDate { get; set; }
        public DateTime? DtPrevToDate { get; set; }
        public int? IntPrevCtc { get; set; }
        public long? IntPrevNoticePeriodReq1 { get; set; }
        public long? IntPrevFixedCtc1 { get; set; }
        public long? IntPrevVariableCtc1 { get; set; }
        public string? VarPrevReferName { get; set; }
        public string? VarPrevReferId { get; set; }
        public string? VarPrevReferDesig { get; set; }
        public string? VarNomineeFatherName { get; set; }
        public DateTime? DtNomineeFatherDob { get; set; }
        public string? VarNomineeMotherName { get; set; }
        public DateTime? DtNomineeMotherDob { get; set; }
        public string? VarNomineeSpouseName { get; set; }
        public DateTime? DtNomineeSpouseDob { get; set; }
        public string? VarNomineeNoOfChildren { get; set; }
        public string? VarSslcSchName { get; set; }
        public string? VarSslcUniversity { get; set; }
        public string? VarSslcLocation { get; set; }
        public string? VarSslcYrComplete { get; set; }
        public string? VarSslcPercentage { get; set; }
        public string? VarHsSchName { get; set; }
        public string? VarHsUniversity { get; set; }
        public string? VarHsLocation { get; set; }
        public string? VarHsYrComplete { get; set; }
        public string? VarHsPercentage { get; set; }
        public string? VarUgDepart { get; set; }
        public string? VarUgInstitution { get; set; }
        public string? VarUgUniversity { get; set; }
        public string? VarUgYrFrom { get; set; }
        public string? VarUgYrTo { get; set; }
        public string? VarUgMedium { get; set; }
        public string? VarUgPercentage { get; set; }
        public string? VarPgDepart { get; set; }
        public string? VarPgInstitution { get; set; }
        public string? VarPgUniversity { get; set; }
        public string? VarPgYrFrom { get; set; }
        public string? VarPgYrTo { get; set; }
        public string? VarPgMedium { get; set; }
        public string? VarPgPercentage { get; set; }
        public string? VarDipDepart { get; set; }
        public string? VarDipInstitution { get; set; }
        public string? VarDipUniversity { get; set; }
        public string? VarDipYrFrom { get; set; }
        public string? VarDipYrTo { get; set; }
        public string? VarDipMedium { get; set; }
        public string? VarDipPercentage { get; set; }
        public string? VarKycBankName { get; set; }
        public string? VarKycAccNo { get; set; }
        public string? VarKycBranch { get; set; }
        public string? VarKycIfsc { get; set; }
        public string? VarKycPan { get; set; }
        public string? VarKycAadhar { get; set; }
        public string? VarKycPassport { get; set; }
        public string? VarKycUan { get; set; }
        public string? VarPerBg { get; set; }
        public string? VarPerEmail { get; set; }
        public string? VarPrevEmpName1 { get; set; }
        public string? VarPrevAddress2 { get; set; }
        public string? VarPrevLocation1 { get; set; }
        public DateTime? DtPrevFromDate1 { get; set; }
        public DateTime? DtPrevToDate2 { get; set; }
        public int? IntPrevCtc1 { get; set; }
        public string? VarPrevReferName1 { get; set; }
        public string? VarPrevReferId1 { get; set; }
        public string? VarPrevReferDesig1 { get; set; }
        public string? VarPerCurrAddress1 { get; set; }
        public string? VarPerCurrAddress2 { get; set; }
        public string? VarPerCurrCity { get; set; }
        public string? VarPerCurrState { get; set; }
        public string? VarPerCurrPincode { get; set; }
        public string? VarPerCurrCountry { get; set; }
        public string? VchExperience { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VarPrevEmpName3 { get; set; }
        public string? VarPerAddress3 { get; set; }
        public string? VarPrevLocation3 { get; set; }
        public DateTime? DtPrevFromDate3 { get; set; }
        public DateTime? DtPrevToDate3 { get; set; }
        public string? VarPrevReferName3 { get; set; }
        public string? VarPrevReferId3 { get; set; }
        public string? VarPrevReferDesig3 { get; set; }
        public long? IntPrevCtc3 { get; set; }
        public DateOnly? GroupDoj { get; set; }
        public DateOnly? DpdhlJoining { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
