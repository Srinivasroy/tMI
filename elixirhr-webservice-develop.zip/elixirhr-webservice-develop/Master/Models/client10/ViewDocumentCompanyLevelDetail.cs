﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ViewDocumentCompanyLevelDetail
    {
        public long? CompanyId { get; set; }
        public string? CompanyName { get; set; }
        public double DocumentSize { get; set; }
        public long? EmployeeCount { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
