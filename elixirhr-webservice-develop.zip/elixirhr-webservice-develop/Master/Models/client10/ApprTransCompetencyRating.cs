﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprTransCompetencyRating
    {
        /// <summary>
        /// Primary key
        /// </summary>
        public long IntReviewId { get; set; }
        /// <summary>
        /// Reference from emp_to_appraisal_mapping
        /// </summary>
        public long? IntEmpMappingId { get; set; }
        /// <summary>
        /// Reference Competency list
        /// </summary>
        public long? IntCompetListSeqid { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntSelfRatingId { get; set; }
        public string? VchSelfRemark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntP1RatingId { get; set; }
        public string? VchP1Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntP2RatingId { get; set; }
        public string? VchP2Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntP3RatingId { get; set; }
        public string? VchP3Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntSo1RatingId { get; set; }
        public string? VchSo1Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntSo2RatingId { get; set; }
        public string? VchSo2Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntSo3RatingId { get; set; }
        public string? VchSo3Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntSup1RatingId { get; set; }
        public string? VchSup1Remark { get; set; }
        /// <summary>
        /// reference from rating table
        /// </summary>
        public long? IntSup2RatingId { get; set; }
        public string? VchSup2Remark { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasCompetencyList? IntCompetListSeq { get; set; }
        public virtual ApprTransEmptoappMapping? IntEmpMapping { get; set; }
        public virtual ApprMasRatingParaMapping? IntP1Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntP2Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntP3Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntSelfRating { get; set; }
        public virtual ApprMasRatingParaMapping? IntSo1Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntSo2Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntSo3Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntSup1Rating { get; set; }
        public virtual ApprMasRatingParaMapping? IntSup2Rating { get; set; }
    }
}
