﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RcsgradeTmp
    {
        public long IntRcsgradeId { get; set; }
        public string? VchRcsgradeName { get; set; }
        public DateTime? DtUpdatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchTransactionId { get; set; }
    }
}
