﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsToolFieldStatusValue
    {
        public long IntGenFieldStatusId { get; set; }
        public string? VchFieldName { get; set; }
        public string? VchModuleName { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchFieldValue { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
