﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsGenericQuery
    {
        public ReportsGenericQuery()
        {
            ReportsGenericFieldValues = new HashSet<ReportsGenericFieldValue>();
            ReportsGenericQueryFields = new HashSet<ReportsGenericQueryField>();
        }

        public long ReportsSeqid { get; set; }
        public string? QueryName { get; set; }
        public string? Query { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchPackageName { get; set; }
        public string? VchModeOfOperation { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ReportsGenericFieldValue> ReportsGenericFieldValues { get; set; }
        public virtual ICollection<ReportsGenericQueryField> ReportsGenericQueryFields { get; set; }
    }
}
