﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementAssetName
    {
        public AssetManagementAssetName()
        {
            AssetManagementAssetRegisters = new HashSet<AssetManagementAssetRegister>();
            AssetManagementAssetRequests = new HashSet<AssetManagementAssetRequest>();
            AssetManagementReturnAssets = new HashSet<AssetManagementReturnAsset>();
        }

        public int IntAssetNameId { get; set; }
        public int? IntAssetGroupId { get; set; }
        public string? VchAssetName { get; set; }
        public string? VchAssetNameDescription { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual AssetManagementAssetGroup? IntAssetGroup { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<AssetManagementAssetRegister> AssetManagementAssetRegisters { get; set; }
        public virtual ICollection<AssetManagementAssetRequest> AssetManagementAssetRequests { get; set; }
        public virtual ICollection<AssetManagementReturnAsset> AssetManagementReturnAssets { get; set; }
    }
}
