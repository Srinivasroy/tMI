﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetManagementAssetRegister
    {
        public int IntAssetRegisterId { get; set; }
        public int? IntAttributeAssetGroupMapId { get; set; }
        public int? AssetGroupId { get; set; }
        public int IntAssetNameId { get; set; }
        public int? AssetAttributeId { get; set; }
        public string? VchDataType { get; set; }
        public string? VchAssetString { get; set; }
        public int? VchAssetNumeric { get; set; }
        public DateOnly? VchAssetDate { get; set; }
        public long? IntCompanyId { get; set; }
        public int? VchCount { get; set; }

        public virtual AssetManagementAssetAttribute? AssetAttribute { get; set; }
        public virtual AssetManagementAssetGroup? AssetGroup { get; set; }
        public virtual AssetManagementAssetName IntAssetName { get; set; } = null!;
        public virtual AssetManagementAttributeAssetgroupMap? IntAttributeAssetGroupMap { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
