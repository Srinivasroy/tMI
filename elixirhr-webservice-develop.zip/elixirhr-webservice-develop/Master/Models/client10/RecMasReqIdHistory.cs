﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasReqIdHistory
    {
        public long? IntReqCode { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
