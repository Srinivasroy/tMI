﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasClientAdmRight
    {
        public long IntClientAdmRightsId { get; set; }
        public long? IntClientId { get; set; }
        public string? VchModuleName { get; set; }
        public string? VchOverallRights { get; set; }
        public string? VchRead { get; set; }
        public string? VchWrite { get; set; }
        public string? VchDelete { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual ConfigMasClientCreation? IntClient { get; set; }
    }
}
