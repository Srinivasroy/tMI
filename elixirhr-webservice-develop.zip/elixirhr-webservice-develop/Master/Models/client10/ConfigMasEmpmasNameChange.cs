﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasEmpmasNameChange
    {
        public long IntEmpmasNameChId { get; set; }
        public string? VchLocationName { get; set; }
        public string? VchDepartmentName { get; set; }
        public string? VchDesignationName { get; set; }
        public string? VchGradeName { get; set; }
        public string? VchDivisionName { get; set; }
        public string? VchBranchName { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
