﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasTmiSuperAdminMaster
    {
        public ConfigMasTmiSuperAdminMaster()
        {
            AuthMasTmiSuperAdminLoginDetails = new HashSet<AuthMasTmiSuperAdminLoginDetail>();
        }

        public long IntTmisaId { get; set; }
        public string? VchTmisaEmpCode { get; set; }
        public string? VchTmisaCode { get; set; }
        public string? VchTmisaPassword { get; set; }
        public string? VchTmisaName { get; set; }
        public string? VchTmisaEmailid { get; set; }
        public string? VchTmisaPhoneno { get; set; }
        public string? VchActive { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchSchemaKey { get; set; }

        public virtual ICollection<AuthMasTmiSuperAdminLoginDetail> AuthMasTmiSuperAdminLoginDetails { get; set; }
    }
}
