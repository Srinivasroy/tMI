﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasCriteriaDesigAssign
    {
        public long IntCriteriaDesignId { get; set; }
        public long? IntCompCreteriaSeqId { get; set; }
        public long? IntDesignationSeqId { get; set; }
        public string? VchDesignationName { get; set; }
        public string? VchActive { get; set; }
        public long? IntLocationSeqId { get; set; }
        public long? IntDepartmentSeqId { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }

        public virtual ComponentMasCriterion? IntCompCreteriaSeq { get; set; }
    }
}
