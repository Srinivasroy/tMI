﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeSalaryDetail
    {
        public long IntEmpSalDtlId { get; set; }
        public long? IntOldBasic { get; set; }
        public long? IntOldDa { get; set; }
        public long? IntOldHra { get; set; }
        public long? IntOldConveyance { get; set; }
        public long? IntOldSplAllowance { get; set; }
        public long? IntOldCtc { get; set; }
        public long? IntNewBasic { get; set; }
        public long? IntNewDa { get; set; }
        public long? IntNewHra { get; set; }
        public long? IntNewConveyance { get; set; }
        public long? IntNewSplAllowance { get; set; }
        public long? IntNewCtc { get; set; }
        public long? IntReimCar1 { get; set; }
        public long? IntReimCar2 { get; set; }
        public long? IntReimTelephone1 { get; set; }
        public long? IntReimTelephone2 { get; set; }
        public long? IntReimDriver1 { get; set; }
        public long? IntReimDriver2 { get; set; }
        public long? IntReimMedical1 { get; set; }
        public long? IntReimMedical2 { get; set; }
        public long? IntOnboardInitiationSeqId { get; set; }
        public long? IntCtcDiff { get; set; }
        public DateTime? DtEffictiveFrom { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VarKycPfNo { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
