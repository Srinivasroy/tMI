﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsQuery
    {
        public ReportsQuery()
        {
            ReportsFieldValues = new HashSet<ReportsFieldValue>();
            ReportsQueryFields = new HashSet<ReportsQueryField>();
        }

        public long ReportsSeqid { get; set; }
        public string? QueryName { get; set; }
        public string? Query { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public DateTime? DtFromDate { get; set; }
        public DateTime? DtToDate { get; set; }
        public string? VchStatus { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ReportsFieldValue> ReportsFieldValues { get; set; }
        public virtual ICollection<ReportsQueryField> ReportsQueryFields { get; set; }
    }
}
