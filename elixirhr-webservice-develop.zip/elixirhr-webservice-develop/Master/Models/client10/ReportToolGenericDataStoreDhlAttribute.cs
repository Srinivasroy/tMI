﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreDhlAttribute
    {
        public long IntDhlReptId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? EmployeeCode { get; set; }
        public string? EmployeeName { get; set; }
        public string? RcsGrade { get; set; }
        public string? Designation { get; set; }
        public DateOnly? DateOfJoining { get; set; }
        public DateOnly? DateOfLeaving { get; set; }
        public string? BusinessPartner { get; set; }
        public string? HireType { get; set; }
        public string? OnCallAllowanceEligibility { get; set; }
        public string? ShiftAllowanceEligibility { get; set; }
        public string? ProfessionalShiftAllowanceEligibility { get; set; }
        public string? TypeOfWorker { get; set; }
        public string? Billing { get; set; }
        public string? LeaveGroup { get; set; }
        public string? PhysicalStatus { get; set; }
        public string? EmploymentType { get; set; }
        public string? MaritalStatus { get; set; }
        public string? TaxSlabOptedFor { get; set; }
        public string? AbeCode { get; set; }
        public string? ItsRoleSfia { get; set; }
        public string? MidPoint { get; set; }
        public string? TotalExperience { get; set; }
        public string? RcsLevel { get; set; }
        public string? SubDepartment { get; set; }
        public string? ProductivityFactor { get; set; }
        public string? BankName { get; set; }
        public string? BusinessUnit { get; set; }
        public string? GroupName { get; set; }
        public DateOnly? GroupDoj { get; set; }
        public string? Ldap { get; set; }
        public string? SapEmployeeNo { get; set; }
        public string? SapPositionId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public float? PrivilegeLeave { get; set; }
        public float? CasualLeave { get; set; }
        public float? SickLeave { get; set; }
        public float? MaternityLeave { get; set; }
        public float? PaternityLeave { get; set; }
        public float? MiscarriageLeave { get; set; }
        public int? OptionalLeave { get; set; }
        public int? CovaccineLeave { get; set; }
        public DateOnly? DpdhlJoining { get; set; }
        public string? SapActionCode { get; set; }
        public string? SapReasonCode { get; set; }
        public string? Departments { get; set; }
        public DateOnly? ModifiedDate { get; set; }
    }
}
