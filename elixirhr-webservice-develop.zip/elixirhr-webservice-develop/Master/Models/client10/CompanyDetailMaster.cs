﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class CompanyDetailMaster
    {
        public CompanyDetailMaster()
        {
            ApprMasAppraiserMappingKras = new HashSet<ApprMasAppraiserMappingKra>();
            ApprMasAppraisers = new HashSet<ApprMasAppraiser>();
            ApprMasCompetKraMappings = new HashSet<ApprMasCompetKraMapping>();
            ApprMasCompetencyLists = new HashSet<ApprMasCompetencyList>();
            ApprMasEmpGroupingAssigns = new HashSet<ApprMasEmpGroupingAssign>();
            ApprMasEmpGroupings = new HashSet<ApprMasEmpGrouping>();
            ApprMasEmptoappMappingHashes = new HashSet<ApprMasEmptoappMappingHash>();
            ApprMasGoalKraMappings = new HashSet<ApprMasGoalKraMapping>();
            ApprMasGoals = new HashSet<ApprMasGoal>();
            ApprMasRatingDescriptions = new HashSet<ApprMasRatingDescription>();
            ApprMasRatingOrders = new HashSet<ApprMasRatingOrder>();
            ApprMasRatingParaMappings = new HashSet<ApprMasRatingParaMapping>();
            ApprMasReviewperiodConfigs = new HashSet<ApprMasReviewperiodConfig>();
            ApprTransCompetencyRatingHistories = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransCompetencyRatings = new HashSet<ApprTransCompetencyRating>();
            ApprTransEmptoappMappingHistories = new HashSet<ApprTransEmptoappMappingHistory>();
            ApprTransEmptoappMappings = new HashSet<ApprTransEmptoappMapping>();
            ApprTransGolesRatingHashes = new HashSet<ApprTransGolesRatingHash>();
            ApprTransGolesRatingHistories = new HashSet<ApprTransGolesRatingHistory>();
            ApprTransGolesRatings = new HashSet<ApprTransGolesRating>();
            ApprTransIncrementalGrids = new HashSet<ApprTransIncrementalGrid>();
            ApprTransProcessHistories = new HashSet<ApprTransProcessHistory>();
            ApprTransProcesses = new HashSet<ApprTransProcess>();
            AssetManagementAssetAttributes = new HashSet<AssetManagementAssetAttribute>();
            AssetManagementAssetGroups = new HashSet<AssetManagementAssetGroup>();
            AssetManagementAssetNames = new HashSet<AssetManagementAssetName>();
            AssetManagementAssetRegisters = new HashSet<AssetManagementAssetRegister>();
            AssetManagementAssetRequests = new HashSet<AssetManagementAssetRequest>();
            AssetManagementAttributeAssetgroupMaps = new HashSet<AssetManagementAttributeAssetgroupMap>();
            AssetManagementReturnAssets = new HashSet<AssetManagementReturnAsset>();
            AuditBankDetails = new HashSet<AuditBankDetail>();
            AuditEmpBankDetails = new HashSet<AuditEmpBankDetail>();
            AuditOrgKycInfos = new HashSet<AuditOrgKycInfo>();
            ComMCompanyPolicyDocuments = new HashSet<ComMCompanyPolicyDocument>();
            ComMCompanyRoles = new HashSet<ComMCompanyRole>();
            ComMCompanyRolesAssigns = new HashSet<ComMCompanyRolesAssign>();
            ComMEmployeeLoginLogs = new HashSet<ComMEmployeeLoginLog>();
            ComponentMasCreations = new HashSet<ComponentMasCreation>();
            ComponentMasCriteria = new HashSet<ComponentMasCriterion>();
            ComponentMasCtcMasterTmps = new HashSet<ComponentMasCtcMasterTmp>();
            ComponentMasCtcMasters = new HashSet<ComponentMasCtcMaster>();
            ComponentMasIdGenerateHistories = new HashSet<ComponentMasIdGenerateHistory>();
            ComponentTransCriteriaComponentAssigns = new HashSet<ComponentTransCriteriaComponentAssign>();
            ComponentTransEmpSalMasterValues = new HashSet<ComponentTransEmpSalMasterValue>();
            ComponentTransEmpSalaryHistories = new HashSet<ComponentTransEmpSalaryHistory>();
            ComponentTransEmpSalaryValuesHistories = new HashSet<ComponentTransEmpSalaryValuesHistory>();
            ConfigMasTmiClientCompanyIntCompanies = new HashSet<ConfigMasTmiClientCompany>();
            ConfigMasTmiClientCompanyIntTmiUsers = new HashSet<ConfigMasTmiClientCompany>();
            ConfirmationAssessmentAns = new HashSet<ConfirmationAssessmentAn>();
            ConfirmationAssessmentQuestions = new HashSet<ConfirmationAssessmentQuestion>();
            ConfirmationAssessmentRequests = new HashSet<ConfirmationAssessmentRequest>();
            ConfirmationQuestionEmployeeMaps = new HashSet<ConfirmationQuestionEmployeeMap>();
            DocumentMasters = new HashSet<DocumentMaster>();
            EmployeeDocumentSizeDetails = new HashSet<EmployeeDocumentSizeDetail>();
            EmployeeMakerCheckers = new HashSet<EmployeeMakerChecker>();
            EmployeeMasDetails = new HashSet<EmployeeMasDetail>();
            EmployeeMasters = new HashSet<EmployeeMaster>();
            EmployeeSalaryAuditLogs = new HashSet<EmployeeSalaryAuditLog>();
            EmployeeSalaryDetails = new HashSet<EmployeeSalaryDetail>();
            EmployeeSalaryDetailsMakerCheckers = new HashSet<EmployeeSalaryDetailsMakerChecker>();
            ExitMasAns = new HashSet<ExitMasAn>();
            ExitMasEmployeeMaps = new HashSet<ExitMasEmployeeMap>();
            ExitMasQuestionTemplateItems = new HashSet<ExitMasQuestionTemplateItem>();
            ExitMasQuestionTemplates = new HashSet<ExitMasQuestionTemplate>();
            ExitMasQuestions = new HashSet<ExitMasQuestion>();
            ExitMasResignations = new HashSet<ExitMasResignation>();
            ExitTransClearances = new HashSet<ExitTransClearance>();
            ExitTransEmprequestAuditLogs = new HashSet<ExitTransEmprequestAuditLog>();
            ExitTransEmprequests = new HashSet<ExitTransEmprequest>();
            GenericEmployeeCodeHistories = new HashSet<GenericEmployeeCodeHistory>();
            LetterMasGenerationMappings = new HashSet<LetterMasGenerationMapping>();
            LetterMasHtmlTemplates = new HashSet<LetterMasHtmlTemplate>();
            OnboardDocumentDetails = new HashSet<OnboardDocumentDetail>();
            OnboardEmployeeDetails = new HashSet<OnboardEmployeeDetail>();
            OnboardEmployeeDetailsHashes = new HashSet<OnboardEmployeeDetailsHash>();
            OnboardNomineeDetails = new HashSet<OnboardNomineeDetail>();
            OnboardNomineeDetailsHashes = new HashSet<OnboardNomineeDetailsHash>();
            OnboardSalaryStructures = new HashSet<OnboardSalaryStructure>();
            OnboardingInitChecklistHashes = new HashSet<OnboardingInitChecklistHash>();
            OnboardingInitiations = new HashSet<OnboardingInitiation>();
            OnboardingRefIdHistories = new HashSet<OnboardingRefIdHistory>();
            PfDetailMasters = new HashSet<PfDetailMaster>();
            RecMasAddCandidates = new HashSet<RecMasAddCandidate>();
            RecMasCandidateIdHistories = new HashSet<RecMasCandidateIdHistory>();
            RecMasCompetManpowreqMappings = new HashSet<RecMasCompetManpowreqMapping>();
            RecMasCompetencyLists = new HashSet<RecMasCompetencyList>();
            RecMasInterviewCompRatings = new HashSet<RecMasInterviewCompRating>();
            RecMasJobIdNoHistories = new HashSet<RecMasJobIdNoHistory>();
            RecMasManpowerPlanJobids = new HashSet<RecMasManpowerPlanJobid>();
            RecMasManpowerPlans = new HashSet<RecMasManpowerPlan>();
            RecMasNewCandidates = new HashSet<RecMasNewCandidate>();
            RecMasNewcanEdudets = new HashSet<RecMasNewcanEdudet>();
            RecMasNewcanEmpdets = new HashSet<RecMasNewcanEmpdet>();
            RecOfferLetterManagements = new HashSet<RecOfferLetterManagement>();
            RecTransManpowerRequests = new HashSet<RecTransManpowerRequest>();
            RecTransOfferletterManagements = new HashSet<RecTransOfferletterManagement>();
            RecTransReferPublishRequests = new HashSet<RecTransReferPublishRequest>();
            RecTransScheduleInterCandidates = new HashSet<RecTransScheduleInterCandidate>();
            RecTransScheduleInterviews = new HashSet<RecTransScheduleInterview>();
            ReportsGenericQueries = new HashSet<ReportsGenericQuery>();
            ReportsQueries = new HashSet<ReportsQuery>();
            ReportsToolQueries = new HashSet<ReportsToolQuery>();
            TrainMasCategories = new HashSet<TrainMasCategory>();
            TrainMasQuestions = new HashSet<TrainMasQuestion>();
            TrainMasTypes = new HashSet<TrainMasType>();
            TrainMasVendorMappings = new HashSet<TrainMasVendorMapping>();
            TrainMasVendors = new HashSet<TrainMasVendor>();
            TrainTransAnswers = new HashSet<TrainTransAnswer>();
            TrainTransHrInitiations = new HashSet<TrainTransHrInitiation>();
            TrainTransRequests = new HashSet<TrainTransRequest>();
            TrainTransTrainerdetExters = new HashSet<TrainTransTrainerdetExter>();
            TrainTransTrainerdetInters = new HashSet<TrainTransTrainerdetInter>();
            TrainTransTrainingDetails = new HashSet<TrainTransTrainingDetail>();
            WttMCompanyTypes = new HashSet<WttMCompanyType>();
            WttMakerCheckers = new HashSet<WttMakerChecker>();
        }

        public long CompanySeqId { get; set; }
        public long? IntClientId { get; set; }
        public string? CompanyName { get; set; }
        public string? CompanyAddress { get; set; }
        public string? PanNo { get; set; }
        public string? TanNo { get; set; }
        public long? CompanyLogo { get; set; }
        public string? PfReg { get; set; }
        public string? EsiReg { get; set; }
        public string? VchPfReg { get; set; }
        public string? VchEsiReg { get; set; }
        public string? VchCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchEmpCodeFormula { get; set; }
        public long? IntIncrementBy { get; set; }
        public long? IntLastEmpNo { get; set; }
        public string? VchEmpCodeAssigned { get; set; }
        public string? VchLogoPath { get; set; }

        public virtual ConfigMasClientCreation? IntClient { get; set; }
        public virtual ICollection<ApprMasAppraiserMappingKra> ApprMasAppraiserMappingKras { get; set; }
        public virtual ICollection<ApprMasAppraiser> ApprMasAppraisers { get; set; }
        public virtual ICollection<ApprMasCompetKraMapping> ApprMasCompetKraMappings { get; set; }
        public virtual ICollection<ApprMasCompetencyList> ApprMasCompetencyLists { get; set; }
        public virtual ICollection<ApprMasEmpGroupingAssign> ApprMasEmpGroupingAssigns { get; set; }
        public virtual ICollection<ApprMasEmpGrouping> ApprMasEmpGroupings { get; set; }
        public virtual ICollection<ApprMasEmptoappMappingHash> ApprMasEmptoappMappingHashes { get; set; }
        public virtual ICollection<ApprMasGoalKraMapping> ApprMasGoalKraMappings { get; set; }
        public virtual ICollection<ApprMasGoal> ApprMasGoals { get; set; }
        public virtual ICollection<ApprMasRatingDescription> ApprMasRatingDescriptions { get; set; }
        public virtual ICollection<ApprMasRatingOrder> ApprMasRatingOrders { get; set; }
        public virtual ICollection<ApprMasRatingParaMapping> ApprMasRatingParaMappings { get; set; }
        public virtual ICollection<ApprMasReviewperiodConfig> ApprMasReviewperiodConfigs { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistories { get; set; }
        public virtual ICollection<ApprTransCompetencyRating> ApprTransCompetencyRatings { get; set; }
        public virtual ICollection<ApprTransEmptoappMappingHistory> ApprTransEmptoappMappingHistories { get; set; }
        public virtual ICollection<ApprTransEmptoappMapping> ApprTransEmptoappMappings { get; set; }
        public virtual ICollection<ApprTransGolesRatingHash> ApprTransGolesRatingHashes { get; set; }
        public virtual ICollection<ApprTransGolesRatingHistory> ApprTransGolesRatingHistories { get; set; }
        public virtual ICollection<ApprTransGolesRating> ApprTransGolesRatings { get; set; }
        public virtual ICollection<ApprTransIncrementalGrid> ApprTransIncrementalGrids { get; set; }
        public virtual ICollection<ApprTransProcessHistory> ApprTransProcessHistories { get; set; }
        public virtual ICollection<ApprTransProcess> ApprTransProcesses { get; set; }
        public virtual ICollection<AssetManagementAssetAttribute> AssetManagementAssetAttributes { get; set; }
        public virtual ICollection<AssetManagementAssetGroup> AssetManagementAssetGroups { get; set; }
        public virtual ICollection<AssetManagementAssetName> AssetManagementAssetNames { get; set; }
        public virtual ICollection<AssetManagementAssetRegister> AssetManagementAssetRegisters { get; set; }
        public virtual ICollection<AssetManagementAssetRequest> AssetManagementAssetRequests { get; set; }
        public virtual ICollection<AssetManagementAttributeAssetgroupMap> AssetManagementAttributeAssetgroupMaps { get; set; }
        public virtual ICollection<AssetManagementReturnAsset> AssetManagementReturnAssets { get; set; }
        public virtual ICollection<AuditBankDetail> AuditBankDetails { get; set; }
        public virtual ICollection<AuditEmpBankDetail> AuditEmpBankDetails { get; set; }
        public virtual ICollection<AuditOrgKycInfo> AuditOrgKycInfos { get; set; }
        public virtual ICollection<ComMCompanyPolicyDocument> ComMCompanyPolicyDocuments { get; set; }
        public virtual ICollection<ComMCompanyRole> ComMCompanyRoles { get; set; }
        public virtual ICollection<ComMCompanyRolesAssign> ComMCompanyRolesAssigns { get; set; }
        public virtual ICollection<ComMEmployeeLoginLog> ComMEmployeeLoginLogs { get; set; }
        public virtual ICollection<ComponentMasCreation> ComponentMasCreations { get; set; }
        public virtual ICollection<ComponentMasCriterion> ComponentMasCriteria { get; set; }
        public virtual ICollection<ComponentMasCtcMasterTmp> ComponentMasCtcMasterTmps { get; set; }
        public virtual ICollection<ComponentMasCtcMaster> ComponentMasCtcMasters { get; set; }
        public virtual ICollection<ComponentMasIdGenerateHistory> ComponentMasIdGenerateHistories { get; set; }
        public virtual ICollection<ComponentTransCriteriaComponentAssign> ComponentTransCriteriaComponentAssigns { get; set; }
        public virtual ICollection<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; }
        public virtual ICollection<ComponentTransEmpSalaryHistory> ComponentTransEmpSalaryHistories { get; set; }
        public virtual ICollection<ComponentTransEmpSalaryValuesHistory> ComponentTransEmpSalaryValuesHistories { get; set; }
        public virtual ICollection<ConfigMasTmiClientCompany> ConfigMasTmiClientCompanyIntCompanies { get; set; }
        public virtual ICollection<ConfigMasTmiClientCompany> ConfigMasTmiClientCompanyIntTmiUsers { get; set; }
        public virtual ICollection<ConfirmationAssessmentAn> ConfirmationAssessmentAns { get; set; }
        public virtual ICollection<ConfirmationAssessmentQuestion> ConfirmationAssessmentQuestions { get; set; }
        public virtual ICollection<ConfirmationAssessmentRequest> ConfirmationAssessmentRequests { get; set; }
        public virtual ICollection<ConfirmationQuestionEmployeeMap> ConfirmationQuestionEmployeeMaps { get; set; }
        public virtual ICollection<DocumentMaster> DocumentMasters { get; set; }
        public virtual ICollection<EmployeeDocumentSizeDetail> EmployeeDocumentSizeDetails { get; set; }
        public virtual ICollection<EmployeeMakerChecker> EmployeeMakerCheckers { get; set; }
        public virtual ICollection<EmployeeMasDetail> EmployeeMasDetails { get; set; }
        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
        public virtual ICollection<EmployeeSalaryAuditLog> EmployeeSalaryAuditLogs { get; set; }
        public virtual ICollection<EmployeeSalaryDetail> EmployeeSalaryDetails { get; set; }
        public virtual ICollection<EmployeeSalaryDetailsMakerChecker> EmployeeSalaryDetailsMakerCheckers { get; set; }
        public virtual ICollection<ExitMasAn> ExitMasAns { get; set; }
        public virtual ICollection<ExitMasEmployeeMap> ExitMasEmployeeMaps { get; set; }
        public virtual ICollection<ExitMasQuestionTemplateItem> ExitMasQuestionTemplateItems { get; set; }
        public virtual ICollection<ExitMasQuestionTemplate> ExitMasQuestionTemplates { get; set; }
        public virtual ICollection<ExitMasQuestion> ExitMasQuestions { get; set; }
        public virtual ICollection<ExitMasResignation> ExitMasResignations { get; set; }
        public virtual ICollection<ExitTransClearance> ExitTransClearances { get; set; }
        public virtual ICollection<ExitTransEmprequestAuditLog> ExitTransEmprequestAuditLogs { get; set; }
        public virtual ICollection<ExitTransEmprequest> ExitTransEmprequests { get; set; }
        public virtual ICollection<GenericEmployeeCodeHistory> GenericEmployeeCodeHistories { get; set; }
        public virtual ICollection<LetterMasGenerationMapping> LetterMasGenerationMappings { get; set; }
        public virtual ICollection<LetterMasHtmlTemplate> LetterMasHtmlTemplates { get; set; }
        public virtual ICollection<OnboardDocumentDetail> OnboardDocumentDetails { get; set; }
        public virtual ICollection<OnboardEmployeeDetail> OnboardEmployeeDetails { get; set; }
        public virtual ICollection<OnboardEmployeeDetailsHash> OnboardEmployeeDetailsHashes { get; set; }
        public virtual ICollection<OnboardNomineeDetail> OnboardNomineeDetails { get; set; }
        public virtual ICollection<OnboardNomineeDetailsHash> OnboardNomineeDetailsHashes { get; set; }
        public virtual ICollection<OnboardSalaryStructure> OnboardSalaryStructures { get; set; }
        public virtual ICollection<OnboardingInitChecklistHash> OnboardingInitChecklistHashes { get; set; }
        public virtual ICollection<OnboardingInitiation> OnboardingInitiations { get; set; }
        public virtual ICollection<OnboardingRefIdHistory> OnboardingRefIdHistories { get; set; }
        public virtual ICollection<PfDetailMaster> PfDetailMasters { get; set; }
        public virtual ICollection<RecMasAddCandidate> RecMasAddCandidates { get; set; }
        public virtual ICollection<RecMasCandidateIdHistory> RecMasCandidateIdHistories { get; set; }
        public virtual ICollection<RecMasCompetManpowreqMapping> RecMasCompetManpowreqMappings { get; set; }
        public virtual ICollection<RecMasCompetencyList> RecMasCompetencyLists { get; set; }
        public virtual ICollection<RecMasInterviewCompRating> RecMasInterviewCompRatings { get; set; }
        public virtual ICollection<RecMasJobIdNoHistory> RecMasJobIdNoHistories { get; set; }
        public virtual ICollection<RecMasManpowerPlanJobid> RecMasManpowerPlanJobids { get; set; }
        public virtual ICollection<RecMasManpowerPlan> RecMasManpowerPlans { get; set; }
        public virtual ICollection<RecMasNewCandidate> RecMasNewCandidates { get; set; }
        public virtual ICollection<RecMasNewcanEdudet> RecMasNewcanEdudets { get; set; }
        public virtual ICollection<RecMasNewcanEmpdet> RecMasNewcanEmpdets { get; set; }
        public virtual ICollection<RecOfferLetterManagement> RecOfferLetterManagements { get; set; }
        public virtual ICollection<RecTransManpowerRequest> RecTransManpowerRequests { get; set; }
        public virtual ICollection<RecTransOfferletterManagement> RecTransOfferletterManagements { get; set; }
        public virtual ICollection<RecTransReferPublishRequest> RecTransReferPublishRequests { get; set; }
        public virtual ICollection<RecTransScheduleInterCandidate> RecTransScheduleInterCandidates { get; set; }
        public virtual ICollection<RecTransScheduleInterview> RecTransScheduleInterviews { get; set; }
        public virtual ICollection<ReportsGenericQuery> ReportsGenericQueries { get; set; }
        public virtual ICollection<ReportsQuery> ReportsQueries { get; set; }
        public virtual ICollection<ReportsToolQuery> ReportsToolQueries { get; set; }
        public virtual ICollection<TrainMasCategory> TrainMasCategories { get; set; }
        public virtual ICollection<TrainMasQuestion> TrainMasQuestions { get; set; }
        public virtual ICollection<TrainMasType> TrainMasTypes { get; set; }
        public virtual ICollection<TrainMasVendorMapping> TrainMasVendorMappings { get; set; }
        public virtual ICollection<TrainMasVendor> TrainMasVendors { get; set; }
        public virtual ICollection<TrainTransAnswer> TrainTransAnswers { get; set; }
        public virtual ICollection<TrainTransHrInitiation> TrainTransHrInitiations { get; set; }
        public virtual ICollection<TrainTransRequest> TrainTransRequests { get; set; }
        public virtual ICollection<TrainTransTrainerdetExter> TrainTransTrainerdetExters { get; set; }
        public virtual ICollection<TrainTransTrainerdetInter> TrainTransTrainerdetInters { get; set; }
        public virtual ICollection<TrainTransTrainingDetail> TrainTransTrainingDetails { get; set; }
        public virtual ICollection<WttMCompanyType> WttMCompanyTypes { get; set; }
        public virtual ICollection<WttMakerChecker> WttMakerCheckers { get; set; }
    }
}
