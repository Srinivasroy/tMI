﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmpMasterEffectiveDateValidateTmp
    {
        public long EmpSeqId { get; set; }
        public string? EmployeeCode { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchTransactionId { get; set; }
    }
}
