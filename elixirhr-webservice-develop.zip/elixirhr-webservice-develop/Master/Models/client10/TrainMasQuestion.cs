﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainMasQuestion
    {
        public TrainMasQuestion()
        {
            TrainTransAnswers = new HashSet<TrainTransAnswer>();
            TrainTransHrInitiations = new HashSet<TrainTransHrInitiation>();
        }

        /// <summary>
        /// primary key of a table
        /// </summary>
        public long IntQuestionId { get; set; }
        public string? VchQuestionTmpName { get; set; }
        public string? VchQuestion1 { get; set; }
        public string? VchAnsQuest1 { get; set; }
        public string? VchQuestion2 { get; set; }
        public string? VchAnsQuest2 { get; set; }
        public string? VchQuestion3 { get; set; }
        public string? VchAnsQuest3 { get; set; }
        public string? VchQuestion4 { get; set; }
        public string? VchAnsQuest4 { get; set; }
        public string? VchQuestion5 { get; set; }
        public string? VchAnsQuest5 { get; set; }
        public string? VchQuestion6 { get; set; }
        public string? VchAnsQuest6 { get; set; }
        public string? VchQuestion7 { get; set; }
        public string? VchAnsQuest7 { get; set; }
        public string? VchQuestion8 { get; set; }
        public string? VchAnsQuest8 { get; set; }
        public string? VchQuestion9 { get; set; }
        public string? VchAnsQuest9 { get; set; }
        public string? VchQuestion10 { get; set; }
        public string? VchAnsQuest10 { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<TrainTransAnswer> TrainTransAnswers { get; set; }
        public virtual ICollection<TrainTransHrInitiation> TrainTransHrInitiations { get; set; }
    }
}
