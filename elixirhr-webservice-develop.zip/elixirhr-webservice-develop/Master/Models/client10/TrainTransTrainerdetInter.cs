﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainTransTrainerdetInter
    {
        /// <summary>
        /// primary key of a table
        /// </summary>
        public double IntTInternalId { get; set; }
        /// <summary>
        /// Reference from employee master(employee_master table)
        /// </summary>
        public long? IntEmpId { get; set; }
        /// <summary>
        /// Reference from hr initiation table (train_trans_hr_initiation)
        /// </summary>
        public long? IntInitiationId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchEmailId { get; set; }
        public string? VchMobile { get; set; }
        public string? VchPostalAddr { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual TrainTransHrInitiation? IntInitiation { get; set; }
    }
}
