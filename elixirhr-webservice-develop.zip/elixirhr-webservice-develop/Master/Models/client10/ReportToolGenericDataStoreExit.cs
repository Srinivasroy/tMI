﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreExit
    {
        public long IntExitReptId { get; set; }
        public string? EmployeeId { get; set; }
        public string? EmployeeName { get; set; }
        public string? Location { get; set; }
        public string? Department { get; set; }
        public string? Designation { get; set; }
        public DateOnly? DateOfJoining { get; set; }
        public DateOnly? ResignationRequestDate { get; set; }
        public DateOnly? DateOfResignation { get; set; }
        public DateOnly? DateOfLeaving { get; set; }
        public DateTime? RequestedDateOfLeaving { get; set; }
        public string? ResignationRequestStatus { get; set; }
        public int? NoticePeriodToBeServed { get; set; }
        public int? NoticePeriodRecoveryDays { get; set; }
        public int? NoticePeriodToBeRecoveredWaived { get; set; }
        public string? ResignationType { get; set; }
        public string? ResignationReason { get; set; }
        public string? EmployeeComments { get; set; }
        public string? RmComments { get; set; }
        public string? HrComments { get; set; }
        public string? FinanceStatus { get; set; }
        public string? AdminStatus { get; set; }
        public string? LearningStatus { get; set; }
        public string? ItStatus { get; set; }
        public string? RmEmployeeId { get; set; }
        public string? HrEmployeeId { get; set; }
        public string? FnfAmount { get; set; }
        public string? ChequeNumber { get; set; }
        public DateOnly? ChequeDate { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
