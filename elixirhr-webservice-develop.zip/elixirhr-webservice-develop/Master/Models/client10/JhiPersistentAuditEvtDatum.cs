﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JhiPersistentAuditEvtDatum
    {
        public long EventId { get; set; }
        public string Name { get; set; } = null!;
        public string? Value { get; set; }

        public virtual JhiPersistentAuditEvent Event { get; set; } = null!;
    }
}
