﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuditOrgKycInfo
    {
        public long IntAdOrKyId { get; set; }
        public long? IntCompanyId { get; set; }
        public long? IntEmpId { get; set; }
        public string? VchAttribute { get; set; }
        public long? IntOldLocValue { get; set; }
        public long? IntNewLocValue { get; set; }
        public long? IntOldDepValue { get; set; }
        public long? IntNewDepValue { get; set; }
        public long? IntOldDesigValue { get; set; }
        public long? IntNewDesigValue { get; set; }
        public long? IntOldCostValue { get; set; }
        public long? IntNewCostValue { get; set; }
        public long? IntNewCategoryValue { get; set; }
        public long? IntOldCategoryValue { get; set; }
        public string? VchOldRmCode { get; set; }
        public string? VchNewRmCode { get; set; }
        public string? VchOldPan { get; set; }
        public string? VchNewPan { get; set; }
        public string? VchOldAdhaar { get; set; }
        public string? VchNewAdhaar { get; set; }
        public string? VchOldPassport { get; set; }
        public string? VchNewPassport { get; set; }
        public string? VchOldUan { get; set; }
        public string? VchNewUan { get; set; }
        public string? VchOldDl { get; set; }
        public string? VchNewDl { get; set; }
        public string? VchOldEsi { get; set; }
        public string? VchNewEsi { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? DtFromDate { get; set; }
        public DateTime? DtToDate { get; set; }
        public string? VchOldPf { get; set; }
        public string? VchNewPf { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual EmployeeCategoryMaster? IntNewCategoryValueNavigation { get; set; }
        public virtual CostcenterMaster? IntNewCostValueNavigation { get; set; }
        public virtual DepartmentMaster? IntNewDepValueNavigation { get; set; }
        public virtual DesignationMaster? IntNewDesigValueNavigation { get; set; }
        public virtual LocationMaster? IntNewLocValueNavigation { get; set; }
        public virtual EmployeeCategoryMaster? IntOldCategoryValueNavigation { get; set; }
        public virtual CostcenterMaster? IntOldCostValueNavigation { get; set; }
        public virtual DepartmentMaster? IntOldDepValueNavigation { get; set; }
        public virtual DesignationMaster? IntOldDesigValueNavigation { get; set; }
        public virtual LocationMaster? IntOldLocValueNavigation { get; set; }
    }
}
