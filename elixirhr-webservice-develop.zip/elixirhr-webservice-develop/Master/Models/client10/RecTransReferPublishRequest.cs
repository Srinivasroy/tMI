﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecTransReferPublishRequest
    {
        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntPublishReqId { get; set; }
        /// <summary>
        /// Reference from rec_trans_manpower_request
        /// </summary>
        public long? IntManpowerReqId { get; set; }
        /// <summary>
        /// Reference for company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public string? VchVendorDesignationIds { get; set; }
        /// <summary>
        /// Contain either Refer(R) or Publish(P)
        /// </summary>
        public string? VchMode { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual RecTransManpowerRequest? IntManpowerReq { get; set; }
    }
}
