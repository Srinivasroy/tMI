﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JhiUser
    {
        public JhiUser()
        {
            AuthorityNames = new HashSet<JhiAuthority>();
        }

        public long Id { get; set; }
        public string Login { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? ImageUrl { get; set; }
        public ulong Activated { get; set; }
        public string? LangKey { get; set; }
        public string? ActivationKey { get; set; }
        public string? ResetKey { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime? CreatedDate { get; set; }
        public DateTime? ResetDate { get; set; }
        public string? LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }

        public virtual ICollection<JhiAuthority> AuthorityNames { get; set; }
    }
}
