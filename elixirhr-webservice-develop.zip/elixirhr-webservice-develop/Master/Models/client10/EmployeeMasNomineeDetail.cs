﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeMasNomineeDetail
    {
        public long IntNimineeSeqId { get; set; }
        /// <summary>
        /// REFERENCE FROM ONBOARD_EMPLOYEE_DETAILS FOREIGN KEY
        /// </summary>
        public long? IntEmployeeSeqId { get; set; }
        public string? VchName { get; set; }
        public DateTime? DtDob { get; set; }
        public short? IntAge { get; set; }
        public string? VchRelation { get; set; }
        public string? VchName1 { get; set; }
        public short? IntAge1 { get; set; }
        public DateTime? DtDob1 { get; set; }
        public string? VchRelation1 { get; set; }
        public string? VchName2 { get; set; }
        public short? IntAge2 { get; set; }
        public DateTime? DtDob2 { get; set; }
        public string? VchRelation2 { get; set; }
        public string? VchName3 { get; set; }
        public short? IntAge3 { get; set; }
        public DateTime? DtDob3 { get; set; }
        public string? VchRelation3 { get; set; }
        public string? VchName4 { get; set; }
        public short? IntAge4 { get; set; }
        public DateTime? DtDob4 { get; set; }
        public string? VchRelation4 { get; set; }
        public string? VarKycPfNo { get; set; }

        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
