﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RoleMTmiNoHistory
    {
        public string? VarLastTmiId { get; set; }
    }
}
