﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class JhiPersistentAuditEvent
    {
        public JhiPersistentAuditEvent()
        {
            JhiPersistentAuditEvtData = new HashSet<JhiPersistentAuditEvtDatum>();
        }

        public long EventId { get; set; }
        public string Principal { get; set; } = null!;
        public DateTime? EventDate { get; set; }
        public string? EventType { get; set; }

        public virtual ICollection<JhiPersistentAuditEvtDatum> JhiPersistentAuditEvtData { get; set; }
    }
}
