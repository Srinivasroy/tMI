﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfirmationQuestionEmployeeMap
    {
        public long IntEmpMapId { get; set; }
        public long? ExitTemplateId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchDesignationList { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual ExitMasQuestionTemplate? ExitTemplate { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
