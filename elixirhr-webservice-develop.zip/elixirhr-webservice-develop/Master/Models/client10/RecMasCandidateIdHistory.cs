﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasCandidateIdHistory
    {
        public long Id { get; set; }
        public string? VchCandidateCode { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
