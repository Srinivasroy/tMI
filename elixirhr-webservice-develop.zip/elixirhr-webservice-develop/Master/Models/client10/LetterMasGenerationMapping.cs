﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class LetterMasGenerationMapping
    {
        public long IntLetterGenMapId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntLetterHtmlId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchStatus { get; set; }
        public string? VchFilePath { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual LetterMasHtmlTemplate? IntLetterHtml { get; set; }
    }
}
