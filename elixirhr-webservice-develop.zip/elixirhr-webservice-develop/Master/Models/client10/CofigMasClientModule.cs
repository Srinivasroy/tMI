﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class CofigMasClientModule
    {
        public CofigMasClientModule()
        {
            ClientUserMasters = new HashSet<ClientUserMaster>();
        }

        public long IntClientModuleGrpId { get; set; }
        /// <summary>
        /// Name of the role
        /// </summary>
        public string? VchRoleName { get; set; }
        /// <summary>
        /// Company Admin module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchCompanyAdmin { get; set; }
        public string? VchEmployeeMaster { get; set; }
        public string? VchDynamicEmployeeMaster { get; set; }
        public string? VchSalaryMaster { get; set; }
        /// <summary>
        /// Recuirement module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchRecuirement { get; set; }
        /// <summary>
        /// Onboarding module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchOnboarding { get; set; }
        /// <summary>
        /// Training module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchTraining { get; set; }
        /// <summary>
        /// Appraisal module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchAppraisal { get; set; }
        public string? VchAppraisalGoal { get; set; }
        /// <summary>
        /// Carrer module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchCareer { get; set; }
        /// <summary>
        /// Exit module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchExit { get; set; }
        public string? VchReports { get; set; }
        public string? VchLetterGeneration { get; set; }
        public string? VchInputToPayroll { get; set; }
        public string? VchDashboard { get; set; }
        public string? VchMobileApp { get; set; }
        public string? VchDocManagement { get; set; }
        public string? VchStorageMaster { get; set; }
        /// <summary>
        /// For Store All module Name
        /// </summary>
        public string? VchModuleNames { get; set; }
        /// <summary>
        /// admin id for created by
        /// </summary>
        public string? VchCreatedBy { get; set; }
        /// <summary>
        /// created time
        /// </summary>
        public DateTime? TsCreatedTime { get; set; }
        /// <summary>
        /// admin id for updated by
        /// </summary>
        public string? VchUpdatedBy { get; set; }
        /// <summary>
        /// updated time
        /// </summary>
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchDynamicEmployeeMasterConfig { get; set; }
        public string? VchEmpCodeFormula { get; set; }
        public long? IntIncrementBy { get; set; }
        public long? IntLastEmpNo { get; set; }
        public string? VchShow { get; set; }
        public string? VchEmpCodeAssigned { get; set; }
        public string? VchEss { get; set; }
        public string? VchConfirmationAssessment { get; set; }
        public string? VchCandidateManagement { get; set; }

        public virtual ICollection<ClientUserMaster> ClientUserMasters { get; set; }
    }
}
