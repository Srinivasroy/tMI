﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class BankNameMasterTmp
    {
        public long BankNameSeqId { get; set; }
        public string? VchBankName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchTransactionId { get; set; }
    }
}
