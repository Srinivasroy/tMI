﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasClientCreation
    {
        public ConfigMasClientCreation()
        {
            AuthMasClientAdminLoginDetails = new HashSet<AuthMasClientAdminLoginDetail>();
            ClientUserMasters = new HashSet<ClientUserMaster>();
            CompanyDetailMasters = new HashSet<CompanyDetailMaster>();
            ConfigMasClientAdmRights = new HashSet<ConfigMasClientAdmRight>();
            ConfigMasTmiAdmClientAssigns = new HashSet<ConfigMasTmiAdmClientAssign>();
            ConfigMasTmiClients = new HashSet<ConfigMasTmiClient>();
        }

        public long IntClientId { get; set; }
        public string? VchClientCode { get; set; }
        public string? VchClientName { get; set; }
        public string? VchPassword { get; set; }
        public string? VchEmailid { get; set; }
        public string? VchMobileno { get; set; }
        public long? IntCompanyCount { get; set; }
        public sbyte? IntCreatedCompanies { get; set; }
        public string? VchActive { get; set; }
        public string? VchModuleAssign { get; set; }
        public string? VchModuleAssignedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchRoleName { get; set; }
        public string? VchSchemaAllowed { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchReports { get; set; }
        public string? VchLetterGeneration { get; set; }
        public string? VchModuleNames { get; set; }
        public string? VchSchemaActive { get; set; }
        public string? VchDbKey { get; set; }
        public string? VchSchemaName { get; set; }
        public string? VchSenderEmail { get; set; }
        public string? VchSenderEmailPword { get; set; }
        public string? VchPwdConfig { get; set; }
        public int? IntPwdDuration { get; set; }
        public string? VchEnableTwoFactor { get; set; }
        public string? VchEnableEmail { get; set; }
        public string? VchEnableSms { get; set; }
        public string? VchEnableClientAdmin { get; set; }
        public string? VchEnableClientUser { get; set; }
        public string? VchEnableClientEmployee { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchConfAssSettings { get; set; }
        public int? IntConfEmailAlertBeforeDay { get; set; }
        public int? IntConfInitialDueMonths { get; set; }
        public int? IntConfExtendedTimes { get; set; }
        public int? IntConfTotalProbationMonths { get; set; }
        public string? VchDisplayName { get; set; }
        public string? VchMailPassword { get; set; }

        public virtual ICollection<AuthMasClientAdminLoginDetail> AuthMasClientAdminLoginDetails { get; set; }
        public virtual ICollection<ClientUserMaster> ClientUserMasters { get; set; }
        public virtual ICollection<CompanyDetailMaster> CompanyDetailMasters { get; set; }
        public virtual ICollection<ConfigMasClientAdmRight> ConfigMasClientAdmRights { get; set; }
        public virtual ICollection<ConfigMasTmiAdmClientAssign> ConfigMasTmiAdmClientAssigns { get; set; }
        public virtual ICollection<ConfigMasTmiClient> ConfigMasTmiClients { get; set; }
    }
}
