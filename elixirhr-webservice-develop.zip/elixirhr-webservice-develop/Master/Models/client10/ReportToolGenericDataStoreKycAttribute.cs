﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreKycAttribute
    {
        public long IntKycId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? EmployeeCode { get; set; }
        public string? EmployeeName { get; set; }
        public string? BankName { get; set; }
        public string? AccountNumber { get; set; }
        public string? Branch { get; set; }
        public string? IfscCode { get; set; }
        public string? PanNumber { get; set; }
        public string? AadhaarNumber { get; set; }
        public string? PassportNumber { get; set; }
        public string? UanNumber { get; set; }
        public string? DlNumber { get; set; }
        public string? PfNumber { get; set; }
        public string? EsiNumber { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
    }
}
