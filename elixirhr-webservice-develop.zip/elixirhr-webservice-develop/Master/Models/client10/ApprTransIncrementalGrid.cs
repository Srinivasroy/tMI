﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprTransIncrementalGrid
    {
        public long IntGridId { get; set; }
        /// <summary>
        /// REFERENCE FROM EMPLOYEE GROUP TABLE
        /// </summary>
        public long? IntEmpgroupId { get; set; }
        public short? IntMultiplierValue { get; set; }
        public decimal? DouMultiplier1 { get; set; }
        public decimal? DouMultiplier2 { get; set; }
        public decimal? DouMultiplier3 { get; set; }
        public decimal? DouMultiplier4 { get; set; }
        public decimal? DouMultiplier5 { get; set; }
        public decimal? DouMultiplier6 { get; set; }
        public decimal? DouMultiplier7 { get; set; }
        public decimal? DouMultiplier8 { get; set; }
        public decimal? DouMultiplier9 { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasEmpGrouping? IntEmpgroup { get; set; }
    }
}
