﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreTraining
    {
        public long IntTrainReptId { get; set; }
        public string? TrainingRequestedEmployeeId { get; set; }
        public DateOnly? TrainingRequestedDate { get; set; }
        public string? TrainingRequestedEmployeeRmId { get; set; }
        public string? TrainingRequestedEmployeeLocation { get; set; }
        public string? TrainingRequestedEmployeeDepartment { get; set; }
        public string? TrainingRequestedEmployeeDesignation { get; set; }
        public string? TrainingAttended { get; set; }
        public string? TrainingInitiatedBy { get; set; }
        public string? TrainingAttendedEmployeeTrainingCode { get; set; }
        public string? TrainingCategoryName { get; set; }
        public string? TrainingType { get; set; }
        public string? TrainingVendorName { get; set; }
        public string? TrainingVendorMobile { get; set; }
        public string? TrainingVendorEmail { get; set; }
        public string? TrainingVendorAddress { get; set; }
        public string? TrainingLocation { get; set; }
        public string? TrainingDepartment { get; set; }
        public string? TrainingVenue { get; set; }
        public DateOnly? TrainingFromDate { get; set; }
        public DateOnly? TrainingToDate { get; set; }
        public string? TrainingStatus { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
