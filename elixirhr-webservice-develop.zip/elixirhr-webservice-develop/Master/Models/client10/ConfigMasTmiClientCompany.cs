﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasTmiClientCompany
    {
        public long IntTmiClientCompId { get; set; }
        public long? IntTmiClientId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchActive { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public long? IntTmiUserId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ConfigMasTmiClient? IntTmiClient { get; set; }
        public virtual CompanyDetailMaster? IntTmiUser { get; set; }
    }
}
