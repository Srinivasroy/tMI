﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfigMasTmiUserCreation
    {
        public ConfigMasTmiUserCreation()
        {
            AuthMasTmiUserLoginDetails = new HashSet<AuthMasTmiUserLoginDetail>();
            ConfigMasTmiClients = new HashSet<ConfigMasTmiClient>();
            ConfigMasTmiUserRights = new HashSet<ConfigMasTmiUserRight>();
        }

        public long IntTmiUserId { get; set; }
        public string? VchTmiUserEmpCode { get; set; }
        public string? VchTmiUserName { get; set; }
        public string? VchTmiUserCode { get; set; }
        public string? VchTmiUserPword { get; set; }
        public string? VchTmiEmailid { get; set; }
        public string? VchTmiPhoneno { get; set; }
        public string? VchActive { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchCompanies { get; set; }
        public string? VchCompanyAssign { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchPwdChangeReq { get; set; }
        public string? VchPwdResetKey { get; set; }
        public string? VchOldPwd1 { get; set; }
        public string? VchOldPwd2 { get; set; }
        public DateTime? TsPwdChangeDate { get; set; }
        public string? VchPwdExpired { get; set; }

        public virtual ICollection<AuthMasTmiUserLoginDetail> AuthMasTmiUserLoginDetails { get; set; }
        public virtual ICollection<ConfigMasTmiClient> ConfigMasTmiClients { get; set; }
        public virtual ICollection<ConfigMasTmiUserRight> ConfigMasTmiUserRights { get; set; }
    }
}
