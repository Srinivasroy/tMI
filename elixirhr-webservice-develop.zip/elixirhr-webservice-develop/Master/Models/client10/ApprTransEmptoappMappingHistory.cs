﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprTransEmptoappMappingHistory
    {
        public ApprTransEmptoappMappingHistory()
        {
            ApprTransCompetencyRatingHistories = new HashSet<ApprTransCompetencyRatingHistory>();
            ApprTransGolesRatingHistories = new HashSet<ApprTransGolesRatingHistory>();
        }

        public long IntApprMasEmpappMapHisSeqid { get; set; }
        public long? IntReviewSeqid { get; set; }
        public long? IntSelfemployeeSeqId { get; set; }
        public long? IntPeeremployee1SeqId { get; set; }
        public long? IntPeeremployee2SeqId { get; set; }
        public long? IntPeeremployee3SeqId { get; set; }
        public long? IntSubordiemployee1SeqId { get; set; }
        public long? IntSubordiemployee2SeqId { get; set; }
        public long? IntSubordiemployee3SeqId { get; set; }
        public long? IntSuperioremployee1SeqId { get; set; }
        public long? IntSuperioremployee2SeqId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchReviewStatus { get; set; }
        public string? VchP1Status { get; set; }
        public string? VchP2Status { get; set; }
        public string? VchP3Status { get; set; }
        public string? VchSo1Status { get; set; }
        public string? VchSo2Status { get; set; }
        public string? VchSo3Status { get; set; }
        public decimal? DouP1AvgScore { get; set; }
        public decimal? DouP2AvgScore { get; set; }
        public decimal? DouP3AvgScore { get; set; }
        public decimal? DouSo1AvgScore { get; set; }
        public decimal? DouSo2AvgScore { get; set; }
        public decimal? DouSo3AvgScore { get; set; }
        public decimal? DouSup1AvgScore { get; set; }
        public decimal? DouSup2AvgScore { get; set; }
        public decimal? DouSelfAvgScore { get; set; }
        public string? VchSelfComments { get; set; }
        public long? IntEmpgroupId { get; set; }
        public decimal? DouFinalAvgScore { get; set; }
        public string? VchSkipComments { get; set; }
        public string? VchFinalStatus { get; set; }
        public string? VchUploadFlag { get; set; }
        public long? IntTRequestId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public decimal? DouGoalSelfScore { get; set; }
        public decimal? DouGoalSupScore { get; set; }
        public decimal? DouGoalPeer1Score { get; set; }
        public decimal? DouGoalPeer2Score { get; set; }
        public decimal? DouGoalPeer3Score { get; set; }
        public decimal? DouGoalSo1Score { get; set; }
        public decimal? DouGoalSo2Score { get; set; }
        public decimal? DouGoalSo3Score { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasEmpGrouping? IntEmpgroup { get; set; }
        public virtual EmployeeMaster? IntPeeremployee1Seq { get; set; }
        public virtual EmployeeMaster? IntPeeremployee2Seq { get; set; }
        public virtual EmployeeMaster? IntPeeremployee3Seq { get; set; }
        public virtual ApprMasReviewperiodConfig? IntReviewSeq { get; set; }
        public virtual EmployeeMaster? IntSelfemployeeSeq { get; set; }
        public virtual EmployeeMaster? IntSubordiemployee1Seq { get; set; }
        public virtual EmployeeMaster? IntSubordiemployee2Seq { get; set; }
        public virtual EmployeeMaster? IntSubordiemployee3Seq { get; set; }
        public virtual EmployeeMaster? IntSuperioremployee1Seq { get; set; }
        public virtual EmployeeMaster? IntSuperioremployee2Seq { get; set; }
        public virtual TrainTransRequest? IntTRequest { get; set; }
        public virtual ICollection<ApprTransCompetencyRatingHistory> ApprTransCompetencyRatingHistories { get; set; }
        public virtual ICollection<ApprTransGolesRatingHistory> ApprTransGolesRatingHistories { get; set; }
    }
}
