﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasRatingOrder
    {
        public ApprMasRatingOrder()
        {
            ApprMasRatingParaMappings = new HashSet<ApprMasRatingParaMapping>();
        }

        /// <summary>
        /// PRIMARY KEY OF TABLE
        /// </summary>
        public long IntRatingOrderId { get; set; }
        /// <summary>
        /// REFERENCE FROM EMPLOYEE GROUP TABLE
        /// </summary>
        public long? IntEmpgroupId { get; set; }
        /// <summary>
        /// A-ASCENDING,D-DESCENDING
        /// </summary>
        public string? VchOrder { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ApprMasEmpGrouping? IntEmpgroup { get; set; }
        public virtual ICollection<ApprMasRatingParaMapping> ApprMasRatingParaMappings { get; set; }
    }
}
