﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuditEmpCategoryChange
    {
        public long IntCategoryChId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntOldCategSeqId { get; set; }
        public long? IntNewCategSeqId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }
        public DateOnly? DtFromDate { get; set; }
        public DateOnly? DtToDate { get; set; }
        public string? VchStatus { get; set; }
        public string? VchActiveStatus { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateOnly? DtCreatedDate { get; set; }
        public string? VchOperation { get; set; }

        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual EmployeeCategoryMaster? IntNewCategSeq { get; set; }
        public virtual EmployeeCategoryMaster? IntOldCategSeq { get; set; }
    }
}
