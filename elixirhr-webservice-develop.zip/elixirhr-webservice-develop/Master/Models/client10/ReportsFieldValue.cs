﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsFieldValue
    {
        public long IntReportsFieldValue { get; set; }
        public string? VchFieldName { get; set; }
        public string? VchOperation { get; set; }
        public string? VchValue { get; set; }
        public long? IntReportsQueryId { get; set; }

        public virtual ReportsQuery? IntReportsQuery { get; set; }
    }
}
