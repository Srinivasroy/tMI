﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsToolConditionValue
    {
        public long ReportsToolCondId { get; set; }
        public string? VchFieldName { get; set; }
        public string? VchOperator { get; set; }
        public string? VchOperation { get; set; }
        public string? VchValue { get; set; }
        public long? IntReportsToolQuerySeqid { get; set; }

        public virtual ReportsToolQuery? IntReportsToolQuerySeq { get; set; }
    }
}
