﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuditEmpLocationChange
    {
        public long IntLocationChId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntOldLocSeqId { get; set; }
        public long? IntNewLocSeqId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }
        public DateOnly? DtFromDate { get; set; }
        public DateOnly? DtToDate { get; set; }
        public string? VchStatus { get; set; }
        public string? VchActiveStatus { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateOnly? DtCreatedDate { get; set; }
        public string? VchOperation { get; set; }
        public string? VchTransactionId { get; set; }

        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual LocationMaster? IntNewLocSeq { get; set; }
        public virtual LocationMaster? IntOldLocSeq { get; set; }
    }
}
