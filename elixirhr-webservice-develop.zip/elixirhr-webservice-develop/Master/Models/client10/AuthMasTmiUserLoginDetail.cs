﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AuthMasTmiUserLoginDetail
    {
        public long IntTmiuLoginId { get; set; }
        public long? IntTmiUserId { get; set; }
        public long? IntLoginSuccessCount { get; set; }
        public long? IntLoginFailedCount { get; set; }
        public DateTime? TsLastLoginTime { get; set; }
        public DateTime? TsLastFailLoginTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual ConfigMasTmiUserCreation? IntTmiUser { get; set; }
    }
}
