﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class Dual
    {
        public string? Dummy { get; set; }
    }
}
