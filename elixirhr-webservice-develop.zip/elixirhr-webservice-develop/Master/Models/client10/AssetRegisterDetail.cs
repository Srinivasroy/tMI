﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class AssetRegisterDetail
    {
        public int IntAttributesDetailId { get; set; }
        public long? IntCompanyId { get; set; }
        public int? IntAssetId { get; set; }
        public int? IntAttributeId { get; set; }
    }
}
