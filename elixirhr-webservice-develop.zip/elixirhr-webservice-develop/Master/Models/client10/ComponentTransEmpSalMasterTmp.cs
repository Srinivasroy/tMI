﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentTransEmpSalMasterTmp
    {
        public long IntCompSalMasId { get; set; }
        /// <summary>
        /// Reference from component_mas_creation
        /// </summary>
        public long? IntCompSeqId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public string? VchComponentName { get; set; }
        public long? IntNumValue { get; set; }
        public string? VchStrValue { get; set; }
        public DateOnly? DtDateValue { get; set; }
        public string? VchValueAssiged { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public byte[]? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public long? IntCompanySeqId { get; set; }
        public int? IntProcessSeqNo { get; set; }
        public string? VchEmpCode { get; set; }
        public long? IntRowIndex { get; set; }
        public string? VchTransactionId { get; set; }
        public string? VchCompShortName { get; set; }
        public DateOnly? DtEffectiveDate { get; set; }
        public string? VchShowView { get; set; }
        public string? VchShowPayslip { get; set; }
    }
}
