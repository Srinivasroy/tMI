﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreEmpSignupAttribute
    {
        public long IntEmpSignupId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? EmployeeCode { get; set; }
        public string? EmployeeName { get; set; }
        public string? RcsGrade { get; set; }
        public string? Designation { get; set; }
        public DateOnly? DateOfJoining { get; set; }
        public string? SignupRequest { get; set; }
        public string? EmployeeMail { get; set; }
        public DateTime? ReportDate { get; set; }
        public DateOnly? ModifiedDate { get; set; }
    }
}
