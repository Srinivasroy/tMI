﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasNewcanEmpdet
    {
        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntNewCanEmpdetSeqId { get; set; }
        /// <summary>
        /// Reference from rec_mas_new_candidate
        /// </summary>
        public long? IntNewCandidateSeqId { get; set; }
        public string? VchCompanyName { get; set; }
        public string? VchDesignationName { get; set; }
        public DateTime? TsEmpFromdate { get; set; }
        public DateTime? TsEmpTodate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual RecMasNewCandidate? IntNewCandidateSeq { get; set; }
    }
}
