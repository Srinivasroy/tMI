﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComAdmEmpDocument
    {
        public long IntEmpDocId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public int? IntDocId { get; set; }
        public bool? FlagOnbDoc { get; set; }
        public string? VchDocumentName { get; set; }
        public string? OldVchDocumentName { get; set; }
        public string? VchDocumentPath { get; set; }
        public string? VchDocumentFinalPath { get; set; }
        public byte[]? BlobDocument { get; set; }
        public string? VchExtension { get; set; }
        public string? OldVchExtension { get; set; }
        public string? VchActive { get; set; }
        public string? OldStatus { get; set; }
        public bool? MandatoryDoc { get; set; }
        public string? VchComments { get; set; }
        public string? OldVchComments { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }

        public virtual DocumentMaster? IntDoc { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
