﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class DesignationMaster
    {
        public DesignationMaster()
        {
            AuditEmpDesignationChangeIntNewDesigSeqs = new HashSet<AuditEmpDesignationChange>();
            AuditEmpDesignationChangeIntOldDesigSeqs = new HashSet<AuditEmpDesignationChange>();
            AuditOrgKycInfoIntNewDesigValueNavigations = new HashSet<AuditOrgKycInfo>();
            AuditOrgKycInfoIntOldDesigValueNavigations = new HashSet<AuditOrgKycInfo>();
            EmployeeMakerCheckerIntNewDesValueNavigations = new HashSet<EmployeeMakerChecker>();
            EmployeeMakerCheckerIntOldDesValueNavigations = new HashSet<EmployeeMakerChecker>();
            EmployeeMasters = new HashSet<EmployeeMaster>();
            HashOnboardingInitiations = new HashSet<HashOnboardingInitiation>();
            OnboardingInitiations = new HashSet<OnboardingInitiation>();
            RecMasManpowerPlanJobids = new HashSet<RecMasManpowerPlanJobid>();
            RecMasManpowerPlans = new HashSet<RecMasManpowerPlan>();
        }

        public long DesignationSeqId { get; set; }
        public string? DesName { get; set; }
        public long? DeptSeqId { get; set; }
        public string? VchDescription { get; set; }
        public string? VchActive { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchUpdatedBy { get; set; }
        public string? VchDeptShortName { get; set; }
        public string? VchDesShortName { get; set; }
        public long? IntCompanyId { get; set; }
        public string? VchCriteriaAssign { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateOnly? DtFromDate { get; set; }
        public DateOnly? DtToDate { get; set; }
        public string? DepartmentName { get; set; }
        public string? LocationName { get; set; }
        public string? VchTransactionId { get; set; }
        public string? VchModified { get; set; }
        public long? IntRcsgradeId { get; set; }
        public string? RcsgradeName { get; set; }
        public string? VchDesignationMapped { get; set; }

        public virtual RcsgradeMaster? IntRcsgrade { get; set; }
        public virtual ICollection<AuditEmpDesignationChange> AuditEmpDesignationChangeIntNewDesigSeqs { get; set; }
        public virtual ICollection<AuditEmpDesignationChange> AuditEmpDesignationChangeIntOldDesigSeqs { get; set; }
        public virtual ICollection<AuditOrgKycInfo> AuditOrgKycInfoIntNewDesigValueNavigations { get; set; }
        public virtual ICollection<AuditOrgKycInfo> AuditOrgKycInfoIntOldDesigValueNavigations { get; set; }
        public virtual ICollection<EmployeeMakerChecker> EmployeeMakerCheckerIntNewDesValueNavigations { get; set; }
        public virtual ICollection<EmployeeMakerChecker> EmployeeMakerCheckerIntOldDesValueNavigations { get; set; }
        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
        public virtual ICollection<HashOnboardingInitiation> HashOnboardingInitiations { get; set; }
        public virtual ICollection<OnboardingInitiation> OnboardingInitiations { get; set; }
        public virtual ICollection<RecMasManpowerPlanJobid> RecMasManpowerPlanJobids { get; set; }
        public virtual ICollection<RecMasManpowerPlan> RecMasManpowerPlans { get; set; }
    }
}
