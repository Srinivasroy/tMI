﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecTransScheduleInterCandidate
    {
        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntTScIntCandId { get; set; }
        /// <summary>
        /// Reference from rec_mas_new_candidate
        /// </summary>
        public long? IntNewCandidateSeqId { get; set; }
        /// <summary>
        /// Reference from rec_trans_schedule_interview
        /// </summary>
        public long? RecTransScheduleInterview { get; set; }
        /// <summary>
        /// Reference from employee_master
        /// </summary>
        public long? IntEmployeeSeqId { get; set; }
        public bool? IntInterRoundNum { get; set; }
        public string? VchStatus { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
        public virtual RecMasNewCandidate? IntNewCandidateSeq { get; set; }
        public virtual RecTransScheduleInterview? RecTransScheduleInterviewNavigation { get; set; }
    }
}
