﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ConfirmationAssessmentRequest
    {
        public ConfirmationAssessmentRequest()
        {
            ConfirmationAssessmentAns = new HashSet<ConfirmationAssessmentAn>();
            ConfirmationAssessmentQuestions = new HashSet<ConfirmationAssessmentQuestion>();
        }

        public long IntConfirmReqId { get; set; }
        /// <summary>
        /// reference from employee master(employee_master)
        /// </summary>
        public long? IntEmpId { get; set; }
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// RMP,RMR,HRP,HRR,HRA
        /// </summary>
        public string? VchStatus { get; set; }
        public string? VchApproverAction { get; set; }
        public string? VchRmReason { get; set; }
        public string? VchHrReason { get; set; }
        /// <summary>
        /// for rm comments
        /// </summary>
        public string? VchRmComments { get; set; }
        /// <summary>
        /// for hr comments
        /// </summary>
        public string? VchHrComments { get; set; }
        public DateOnly? DtExtendFromDate { get; set; }
        public DateOnly? DtExtendToDate { get; set; }
        public DateOnly? DtLetterGenDate { get; set; }
        public string? VchLetterGenPath { get; set; }
        public string? VchApproveRmCode { get; set; }
        public string? VchApproveHrCode { get; set; }
        public string? VchApproveRmName { get; set; }
        public string? VchApproveHrName { get; set; }
        public string? VchDocumentPath { get; set; }
        public string? VchAnswered { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmp { get; set; }
        public virtual ICollection<ConfirmationAssessmentAn> ConfirmationAssessmentAns { get; set; }
        public virtual ICollection<ConfirmationAssessmentQuestion> ConfirmationAssessmentQuestions { get; set; }
    }
}
