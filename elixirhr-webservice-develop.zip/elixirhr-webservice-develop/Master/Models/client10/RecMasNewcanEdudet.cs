﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecMasNewcanEdudet
    {
        /// <summary>
        /// Primary key of table
        /// </summary>
        public long IntNewCanEmpdetSeqId { get; set; }
        /// <summary>
        /// Reference from rec_mas_new_candidate
        /// </summary>
        public long? IntNewCandidateSeqId { get; set; }
        /// <summary>
        /// Reference from qualification_master
        /// </summary>
        public long? IntQualificationId { get; set; }
        public string? VchGrade { get; set; }
        public decimal? IntYearOfPassing { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedDate { get; set; }
        public DateTime? TsCreatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual RecMasNewCandidate? IntNewCandidateSeq { get; set; }
        public virtual QualificationMaster? IntQualification { get; set; }
    }
}
