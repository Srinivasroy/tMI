﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComMClientAdminRole
    {
        /// <summary>
        /// Primary key of a table
        /// </summary>
        public long IntClientAdminRoleId { get; set; }
        /// <summary>
        /// Name of the role
        /// </summary>
        public string? VchRoleName { get; set; }
        /// <summary>
        /// Company Admin module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchCompanyAdmin { get; set; }
        /// <summary>
        /// Recuirement module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchRecuirement { get; set; }
        /// <summary>
        /// Onboarding module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchOnboarding { get; set; }
        /// <summary>
        /// Training module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchTraining { get; set; }
        /// <summary>
        /// Appraisal module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchAppraisal { get; set; }
        /// <summary>
        /// Carrer module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchCareer { get; set; }
        /// <summary>
        /// Exit module for this role.(Y/N).If &apos;Y&apos; then active. If  &apos;N&apos; then Inactive.
        /// </summary>
        public string? VchExit { get; set; }
        /// <summary>
        /// admin id for created by
        /// </summary>
        public string? VchCreatedBy { get; set; }
        /// <summary>
        /// created time
        /// </summary>
        public DateTime? TsCreatedTime { get; set; }
        /// <summary>
        /// admin id for updated by
        /// </summary>
        public string? VchUpdatedBy { get; set; }
        /// <summary>
        /// updated time
        /// </summary>
        public DateTime? TsUpdatedTime { get; set; }
    }
}
