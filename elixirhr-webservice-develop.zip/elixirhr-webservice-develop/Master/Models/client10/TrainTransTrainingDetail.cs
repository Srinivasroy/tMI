﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class TrainTransTrainingDetail
    {
        /// <summary>
        /// Primary key of a table 
        /// </summary>
        public long IntTTrainingDetailsId { get; set; }
        /// <summary>
        /// Reference from Hr initiation table(train_trans_hr_initiation)
        /// </summary>
        public long? IntInitiationId { get; set; }
        /// <summary>
        /// Training name or project name workshop name
        /// </summary>
        public string? VchDetail { get; set; }
        /// <summary>
        /// Reference from location master(location_master)
        /// </summary>
        public long? IntLocationId { get; set; }
        /// <summary>
        /// Reference from department master(department_master)
        /// </summary>
        public long? IntDepartmentId { get; set; }
        public string? VchVenueDetails { get; set; }
        public DateTime? TsTimeFrom { get; set; }
        public DateTime? TsTimeTo { get; set; }
        public string? VchDuration { get; set; }
        public DateTime? DtDateFrom { get; set; }
        public DateTime? DtDateTo { get; set; }
        public string? VchTrainingDesc { get; set; }
        public string? VchComponent1 { get; set; }
        public string? VchComponent2 { get; set; }
        public string? VchComponent3 { get; set; }
        public string? VchComponent4 { get; set; }
        public string? VchComponent5 { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? DtCreatedDate { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual DepartmentMaster? IntDepartment { get; set; }
        public virtual TrainTransHrInitiation? IntInitiation { get; set; }
        public virtual LocationMaster? IntLocation { get; set; }
    }
}
