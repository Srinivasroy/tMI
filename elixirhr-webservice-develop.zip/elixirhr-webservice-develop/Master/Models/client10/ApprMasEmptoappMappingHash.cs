﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ApprMasEmptoappMappingHash
    {
        public long IntApprEmpappMapSeqidHash { get; set; }
        public long? IntCategoryId { get; set; }
        public long? IntTypeId { get; set; }
        public string? VchTrainComments { get; set; }
        public string? VchSelfComments { get; set; }
        public string? VchSkipComments { get; set; }
        public string? VchSelfStatus { get; set; }
        public string? VchSupStatus { get; set; }
        public string? VchSkipStatus { get; set; }
        public long? IntApprMasEmpappMapSeqid { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdateDate { get; set; }
        public string? VchP1Status { get; set; }
        public string? VchP2Status { get; set; }
        public string? VchP3Status { get; set; }
        public string? VchSo1Status { get; set; }
        public string? VchSo2Status { get; set; }
        public string? VchSo3Status { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual ApprTransEmptoappMapping? IntApprMasEmpappMapSeq { get; set; }
        public virtual TrainMasCategory? IntCategory { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual TrainMasType? IntType { get; set; }
    }
}
