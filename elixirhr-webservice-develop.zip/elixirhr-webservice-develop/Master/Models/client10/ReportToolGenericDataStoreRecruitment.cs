﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreRecruitment
    {
        public long IntRecReptId { get; set; }
        public string? JobRequestId { get; set; }
        public DateOnly? JobRequestCreatedDate { get; set; }
        public string? JobRequestStatus { get; set; }
        public string? ReferredRequest { get; set; }
        public string? PublishedRequest { get; set; }
        public string? Location { get; set; }
        public string? Department { get; set; }
        public string? Designation { get; set; }
        public string? Domain { get; set; }
        public string? Skill { get; set; }
        public string? HighImportance { get; set; }
        public DateOnly? RequestClosedDate { get; set; }
        public string? CandidateId { get; set; }
        public string? CandidateName { get; set; }
        public DateOnly? CandidateDob { get; set; }
        public string? CandidateGender { get; set; }
        public string? CandidateMailId { get; set; }
        public string? CandidatePhoneNumber { get; set; }
        public long? CandidateExperience { get; set; }
        public string? CandidatePreviousEmployerName { get; set; }
        public string? ProfileSource { get; set; }
        public string? VendorName { get; set; }
        public string? InternalReferralByName { get; set; }
        public DateOnly? InterviewDate { get; set; }
        public string? InterviewVenue { get; set; }
        public string? InterviewerEmployeeId { get; set; }
        public string? InterviewerName { get; set; }
        public DateOnly? OfferLetterGenerationDate { get; set; }
        public DateOnly? ExpectedDoj { get; set; }
        public string? CtcOffered { get; set; }
        public long? OpenRequest { get; set; }
        public long? ClosedRequest { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
