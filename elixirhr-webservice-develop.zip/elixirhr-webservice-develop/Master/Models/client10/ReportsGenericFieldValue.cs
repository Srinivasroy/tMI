﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportsGenericFieldValue
    {
        public long IntReportsFieldValue { get; set; }
        public string? VchFieldName { get; set; }
        public string? VchValue { get; set; }
        public long? IntReportsQueryId { get; set; }
        public string? VchOperation { get; set; }

        public virtual ReportsGenericQuery? IntReportsQuery { get; set; }
    }
}
