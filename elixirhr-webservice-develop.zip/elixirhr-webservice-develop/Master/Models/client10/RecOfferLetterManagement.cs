﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class RecOfferLetterManagement
    {
        /// <summary>
        /// Primary key of  table
        /// </summary>
        public long IntRecOfferManageId { get; set; }
        /// <summary>
        /// Reference from RecCreateNewCandidate
        /// </summary>
        public long? IntCandidateSeqId { get; set; }
        /// <summary>
        /// Reference from company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public long? IntCtcAmount { get; set; }
        public byte[]? BlobOfferLetter { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchComments { get; set; }
        public string? VchOfferLetterPath { get; set; }
        public DateOnly? DtExpectedDoj { get; set; }
        public DateOnly? DtOfferValidity { get; set; }

        public virtual RecMasAddCandidate? IntCandidateSeq { get; set; }
        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
