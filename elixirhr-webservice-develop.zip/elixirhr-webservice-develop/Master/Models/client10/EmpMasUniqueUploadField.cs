﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmpMasUniqueUploadField
    {
        public long IntAttributeId { get; set; }
        public string? VchAttributeName { get; set; }
        public string? VchDataType { get; set; }
        public string? VchAttributeValue { get; set; }
        public string? VchQuery { get; set; }
        public string? VarKycPfNo { get; set; }
    }
}
