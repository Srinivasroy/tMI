﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class VendorMaster
    {
        public VendorMaster()
        {
            RecMasAddCandidates = new HashSet<RecMasAddCandidate>();
            RecMasNewCandidates = new HashSet<RecMasNewCandidate>();
        }

        public long VendorSeqId { get; set; }
        public string? VendorName { get; set; }
        public long? VendorCategoryId { get; set; }
        public string? VendorCode { get; set; }
        public string? VendorAddress { get; set; }
        public string? EmailId { get; set; }
        public string? Name1 { get; set; }
        public string? Name2 { get; set; }
        public string? Phone1 { get; set; }
        public string? Phone2 { get; set; }
        public string? EmailId1 { get; set; }
        public string? EmailId2 { get; set; }
        public string? Preferred { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }

        public virtual ICollection<RecMasAddCandidate> RecMasAddCandidates { get; set; }
        public virtual ICollection<RecMasNewCandidate> RecMasNewCandidates { get; set; }
    }
}
