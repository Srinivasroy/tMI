﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreAppraisal
    {
        public long IntApprReptId { get; set; }
        public string? EmployeeId { get; set; }
        public string? EmployeeName { get; set; }
        public string? RmEmployeeId { get; set; }
        public string? RmName { get; set; }
        public string? KraGroupName { get; set; }
        public string? LocationName { get; set; }
        public string? DepartmentName { get; set; }
        public string? DesignationName { get; set; }
        public string? ReviewCycleDescription { get; set; }
        public DateOnly? ReviewStartDate { get; set; }
        public string? ReviewType { get; set; }
        public DateOnly? PerformancePeriodStartDate { get; set; }
        public DateOnly? PerformancePeriodEndDate { get; set; }
        public string? ReviewPeriodStatus { get; set; }
        public DateOnly? ReviewPeriodRoleChangeDate { get; set; }
        public string? CompetencySelfAvgScore { get; set; }
        public string? CompetencyPeer1AvgScore { get; set; }
        public string? CompetencyPeer2AvgScore { get; set; }
        public string? CompetencyPeer3AvgScore { get; set; }
        public string? CompetencySubordinate1AvgScore { get; set; }
        public string? CompetencySubordinate2AvgScore { get; set; }
        public string? CompetencySubordinate3AvgScore { get; set; }
        public string? CompetencySuperiorAvgScore { get; set; }
        public string? CompetencySkipSuperiorAvgScore { get; set; }
        public string? GoalSelfAvgScore { get; set; }
        public string? GoalPeer1AvgScore { get; set; }
        public string? GoalPeer2AvgScore { get; set; }
        public string? GoalPeer3AvgScore { get; set; }
        public string? GoalSubordinate1AvgScore { get; set; }
        public string? GoalSubordinate2AvgScore { get; set; }
        public string? GoalSubordinate3AvgScore { get; set; }
        public string? GoalSuperiorAvgScore { get; set; }
        public string? AppraisalStatus { get; set; }
        public string? LetterGenerationStatus { get; set; }
        public string? IncrementPercentage { get; set; }
        public string? IncrementAmount { get; set; }
        public string? OriginalCtc { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public long? IntEmployeeId { get; set; }
        public long? IntReviewSeqid { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public long? IntCompanyId { get; set; }
    }
}
