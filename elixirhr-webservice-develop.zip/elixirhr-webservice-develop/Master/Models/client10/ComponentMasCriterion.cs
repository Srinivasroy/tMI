﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasCriterion
    {
        public ComponentMasCriterion()
        {
            ComponentMasCriteriaDesigAssigns = new HashSet<ComponentMasCriteriaDesigAssign>();
            ComponentMasCriteriaPatternAssigns = new HashSet<ComponentMasCriteriaPatternAssign>();
            ComponentTransCriteriaComponentAssigns = new HashSet<ComponentTransCriteriaComponentAssign>();
        }

        public long IntCompCreteriaSeqId { get; set; }
        /// <summary>
        /// REFERENCE FROM company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        public string? VchCriteriaName { get; set; }
        public string? VchComponentAssign { get; set; }
        public string? VchComponentValueAssign { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? VchUpdatedTime { get; set; }
        public string? VchComponentNames { get; set; }
        public string? VchAttributeValues { get; set; }
        public string? VchProcessed { get; set; }
        public string? VchCreationType { get; set; }
        public string? VchAttributeName { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual ICollection<ComponentMasCriteriaDesigAssign> ComponentMasCriteriaDesigAssigns { get; set; }
        public virtual ICollection<ComponentMasCriteriaPatternAssign> ComponentMasCriteriaPatternAssigns { get; set; }
        public virtual ICollection<ComponentTransCriteriaComponentAssign> ComponentTransCriteriaComponentAssigns { get; set; }
    }
}
