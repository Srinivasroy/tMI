﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    /// <summary>
    /// Using for generating client admin number
    /// </summary>
    public partial class RoleMClientAdminNoHistory
    {
        public string? VarLastAdminId { get; set; }
        public string? VchSchemaKey { get; set; }
    }
}
