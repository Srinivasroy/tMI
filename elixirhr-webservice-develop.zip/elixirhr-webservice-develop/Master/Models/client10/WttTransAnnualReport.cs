﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class WttTransAnnualReport
    {
        public WttTransAnnualReport()
        {
            WttMakerCheckers = new HashSet<WttMakerChecker>();
            WttTransAnnualReportDetails = new HashSet<WttTransAnnualReportDetail>();
        }

        /// <summary>
        /// primary key of a table
        /// </summary>
        public long IntWttAnnSeqId { get; set; }
        /// <summary>
        /// Reference From wtt_m_company_type
        /// </summary>
        public long? IntWttComTypeId { get; set; }
        public string? VchReportType { get; set; }
        /// <summary>
        /// Name Of month
        /// </summary>
        public string? VchMonth { get; set; }
        /// <summary>
        /// Name of Year
        /// </summary>
        public short? IntYear { get; set; }
        /// <summary>
        /// Starting Date of given month
        /// </summary>
        public DateTime? DtFromDate { get; set; }
        /// <summary>
        /// Ending Date of given month
        /// </summary>
        public DateTime? DtToDate { get; set; }
        /// <summary>
        /// Y-Enable,N-Disable
        /// </summary>
        public string? VchEnable { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchStatus { get; set; }
        public string? VchDownloadStatus { get; set; }
        public string? VchDownloadPath { get; set; }
        public int? IntReportNo { get; set; }

        public virtual WttMCompanyType? IntWttComType { get; set; }
        public virtual ICollection<WttMakerChecker> WttMakerCheckers { get; set; }
        public virtual ICollection<WttTransAnnualReportDetail> WttTransAnnualReportDetails { get; set; }
    }
}
