﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    /// <summary>
    /// For Employee Login
    /// </summary>
    public partial class ComMEmployeeLoginLog
    {
        public long IntLogId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public DateTime? TsLastLoginTime { get; set; }
        public string? VchOpen { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public long? IntCompanyId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
