﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeCategoryMasterTmp
    {
        public long EmployeeCategorySeqId { get; set; }
        public string? EmpCategoryName { get; set; }
        public string? Tenure { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchActive { get; set; }
        public string? DtFromDate { get; set; }
        public string? DtToDate { get; set; }
        public string? VchTransactionId { get; set; }
    }
}
