﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ReportToolGenericDataStoreConfAttribute
    {
        public long IntConfReptId { get; set; }
        public long? IntCompanyId { get; set; }
        public string? EmployeeCode { get; set; }
        public string? EmployeeName { get; set; }
        public string? RmCode { get; set; }
        public string? RmName { get; set; }
        public string? RcsGrade { get; set; }
        public string? Designation { get; set; }
        public DateOnly? DateOfJoining { get; set; }
        public DateOnly? ConfirmationDueDate { get; set; }
        public string? ConfirmationStatus { get; set; }
        public string? RmComment { get; set; }
        public string? HrComment { get; set; }
        public string? ApproverAction { get; set; }
        public DateOnly? ExtendedFrom { get; set; }
        public DateOnly? ExtendedTo { get; set; }
        public long? DaysExtended { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
    }
}
