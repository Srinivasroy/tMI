﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class EmployeeDocumentSizeDetail
    {
        public long IntEmpDocSizeId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        public long? IntCompanyId { get; set; }
        public double? DouDocsSize { get; set; }
        public double? DouProfileSize { get; set; }
        public double? DouResumeSize { get; set; }
        public double? DouFeedbackSize { get; set; }
        public double? DouOnbSize { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
        public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
