﻿using System;
using System.Collections.Generic;

namespace Master.Models.client10
{
    public partial class ComponentMasIdGenerateHistory
    {
        public long IntComIdGenId { get; set; }
        /// <summary>
        /// REFERENCE FROM company_detail_master
        /// </summary>
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// FOR store last seq id
        /// </summary>
        public string? VchLastGenId { get; set; }

        public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
