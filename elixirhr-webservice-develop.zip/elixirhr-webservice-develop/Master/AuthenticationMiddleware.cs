﻿


using Master.Models.client10;
using Microsoft.AspNetCore.Mvc.Controllers;


namespace ExitAPIs
{
    public class AuthenticationMiddleware
    {
        private readonly RequestDelegate _next;


        public AuthenticationMiddleware(RequestDelegate next)
        {
            this._next = next;

        }
        public async Task Invoke(HttpContext context)
        {
            try
            {
                if (context.Request.RouteValues["tenantId"] != null)
                {
                    var ProjectName = context.Request.RouteValues["tenantId"].ToString();
                    //List<DBConnection> _list = new List<DBConnection>();
                    //_list = _masterContext.DBConnections.Where(_value =>
                    // _value.ProjectName.ToLower() == ProjectName.ToLower()
                    //).ToList();
                    IConfigurationRoot configuration = new ConfigurationBuilder()
         .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
         .AddJsonFile("appsettings.json")
         .Build();
                    var ConnectionString = configuration.GetConnectionString("MasterDatabase").ToString();
                    System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
                    builder.ConnectionString = ConnectionString;
                    builder["database"] = ProjectName;
                    if (ProjectName != null)
                    {
                        DBcontext.ConnectionString = builder.ConnectionString;
                        var controllerActionDescriptor = context.GetEndpoint().Metadata.GetMetadata<ControllerActionDescriptor>();
                        var controllerName = controllerActionDescriptor.ControllerName;
                        var actionName = controllerActionDescriptor.ActionName;
                        await _next.Invoke(context);
                    }
                    else
                    {
                        // no authorization header    
                        context.Response.StatusCode = 401; //Unauthorized    
                        return;
                    }
                }
                else
                {
                    // no authorization header    
                    context.Response.StatusCode = 401; //Unauthorized    
                    return;
                }
            }
            catch (Exception e)
            {
                // no authorization header    
                context.Response.StatusCode = 400;
                return;
            }
        }
    }
}
