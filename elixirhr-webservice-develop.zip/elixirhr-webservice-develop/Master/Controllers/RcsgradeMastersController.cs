﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Master.Models.client10;

//namespace Master.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class RcsgradeMastersController : ControllerBase
//    {
//        private readonly DBcontext _context;

//        public RcsgradeMastersController(DBcontext context)
//        {
//            _context = context;
//        }

//        // GET: api/RcsgradeMasters
//        [HttpGet]
//        public async Task<ActionResult<IEnumerable<RcsgradeMaster>>> GetRcsgradeMasters()
//        {
//          if (_context.RcsgradeMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.RcsgradeMasters.ToListAsync();
//        }

//        // GET: api/RcsgradeMasters/5
//        [HttpGet("{id}")]
//        public async Task<ActionResult<RcsgradeMaster>> GetRcsgradeMaster(long id)
//        {
//          if (_context.RcsgradeMasters == null)
//          {
//              return NotFound();
//          }
//            var rcsgradeMaster = await _context.RcsgradeMasters.FindAsync(id);

//            if (rcsgradeMaster == null)
//            {
//                return NotFound();
//            }

//            return rcsgradeMaster;
//        }

//        // PUT: api/RcsgradeMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("{id}")]
//        public async Task<IActionResult> PutRcsgradeMaster(long id, RcsgradeMaster rcsgradeMaster)
//        {
//            if (id != rcsgradeMaster.IntRcsgradeId)
//            {
//                return BadRequest();
//            }

//            _context.Entry(rcsgradeMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!RcsgradeMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/RcsgradeMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost]
//        public async Task<ActionResult<RcsgradeMaster>> PostRcsgradeMaster(RcsgradeMaster rcsgradeMaster)
//        {
//          if (_context.RcsgradeMasters == null)
//          {
//              return Problem("Entity set 'DBcontext.RcsgradeMasters'  is null.");
//          }
//            _context.RcsgradeMasters.Add(rcsgradeMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetRcsgradeMaster", new { id = rcsgradeMaster.IntRcsgradeId }, rcsgradeMaster);
//        }

//        // DELETE: api/RcsgradeMasters/5
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> DeleteRcsgradeMaster(long id)
//        {
//            if (_context.RcsgradeMasters == null)
//            {
//                return NotFound();
//            }
//            var rcsgradeMaster = await _context.RcsgradeMasters.FindAsync(id);
//            if (rcsgradeMaster == null)
//            {
//                return NotFound();
//            }

//            _context.RcsgradeMasters.Remove(rcsgradeMaster);
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }

//        private bool RcsgradeMasterExists(long id)
//        {
//            return (_context.RcsgradeMasters?.Any(e => e.IntRcsgradeId == id)).GetValueOrDefault();
//        }
//    }
//}
