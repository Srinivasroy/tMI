﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Master.Models.client10;

//namespace Master.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class LocationMastersController : ControllerBase
//    {
//        private readonly DBcontext _context;

//        public LocationMastersController(DBcontext context)
//        {
//            _context = context;
//        }

//        // GET: api/LocationMasters
//        [HttpGet]
//        public async Task<ActionResult<IEnumerable<LocationMaster>>> GetLocationMasters()
//        {
//          if (_context.LocationMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.LocationMasters.ToListAsync();
//        }

//        // GET: api/LocationMasters/5
//        [HttpGet("{id}")]
//        public async Task<ActionResult<LocationMaster>> GetLocationMaster(long id)
//        {
//          if (_context.LocationMasters == null)
//          {
//              return NotFound();
//          }
//            var locationMaster = await _context.LocationMasters.FindAsync(id);

//            if (locationMaster == null)
//            {
//                return NotFound();
//            }

//            return locationMaster;
//        }

//        // PUT: api/LocationMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("{id}")]
//        public async Task<IActionResult> PutLocationMaster(long id, LocationMaster locationMaster)
//        {
//            if (id != locationMaster.LocationSeqId)
//            {
//                return BadRequest();
//            }

//            _context.Entry(locationMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!LocationMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/LocationMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost]
//        public async Task<ActionResult<LocationMaster>> PostLocationMaster(LocationMaster locationMaster)
//        {
//          if (_context.LocationMasters == null)
//          {
//              return Problem("Entity set 'DBcontext.LocationMasters'  is null.");
//          }
//            _context.LocationMasters.Add(locationMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetLocationMaster", new { id = locationMaster.LocationSeqId }, locationMaster);
//        }

//        // DELETE: api/LocationMasters/5
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> DeleteLocationMaster(long id)
//        {
//            if (_context.LocationMasters == null)
//            {
//                return NotFound();
//            }
//            var locationMaster = await _context.LocationMasters.FindAsync(id);
//            if (locationMaster == null)
//            {
//                return NotFound();
//            }

//            _context.LocationMasters.Remove(locationMaster);
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }

//        private bool LocationMasterExists(long id)
//        {
//            return (_context.LocationMasters?.Any(e => e.LocationSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
