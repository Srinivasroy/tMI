﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Master.Models.client10;

//namespace Master.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class DesignationMastersController : ControllerBase
//    {
//        private readonly DBcontext _context;

//        public DesignationMastersController(DBcontext context)
//        {
//            _context = context;
//        }

//        // GET: api/DesignationMasters
//        [HttpGet("GetDesignationMasters/{tenantId}")]
//        public async Task<ActionResult<IEnumerable<DesignationMaster>>> GetDesignationMasters()
//        {
//          if (_context.DesignationMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.DesignationMasters.ToListAsync();
//        }

//        // GET: api/DesignationMasters/5
//        [HttpGet("{id}")]
//        public async Task<ActionResult<DesignationMaster>> GetDesignationMaster(long id)
//        {
//          if (_context.DesignationMasters == null)
//          {
//              return NotFound();
//          }
//            var designationMaster = await _context.DesignationMasters.FindAsync(id);

//            if (designationMaster == null)
//            {
//                return NotFound();
//            }

//            return designationMaster;
//        }

//        // PUT: api/DesignationMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("{id}")]
//        public async Task<IActionResult> PutDesignationMaster(long id, DesignationMaster designationMaster)
//        {
//            if (id != designationMaster.DesignationSeqId)
//            {
//                return BadRequest();
//            }

//            _context.Entry(designationMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!DesignationMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/DesignationMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost]
//        public async Task<ActionResult<DesignationMaster>> PostDesignationMaster(DesignationMaster designationMaster)
//        {
//          if (_context.DesignationMasters == null)
//          {
//              return Problem("Entity set 'DBcontext.DesignationMasters'  is null.");
//          }
//            _context.DesignationMasters.Add(designationMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetDesignationMaster", new { id = designationMaster.DesignationSeqId }, designationMaster);
//        }

//        // DELETE: api/DesignationMasters/5
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> DeleteDesignationMaster(long id)
//        {
//            if (_context.DesignationMasters == null)
//            {
//                return NotFound();
//            }
//            var designationMaster = await _context.DesignationMasters.FindAsync(id);
//            if (designationMaster == null)
//            {
//                return NotFound();
//            }

//            _context.DesignationMasters.Remove(designationMaster);
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }

//        private bool DesignationMasterExists(long id)
//        {
//            return (_context.DesignationMasters?.Any(e => e.DesignationSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
