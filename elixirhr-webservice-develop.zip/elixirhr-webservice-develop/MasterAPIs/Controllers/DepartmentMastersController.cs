﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public DepartmentMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/DepartmentMasters
        [HttpGet("GetDepartmentMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<DepartmentMaster>>> GetDepartmentMasters()
        {
            try
            {
                if (_context.DepartmentMasters == null)
                {
                    return NotFound();
                }
                return await _context.DepartmentMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/DepartmentMasters/5
        [HttpGet("GetDepartmentMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<DepartmentMaster>> GetDepartmentMaster(long id)
        {
            var departmentMaster = await _context.DepartmentMasters.FindAsync(id);

            if (departmentMaster == null)
            {
                return NotFound();
            }

            return departmentMaster;
        }

        //// PUT: api/DepartmentMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutDepartmentMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutDepartmentMaster(long id, DepartmentMaster departmentMaster)
        //{
        //    if (id != departmentMaster.departmentId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(departmentMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!DepartmentMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/DepartmentMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostDepartmentMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostDepartmentMaster(DepartmentMaster departmentMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(departmentMaster.departmentName))
                {
                    return Conflict("DepartmentName can not be null");
                }

                if (departmentMaster.departmentId > 0)
                {
                    departmentMaster.updatedBy = MasterContext.Email;
                    departmentMaster.updatedDate = DateTime.UtcNow;
                    _context.DepartmentMasters.Update(departmentMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                departmentMaster.createdBy = MasterContext.Email;
                departmentMaster.updatedBy = departmentMaster.createdBy;
                departmentMaster.createdTime = DateTime.UtcNow;
                departmentMaster.updatedDate = DateTime.UtcNow;
                departmentMaster.companyId = currentCompanyId;
                _context.DepartmentMasters.Add(departmentMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }

        
        private bool DepartmentMasterExists(long id)
        {
            return _context.DepartmentMasters.Any(e => e.departmentId == id);
        }
    }
}
