﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ItsRoleSfiaMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ItsRoleSfiaMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ItsRoleSfiaMasters
//        [HttpGet("GetItsRoleSfiaMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ItsRoleSfiaMaster>>> GetItsRoleSfiaMasters()
//        {
//          if (_context.ItsRoleSfiaMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.ItsRoleSfiaMasters.ToListAsync();
//        }

//        // GET: api/ItsRoleSfiaMasters/5
//        [HttpGet("GetItsRoleSfiaMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ItsRoleSfiaMaster>> GetItsRoleSfiaMaster( long id)
//        {
//          if (_context.ItsRoleSfiaMasters == null)
//          {
//              return NotFound();
//          }
//            var itsRoleSfiaMaster = await _context.ItsRoleSfiaMasters.FindAsync(id);

//            if (itsRoleSfiaMaster == null)
//            {
//                return NotFound();
//            }

//            return itsRoleSfiaMaster;
//        }

//        // PUT: api/ItsRoleSfiaMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutItsRoleSfiaMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutItsRoleSfiaMaster( long id, ItsRoleSfiaMaster itsRoleSfiaMaster)
//        {
//            if (id != itsRoleSfiaMaster.IntItsRoleSfiaId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)itsRoleSfiaMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{itsRoleSfiaMaster.IntCompanyId}' not found." });
//                }


//            }
//            itsRoleSfiaMaster.DtUpdatedTime = DateTime.UtcNow;
//            _context.Entry(itsRoleSfiaMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ItsRoleSfiaMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ItsRoleSfiaMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostItsRoleSfiaMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ItsRoleSfiaMaster>> PostItsRoleSfiaMaster(  ItsRoleSfiaMaster itsRoleSfiaMaster)
//        {
//          if (_context.ItsRoleSfiaMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ItsRoleSfiaMasters'  is null.");
//          }
//            if (itsRoleSfiaMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            itsRoleSfiaMaster.DtUpdatedTime = DateTime.UtcNow;
//            itsRoleSfiaMaster.TsCreatedTime = DateTime.UtcNow;
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)itsRoleSfiaMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{itsRoleSfiaMaster.IntCompanyId}' not found." });
//                }


//                await _context.SaveChangesAsync();


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            _context.ItsRoleSfiaMasters.Add(itsRoleSfiaMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetItsRoleSfiaMaster", new {  id = itsRoleSfiaMaster.IntItsRoleSfiaId }, itsRoleSfiaMaster);
//        }

//        // DELETE: api/ItsRoleSfiaMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteItsRoleSfiaMaster(long id)
//        //{
//        //    if (_context.ItsRoleSfiaMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var itsRoleSfiaMaster = await _context.ItsRoleSfiaMasters.FindAsync(id);
//        //    if (itsRoleSfiaMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ItsRoleSfiaMasters.Remove(itsRoleSfiaMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ItsRoleSfiaMasterExists(long id)
//        {
//            return (_context.ItsRoleSfiaMasters?.Any(e => e.IntItsRoleSfiaId == id)).GetValueOrDefault();
//        }
//    }
//}
