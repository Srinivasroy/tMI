﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using ExcelDataReader;
using System.Data;
using static MasterAPIs.Models.Helper.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeStatusMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public EmployeeStatusMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/EmpStatusMasters
        [HttpGet("GetEmpStatusMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<IEnumerable<EmployeeStatusMaster>>> GetEmpStatusMasters()
        {
            return await _context.EmployeeStatusMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/EmpStatusMasters/5
        [HttpGet("GetEmpStatusMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<EmployeeStatusMaster>> GetEmpStatusMaster(long id)
        {
            var empStatusMaster = await _context.EmployeeStatusMasters.FindAsync(id);

            if (empStatusMaster == null)
            {
                return NotFound();
            }

            return empStatusMaster;
        }

        // PUT: api/EmpStatusMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutEmpStatusMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        //public async Task<IActionResult> PutEmpStatusMaster(long id, EmployeeStatusMaster empStatusMaster)
        //{
        //    if (id != empStatusMaster.employeeStatusId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(empStatusMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!EmpStatusMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/EmpStatusMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostEmpStatusMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<object>> PostEmpStatusMaster(EmployeeStatusMaster empStatusMaster)
        {
            try
            {
                if (empStatusMaster.employeeStatusId == 0)
                {
                    if (EmployeeStatusExists(empStatusMaster.employeeStatus, empStatusMaster.companyId))
                    {
                        return Conflict(new { message = $"EmployeeStatus  '{empStatusMaster.employeeStatus}' already exists" });
                    }
                }

                empStatusMaster.createdTime = DateTime.UtcNow;
                empStatusMaster.updatedDate = empStatusMaster.createdTime;
                empStatusMaster.createdBy = EmailId;
                empStatusMaster.updatedBy = EmailId;
                _context.EmployeeStatusMasters.Update(empStatusMaster);
                await _context.SaveChangesAsync();
            }
            catch
            {
                throw;
            }
            var employeestatusmasterjson = JsonConvert.SerializeObject(empStatusMaster);
            var _employeestatusmaster = System.Text.Json.JsonSerializer.Deserialize<object>(employeestatusmasterjson);

            return _employeestatusmaster;
            //return CreatedAtAction("GetEmpStatusMaster", new { id = empStatusMaster.employeeStatusId }, empStatusMaster);
        }


        [HttpPost("EmployeeStatusMasterBulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> EmployeeStatusMasterBulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                //return new { message = "No file was uploaded !!!" };
                return Conflict(new { message = "No file was uploaded !!!" });

            }
            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                // return new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" };
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    var employeeStatusRows = dataTable.AsEnumerable().Select(x => x["employeeStatus"].ToString()).Distinct().ToList();
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any data!" });
                    }
                    foreach (var employeestatusRow in employeeStatusRows)
                    {
                        var conFil = _context.EmployeeStatusMasters.Where(x => x.employeeStatus == employeestatusRow.ToString() && x.companyId == currentCompanyId).FirstOrDefault();
                        if (conFil == null)
                        {
                            var employeeStatusMaster = new EmployeeStatusMaster
                            {
                                employeeStatus = employeestatusRow.ToString(),
                                companyId = currentCompanyId,
                                createdBy = MasterContext.Email,
                                createdTime = DateTime.UtcNow,
                                updatedBy = MasterContext.Email,
                                updatedDate = DateTime.UtcNow,
                                status = (int)Statuses.Approved
                            };
                            _context.EmployeeStatusMasters.Add(employeeStatusMaster);
                        }
                    }
                    await _context.SaveChangesAsync();
                    //return Ok("File uploaded sucessfully!!!");
                    return new { message = "File uploaded sucessfully!!!", status = "success" };
                    // "message": "File uploaded successfully",

                }
            }
        }



        // DELETE: api/EmpStatusMasters/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmpStatusMaster(long id)
        {
            var empStatusMaster = await _context.EmployeeStatusMasters.FindAsync(id);
            if (empStatusMaster == null)
            {
                return NotFound();
            }

            _context.EmployeeStatusMasters.Remove(empStatusMaster);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmpStatusMasterExists(long id)
        {
            return _context.EmployeeStatusMasters.Any(e => e.employeeStatusId == id);
        }
        private bool EmployeeStatusExists(string employeeStatus, long? companyId)
        {
            return _context.EmployeeStatusMasters.Any(e => e.employeeStatus == employeeStatus && e.companyId == companyId);
        }
    }
}
