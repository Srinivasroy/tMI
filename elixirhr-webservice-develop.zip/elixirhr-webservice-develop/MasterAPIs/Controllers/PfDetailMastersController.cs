﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class PfDetailMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public PfDetailMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/PfDetailMasters
//        [HttpGet("GetItsRoleSfiaMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<PfDetailMaster>>> GetPfDetailMasters()
//        {
//          if (_context.PfDetailMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.PfDetailMasters.ToListAsync();
//        }

//        // GET: api/PfDetailMasters/5
//        [HttpGet("GetItsRoleSfiaMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<PfDetailMaster>> GetPfDetailMaster( long id)
//        {
//          if (_context.PfDetailMasters == null)
//          {
//              return NotFound();
//          }
//            var pfDetailMaster = await _context.PfDetailMasters.FindAsync(id);

//            if (pfDetailMaster == null)
//            {
//                return NotFound();
//            }

//            return pfDetailMaster;
//        }

//        // PUT: api/PfDetailMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutItsRoleSfiaMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutPfDetailMaster( long id, PfDetailMaster pfDetailMaster)
//        {
//            if (id != pfDetailMaster.IntPfId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)pfDetailMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{pfDetailMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntEmpIdExists((long)pfDetailMaster.IntEmpId))
//                {
//                    return Conflict(new { message = $"IntEmp Id '{pfDetailMaster.IntEmpId}' not found." });
//                }


//            }
//            pfDetailMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(pfDetailMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!PfDetailMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/PfDetailMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostItsRoleSfiaMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<PfDetailMaster>> PostPfDetailMaster( PfDetailMaster pfDetailMaster)
//        {
//          if (_context.PfDetailMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.PfDetailMasters'  is null.");
//          }
//            if (pfDetailMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            pfDetailMaster.DtUpdatedDate = DateTime.UtcNow;
//            pfDetailMaster.TsCreatedTime = DateTime.UtcNow;
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)pfDetailMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{pfDetailMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntEmpIdExists((long)pfDetailMaster.IntEmpId))
//                {
//                    return Conflict(new { message = $"IntEmp Id '{pfDetailMaster.IntEmpId}' not found." });
//                }

//                await _context.SaveChangesAsync();


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            _context.PfDetailMasters.Add(pfDetailMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetPfDetailMaster", new {  id = pfDetailMaster.IntPfId }, pfDetailMaster);
//        }

//        // DELETE: api/PfDetailMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeletePfDetailMaster(long id)
//        //{
//        //    if (_context.PfDetailMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var pfDetailMaster = await _context.PfDetailMasters.FindAsync(id);
//        //    if (pfDetailMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.PfDetailMasters.Remove(pfDetailMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool PfDetailMasterExists(long id)
//        {
//            return (_context.PfDetailMasters?.Any(e => e.IntPfId == id)).GetValueOrDefault();
//        }
//    }
//}
