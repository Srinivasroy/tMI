﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class SkillMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public SkillMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/SkillMasters
//        [HttpGet("GetSkillMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<SkillMaster>>> GetSkillMasters()
//        {
//          if (_context.SkillMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.SkillMasters.ToListAsync();
//        }

//        // GET: api/SkillMasters/5
//        [HttpGet("GetSkillMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<SkillMaster>> GetSkillMaster( long id)
//        {
//          if (_context.SkillMasters == null)
//          {
//              return NotFound();
//          }
//            var skillMaster = await _context.SkillMasters.FindAsync(id);

//            if (skillMaster == null)
//            {
//                return NotFound();
//            }

//            return skillMaster;
//        }

//        // PUT: api/SkillMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutSkillMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutSkillMaster( long id, SkillMaster skillMaster)
//        {
//            if (id != skillMaster.SkillSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)skillMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{skillMaster.IntCompanyId}' not found." });
//                }


//            }

//              skillMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(skillMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!SkillMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/SkillMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostSkillMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<SkillMaster>> PostSkillMaster( SkillMaster skillMaster)
//        {
//          if (_context.SkillMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.SkillMasters'  is null.");
//          }
//            if (skillMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            skillMaster.DtUpdatedDate = DateTime.UtcNow;
//            skillMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.SkillMasters.Add(skillMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)skillMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{skillMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            return CreatedAtAction("GetSkillMaster", new {  id = skillMaster.SkillSeqId }, skillMaster);
//        }

//        // DELETE: api/SkillMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteSkillMaster(long id)
//        //{
//        //    if (_context.SkillMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var skillMaster = await _context.SkillMasters.FindAsync(id);
//        //    if (skillMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.SkillMasters.Remove(skillMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool SkillMasterExists(long id)
//        {
//            return (_context.SkillMasters?.Any(e => e.SkillSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
