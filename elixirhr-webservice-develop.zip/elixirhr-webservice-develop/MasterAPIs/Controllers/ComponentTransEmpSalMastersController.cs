﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ComponentTransEmpSalMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ComponentTransEmpSalMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ComponentTransEmpSalMasters
//        [HttpGet("GetComponentTransEmpSalMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ComponentTransEmpSalMaster>>> GetComponentTransEmpSalMasters()
//        {
//          if (_context.ComponentTransEmpSalMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.ComponentTransEmpSalMasters.ToListAsync();
//        }

//        // GET: api/ComponentTransEmpSalMasters/5
//        [HttpGet("GetComponentTransEmpSalMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ComponentTransEmpSalMaster>> GetComponentTransEmpSalMaster( long id)
//        {
//          if (_context.ComponentTransEmpSalMasters == null)
//          {
//              return NotFound();
//          }
//            var componentTransEmpSalMaster = await _context.ComponentTransEmpSalMasters.FindAsync(id);

//            if (componentTransEmpSalMaster == null)
//            {
//                return NotFound();
//            }

//            return componentTransEmpSalMaster;
//        }

//        // PUT: api/ComponentTransEmpSalMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutComponentTransEmpSalMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutComponentTransEmpSalMaster( long id, ComponentTransEmpSalMaster componentTransEmpSalMaster)
//        {
//            if (id != componentTransEmpSalMaster.IntCompSalMasSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)componentTransEmpSalMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentTransEmpSalMaster.IntCompanyId}' not found." });
//                }


//            }

//            componentTransEmpSalMaster.IntCompSalMasSeqId = id;
//            componentTransEmpSalMaster.TsUpdatedTime= DateTime.UtcNow;

//            _context.Entry(componentTransEmpSalMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ComponentTransEmpSalMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ComponentTransEmpSalMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostComponentTransEmpSalMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ComponentTransEmpSalMaster>> PostComponentTransEmpSalMaster( ComponentTransEmpSalMaster componentTransEmpSalMaster)
//        {
//          if (_context.ComponentTransEmpSalMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ComponentTransEmpSalMasters'  is null.");
//          }
//            if (componentTransEmpSalMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            componentTransEmpSalMaster.TsUpdatedTime = DateTime.UtcNow;
//            componentTransEmpSalMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.ComponentTransEmpSalMasters.Add(componentTransEmpSalMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)componentTransEmpSalMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentTransEmpSalMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
            

//            return CreatedAtAction("GetComponentTransEmpSalMaster", new {  id = componentTransEmpSalMaster.IntCompSalMasSeqId }, componentTransEmpSalMaster);
//        }

//        // DELETE: api/ComponentTransEmpSalMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteComponentTransEmpSalMaster(long id)
//        //{
//        //    if (_context.ComponentTransEmpSalMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var componentTransEmpSalMaster = await _context.ComponentTransEmpSalMasters.FindAsync(id);
//        //    if (componentTransEmpSalMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ComponentTransEmpSalMasters.Remove(componentTransEmpSalMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ComponentTransEmpSalMasterExists(long id)
//        {
//            return (_context.ComponentTransEmpSalMasters?.Any(e => e.IntCompSalMasSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
