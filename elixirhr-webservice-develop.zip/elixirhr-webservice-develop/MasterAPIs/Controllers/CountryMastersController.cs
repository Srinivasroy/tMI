﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using ExcelDataReader;
using System.Data;
using MySqlConnector;
using Newtonsoft.Json;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private readonly string _connectionString;

        public CountryMastersController(MasterContext context)
        {
            _context = context;
            _connectionString = "server=127.0.0.1;port=3306;database=newschema;uid=root;pwd=Test";

        }

        // GET: api/CountryMasters
        [HttpGet("GetCountryMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<IEnumerable<CountryMaster>>> GetCountryMasters()
        {
            return await _context.CountryMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/CountryMasters/5
        [HttpGet("GetCountryMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<CountryMaster>> GetCountryMaster(long id)
        {
            var countryMaster = await _context.CountryMasters.FindAsync(id);

            if (countryMaster == null)
            {
                return NotFound();
            }

            return countryMaster;
        }

        // PUT: api/CountryMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("PutCountryMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<IActionResult> PutCountryMaster(long id, CountryMaster countryMaster)
        {
            if (id != countryMaster.countryId)
            {
                return BadRequest();
            }
            else if (CountryMasterNameExists(countryMaster.countryName))
            {
                return Conflict(new { message = $"Country Name '{countryMaster.countryName}' already exists" });
            }
            _context.Entry(countryMaster).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CountryMasterExists(id))
                {
                    return NotFound();
                }
                else if (CountryMasterNameExists(countryMaster.countryName))
                {
                    return Conflict(new { message = $"Country name '{countryMaster.countryName}' already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CountryMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostCountryMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostCountryMaster(CountryMaster countryMaster)
        {
            try
            {
                if (CountryMasterNameExists(countryMaster.countryName))
                {
                    return Conflict(new { message = $"Country Name '{countryMaster.countryName}' already exists" });
                }
                countryMaster.createdTime = DateTime.UtcNow;
                countryMaster.updatedDate = countryMaster.createdTime;
                _context.CountryMasters.Add(countryMaster);

                await _context.SaveChangesAsync();
            }
            catch
            {

                if (CountryMasterNameExists(countryMaster.countryName))
                {
                    return Conflict(new { message = $"Country name '{countryMaster.countryName}' already exists !!!" });
                }
                else
                {
                    throw;
                }
            }
            var countrymasterjson = JsonConvert.SerializeObject(countryMaster);
            var _countrymaster = System.Text.Json.JsonSerializer.Deserialize<object>(countrymasterjson);

            return _countrymaster;
            //return CreatedAtAction("GetStateMaster", new { id = stateMaster.stateId }, stateMaster);
        }


        [HttpPost("CountryBulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> CountryBulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                //return new { message = "No file was uploaded !!!" };
                return Conflict(new { message = "No file was uploaded !!!" });

            }
            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
               // return new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" };
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    var countryRows = dataTable.AsEnumerable().Select(x => x["country"].ToString()).Distinct().ToList();
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any country data!" });
                    }
                    foreach (var countryRow in countryRows)
                    {
                        var conFil = _context.CountryMasters.Where(x => x.countryName == countryRow.ToString() && x.companyId == currentCompanyId).FirstOrDefault();
                        if (conFil == null)
                        {
                            var countryMaster = new CountryMaster
                            {
                                countryName = countryRow.ToString(),
                                companyId = currentCompanyId,
                                createdBy = MasterContext.Email,
                                createdTime = DateTime.UtcNow,
                            };
                            _context.CountryMasters.Add(countryMaster);
                        }
                    }
                    await _context.SaveChangesAsync();
                    //return Ok("File uploaded sucessfully!!!");
                    return new { message = "File uploaded sucessfully!!!",  status= "success" };
                   // "message": "File uploaded successfully",
  
                }
            }
        }


        [HttpDelete("CountryDelete/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteCountryMaster(long id)
        {
            var countryMasters = await _context.CountryMasters.FindAsync(id);
            if (countryMasters == null)
            {
                return NotFound();
            }
            try
            {
                _context.CountryMasters.Remove(countryMasters);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception)
            {
                return Conflict(new { message = $"This Country can not be deleted as some states are assigned to it !!!" });
            }
        }
        private bool CountryMasterExists(long id)
        {
            return _context.CountryMasters.Any(e => e.countryId == id);
        }
        private bool CountryMasterNameExists(string countryName)
        {
            return _context.CountryMasters.Any(e => e.countryName == countryName);
        }
    }
}
