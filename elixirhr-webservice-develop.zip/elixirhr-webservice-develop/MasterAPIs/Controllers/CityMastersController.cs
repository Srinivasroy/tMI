﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using System.Collections;
using Newtonsoft.Json;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public CityMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/CityMasters
        [HttpGet("GetCityMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
       public async Task<ActionResult<CityViewModel>> GetCityMasters()
             
        {
            try
            {
                if (_context.CityMasters == null)
                {
                    return NotFound();
                }
                var cityViewModel = new CityViewModel
                {
                    cityList = await _context.CityMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                    stateList = await _context.StateMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                    countryList = await _context.CountryMasters.Where(x => x.companyId == currentCompanyId).ToListAsync()
                };
                return cityViewModel;

                

            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }

            
        }
      
        // GET: api/CityMasters/5
        [HttpGet("GetCityMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<CityMaster>> GetCityMaster(long id)
        {
            var cityMaster = await _context.CityMasters.FindAsync(id);

            if (cityMaster == null)
            {
                return NotFound();
            }

            return cityMaster;
        }

        //// PUT: api/CityMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutCityMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutCityMaster(int id, CityMaster cityMaster)
        //{
        //    if (id != cityMaster.cityId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(cityMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!CityMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/CityMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostCityMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostCityMaster(CityMaster cityMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(cityMaster.cityName))
                {
                    return Conflict("CityName can not be null");
                }

                if (cityMaster.cityId > 0)
                {
                    cityMaster.updatedBy = MasterContext.Email;
                    cityMaster.updatedDate = DateTime.UtcNow;
                    _context.CityMasters.Update(cityMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                cityMaster.createdBy = MasterContext.Email;
                cityMaster.updatedBy = cityMaster.createdBy;
                cityMaster.createdTime = DateTime.UtcNow;
                cityMaster.updatedDate = DateTime.UtcNow;
                cityMaster.companyId = currentCompanyId;
                _context.CityMasters.Add(cityMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }

        
        private bool CityMasterExists(int id)
        {
            return _context.CityMasters.Any(e => e.cityId == id);
        }
    }
}
