﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class EmploymentTypeMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public EmploymentTypeMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/EmploymentTypeMasters
//        [HttpGet("GetEmploymentTypeMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<EmploymentTypeMaster>>> GetEmploymentTypeMasters()
//        {
//          if (_context.EmploymentTypeMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.EmploymentTypeMasters.ToListAsync();
//        }

//        // GET: api/EmploymentTypeMasters/5
//        [HttpGet("GetEmploymentTypeMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<EmploymentTypeMaster>> GetEmploymentTypeMaster( long id)
//        {
//          if (_context.EmploymentTypeMasters == null)
//          {
//              return NotFound();
//          }
//            var employmentTypeMaster = await _context.EmploymentTypeMasters.FindAsync(id);

//            if (employmentTypeMaster == null)
//            {
//                return NotFound();
//            }

//            return employmentTypeMaster;
//        }

//        // PUT: api/EmploymentTypeMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut(("PutEmploymentTypeMaster/{id}"))]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutEmploymentTypeMaster( long id, EmploymentTypeMaster employmentTypeMaster)
//        {
//            if (id != employmentTypeMaster.IntEmploymentTypeId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)employmentTypeMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{employmentTypeMaster.IntCompanyId}' not found." });
//                }


//            }

//            employmentTypeMaster.DtUpdatedTime = DateTime.UtcNow;
//            _context.Entry(employmentTypeMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!EmploymentTypeMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/EmploymentTypeMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostEmploymentTypeMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<EmploymentTypeMaster>> PostEmploymentTypeMaster( EmploymentTypeMaster employmentTypeMaster)
//        {
//          if (_context.EmploymentTypeMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.EmploymentTypeMasters'  is null.");
//          }

//            if (employmentTypeMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }

//            employmentTypeMaster.DtUpdatedTime = DateTime.UtcNow;
//            employmentTypeMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.EmploymentTypeMasters.Add(employmentTypeMaster);
//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)employmentTypeMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{employmentTypeMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();

//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

            

//            return CreatedAtAction("GetEmploymentTypeMaster", new {  id = employmentTypeMaster.IntEmploymentTypeId }, employmentTypeMaster);
//        }

//        // DELETE: api/EmploymentTypeMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteEmploymentTypeMaster(long id)
//        //{
//        //    if (_context.EmploymentTypeMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var employmentTypeMaster = await _context.EmploymentTypeMasters.FindAsync(id);
//        //    if (employmentTypeMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.EmploymentTypeMasters.Remove(employmentTypeMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool EmploymentTypeMasterExists(long id)
//        {
//            return (_context.EmploymentTypeMasters?.Any(e => e.IntEmploymentTypeId == id)).GetValueOrDefault();
//        }
//    }
//}
