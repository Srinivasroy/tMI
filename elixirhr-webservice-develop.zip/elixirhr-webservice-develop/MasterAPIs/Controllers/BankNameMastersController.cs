﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class BankNameMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;
//        private int currentCompanyId = MasterContext.CurrentCompanyId;
//        public BankNameMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/BankNameMasters
//        [HttpGet("GetBankNameMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<BankNameMaster>>> GetBankNameMasters()
//        {
//          if (_context.BankNameMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.BankNameMasters.Where(x=> x.IntCompanyId==currentCompanyId).ToListAsync();
//        }

//        // GET: api/BankNameMasters/5
//        [HttpGet("GetBankNameMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<BankNameMaster>> GetBankNameMaster(long id)
//        {
//          if (_context.BankNameMasters == null)
//          {
//              return NotFound();
//          }
//            var bankNameMaster = await _context.BankNameMasters.FindAsync(id);

//            if (bankNameMaster == null)
//            {
//                return NotFound();
//            }

//            return bankNameMaster;
//        }

//        // PUT: api/BankNameMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutBankNameMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutBankNameMaster(long id, BankNameMaster bankNameMaster)
//        {
//            if (id != bankNameMaster.BankNameSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)bankNameMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{bankNameMaster.IntCompanyId}' not found." });
//                }

              
//            }

//            bankNameMaster.BankNameSeqId = id;
//            bankNameMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(bankNameMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!BankNameMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/BankNameMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostBankNameMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<BankNameMaster>> PostBankNameMaster( BankNameMaster bankNameMaster)
//        {
//          if (_context.BankNameMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.BankNameMasters'  is null.");
//          }
//            if (bankNameMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            bankNameMaster.DtUpdatedDate = DateTime.UtcNow;
//            bankNameMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.BankNameMasters.Add(bankNameMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)bankNameMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{bankNameMaster.IntCompanyId}' not found." });
//                }

//                 await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

            
//            return CreatedAtAction("GetBankNameMaster", new { id = bankNameMaster.BankNameSeqId }, bankNameMaster);
//        }

//        // DELETE: api/BankNameMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteBankNameMaster(long id)
//        //{
//        //    if (_context.BankNameMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var bankNameMaster = await _context.BankNameMasters.FindAsync(id);
//        //    if (bankNameMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.BankNameMasters.Remove(bankNameMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool BankNameMasterExists(long id)
//        {
//            return (_context.BankNameMasters?.Any(e => e.BankNameSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
