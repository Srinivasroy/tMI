﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using System.Collections;
using Newtonsoft.Json;
using ExcelDataReader;
using System.Data;
using static MasterAPIs.Models.Helper.Helper;

namespace Master.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenderMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public GenderMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/GenderMasters
        [HttpGet("GetGenderMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<GenderMaster>>> GetGenderMasters()
        {
            try
            {
                if (_context.GenderMasters == null)
                {
                    return NotFound();
                }
                return await _context.GenderMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/GenderMasters/5
        [HttpGet("GetGenderMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<GenderMaster>> GetGenderMaster(long id)
        {
            var genderMaster = await _context.GenderMasters.FindAsync(id);

            if (genderMaster == null)
            {
                return NotFound();
            }

            return genderMaster;
        }

        // PUT: api/GenderMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutGenderMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutGenderMaster(long id, GenderMaster genderMaster)
        //{
        //    if (id != genderMaster.genderId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(genderMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!GenderMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/GenderMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostGenderMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostGenderMaster(GenderMaster genderMaster)
        {
            try
            {
                if (genderMaster.genderId == 0)
                {
                    if (GenderExists(genderMaster.gender, genderMaster.companyId))
                    {
                        return Conflict(new { message = $"gender  '{genderMaster.gender}' already exists" });
                    }
                }

                genderMaster.createdTime = DateTime.UtcNow;
                genderMaster.updatedDate = genderMaster.createdTime;
                genderMaster.createdBy = EmailId;
                genderMaster.updatedBy = genderMaster.createdBy;
                _context.GenderMasters.Update(genderMaster);
                await _context.SaveChangesAsync();
            }
            catch
            {
                    throw;
            }
            var gendermasterjson = JsonConvert.SerializeObject(genderMaster);
            var _gendermaster = System.Text.Json.JsonSerializer.Deserialize<object>(gendermasterjson);

            return _gendermaster;
            //return CreatedAtAction("GetGenderMaster", new { id = genderMaster.genderId }, genderMaster);
        }

        [HttpPost("GenderBulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GenderBulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
               
                return Conflict(new { message = "No file was uploaded !!!" });

            }
            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    var Rows = dataTable.AsEnumerable().Select(x => x["gender"].ToString()).Distinct().ToList();
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any data!" });
                    }
                    foreach (var Row in Rows)
                    {
                        var conFil = _context.GenderMasters.Where(x => x.gender == Row.ToString() && x.companyId == currentCompanyId).FirstOrDefault();
                        if (conFil == null)
                        {
                            var genderMaster = new GenderMaster
                            {
                                gender = Row.ToString(),
                                companyId = currentCompanyId,
                                createdBy = MasterContext.Email,
                                createdTime = DateTime.UtcNow,
                                status = (int)Statuses.Approved,
                                updatedBy = MasterContext.Email,
                                updatedDate = DateTime.UtcNow,
                            };
                            _context.GenderMasters.Add(genderMaster);
                        }


                    }
                    await _context.SaveChangesAsync();
                    //return Ok("File uploaded sucessfully!!!");
                    return new { message = "File uploaded sucessfully!!!", status = "success" };
                    // "message": "File uploaded successfully",

                }
            }
        }


        //// DELETE: api/GenderMasters/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGenderMaster(long id)
        {
            var genderMaster = await _context.GenderMasters.FindAsync(id);
            if (genderMaster == null)
            {
                return NotFound();
            }

            _context.GenderMasters.Remove(genderMaster);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool GenderMasterExists(long id)
        {
            return _context.GenderMasters.Any(e => e.genderId == id);
        }
        private bool GenderExists(string gender, long? companyId)
        {
            return _context.GenderMasters.Any(e => e.gender == gender && e.companyId == companyId);
        }
    }
}
