﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MaritalStatusMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private string EmailId = MasterContext.Email;
        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public MaritalStatusMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/MaritalStatusMasters
        [HttpGet("GetMaritalStatusMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<MaritalStatusMaster>>> GetMaritalStatusMaster()
        {
            return await _context.MaritalStatusMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/MaritalStatusMasters/5
        [HttpGet("GetMaritalStatusMaster{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<MaritalStatusMaster>> GetMaritalStatusMaster(long id)
        {
            var maritalStatusMaster = await _context.MaritalStatusMasters.FindAsync(id);

            if (maritalStatusMaster == null)
            {
                return NotFound();
            }

            return maritalStatusMaster;
        }

        // PUT: api/MaritalStatusMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutMaritalStatusMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutMaritalStatusMaster(long id, MaritalStatusMaster maritalStatusMaster)
        //{
        //    if (id != maritalStatusMaster.maritalStatusId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(maritalStatusMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!MaritalStatusMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/MaritalStatusMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostMaritalStatusMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostMaritalStatusMaster(MaritalStatusMaster maritalStatusMaster)
        {
            try
            {
                if (maritalStatusMaster.maritalStatusId == 0)
                {
                    if (MaritalStatusExists(maritalStatusMaster.maritalStatus, maritalStatusMaster.companyId))
                    {
                        return Conflict(new { message = $"gender  '{maritalStatusMaster.maritalStatus}' already exists" });
                    }
                }

                maritalStatusMaster.createdTime = DateTime.UtcNow;
                maritalStatusMaster.updatedDate = maritalStatusMaster.createdTime;
                maritalStatusMaster.createdBy = EmailId;
                maritalStatusMaster.updatedBy = maritalStatusMaster.createdBy;
                _context.MaritalStatusMasters.Update(maritalStatusMaster);
                await _context.SaveChangesAsync();
            }
            catch(DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
                //throw;
            }
            var maritalstatusmasterjson = JsonConvert.SerializeObject(maritalStatusMaster);
            var _maritalstatusmaster = System.Text.Json.JsonSerializer.Deserialize<object>(maritalstatusmasterjson);

            return _maritalstatusmaster;
            //return new { message = "Record updated successfully !!!" };
            //return CreatedAtAction("GetMaritalStatusMaster", new { id = maritalStatusMaster.maritalStatusId }, maritalStatusMaster);
        }

        
        private bool MaritalStatusMasterExists(long id)
        {
            return _context.MaritalStatusMasters.Any(e => e.maritalStatusId == id);
        }
        private bool MaritalStatusExists(string maritalStatus, long? companyId)
        {
            return _context.MaritalStatusMasters.Any(e => e.maritalStatus == maritalStatus && e.companyId == companyId);
        }
    }
}
