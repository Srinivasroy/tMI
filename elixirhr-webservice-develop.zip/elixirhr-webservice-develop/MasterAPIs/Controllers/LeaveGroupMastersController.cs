﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class LeaveGroupMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public LeaveGroupMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/LeaveGroupMasters
//        [HttpGet("GetLeaveGroupMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<LeaveGroupMaster>>> GetLeaveGroupMasters()
//        {
//            if (_context.LeaveGroupMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.LeaveGroupMasters.ToListAsync();
//        }

//        // GET: api/LeaveGroupMasters/5
//        [HttpGet("GetLeaveGroupMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<LeaveGroupMaster>> GetLeaveGroupMaster( long id)
//        {
//            if (_context.LeaveGroupMasters == null)
//            {
//                return NotFound();
//            }
//            var leaveGroupMaster = await _context.LeaveGroupMasters.FindAsync(id);

//            if (leaveGroupMaster == null)
//            {
//                return NotFound();
//            }

//            return leaveGroupMaster;
//        }

//        // PUT: api/LeaveGroupMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutLeaveGroupMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutLeaveGroupMaster( long id, LeaveGroupMaster leaveGroupMaster)
//        {
//            if (id != leaveGroupMaster.LeaveGroupSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)leaveGroupMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{leaveGroupMaster.IntCompanyId}' not found." });
//                }

//            }

//            leaveGroupMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(leaveGroupMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!LeaveGroupMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/LeaveGroupMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostLeaveGroupMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<LeaveGroupMaster>> PostLeaveGroupMaster( LeaveGroupMaster leaveGroupMaster)
//        {
//            if (_context.LeaveGroupMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.LeaveGroupMasters'  is null.");
//            }
//            if (leaveGroupMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            leaveGroupMaster.DtUpdatedDate = DateTime.UtcNow;
//            leaveGroupMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.LeaveGroupMasters.Add(leaveGroupMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)leaveGroupMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{leaveGroupMaster.IntCompanyId}' not found." });
//                }

//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetLeaveGroupMaster", new {  id = leaveGroupMaster.LeaveGroupSeqId }, leaveGroupMaster);
//        }

//        //// DELETE: api/LeaveGroupMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteLeaveGroupMaster(long id)
//        //{
//        //    if (_context.LeaveGroupMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var leaveGroupMaster = await _context.LeaveGroupMasters.FindAsync(id);
//        //    if (leaveGroupMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.LeaveGroupMasters.Remove(leaveGroupMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool LeaveGroupMasterExists(long id)
//        {
//            return (_context.LeaveGroupMasters?.Any(e => e.LeaveGroupSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
