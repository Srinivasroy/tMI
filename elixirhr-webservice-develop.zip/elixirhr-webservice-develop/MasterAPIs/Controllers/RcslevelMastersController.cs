﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class RcslevelMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public RcslevelMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/RcslevelMasters
//        [HttpGet("GetRcslevelMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<RcslevelMaster>>> GetRcslevelMasters()
//        {
//          if (_context.RcslevelMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.RcslevelMasters.ToListAsync();
//        }

//        // GET: api/RcslevelMasters/5
//        [HttpGet("GetRcslevelMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<RcslevelMaster>> GetRcslevelMaster(long id)
//        {
//          if (_context.RcslevelMasters == null)
//          {
//              return NotFound();
//          }
//            var rcslevelMaster = await _context.RcslevelMasters.FindAsync(id);

//            if (rcslevelMaster == null)
//            {
//                return NotFound();
//            }

//            return rcslevelMaster;
//        }

//        // PUT: api/RcslevelMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutRcslevelMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutRcslevelMaster(long id, RcslevelMaster rcslevelMaster)
//        {
//            if (id != rcslevelMaster.RcslevelSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)rcslevelMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{rcslevelMaster.IntCompanyId}' not found." });
//                }


//            }
//            rcslevelMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(rcslevelMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!RcslevelMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/RcslevelMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostRcslevelMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<RcslevelMaster>> PostRcslevelMaster(RcslevelMaster rcslevelMaster)
//        {
//          if (_context.RcslevelMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.RcslevelMasters'  is null.");
//          }
//            if (rcslevelMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            rcslevelMaster.DtUpdatedDate = DateTime.UtcNow;
//            rcslevelMaster.TsCreatedTime = DateTime.UtcNow;
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)rcslevelMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{rcslevelMaster.IntCompanyId}' not found." });
//                }


//                await _context.SaveChangesAsync();


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            _context.RcslevelMasters.Add(rcslevelMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetRcslevelMaster", new {  id = rcslevelMaster.RcslevelSeqId }, rcslevelMaster);
//        }

//        // DELETE: api/RcslevelMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteRcslevelMaster(long id)
//        //{
//        //    if (_context.RcslevelMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var rcslevelMaster = await _context.RcslevelMasters.FindAsync(id);
//        //    if (rcslevelMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.RcslevelMasters.Remove(rcslevelMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool RcslevelMasterExists(long id)
//        {
//            return (_context.RcslevelMasters?.Any(e => e.RcslevelSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
