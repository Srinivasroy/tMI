﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Master.Models.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentsMastersController : ControllerBase
    {
        private readonly MasterContext _context;

        public DepartmentsMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/DepartmentsMasters
        [HttpGet("GetDepartmentsMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<DepartmentsMaster>>> GetDepartmentsMasters()
        {
            if (_context.DepartmentsMasters == null)
            {
                return NotFound();
            }
            return await _context.DepartmentsMasters.ToListAsync();
        }

        // GET: api/DepartmentsMasters/5
        [HttpGet("GetDepartmentsMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<DepartmentsMaster>> GetDepartmentsMaster( long id)
        {
            if (_context.DepartmentsMasters == null)
            {
                return NotFound();
            }
            var departmentsMaster = await _context.DepartmentsMasters.FindAsync(id);

            if (departmentsMaster == null)
            {
                return NotFound();
            }

            return departmentsMaster;
        }

        // PUT: api/DepartmentsMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("PutDepartmentsMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PutDepartmentsMaster( long id, DepartmentsMaster departmentsMaster)
        {
            if (id != departmentsMaster.DeptsSeqId)
            {
                return BadRequest();
            }
            if (id >= 1)
            {
                if (!Helper.IntCompanyIdExists((long)departmentsMaster.IntCompanyId))
                {
                    return Conflict(new { message = $"Company Id '{departmentsMaster.IntCompanyId}' not found." });
                }

            }

            departmentsMaster.DtUpdatedDate = DateTime.UtcNow;

            _context.Entry(departmentsMaster).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepartmentsMasterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/DepartmentsMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostDepartmentsMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<DepartmentsMaster>> PostDepartmentsMaster( DepartmentsMaster departmentsMaster)
        {
            if (_context.DepartmentsMasters == null)
            {
                return Problem("Entity set 'MasterContext.DepartmentsMasters'  is null.");
            }
            if (departmentsMaster == null)
            {
                return Conflict(new { message = "Value cannot be null" });
            }
            departmentsMaster.DtUpdatedDate = DateTime.UtcNow;
            departmentsMaster.TsCreatedTime = DateTime.UtcNow;
            _context.DepartmentsMasters.Add(departmentsMaster);

            try
            {
                if (!Helper.IntCompanyIdExists((long)departmentsMaster.IntCompanyId))
                {
                    return Conflict(new { message = $"Company Id '{departmentsMaster.IntCompanyId}' not found." });
                }
                await _context.SaveChangesAsync();
            }

            catch (DbUpdateException)
            {
                throw;
            }
            return CreatedAtAction("GetDepartmentsMaster", new {  id = departmentsMaster.DeptsSeqId }, departmentsMaster);
        }

        //// DELETE: api/DepartmentsMasters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteDepartmentsMaster(long id)
        //{
        //    if (_context.DepartmentsMasters == null)
        //    {
        //        return NotFound();
        //    }
        //    var departmentsMaster = await _context.DepartmentsMasters.FindAsync(id);
        //    if (departmentsMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.DepartmentsMasters.Remove(departmentsMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool DepartmentsMasterExists(long id)
        {
            return (_context.DepartmentsMasters?.Any(e => e.DeptsSeqId == id)).GetValueOrDefault();
        }
    }
}
