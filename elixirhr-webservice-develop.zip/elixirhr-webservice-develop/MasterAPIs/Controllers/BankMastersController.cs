﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using ExcelDataReader;
using System.Data;
using static MasterAPIs.Models.Helper.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public BankMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/BankMasters
        [HttpGet("GetBankMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<BankMaster>>> GetBankMasters()
        {
            return await _context.BankMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/BankMasters/5
        [HttpGet("GetBankMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<BankMaster>> GetBankMaster(long id)
        {
            var bankMaster = await _context.BankMasters.FindAsync(id);

            if (bankMaster == null)
            {
                return NotFound();
            }

            return bankMaster;
        }

        //// PUT: api/BankMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutBankMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutBankMaster(int id, BankMaster bankMaster)
        //{
        //    if (id != bankMaster.bankId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(bankMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!BankMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/BankMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostBankMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostBankMaster(BankMaster bankMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(bankMaster.bankName))
                {
                    return Conflict("BankName can not be null");
                }

                if (bankMaster.bankId > 0)
                {
                    bankMaster.updatedBy = MasterContext.Email;
                    bankMaster.updatedDate = DateTime.UtcNow;
                    _context.BankMasters.Update(bankMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                bankMaster.createdBy = MasterContext.Email;
                bankMaster.updatedBy = bankMaster.createdBy;
                bankMaster.createdTime = DateTime.UtcNow;
                bankMaster.updatedDate = DateTime.UtcNow;
                bankMaster.companyId = currentCompanyId;
                _context.BankMasters.Add(bankMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }


        [HttpPost("BankBulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> BankBulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                //return new { message = "No file was uploaded !!!" };
                return Conflict(new { message = "No file was uploaded !!!" });

            }
            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                // return new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" };
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    var bankRows = dataTable.AsEnumerable().Select(x => x["bankName"].ToString()).Distinct().ToList();
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any bank data!" });
                    }
                    foreach (var bankRow in bankRows)
                    {
                        var conFil = _context.BankMasters.Where(x => x.bankName == bankRow.ToString() && x.companyId == currentCompanyId).FirstOrDefault();
                        if (conFil == null)
                        {
                            var bankMaster = new BankMaster
                            {
                                bankName = bankRow.ToString(),
                                companyId = currentCompanyId,
                                createdBy = MasterContext.Email,
                                createdTime = DateTime.UtcNow,
                                status = (int)Statuses.Approved,
                                updatedBy = MasterContext.Email,
                                updatedDate = DateTime.UtcNow,
                            };
                            _context.BankMasters.Add(bankMaster);
                        }
                     

                    }
                    await _context.SaveChangesAsync();
                    //return Ok("File uploaded sucessfully!!!");
                    return new { message = "File uploaded sucessfully!!!", status = "success" };
                    // "message": "File uploaded successfully",

                }
            }
        }


        // DELETE: api/BankMasters/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteBankMaster(long id)
        {
            var bankMaster = await _context.BankMasters.FindAsync(id);
            if (bankMaster == null)
            {
                return NotFound();
            }

            _context.BankMasters.Remove(bankMaster);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BankMasterExists(int id)
        {
            return _context.BankMasters.Any(e => e.bankId == id);
        }
    }
}
