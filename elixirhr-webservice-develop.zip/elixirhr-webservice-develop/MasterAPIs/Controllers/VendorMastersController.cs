﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class VendorMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public VendorMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/VendorMasters
//        [HttpGet("GetVendorMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<VendorMaster>>> GetVendorMasters()
//        {
//          if (_context.VendorMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.VendorMasters.ToListAsync();
//        }

//        // GET: api/VendorMasters/5
//        [HttpGet("GetVendorMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<VendorMaster>> GetVendorMaster( long id)
//        {
//          if (_context.VendorMasters == null)
//          {
//              return NotFound();
//          }
//            var vendorMaster = await _context.VendorMasters.FindAsync(id);

//            if (vendorMaster == null)
//            {
//                return NotFound();
//            }

//            return vendorMaster;
//        }

//        // PUT: api/VendorMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutVendorMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutVendorMaster( long id, VendorMaster vendorMaster)
//        {
//            if (id != vendorMaster.VendorSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)vendorMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{vendorMaster.IntCompanyId}' not found." });
//                }


//            }

//            vendorMaster.VendorSeqId = id;
//            vendorMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(vendorMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!VendorMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/VendorMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostVendorMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<VendorMaster>> PostVendorMaster( VendorMaster vendorMaster)
//        {
//          if (_context.VendorMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.VendorMasters'  is null.");
//          }
//            if (vendorMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            vendorMaster.DtUpdatedDate = DateTime.UtcNow;
//            vendorMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.VendorMasters.Add(vendorMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)vendorMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{vendorMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            return CreatedAtAction("GetVendorMaster", new {  id = vendorMaster.VendorSeqId }, vendorMaster);
//        }

//        // DELETE: api/VendorMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteVendorMaster(long id)
//        //{
//        //    if (_context.VendorMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var vendorMaster = await _context.VendorMasters.FindAsync(id);
//        //    if (vendorMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.VendorMasters.Remove(vendorMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool VendorMasterExists(long id)
//        {
//            return (_context.VendorMasters?.Any(e => e.VendorSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
