﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class EmployeeCategoryMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public EmployeeCategoryMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/EmployeeCategoryMasters
//        [HttpGet("EmployeeCategoryMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<EmployeeCategoryMaster>>> GetEmployeeCategoryMasters()
//        {
//          if (_context.EmployeeCategoryMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.EmployeeCategoryMasters.ToListAsync();
//        }

//        // GET: api/EmployeeCategoryMasters/5
//        [HttpGet("GetEmployeeCategoryMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<EmployeeCategoryMaster>> GetEmployeeCategoryMaster( long id)
//        {
//          if (_context.EmployeeCategoryMasters == null)
//          {
//              return NotFound();
//          }
//            var employeeCategoryMaster = await _context.EmployeeCategoryMasters.FindAsync(id);

//            if (employeeCategoryMaster == null)
//            {
//                return NotFound();
//            }

//            return employeeCategoryMaster;
//        }

//        // PUT: api/EmployeeCategoryMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutEmployeeCategoryMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutEmployeeCategoryMaster( long id, EmployeeCategoryMaster employeeCategoryMaster)
//        {
//            if (id != employeeCategoryMaster.EmployeeCategorySeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)employeeCategoryMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{employeeCategoryMaster.IntCompanyId}' not found." });
//                }


//            }

//            employeeCategoryMaster.EmployeeCategorySeqId = id;
//            employeeCategoryMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(employeeCategoryMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!EmployeeCategoryMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/EmployeeCategoryMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostEmployeeCategoryMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<EmployeeCategoryMaster>> PostEmployeeCategoryMaster( EmployeeCategoryMaster employeeCategoryMaster)
//        {
//          if (_context.EmployeeCategoryMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.EmployeeCategoryMasters'  is null.");
//          }
//            if (employeeCategoryMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            employeeCategoryMaster.DtUpdatedDate = DateTime.UtcNow;
//            employeeCategoryMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.EmployeeCategoryMasters.Add(employeeCategoryMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)employeeCategoryMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{employeeCategoryMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }


//            return CreatedAtAction("GetEmployeeCategoryMaster", new {  id = employeeCategoryMaster.EmployeeCategorySeqId }, employeeCategoryMaster);
//        }

//        // DELETE: api/EmployeeCategoryMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteEmployeeCategoryMaster(long id)
//        //{
//        //    if (_context.EmployeeCategoryMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var employeeCategoryMaster = await _context.EmployeeCategoryMasters.FindAsync(id);
//        //    if (employeeCategoryMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.EmployeeCategoryMasters.Remove(employeeCategoryMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool EmployeeCategoryMasterExists(long id)
//        {
//            return (_context.EmployeeCategoryMasters?.Any(e => e.EmployeeCategorySeqId == id)).GetValueOrDefault();
//        }
//    }
//}
