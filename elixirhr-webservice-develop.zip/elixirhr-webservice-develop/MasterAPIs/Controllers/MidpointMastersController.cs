﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using System.Net;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class MidpointMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public MidpointMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/MidpointMasters
//        [HttpGet("GetMidpointMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<MidpointMaster>>> GetMidpointMasters()
//        {
//          if (_context.MidpointMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.MidpointMasters.ToListAsync();
//        }

//        // GET: api/MidpointMasters/5
//        [HttpGet("GetMidpointMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<MidpointMaster>> GetMidpointMaster( long id)
//        {
//          if (_context.MidpointMasters == null)
//          {
//              return NotFound();
//          }
//            var midpointMaster = await _context.MidpointMasters.FindAsync(id);

//            if (midpointMaster == null)
//            {
//                return NotFound();
//            }

//            return midpointMaster;
//        }

//        // PUT: api/MidpointMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut(("PutMidpointMaster/{id}"))]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutMidpointMaster( long id, MidpointMaster midpointMaster)
//        {
//            if (id != midpointMaster.MidpointSeqId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)midpointMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{midpointMaster.IntCompanyId}' not found." });
//                }

//            }

//            midpointMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(midpointMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!MidpointMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/MidpointMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostMidpointMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<MidpointMaster>> PostMidpointMaster( MidpointMaster midpointMaster)
//        {
//          if (_context.MidpointMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.MidpointMasters'  is null.");
//          }

//            if (midpointMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }

//            midpointMaster.DtUpdatedDate = DateTime.UtcNow;
//            midpointMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.MidpointMasters.Add(midpointMaster);
//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)midpointMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{midpointMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();

//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
           

//            return CreatedAtAction("GetMidpointMaster", new {  id = midpointMaster.MidpointSeqId }, midpointMaster);
//        }

//        // DELETE: api/MidpointMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteMidpointMaster(long id)
//        //{
//        //    if (_context.MidpointMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var midpointMaster = await _context.MidpointMasters.FindAsync(id);
//        //    if (midpointMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.MidpointMasters.Remove(midpointMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool MidpointMasterExists(long id)
//        {
//            return (_context.MidpointMasters?.Any(e => e.MidpointSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
