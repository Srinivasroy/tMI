﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public CategoryMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/CategoryMasters
        [HttpGet("GetCategories")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<CategoryMaster>>> GetCategories()
        {
            return await _context.Categories.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/CategoryMasters/5
        [HttpGet("GetCategoryMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<CategoryMaster>> GetCategoryMaster(long id)
        {
            var categoryMaster = await _context.Categories.FindAsync(id);

            if (categoryMaster == null)
            {
                return NotFound();
            }

            return categoryMaster;
        }

        //// PUT: api/CategoryMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutCategoryMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        //public async Task<IActionResult> PutCategoryMaster(long id, CategoryMaster categoryMaster)
        //{
        //    if (id != categoryMaster.CategoryId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(categoryMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!CategoryMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/CategoryMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostCategoryMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostCategoryMaster(CategoryMaster categoryMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(categoryMaster.empCategoryName))
                {
                    return Conflict("CategoryName can not be null");
                }

                if (categoryMaster.categoryId > 0)
                {
                    categoryMaster.updatedBy = MasterContext.Email;
                    categoryMaster.updatedDate = DateTime.UtcNow;
                    _context.Categories.Update(categoryMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                categoryMaster.createdBy = MasterContext.Email;
                categoryMaster.updatedBy = categoryMaster.createdBy;
                categoryMaster.createdTime = DateTime.UtcNow;
                categoryMaster.updatedDate = DateTime.UtcNow;
                categoryMaster.companyId = currentCompanyId;
                _context.Categories.Add(categoryMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }

        // DELETE: api/CategoryMasters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteCategoryMaster(long id)
        //{
        //    var categoryMaster = await _context.Categories.FindAsync(id);
        //    if (categoryMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Categories.Remove(categoryMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool CategoryMasterExists(long id)
        {
            return _context.Categories.Any(e => e.categoryId == id);
        }
    }
}
