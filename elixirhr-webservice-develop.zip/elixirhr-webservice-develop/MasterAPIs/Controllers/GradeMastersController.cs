﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GradeMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public GradeMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/GradeMasters
        [HttpGet("GetGradeMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<GradeMaster>>> GetGradeMasters()
        {

           return await _context.GradeMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        [HttpGet("GetGradeMasters1")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<LocationMasterViewModel>> GetGradeMasters1()
        {
            try
            {
                if (_context.GradeMasters == null)
                {
                    return NotFound();
                }
                var gradeviewmodel = new LocationMasterViewModel
                {
                    locationMasterlist = await _context.LocationMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                   
                };


                return gradeviewmodel;
                //return await _context.LocationMasters.Where(x => x.CompanyId == currentCompanyId).ToListAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/GradeMasters/5
        [HttpGet("GetGradeMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<GradeMaster>> GetGradeMaster(long id)
        {
            var gradeMaster = await _context.GradeMasters.FindAsync(id);

            if (gradeMaster == null)
            {
                return NotFound();
            }

            return gradeMaster;
        }

        // PUT: api/GradeMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutGradeMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutGradeMaster(int id, GradeMaster gradeMaster)
        //{
        //    if (id != gradeMaster.gradeId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(gradeMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!GradeMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/GradeMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostGradeMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostGradeMaster(GradeMaster gradeMaster)
        {
            try
            {
                if (gradeMaster.gradeId == 0)
                {
                    if (RCSGradeNameExists(gradeMaster.RCSgradeName, gradeMaster.companyId, gradeMaster.locationId))
                    {
                        return Conflict(new { message = $"RCSGradeName  '{gradeMaster.RCSgradeName}' already exists" });
                    }
                }

                gradeMaster.createdTime = DateTime.UtcNow;
                gradeMaster.updatedDate = gradeMaster.createdTime;
                gradeMaster.createdBy = EmailId;
                gradeMaster.updatedBy = gradeMaster.createdBy;
                _context.GradeMasters.Update(gradeMaster);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
                //throw;
            }
            var grademasterjson = JsonConvert.SerializeObject(gradeMaster);
            var _grademaster = System.Text.Json.JsonSerializer.Deserialize<object>(grademasterjson);

            return _grademaster;

            //return CreatedAtAction("GetGradeMaster", new { id = gradeMaster.gradeId }, gradeMaster);
        }

        // DELETE: api/GradeMasters/5
        //[HttpDelete("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> DeleteGradeMaster(int id)
        //{
        //    var gradeMaster = await _context.GradeMasters.FindAsync(id);
        //    if (gradeMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.GradeMasters.Remove(gradeMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool GradeMasterExists(long id)
        {
            return _context.GradeMasters.Any(e => e.gradeId == id);
        }
        private bool RCSGradeNameExists(string RCSGradeName, long? companyId, long? locationId)
        {
            return _context.GradeMasters.Any(e => e.RCSgradeName == RCSGradeName && e.companyId == companyId && e.locationId == locationId);
        }
    }
}
