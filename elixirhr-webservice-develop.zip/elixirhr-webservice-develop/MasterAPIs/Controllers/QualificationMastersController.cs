﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class QualificationMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public QualificationMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/QualificationMasters
//        [HttpGet("GetQualificationMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<QualificationMaster>>> GetQualificationMasters()
//        {
//            if (_context.QualificationMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.QualificationMasters.ToListAsync();
//        }

//        // GET: api/QualificationMasters/5
//        [HttpGet("GetQualificationMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<QualificationMaster>> GetQualificationMaster( long id)
//        {
//            if (_context.QualificationMasters == null)
//            {
//                return NotFound();
//            }
//            var qualificationMaster = await _context.QualificationMasters.FindAsync(id);

//            if (qualificationMaster == null)
//            {
//                return NotFound();
//            }

//            return qualificationMaster;
//        }

//        // PUT: api/QualificationMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutQualificationMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutQualificationMaster( long id, QualificationMaster qualificationMaster)
//        {
//            if (id != qualificationMaster.QualificationSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)qualificationMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{qualificationMaster.IntCompanyId}' not found." });
//                }

//            }

//            qualificationMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(qualificationMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!QualificationMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/QualificationMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostQualificationMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<QualificationMaster>> PostQualificationMaster( QualificationMaster qualificationMaster)
//        {
//            if (_context.QualificationMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.QualificationMasters'  is null.");
//            }
//            if (qualificationMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            qualificationMaster.DtUpdatedDate = DateTime.UtcNow;
//            qualificationMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.QualificationMasters.Add(qualificationMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)qualificationMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{qualificationMaster.IntCompanyId}' not found." });
//                }
//                await _context.SaveChangesAsync();
//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            return CreatedAtAction("GetQualificationMaster", new {  id = qualificationMaster.QualificationSeqId }, qualificationMaster);
//        }

//        //// DELETE: api/QualificationMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteQualificationMaster(long id)
//        //{
//        //    if (_context.QualificationMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var qualificationMaster = await _context.QualificationMasters.FindAsync(id);
//        //    if (qualificationMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.QualificationMasters.Remove(qualificationMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool QualificationMasterExists(long id)
//        {
//            return (_context.QualificationMasters?.Any(e => e.QualificationSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
