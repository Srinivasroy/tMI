﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ProductivityFactorMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ProductivityFactorMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ProductivityFactorMasters
//        [HttpGet("GetProductivityFactorMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ProductivityFactorMaster>>> GetProductivityFactorMasters()
//        {
//          if (_context.ProductivityFactorMasters == null)
//          {
//              return NotFound();
//          }
           
//            return await _context.ProductivityFactorMasters.ToListAsync();
//        }

//        // GET: api/ProductivityFactorMasters/5
//        [HttpGet("GetProductivityFactorMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ProductivityFactorMaster>> GetProductivityFactorMaster( long id)
//        {
//          if (_context.ProductivityFactorMasters == null)
//          {
//              return NotFound();
//          }
//            var productivityFactorMaster = await _context.ProductivityFactorMasters.FindAsync(id);

//            if (productivityFactorMaster == null)
//            {
//                return NotFound();
//            }

//            return productivityFactorMaster;
//        }

//        // PUT: api/ProductivityFactorMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutProductivityFactorMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutProductivityFactorMaster( long id, ProductivityFactorMaster productivityFactorMaster)
//        {
//            if (id != productivityFactorMaster.ProductivityFactorSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)productivityFactorMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{productivityFactorMaster.IntCompanyId}' not found." });
//                }


//            }

//            productivityFactorMaster.ProductivityFactorSeqId = id;
//            productivityFactorMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(productivityFactorMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ProductivityFactorMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ProductivityFactorMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostProductivityFactorMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ProductivityFactorMaster>> PostProductivityFactorMaster( ProductivityFactorMaster productivityFactorMaster)
//        {
//          if (_context.ProductivityFactorMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ProductivityFactorMasters'  is null.");
//          }
//            if (productivityFactorMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            productivityFactorMaster.DtUpdatedDate = DateTime.UtcNow;
//            productivityFactorMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.ProductivityFactorMasters.Add(productivityFactorMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)productivityFactorMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{productivityFactorMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            return CreatedAtAction("GetProductivityFactorMaster", new {  id = productivityFactorMaster.ProductivityFactorSeqId }, productivityFactorMaster);
//        }

//        // DELETE: api/ProductivityFactorMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteProductivityFactorMaster(long id)
//        //{
//        //    if (_context.ProductivityFactorMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var productivityFactorMaster = await _context.ProductivityFactorMasters.FindAsync(id);
//        //    if (productivityFactorMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ProductivityFactorMasters.Remove(productivityFactorMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ProductivityFactorMasterExists(long id)
//        {
//            return (_context.ProductivityFactorMasters?.Any(e => e.ProductivityFactorSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
