﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using ExcelDataReader;
using System.Data;
using static MasterAPIs.Models.Helper.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchMastersController : ControllerBase
    {
        private readonly MasterContext _context;

        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public BranchMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/BranchMasters
        [HttpGet("GetBranchMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<BranchMaster>>> GetBranchMaster()
        {
            return await _context.BranchMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/BranchMasters/5
        [HttpGet("GetBranchMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<BranchMaster>> GetBranchMaster(int id)
        {
            var branchMaster = await _context.BranchMasters.FindAsync(id);

            if (branchMaster == null)
            {
                return NotFound();
            }

            return branchMaster;
        }

        //// PUT: api/BranchMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutBranchMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutBranchMaster(int id, BranchMaster branchMaster)
        //{
        //    if (id != branchMaster.branchId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(branchMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!BranchMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/BranchMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostBranchMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostBranchMaster(BranchMaster branchMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(branchMaster.branchName))
                {
                    return Conflict("BranchName can not be null");
                }

                if (branchMaster.branchId > 0)
                {
                    branchMaster.updatedBy = MasterContext.Email;
                    branchMaster.updatedTime = DateTime.UtcNow;
                    _context.BranchMasters.Update(branchMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                branchMaster.createdBy = MasterContext.Email;
                branchMaster.updatedBy = branchMaster.createdBy;
                branchMaster.createdTime = DateTime.UtcNow;
                branchMaster.updatedTime = DateTime.UtcNow;
                branchMaster.companyId = currentCompanyId;
                _context.BranchMasters.Add(branchMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }

        [HttpPost("BranchBulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> BranchBulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {

                return Conflict(new { message = "No file was uploaded !!!" });

            }
            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    var Rows = dataTable.AsEnumerable().Select(x => x["branchName"].ToString()).Distinct().ToList();
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any data!" });
                    }
                    foreach (var Row in Rows)
                    {
                        var conFil = _context.BranchMasters.Where(x => x.branchName == Row.ToString() && x.companyId == currentCompanyId).FirstOrDefault();
                        if (conFil == null)
                        {
                            var branchMaster = new BranchMaster
                            {
                                branchName = Row.ToString(),
                                companyId = currentCompanyId,
                                createdBy = MasterContext.Email,
                                createdTime = DateTime.UtcNow,
                                status = (int)Statuses.Approved,
                                updatedBy = MasterContext.Email,
                                updatedTime = DateTime.UtcNow,
                            };
                            _context.BranchMasters.Add(branchMaster);
                        }


                    }
                    await _context.SaveChangesAsync();
                    return new { message = "File uploaded sucessfully!!!", status = "success" };

                }
            }
        }




        //// DELETE: api/BranchMasters/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBranchMaster(long id)
        {
            var branchMaster = await _context.BranchMasters.FindAsync(id);
            if (branchMaster == null)
            {
                return NotFound();
            }

            _context.BranchMasters.Remove(branchMaster);
            await _context.SaveChangesAsync();

            return NoContent();
        }



        private bool BranchMasterExists(int id)
        {
            return _context.BranchMasters.Any(e => e.branchId == id);
        }
    }
}
