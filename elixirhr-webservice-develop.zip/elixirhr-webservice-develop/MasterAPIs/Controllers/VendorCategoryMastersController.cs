﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class VendorCategoryMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public VendorCategoryMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/VendorCategoryMasters
//        [HttpGet("GetVendorCategoryMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<VendorCategoryMaster>>> GetVendorCategoryMasters()
//        {
//            if (_context.VendorCategoryMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.VendorCategoryMasters.ToListAsync();
//        }

//        // GET: api/VendorCategoryMasters/5
//        [HttpGet("GetVendorCategoryMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<VendorCategoryMaster>> GetVendorCategoryMaster( long id)
//        {
//            if (_context.VendorCategoryMasters == null)
//            {
//                return NotFound();
//            }
//            var vendorCategoryMaster = await _context.VendorCategoryMasters.FindAsync(id);

//            if (vendorCategoryMaster == null)
//            {
//                return NotFound();
//            }

//            return vendorCategoryMaster;
//        }

//        // PUT: api/VendorCategoryMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutVendorCategoryMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutVendorCategoryMaster( long id, VendorCategoryMaster vendorCategoryMaster)
//        {
//            if (id != vendorCategoryMaster.VendorCategorySeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)vendorCategoryMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{vendorCategoryMaster.IntCompanyId}' not found." });
//                }

//            }

//            vendorCategoryMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(vendorCategoryMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!VendorCategoryMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/VendorCategoryMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostVendorCategoryMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<VendorCategoryMaster>> PostVendorCategoryMaster( VendorCategoryMaster vendorCategoryMaster)
//        {
//            if (_context.VendorCategoryMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.VendorCategoryMasters'  is null.");
//            }
//            if (vendorCategoryMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            vendorCategoryMaster.DtUpdatedDate = DateTime.UtcNow;
//            vendorCategoryMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.VendorCategoryMasters.Add(vendorCategoryMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)vendorCategoryMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{vendorCategoryMaster.IntCompanyId}' not found." });
//                }

//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetVendorCategoryMaster", new {  id = vendorCategoryMaster.VendorCategorySeqId }, vendorCategoryMaster);
//        }

//        //// DELETE: api/VendorCategoryMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteVendorCategoryMaster(long id)
//        //{
//        //    if (_context.VendorCategoryMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var vendorCategoryMaster = await _context.VendorCategoryMasters.FindAsync(id);
//        //    if (vendorCategoryMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.VendorCategoryMasters.Remove(vendorCategoryMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool VendorCategoryMasterExists(long id)
//        {
//            return (_context.VendorCategoryMasters?.Any(e => e.VendorCategorySeqId == id)).GetValueOrDefault();
//        }
//    }
//}
