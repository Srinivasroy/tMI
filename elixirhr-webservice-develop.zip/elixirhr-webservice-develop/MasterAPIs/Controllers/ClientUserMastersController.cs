﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ClientUserMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ClientUserMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ClientUserMasters
//        [HttpGet("GetClientUserMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<IEnumerable<ClientUserMaster>>> GetClientUserMasters()
//        {
//          if (_context.ClientUserMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.ClientUserMasters.ToListAsync();
//        }

//        // GET: api/ClientUserMasters/5
//        [HttpGet("GetClientUserMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<ClientUserMaster>> GetClientUserMaster( long id)
//        {
//          if (_context.ClientUserMasters == null)
//          {
//              return NotFound();
//          }
//            var clientUserMaster = await _context.ClientUserMasters.FindAsync(id);

//            if (clientUserMaster == null)
//            {
//                return NotFound();
//            }

//            return clientUserMaster;
//        }

//        // PUT: api/ClientUserMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutClientUserMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<object>> PutClientUserMaster( long id, ClientUserMaster clientUserMaster)
//        {
//            if (id != clientUserMaster.ClientSeqId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)clientUserMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{clientUserMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntEmpIdExists((long)clientUserMaster.IntEmpSeqId))
//                {
//                    return Conflict(new { message = $"EmpSeqId Id '{clientUserMaster.IntEmpSeqId}' not found." });
//                }
//                if (!Helper.IntClientIdExists((long)clientUserMaster.IntClientId))
//                {
//                    return Conflict(new { message = $"ClientId Id '{clientUserMaster.IntClientId}' not found." });
//                }
//                if (!Helper.IntClientModuleGrpIdExists((long)clientUserMaster.IntClientModuleGrpId))
//                {
//                    return Conflict(new { message = $"ClientModuleGrp Id '{clientUserMaster.IntClientModuleGrpId}' not found." });
//                }
//                if (!Helper.IntClientUserRoleIdExists((long)clientUserMaster.IntClientUserRoleId))
//                {
//                    return Conflict(new { message = $"ClientUserRole Id '{clientUserMaster.IntClientUserRoleId}' not found." });
//                }
//                if (!Helper.IntCompanyRoleIdExists((long)clientUserMaster.IntCompanyRoleId))
//                {
//                    return Conflict(new { message = $"CompanyRole Id '{clientUserMaster.IntCompanyRoleId}' not found." });
//                }
//            }

//            clientUserMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(clientUserMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ClientUserMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ClientUserMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostClientUserMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<ClientUserMaster>> PostClientUserMaster( ClientUserMaster clientUserMaster)
//        {
//          if (_context.ClientUserMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ClientUserMasters'  is null.");
//          }
//            if (clientUserMaster == null)
//            {
//                return Conflict(new { message = "Value should not be null." });
//            }
//            clientUserMaster.TsCreatedTime = DateTime.UtcNow;
//            clientUserMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.ClientUserMasters.Add(clientUserMaster);
           
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)clientUserMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{clientUserMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntEmpIdExists((long)clientUserMaster.IntEmpSeqId))
//                {
//                    return Conflict(new { message = $"EmpSeq Id '{clientUserMaster.IntEmpSeqId}' not found." });
//                }
//                if (!Helper.IntClientIdExists((long)clientUserMaster.IntClientId))
//                {
//                    return Conflict(new { message = $"Client Id '{clientUserMaster.IntClientId}' not found." });
//                }
//                if (!Helper.IntClientModuleGrpIdExists((long)clientUserMaster.IntClientModuleGrpId))
//                {
//                    return Conflict(new { message = $"ClientModuleGrp Id '{clientUserMaster.IntClientModuleGrpId}' not found." });
//                }
//                if (!Helper.IntClientUserRoleIdExists((long)clientUserMaster.IntClientUserRoleId))
//                {
//                    return Conflict(new { message = $"ClientUserRole Id '{clientUserMaster.IntClientUserRoleId}' not found." });
//                }
//                if (!Helper.IntCompanyRoleIdExists((long)clientUserMaster.IntCompanyRoleId))
//                {
//                    return Conflict(new { message = $"CompanyRole Id '{clientUserMaster.IntCompanyRoleId}' not found." });
//                }

//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetClientUserMaster", new {  id = clientUserMaster.ClientSeqId }, clientUserMaster);
//        }

//        // DELETE: api/ClientUserMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteClientUserMaster(long id)
//        //{
//        //    if (_context.ClientUserMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var clientUserMaster = await _context.ClientUserMasters.FindAsync(id);
//        //    if (clientUserMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ClientUserMasters.Remove(clientUserMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ClientUserMasterExists(long id)
//        {
//            return (_context.ClientUserMasters?.Any(e => e.ClientSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
