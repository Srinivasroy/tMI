﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class EmployeeMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public EmployeeMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/EmployeeMasters
//        [HttpGet("GetEmployeeMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<EmployeeMaster>>> GetEmployeeMasters()
//        {
//            if (_context.EmployeeMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.EmployeeMasters.ToListAsync();
//        }

//        // GET: api/EmployeeMasters/5
//        [HttpGet("GetEmployeeMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<EmployeeMaster>> GetEmployeeMaster( long id)
//        {
//            if (_context.EmployeeMasters == null)
//            {
//                return NotFound();
//            }
//            var employeeMaster = await _context.EmployeeMasters.FindAsync(id);

//            if (employeeMaster == null)
//            {
//                return NotFound();
//            }

//            return employeeMaster;
//        }

//        // PUT: api/EmployeeMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutEmployeeMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutEmployeeMaster( long id, EmployeeMaster employeeMaster)
//        {
//            if (id != employeeMaster.EmployeeSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)employeeMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{employeeMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.AbeCodeValueExists((long)employeeMaster.AbeCodeValue))
//                {
//                    return Conflict(new { message = $"AbeCodeValue Id '{employeeMaster.AbeCodeValue}' not found." });
//                }
//                if (!Helper.BankNameExists((long)employeeMaster.BankName))
//                {
//                    return Conflict(new { message = $"BankName Id '{employeeMaster.BankName}' not found." });
//                }
//                if (!Helper.EmploymentTypeExists((long)employeeMaster.EmploymentType))
//                {
//                    return Conflict(new { message = $"EmploymentType Id '{employeeMaster.EmploymentType}' not found." });
//                }
//                if (!Helper.ItsRoleSfiaValueExists((long)employeeMaster.ItsRoleSfiaValue))
//                {
//                    return Conflict(new { message = $"ItsRoleSfiaValue Id '{employeeMaster.ItsRoleSfiaValue}' not found." });
//                }
//                if (!Helper.LeaveGroupExists((long)employeeMaster.LeaveGroup))
//                {
//                    return Conflict(new { message = $"LeaveGroup Id '{employeeMaster.LeaveGroup}' not found." });
//                }
//                if (!Helper.MaritalStatusExists((long)employeeMaster.MaritalStatus))
//                {
//                    return Conflict(new { message = $"MaritalStatus Id '{employeeMaster.MaritalStatus}' not found." });
//                }
//                if (!Helper.IntCompanyRoleIdExists((long)employeeMaster.IntCompanyRoleId))
//                {
//                    return Conflict(new { message = $"CompanyRole Id '{employeeMaster.IntCompanyRoleId}' not found." });
//                }
//                if (!Helper.DepartmentsExists((long)employeeMaster.Departments))
//                {
//                    return Conflict(new { message = $"Departments Id '{employeeMaster.Departments}' not found." });
//                }
//                if (!Helper.IntRcsgradeIdExists((long)employeeMaster.IntRcsgradeId))
//                {
//                    return Conflict(new { message = $"IntRcsgrade Id '{employeeMaster.IntRcsgradeId}' not found." });
//                }
//                if (!Helper.MidpointValueExists((long)employeeMaster.MidpointValue))
//                {
//                    return Conflict(new { message = $"MidpointValue Id '{employeeMaster.MidpointValue}' not found." });
//                }
//                if (!Helper.PhysicalStatusExists((long)employeeMaster.PhysicalStatus))
//                {
//                    return Conflict(new { message = $"PhysicalStatus Id '{employeeMaster.PhysicalStatus}' not found." });
//                }
//                if (!Helper.ProductivityFactorExists((long)employeeMaster.ProductivityFactor))
//                {
//                    return Conflict(new { message = $"ProductivityFactor Id '{employeeMaster.ProductivityFactor}' not found." });
//                }
//                if (!Helper.RcslevelValueExists((long)employeeMaster.RcslevelValue))
//                {
//                    return Conflict(new { message = $"RcslevelValue Id '{employeeMaster.RcslevelValue}' not found." });
//                }
//                if (!Helper.SubdepartmentExists((long)employeeMaster.Subdepartment))
//                {
//                    return Conflict(new { message = $"Subdepartment Id '{employeeMaster.Subdepartment}' not found." });
//                }
//                if (!Helper.TaxSlabOptedExists((long)employeeMaster.TaxSlabOpted))
//                {
//                    return Conflict(new { message = $"Subdepartment Id '{employeeMaster.TaxSlabOpted}' not found." });
//                }
//                if (!Helper.DesignationExists((long)employeeMaster.Designation))
//                {
//                    return Conflict(new { message = $"Designation Id '{employeeMaster.Designation}' not found." });
//                }
//                if (!Helper.CostcenterExists((long)employeeMaster.Costcenter))
//                {
//                    return Conflict(new { message = $"Costcenter Id '{employeeMaster.Costcenter}' not found." });
//                }
//                if (!Helper.DepartmentExists((long)employeeMaster.Department))
//                {
//                    return Conflict(new { message = $"Department Id '{employeeMaster.Department}' not found." });
//                }
//                if (!Helper.LocationExists((long)employeeMaster.Location))
//                {
//                    return Conflict(new { message = $"Location Id '{employeeMaster.Location}' not found." });
//                }
//                if (!Helper.CategoryExists((long)employeeMaster.Category))
//                {
//                    return Conflict(new { message = $"Category Id '{employeeMaster.Category}' not found." });
//                }
//                if (!Helper.IntGradeIdExists((long)employeeMaster.IntGradeId))
//                {
//                    return Conflict(new { message = $"IntGrade Id '{employeeMaster.IntGradeId}' not found." });
//                }
//            }

//            //employeeMaster.EmployeeSeqId = id;
//            employeeMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(employeeMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!EmployeeMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/EmployeeMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostEmployeeMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<EmployeeMaster>> PostEmployeeMaster( EmployeeMaster employeeMaster)
//        {
//            if (_context.EmployeeMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.EmployeeMasters'  is null.");
//            }
//            if (employeeMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            employeeMaster.DtUpdatedDate = DateTime.UtcNow;
//            employeeMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.EmployeeMasters.Add(employeeMaster);

//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)employeeMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{employeeMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.AbeCodeValueExists((long)employeeMaster.AbeCodeValue))
//                {
//                    return Conflict(new { message = $"AbeCodeValue Id '{employeeMaster.AbeCodeValue}' not found." });
//                }
//                if (!Helper.BankNameExists((long)employeeMaster.BankName))
//                {
//                    return Conflict(new { message = $"BankName Id '{employeeMaster.BankName}' not found." });
//                }
//                if (!Helper.EmploymentTypeExists((long)employeeMaster.EmploymentType))
//                {
//                    return Conflict(new { message = $"EmploymentType Id '{employeeMaster.EmploymentType}' not found." });
//                }
//                if (!Helper.ItsRoleSfiaValueExists((long)employeeMaster.ItsRoleSfiaValue))
//                {
//                    return Conflict(new { message = $"ItsRoleSfiaValue Id '{employeeMaster.ItsRoleSfiaValue}' not found." });
//                }
//                if (!Helper.LeaveGroupExists((long)employeeMaster.LeaveGroup))
//                {
//                    return Conflict(new { message = $"LeaveGroup Id '{employeeMaster.LeaveGroup}' not found." });
//                }
//                if (!Helper.MaritalStatusExists((long)employeeMaster.MaritalStatus))
//                {
//                    return Conflict(new { message = $"MaritalStatus Id '{employeeMaster.MaritalStatus}' not found." });
//                }
//                if (!Helper.IntCompanyRoleIdExists((long)employeeMaster.IntCompanyRoleId))
//                {
//                    return Conflict(new { message = $"CompanyRole Id '{employeeMaster.IntCompanyRoleId}' not found." });
//                }
//                if (!Helper.DepartmentsExists((long)employeeMaster.Departments))
//                {
//                    return Conflict(new { message = $"Departments Id '{employeeMaster.Departments}' not found." });
//                }
//                if (!Helper.IntRcsgradeIdExists((long)employeeMaster.IntRcsgradeId))
//                {
//                    return Conflict(new { message = $"IntRcsgrade Id '{employeeMaster.IntRcsgradeId}' not found." });
//                }
//                if (!Helper.MidpointValueExists((long)employeeMaster.MidpointValue))
//                {
//                    return Conflict(new { message = $"MidpointValue Id '{employeeMaster.MidpointValue}' not found." });
//                }
//                if (!Helper.PhysicalStatusExists((long)employeeMaster.PhysicalStatus))
//                {
//                    return Conflict(new { message = $"PhysicalStatus Id '{employeeMaster.PhysicalStatus}' not found." });
//                }
//                if (!Helper.ProductivityFactorExists((long)employeeMaster.ProductivityFactor))
//                {
//                    return Conflict(new { message = $"ProductivityFactor Id '{employeeMaster.ProductivityFactor}' not found." });
//                }
//                if (!Helper.RcslevelValueExists((long)employeeMaster.RcslevelValue))
//                {
//                    return Conflict(new { message = $"RcslevelValue Id '{employeeMaster.RcslevelValue}' not found." });
//                }
//                if (!Helper.SubdepartmentExists((long)employeeMaster.Subdepartment))
//                {
//                    return Conflict(new { message = $"Subdepartment Id '{employeeMaster.Subdepartment}' not found." });
//                }
//                if (!Helper.TaxSlabOptedExists((long)employeeMaster.TaxSlabOpted))
//                {
//                    return Conflict(new { message = $"Subdepartment Id '{employeeMaster.TaxSlabOpted}' not found." });
//                }
//                if (!Helper.DesignationExists((long)employeeMaster.Designation))
//                {
//                    return Conflict(new { message = $"Designation Id '{employeeMaster.Designation}' not found." });
//                }
//                if (!Helper.CostcenterExists((long)employeeMaster.Costcenter))
//                {
//                    return Conflict(new { message = $"Costcenter Id '{employeeMaster.Costcenter}' not found." });
//                }
//                if (!Helper.DepartmentExists((long)employeeMaster.Department))
//                {
//                    return Conflict(new { message = $"Department Id '{employeeMaster.Department}' not found." });
//                }
//                if (!Helper.LocationExists((long)employeeMaster.Location))
//                {
//                    return Conflict(new { message = $"Location Id '{employeeMaster.Location}' not found." });
//                }
//                if (!Helper.CategoryExists((long)employeeMaster.Category))
//                {
//                    return Conflict(new { message = $"Category Id '{employeeMaster.Category}' not found." });
//                }
//                if (!Helper.IntGradeIdExists((long)employeeMaster.IntGradeId))
//                {
//                    return Conflict(new { message = $"IntGrade Id '{employeeMaster.IntGradeId}' not found." });
//                }


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetEmployeeMaster", new {  id = employeeMaster.EmployeeSeqId }, employeeMaster);
//        }

//        // DELETE: api/EmployeeMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteEmployeeMaster(long id)
//        //{
//        //    if (_context.EmployeeMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var employeeMaster = await _context.EmployeeMasters.FindAsync(id);
//        //    if (employeeMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.EmployeeMasters.Remove(employeeMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool EmployeeMasterExists(long id)
//        {
//            return (_context.EmployeeMasters?.Any(e => e.EmployeeSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
