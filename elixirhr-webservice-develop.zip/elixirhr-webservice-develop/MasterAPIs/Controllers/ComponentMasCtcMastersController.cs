﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ComponentMasCtcMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ComponentMasCtcMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ComponentMasCtcMasters
//        [HttpGet("GetComponentMasCtcMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ComponentMasCtcMaster>>> GetComponentMasCtcMasters()
//        {
//          if (_context.ComponentMasCtcMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.ComponentMasCtcMasters.ToListAsync();
//        }

//        // GET: api/ComponentMasCtcMasters/5
//        [HttpGet("GetComponentMasCtcMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ComponentMasCtcMaster>> GetComponentMasCtcMaster(long id )
//        {
//          if (_context.ComponentMasCtcMasters == null)
//          {
//              return NotFound();
//          }
//            var componentMasCtcMaster = await _context.ComponentMasCtcMasters.FindAsync(id);

//            if (componentMasCtcMaster == null)
//            {
//                return NotFound();
//            }

//            return componentMasCtcMaster;
//        }

//        // PUT: api/ComponentMasCtcMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutComponentMasCtcMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutComponentMasCtcMaster(long id, ComponentMasCtcMaster componentMasCtcMaster )
//        {
//            if (id != componentMasCtcMaster.IntComMCtcMasId)
//            {
//                return BadRequest();
//            }
//            if(id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)componentMasCtcMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentMasCtcMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntEmployeeSeqIdExists((long)componentMasCtcMaster.IntEmployeeSeqId))
//                {
//                    return Conflict(new { message = $"IntInitiation Id '{componentMasCtcMaster.IntEmployeeSeqId}' not found." });
//                }
                
//            }
            
//            componentMasCtcMaster.TsUpdatedTime = DateTime.UtcNow;
            

//            _context.Entry(componentMasCtcMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ComponentMasCtcMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ComponentMasCtcMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostComponentMasCtcMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ComponentMasCtcMaster>> PostComponentMasCtcMaster(ComponentMasCtcMaster componentMasCtcMaster)
//        {
//          if (_context.ComponentMasCtcMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ComponentMasCtcMasters'  is null.");
//          }
//            if (componentMasCtcMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            componentMasCtcMaster.TsCreatedTime = DateTime.UtcNow;
//            componentMasCtcMaster.TsUpdatedTime = DateTime.UtcNow;
//            _context.ComponentMasCtcMasters.Add(componentMasCtcMaster);
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)componentMasCtcMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentMasCtcMaster.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntEmployeeSeqIdExists((long)componentMasCtcMaster.IntEmployeeSeqId))
//                {
//                    return Conflict(new { message = $"IntEmployeeSeq Id  '{componentMasCtcMaster.IntEmployeeSeqId}' not found." });
//                }

//                await _context.SaveChangesAsync();


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
            
            

//            return CreatedAtAction("GetComponentMasCtcMaster", new {  id = componentMasCtcMaster.IntComMCtcMasId }, componentMasCtcMaster);
//        }

//        // DELETE: api/ComponentMasCtcMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteComponentMasCtcMaster(long id)
//        //{
//        //    if (_context.ComponentMasCtcMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var componentMasCtcMaster = await _context.ComponentMasCtcMasters.FindAsync(id);
//        //    if (componentMasCtcMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ComponentMasCtcMasters.Remove(componentMasCtcMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ComponentMasCtcMasterExists(long id)
//        {
//            return (_context.ComponentMasCtcMasters?.Any(e => e.IntComMCtcMasId == id)).GetValueOrDefault();
//        }
//    }
//}
