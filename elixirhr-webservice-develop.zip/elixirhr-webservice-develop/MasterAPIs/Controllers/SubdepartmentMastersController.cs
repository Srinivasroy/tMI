﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubdepartmentMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public SubdepartmentMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/SubdepartmentMasters
        [HttpGet("GetSubdepartmentMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<DepartmentViewModel>> GetSubdepartmentMasters()
        {
            try
            {
                if (_context.SubdepartmentMasters == null)
                {
                    return NotFound();
                }
                var departmentViewModel = new DepartmentViewModel
                {
                    departmentlist = await _context.DepartmentMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                    subdepartmentlist = await _context.SubdepartmentMasters.Where(x => x.companyId == currentCompanyId).ToListAsync()
                };
                return departmentViewModel;
                //return await _context.SubdepartmentMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/SubdepartmentMasters/5
        [HttpGet("GetSubdepartmentMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<SubdepartmentMaster>> GetSubdepartmentMaster(long id)
        {
            var subdepartmentMaster = await _context.SubdepartmentMasters.FindAsync(id);

            if (subdepartmentMaster == null)
            {
                return NotFound();
            }

            return subdepartmentMaster;
        }

        // PUT: api/SubdepartmentMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutSubdepartmentMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutSubdepartmentMaster(long id, SubdepartmentMaster subdepartmentMaster)
        //{
        //    if (id != subdepartmentMaster.Id)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(subdepartmentMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!SubdepartmentMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/SubdepartmentMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostSubdepartmentMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostSubdepartmentMaster(SubdepartmentMaster subdepartmentMaster)
        {
            try
            {
                if (subdepartmentMaster.subdepartmentId == 0)
                {
                    if (SubDepartmentExists(subdepartmentMaster.subDepartment, subdepartmentMaster.companyId, subdepartmentMaster.departmentId))
                    {
                        return Conflict(new { message = $"SubDepartment  '{subdepartmentMaster.subDepartment}' already exists" });
                    }
                }

                subdepartmentMaster.createdTime = DateTime.UtcNow;
                subdepartmentMaster.updatedDate = subdepartmentMaster.createdTime;
                subdepartmentMaster.createdBy = EmailId;
                subdepartmentMaster.updatedBy = subdepartmentMaster.createdBy;
                _context.SubdepartmentMasters.Update(subdepartmentMaster);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
                //throw;
            }
            var subdepartmentmasterjson = JsonConvert.SerializeObject(subdepartmentMaster);
            var _subdepartmentmaster = System.Text.Json.JsonSerializer.Deserialize<object>(subdepartmentmasterjson);

            return _subdepartmentmaster;
            //return CreatedAtAction("GetSubdepartmentMaster", new { id = subdepartmentMaster.Id }, subdepartmentMaster);
        }

        //// DELETE: api/SubdepartmentMasters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteSubdepartmentMaster(long id)
        //{
        //    var subdepartmentMaster = await _context.SubdepartmentMasters.FindAsync(id);
        //    if (subdepartmentMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.SubdepartmentMasters.Remove(subdepartmentMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool SubdepartmentMasterExists(long id)
        {
            return _context.SubdepartmentMasters.Any(e => e.subdepartmentId == id);
        }
        private bool SubDepartmentExists(string subDepartment, long? companyId, long? departmentId)
        {
            return _context.SubdepartmentMasters.Any(e => e.subDepartment == subDepartment && e.companyId == companyId && e.departmentId == departmentId);
        }
    }
}
