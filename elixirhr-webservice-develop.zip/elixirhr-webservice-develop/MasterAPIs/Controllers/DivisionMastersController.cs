﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using ExcelDataReader;
using System.Data;
using static MasterAPIs.Models.Helper.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DivisionMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public DivisionMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/DivisionMasters
        [HttpGet("GetDivisionMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<DivisionMaster>>> GetDivisionMasters()
        {
            return await _context.DivisionMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
        }

        // GET: api/DivisionMasters/5
        [HttpGet("GetDivisionMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<DivisionMaster>> GetDivisionMaster(long id)
        {
            var divisionMaster = await _context.DivisionMasters.FindAsync(id);

            if (divisionMaster == null)
            {
                return NotFound();
            }

            return divisionMaster;
        }

        // PUT: api/DivisionMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutDivisionMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutDivisionMaster(int id, DivisionMaster divisionMaster)
        //{
        //    if (id != divisionMaster.divisionId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(divisionMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!DivisionMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/DivisionMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostDivisionMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostDivisionMaster(DivisionMaster divisionMaster)
        {
            try
            {
                if (divisionMaster.divisionId == 0)
                {
                    if (DivisionNameExists(divisionMaster.division, divisionMaster.companyId))
                    {
                        return Conflict(new { message = $"division  '{divisionMaster.division}' already exists" });
                    }
                }

                divisionMaster.createdTime = DateTime.UtcNow;
                divisionMaster.updatedDate = divisionMaster.createdTime;
                divisionMaster.createdBy = EmailId;
                divisionMaster.updatedBy = EmailId;
                _context.DivisionMasters.Update(divisionMaster);
                await _context.SaveChangesAsync();
            }
            catch
            {
                throw;
            }
            var divisionmasterjson = JsonConvert.SerializeObject(divisionMaster);
            var _divisionmaster = System.Text.Json.JsonSerializer.Deserialize<object>(divisionmasterjson);

            return _divisionmaster;
            //return CreatedAtAction("GetDivisionMaster", new { id = divisionMaster.divisionId }, divisionMaster);
        }


        [HttpPost("DivisionBulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> DivisionBulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                //return new { message = "No file was uploaded !!!" };
                return Conflict(new { message = "No file was uploaded !!!" });

            }
            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                // return new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" };
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    var divisionRows = dataTable.AsEnumerable().Select(x => x["division"].ToString()).Distinct().ToList();
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any division data!" });
                    }
                    foreach (var divisionRow in divisionRows)
                    {
                        var conFil = _context.DivisionMasters.Where(x => x.division == divisionRow.ToString() && x.companyId == currentCompanyId).FirstOrDefault();
                        if (conFil == null)
                        {
                            var divisionMaster = new DivisionMaster
                            {
                                division = divisionRow.ToString(),
                                companyId = currentCompanyId,
                                createdBy = MasterContext.Email,
                                createdTime = DateTime.UtcNow,
                                updatedBy = MasterContext.Email,
                                updatedDate = DateTime.UtcNow,
                                status = (int)Statuses.Approved
                            };
                            _context.DivisionMasters.Add(divisionMaster);
                        }
                    }
                    await _context.SaveChangesAsync();
                    //return Ok("File uploaded sucessfully!!!");
                    return new { message = "File uploaded sucessfully!!!", status = "success" };
                    // "message": "File uploaded successfully",

                }
            }
        }


        // DELETE: api/DivisionMasters/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteDivisionMaster(long id)
        {
            var divisionMaster = await _context.DivisionMasters.FindAsync(id);
            if (divisionMaster == null)
            {
                return NotFound();
            }

            _context.DivisionMasters.Remove(divisionMaster);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DivisionMasterExists(int id)
        {
            return _context.DivisionMasters.Any(e => e.divisionId == id);
        }
        private bool DivisionNameExists(string division, long? companyId)
        {
            return _context.DivisionMasters.Any(e => e.division == division && e.companyId == companyId);
        }
    }
}
