﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;


namespace Master.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CostcenterMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public CostcenterMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/CostcenterMasters
        [HttpGet("GetCostcenterMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<CostcenterMaster>>> GetCostcenterMasters()
        {
            try
            {
                if (_context.CostcenterMasters == null)
                {
                    return NotFound();
                }
                return await _context.CostcenterMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/CostcenterMasters/5
        [HttpGet("GetCostcenterMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<CostcenterMaster>> GetCostcenterMaster(long id)
        {
            var costcenterMaster = await _context.CostcenterMasters.FindAsync(id);

            if (costcenterMaster == null)
            {
                return NotFound();
            }

            return costcenterMaster;
        }

        //// PUT: api/CostcenterMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutCostcenterMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutCostcenterMaster(long id, CostcenterMaster costcenterMaster)
        //{
        //    if (id != costcenterMaster.costCenterId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(costcenterMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!CostcenterMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/CostcenterMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostCostcenterMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostCostcenterMaster(CostcenterMaster costcenterMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(costcenterMaster.costCenterName))
                {
                    return Conflict("CostCenterName can not be null");
                }

                if (costcenterMaster.costCenterId > 0)
                {
                    costcenterMaster.updatedBy = MasterContext.Email;
                    costcenterMaster.updatedDate = DateTime.UtcNow;
                    _context.CostcenterMasters.Update(costcenterMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                costcenterMaster.createdBy = MasterContext.Email;
                costcenterMaster.updatedBy = costcenterMaster.createdBy;
                costcenterMaster.createdTime = DateTime.UtcNow;
                costcenterMaster.updatedDate = DateTime.UtcNow;
                costcenterMaster.companyId = currentCompanyId;
                _context.CostcenterMasters.Add(costcenterMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }

        //// DELETE: api/CostcenterMasters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteCostcenterMaster(long id)
        //{
        //    var costcenterMaster = await _context.CostcenterMasters.FindAsync(id);
        //    if (costcenterMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.CostcenterMasters.Remove(costcenterMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool CostcenterMasterExists(long id)
        {
            return _context.CostcenterMasters.Any(e => e.costCenterId == id);
        }
    }
}
