﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Master.Models.Helper;
//using Microsoft.AspNetCore.Server.HttpSys;
//using System.Net;
//using Microsoft.AspNetCore.Authorization;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class CompanyDetailMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public CompanyDetailMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/CompanyDetailMasters
//        [HttpGet("GetCompanyDetailMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<CompanyDetailMaster>>> GetCompanyDetailMasters()
//        {
//          if (_context.CompanyDetailMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.CompanyDetailMasters.ToListAsync();
//        }

//        // GET: api/CompanyDetailMasters/5
//        [HttpGet("GetCompanyDetailMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<CompanyDetailMaster>> GetCompanyDetailMaster(long id)
//        {
//          if (_context.CompanyDetailMasters == null)
//          {
//              return NotFound();
//          }
//            var companyDetailMaster = await _context.CompanyDetailMasters.FindAsync(id);

//            if (companyDetailMaster == null)
//            {
//                return NotFound();
//            }

//            return companyDetailMaster;
//        }

//        // PUT: api/CompanyDetailMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut(("PutCompanyDetailMaster/{id}"))]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutCompanyDetailMaster(long id, CompanyDetailMaster companyDetailMaster)
//        {
//            if (id != companyDetailMaster.CompanySeqId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {
//                if (!Helper.IntClientIdExists((long)companyDetailMaster.IntClientId))
//                {
//                    return Conflict(new { message = $"Client Id '{companyDetailMaster.IntClientId}' not found." });
//                }

                
//            }
//            companyDetailMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(companyDetailMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!CompanyDetailMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/CompanyDetailMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostCompanyDetailMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<CompanyDetailMaster>> PostCompanyDetailMaster(CompanyDetailMaster companyDetailMaster)
//        {
//            if (_context.CompanyDetailMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.CompanyDetailMasters'  is null.");
//            }

//            if (companyDetailMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            companyDetailMaster.DtUpdatedDate = DateTime.UtcNow;
//            companyDetailMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.CompanyDetailMasters.Add(companyDetailMaster);
//            try
//            {

//                if (!Helper.IntClientIdExists((long)companyDetailMaster.IntClientId))
//                {
//                    return Conflict(new { message = $"Client Id '{companyDetailMaster.IntClientId}' not found." });
//                }

//                await _context.SaveChangesAsync();

//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }




//            return CreatedAtAction("GetCompanyDetailMaster", new { id = companyDetailMaster.CompanySeqId }, companyDetailMaster);
//        }

//        // DELETE: api/CompanyDetailMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteCompanyDetailMaster(long id)
//        //{
//        //    if (_context.CompanyDetailMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var companyDetailMaster = await _context.CompanyDetailMasters.FindAsync(id);
//        //    if (companyDetailMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.CompanyDetailMasters.Remove(companyDetailMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool CompanyDetailMasterExists(long id)
//        {
//            return (_context.CompanyDetailMasters?.Any(e => e.CompanySeqId == id)).GetValueOrDefault();
//        }
//    }
//}
