﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ConfigMasTmiSuperAdminMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ConfigMasTmiSuperAdminMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ConfigMasTmiSuperAdminMasters
//        [HttpGet("GetConfigMasTmiSuperAdminMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ConfigMasTmiSuperAdminMaster>>> GetConfigMasTmiSuperAdminMasters()
//        {
//          if (_context.ConfigMasTmiSuperAdminMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.ConfigMasTmiSuperAdminMasters.ToListAsync();
//        }

//        // GET: api/ConfigMasTmiSuperAdminMasters/5
//        [HttpGet("GetConfigMasTmiSuperAdminMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ConfigMasTmiSuperAdminMaster>> GetConfigMasTmiSuperAdminMaster( long id)
//        {
//          if (_context.ConfigMasTmiSuperAdminMasters == null)
//          {
//              return NotFound();
//          }
//            var configMasTmiSuperAdminMaster = await _context.ConfigMasTmiSuperAdminMasters.FindAsync(id);

//            if (configMasTmiSuperAdminMaster == null)
//            {
//                return NotFound();
//            }

//            return configMasTmiSuperAdminMaster;
//        }

//        // PUT: api/ConfigMasTmiSuperAdminMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutConfigMasTmiSuperAdminMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutConfigMasTmiSuperAdminMaster(long id, ConfigMasTmiSuperAdminMaster configMasTmiSuperAdminMaster)
//        {
//            if (id != configMasTmiSuperAdminMaster.IntTmisaId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)configMasTmiSuperAdminMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{configMasTmiSuperAdminMaster.IntCompanyId}' not found." });
//                }
                

//            }
//            configMasTmiSuperAdminMaster.TsUpdatedTime = DateTime.UtcNow;
//            _context.Entry(configMasTmiSuperAdminMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ConfigMasTmiSuperAdminMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ConfigMasTmiSuperAdminMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostConfigMasTmiSuperAdminMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ConfigMasTmiSuperAdminMaster>> PostConfigMasTmiSuperAdminMaster( ConfigMasTmiSuperAdminMaster configMasTmiSuperAdminMaster)
//        {
//          if (_context.ConfigMasTmiSuperAdminMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ConfigMasTmiSuperAdminMasters'  is null.");
//          }
//            if (configMasTmiSuperAdminMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)configMasTmiSuperAdminMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{configMasTmiSuperAdminMaster.IntCompanyId}' not found." });
//                }


              


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            configMasTmiSuperAdminMaster.TsCreatedTime = DateTime.UtcNow;
//            configMasTmiSuperAdminMaster.TsUpdatedTime = DateTime.UtcNow;
//            _context.ConfigMasTmiSuperAdminMasters.Add(configMasTmiSuperAdminMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetConfigMasTmiSuperAdminMaster", new {  id = configMasTmiSuperAdminMaster.IntTmisaId }, configMasTmiSuperAdminMaster);
//        }

//        // DELETE: api/ConfigMasTmiSuperAdminMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteConfigMasTmiSuperAdminMaster(long id)
//        //{
//        //    if (_context.ConfigMasTmiSuperAdminMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var configMasTmiSuperAdminMaster = await _context.ConfigMasTmiSuperAdminMasters.FindAsync(id);
//        //    if (configMasTmiSuperAdminMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ConfigMasTmiSuperAdminMasters.Remove(configMasTmiSuperAdminMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ConfigMasTmiSuperAdminMasterExists(long id)
//        {
//            return (_context.ConfigMasTmiSuperAdminMasters?.Any(e => e.IntTmisaId == id)).GetValueOrDefault();
//        }
//    }
//}
