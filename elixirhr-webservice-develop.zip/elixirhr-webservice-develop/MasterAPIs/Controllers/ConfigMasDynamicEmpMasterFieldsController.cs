﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using System.Net;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ConfigMasDynamicEmpMasterFieldsController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ConfigMasDynamicEmpMasterFieldsController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ConfigMasDynamicEmpMasterFields
//        [HttpGet("GetConfigMasDynamicEmpMasterFields")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ConfigMasDynamicEmpMasterField>>> GetConfigMasDynamicEmpMasterFields()
//        {
//          if (_context.ConfigMasDynamicEmpMasterFields == null)
//          {
//              return NotFound();
//          }
//            return await _context.ConfigMasDynamicEmpMasterFields.ToListAsync();
//        }

//        // GET: api/ConfigMasDynamicEmpMasterFields/5
//        [HttpGet("GetConfigMasDynamicEmpMasterField/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ConfigMasDynamicEmpMasterField>> GetConfigMasDynamicEmpMasterField( long id)
//        {
//          if (_context.ConfigMasDynamicEmpMasterFields == null)
//          {
//              return NotFound();
//          }
//            var configMasDynamicEmpMasterField = await _context.ConfigMasDynamicEmpMasterFields.FindAsync(id);

//            if (configMasDynamicEmpMasterField == null)
//            {
//                return NotFound();
//            }

//            return configMasDynamicEmpMasterField;
//        }

//        // PUT: api/ConfigMasDynamicEmpMasterFields/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut(("PutConfigMasDynamicEmpMasterField/{id}"))]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutConfigMasDynamicEmpMasterField( long id, ConfigMasDynamicEmpMasterField configMasDynamicEmpMasterField)
//        {
//            if (id != configMasDynamicEmpMasterField.IntDynamicEmpMasId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)configMasDynamicEmpMasterField.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{configMasDynamicEmpMasterField.IntCompanyId}' not found." });
//                }

//            }

//            configMasDynamicEmpMasterField.TsUpdatedTime = DateTime.UtcNow;
//            _context.Entry(configMasDynamicEmpMasterField).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ConfigMasDynamicEmpMasterFieldExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ConfigMasDynamicEmpMasterFields
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostConfigMasDynamicEmpMasterField")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ConfigMasDynamicEmpMasterField>> PostConfigMasDynamicEmpMasterField( ConfigMasDynamicEmpMasterField configMasDynamicEmpMasterField)
//        {
//          if (_context.ConfigMasDynamicEmpMasterFields == null)
//          {
//              return Problem("Entity set 'MasterContext.ConfigMasDynamicEmpMasterFields'  is null.");
//          }
//            if (configMasDynamicEmpMasterField == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            configMasDynamicEmpMasterField.TsUpdatedTime = DateTime.UtcNow;
//            configMasDynamicEmpMasterField.TsCreatedTime = DateTime.UtcNow;
//            _context.ConfigMasDynamicEmpMasterFields.Add(configMasDynamicEmpMasterField);
//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)configMasDynamicEmpMasterField.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{configMasDynamicEmpMasterField.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();

//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
           

//            return CreatedAtAction("GetConfigMasDynamicEmpMasterField", new {  id = configMasDynamicEmpMasterField.IntDynamicEmpMasId }, configMasDynamicEmpMasterField);
//        }

//        // DELETE: api/ConfigMasDynamicEmpMasterFields/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteConfigMasDynamicEmpMasterField(long id)
//        //{
//        //    if (_context.ConfigMasDynamicEmpMasterFields == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var configMasDynamicEmpMasterField = await _context.ConfigMasDynamicEmpMasterFields.FindAsync(id);
//        //    if (configMasDynamicEmpMasterField == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ConfigMasDynamicEmpMasterFields.Remove(configMasDynamicEmpMasterField);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ConfigMasDynamicEmpMasterFieldExists(long id)
//        {
//            return (_context.ConfigMasDynamicEmpMasterFields?.Any(e => e.IntDynamicEmpMasId == id)).GetValueOrDefault();
//        }
//    }
//}
