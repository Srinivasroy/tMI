﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Master.Models.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RcsgradeMastersController : ControllerBase
    {
        private readonly MasterContext _context;

        public RcsgradeMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/RcsgradeMasters
        [HttpGet("GetRcsgradeMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<RcsgradeMaster>>> GetRcsgradeMasters()
        {
          if (_context.RcsgradeMasters == null)
          {
              return NotFound();
          }
            return await _context.RcsgradeMasters.ToListAsync();
        }

        // GET: api/RcsgradeMasters/5
        [HttpGet("GetRcsgradeMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<RcsgradeMaster>> GetRcsgradeMaster( long id)
        {
          if (_context.RcsgradeMasters == null)
          {
              return NotFound();
          }
            var rcsgradeMaster = await _context.RcsgradeMasters.FindAsync(id);

            if (rcsgradeMaster == null)
            {
                return NotFound();
            }

            return rcsgradeMaster;
        }

        // PUT: api/RcsgradeMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut(("PutRcsgradeMaster/{id}"))]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PutRcsgradeMaster( long id, RcsgradeMaster rcsgradeMaster)
        {
            if (id != rcsgradeMaster.IntRcsgradeId)
            {
                return BadRequest();
            }

            if (id >= 1)
            {

                if (!Helper.IntCompanyIdExists((long)rcsgradeMaster.IntCompanyId))
                {
                    return Conflict(new { message = $"Company Id '{rcsgradeMaster.IntCompanyId}' not found." });
                }

            }

            rcsgradeMaster.DtUpdatedTime = DateTime.UtcNow;
            _context.Entry(rcsgradeMaster).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RcsgradeMasterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RcsgradeMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostRcsgradeMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<RcsgradeMaster>> PostRcsgradeMaster( RcsgradeMaster rcsgradeMaster)
        {
          if (_context.RcsgradeMasters == null)
          {
              return Problem("Entity set 'MasterContext.RcsgradeMasters'  is null.");
          }
            if (rcsgradeMaster == null)
            {
                return Conflict(new { message = "Value cannot be null" });
            }

            rcsgradeMaster.DtUpdatedTime = DateTime.UtcNow;
            rcsgradeMaster.TsCreatedTime = DateTime.UtcNow;
            _context.RcsgradeMasters.Add(rcsgradeMaster);
            try
            {

                if (!Helper.IntCompanyIdExists((long)rcsgradeMaster.IntCompanyId))
                {
                    return Conflict(new { message = $"Company Id '{rcsgradeMaster.IntCompanyId}' not found." });
                }

                await _context.SaveChangesAsync();

            }
            catch (DbUpdateException)
            {
                throw;
            }
          

            return CreatedAtAction("GetRcsgradeMaster", new {  id = rcsgradeMaster.IntRcsgradeId }, rcsgradeMaster);
        }

        // DELETE: api/RcsgradeMasters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteRcsgradeMaster(long id)
        //{
        //    if (_context.RcsgradeMasters == null)
        //    {
        //        return NotFound();
        //    }
        //    var rcsgradeMaster = await _context.RcsgradeMasters.FindAsync(id);
        //    if (rcsgradeMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.RcsgradeMasters.Remove(rcsgradeMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool RcsgradeMasterExists(long id)
        {
            return (_context.RcsgradeMasters?.Any(e => e.IntRcsgradeId == id)).GetValueOrDefault();
        }
    }
}
