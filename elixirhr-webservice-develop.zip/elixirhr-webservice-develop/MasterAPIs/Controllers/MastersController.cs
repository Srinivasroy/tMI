﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Newtonsoft.Json;
using System.Collections;
using Microsoft.AspNetCore.Authorization;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MastersController : ControllerBase
    {
        private readonly MasterContext _context;

        public MastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/Masters
        [HttpGet("GetMasters/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetMasters( long companyId)
        {
            try
            {
                var masters = await _context.Masters.Where(master => master.IntCompanyId == companyId).ToListAsync();
                if (_context.Masters == null)
                {
                    return NotFound();
                }
                var mastersJson = JsonConvert.SerializeObject(masters);

                ArrayList mastersList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(mastersJson);
                return mastersList;
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }

        }

        // GET: api/GetMasterChildren
        [HttpGet("GetMasterChildren/{masterName}/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetMasterChildren( string masterName, long companyId)
        {
            try
            {
                var parent = await _context.Masters.Where(master => master.Name.ToLower() == masterName.ToLower()).FirstOrDefaultAsync();
                if (parent == null)
                {
                    return Conflict(new { message = $"There is no master with the name {masterName}" });
                }
                var masters = await _context.Masters.Where(master => master.ParentId == parent.Id && master.IntCompanyId == companyId).ToListAsync();
                if (_context.Masters == null)
                {
                    return NotFound();
                }
                var mastersJson = JsonConvert.SerializeObject(masters);

                ArrayList mastersList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(mastersJson);
                return mastersList;
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }

        }

        // GET: api/Masters/5
        [HttpGet("GetMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<MasterAttribute>> GetMaster( long id)
        {
            if (_context.Masters == null)
            {
                return NotFound();
            }
            var master = await _context.Masters.FindAsync(id);

            if (master == null)
            {
                return NotFound();
            }

            return master;
        }

        // PUT: api/Masters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("PutMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PutMaster( long id, MasterAttribute master)
        {
            //if (id != master.Id)
            //{
            //    return BadRequest();
            //}
            master.Id = id;
            _context.Entry(master).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MasterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/Masters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<MasterAttribute>> PostMaster( MasterAttribute master)
        {
            try
            {
                if (_context.Masters == null)
                {
                    return Problem("Entity set 'MasterContext.Masters'  is null.");
                }
                var lastMaster = await _context.Masters.Where(mast => mast.IntCompanyId == master.IntCompanyId).OrderBy(m => m.OrderNo).LastOrDefaultAsync();
                if (lastMaster != null)
                {
                    master.OrderNo = lastMaster.OrderNo + 1;
                    master.ApprovedOrderNo = lastMaster.OrderNo + 1;
                }
                else
                {
                    master.OrderNo = 1;
                    master.ApprovedOrderNo = 1;
                }
                _context.Masters.Add(master);
                await _context.SaveChangesAsync();

            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return master;
        }

        // GET: api/GetMasterOrders/companyId
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpGet("GetMasterOrders/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetMasterOrders( int companyId)
        {
            try
            {
                var approvedOrder = await _context.Masters.Where(mas => mas.IntCompanyId == companyId).OrderBy(m => m.OrderNo).ToListAsync();
                var approvedOrderJson = JsonConvert.SerializeObject(approvedOrder);
                ArrayList approvedOrderList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(approvedOrderJson);
                var orders = await _context.Masters.Where(mas => mas.IntCompanyId == companyId).ToListAsync();
                var ordersJson = JsonConvert.SerializeObject(orders);
                ArrayList ordersList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(ordersJson);
                await _context.SaveChangesAsync();
                return new { ActualOrder = approvedOrderList, ToBeApproved = ordersList };

            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
        }

        // GET: api/ChangeMasterOrderRequest
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeMasterOrderRequest/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ChangeMasterOrderRequest( int companyId, ChangeOrderObject changeOrderObject)
        {
            try
            {
                for (int i = 0; i < changeOrderObject.actualOrder.Count(); i++)
                {
                    var order = changeOrderObject.actualOrder[i];
                    var master = await _context.Masters.Where(master => master.OrderNo == order && master.IntCompanyId == companyId).FirstOrDefaultAsync();
                    if (master != null)
                    {
                        master.ApprovedOrderNo = changeOrderObject.changeOrder[i];
                        _context.Entry(master).State = EntityState.Modified;
                        await _context.SaveChangesAsync();
                    }
                }

                return new { message = "Record updated successfully !!!" };

            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
        }

        // GET: api/ChangeMasterOrderApprove/{companyId}
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeMasterOrderApprove/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ChangeMasterOrderApprove( int companyId)
        {
            try
            {
                var masters = await _context.Masters.Where(master => master.IntCompanyId == companyId).ToListAsync();
                masters.ForEach(async (master) =>
                {

                    master.OrderNo = master.ApprovedOrderNo;
                    _context.Entry(master).State = EntityState.Modified;


                });
                await _context.SaveChangesAsync();
                return new { message = "Record updated successfully !!!" };

            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
        }

        // GET: api/ChangeMasterOrderReject/{companyId}
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeMasterOrderReject/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ChangeMasterOrderReject( int companyId)
        {
            try
            {
                var masters = await _context.Masters.Where(master => master.IntCompanyId == companyId).ToListAsync();
                masters.ForEach(async (master) =>
                {

                    master.ApprovedOrderNo = master.OrderNo;
                    _context.Entry(master).State = EntityState.Modified;


                });
                await _context.SaveChangesAsync();
                return new { message = "Record updated successfully !!!" };

            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
        }

        //// DELETE: api/Masters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteMaster(long id)
        //{
        //    if (_context.Masters == null)
        //    {
        //        return NotFound();
        //    }
        //    var master = await _context.Masters.FindAsync(id);
        //    if (master == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Masters.Remove(master);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool MasterExists(long id)
        {
            return (_context.Masters?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
