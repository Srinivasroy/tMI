﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ComponentMasUdfMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ComponentMasUdfMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ComponentMasUdfMasters
//        [HttpGet("GetComponentMasUdfMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ComponentMasUdfMaster>>> GetComponentMasUdfMasters()
//        {
//          if (_context.ComponentMasUdfMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.ComponentMasUdfMasters.ToListAsync();
//        }

//        // GET: api/ComponentMasUdfMasters/5
//        [HttpGet("GetComponentMasUdfMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ComponentMasUdfMaster>> GetComponentMasUdfMaster(long id)
//        {
//          if (_context.ComponentMasUdfMasters == null)
//          {
//              return NotFound();
//          }
//            var componentMasUdfMaster = await _context.ComponentMasUdfMasters.FindAsync(id);

//            if (componentMasUdfMaster == null)
//            {
//                return NotFound();
//            }

//            return componentMasUdfMaster;
//        }

//        // PUT: api/ComponentMasUdfMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutComponentMasUdfMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutComponentMasUdfMaster( long id, ComponentMasUdfMaster componentMasUdfMaster)
//        {
//            if (id != componentMasUdfMaster.IntUdfSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)componentMasUdfMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentMasUdfMaster.IntCompanyId}' not found." });
//                }

//            }

//            componentMasUdfMaster.DTUpdatedDate = DateTime.UtcNow;

//            _context.Entry(componentMasUdfMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ComponentMasUdfMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ComponentMasUdfMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostComponentMasUdfMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ComponentMasUdfMaster>> PostComponentMasUdfMaster( ComponentMasUdfMaster componentMasUdfMaster)
//        {
//          if (_context.ComponentMasUdfMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.ComponentMasUdfMasters'  is null.");
//          }
//          if (componentMasUdfMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            componentMasUdfMaster.DTUpdatedDate = DateTime.UtcNow;
//            componentMasUdfMaster.TSCreatedDate = DateTime.UtcNow;
//            _context.ComponentMasUdfMasters.Add(componentMasUdfMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)componentMasUdfMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentMasUdfMaster.IntCompanyId}' not found." });
//                }
//                await _context.SaveChangesAsync();
//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            return CreatedAtAction("GetComponentMasUdfMaster", new {  id = componentMasUdfMaster.IntUdfSeqId }, componentMasUdfMaster);
//        }

//        //// DELETE: api/ComponentMasUdfMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteComponentMasUdfMaster(long id)
//        //{
//        //    if (_context.ComponentMasUdfMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var componentMasUdfMaster = await _context.ComponentMasUdfMasters.FindAsync(id);
//        //    if (componentMasUdfMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ComponentMasUdfMasters.Remove(componentMasUdfMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ComponentMasUdfMasterExists(long id)
//        {
//            return (_context.ComponentMasUdfMasters?.Any(e => e.IntUdfSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
