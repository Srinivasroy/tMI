﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class DomainMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public DomainMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/DomainMasters
//        [HttpGet("GetDomainMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<DomainMaster>>> GetDomainMasters()
//        {
//            if (_context.DomainMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.DomainMasters.ToListAsync();
//        }

//        // GET: api/DomainMasters/5
//        [HttpGet("GetDomainMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<DomainMaster>> GetDomainMaster( long id)
//        {
//            if (_context.DomainMasters == null)
//            {
//                return NotFound();
//            }
//            var domainMaster = await _context.DomainMasters.FindAsync(id);

//            if (domainMaster == null)
//            {
//                return NotFound();
//            }

//            return domainMaster;
//        }

//        // PUT: api/DomainMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutDomainMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutDomainMaster( long id, DomainMaster domainMaster)
//        {
//            if (id != domainMaster.DomainSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)domainMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{domainMaster.IntCompanyId}' not found." });
//                }

//            }

//            domainMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(domainMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!DomainMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/DomainMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostDomainMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<DomainMaster>> PostDomainMaster( DomainMaster domainMaster)
//        {
//            if (_context.DomainMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.DomainMasters'  is null.");
//            }
//            if (domainMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            domainMaster.DtUpdatedDate = DateTime.UtcNow;
//            domainMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.DomainMasters.Add(domainMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)domainMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{domainMaster.IntCompanyId}' not found." });
//                }

//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetDomainMaster", new {  id = domainMaster.DomainSeqId }, domainMaster);
//        }

//        //// DELETE: api/DomainMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteDomainMaster(long id)
//        //{
//        //    if (_context.DomainMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var domainMaster = await _context.DomainMasters.FindAsync(id);
//        //    if (domainMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.DomainMasters.Remove(domainMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool DomainMasterExists(long id)
//        {
//            return (_context.DomainMasters?.Any(e => e.DomainSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
