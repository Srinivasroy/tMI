﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AbeCodeMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public AbeCodeMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/AbeCodeMasters
//        [HttpGet("GetAbeCodeMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<AbeCodeMaster>>> GetAbeCodeMasters()
//        {
//            if (_context.AbeCodeMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.AbeCodeMasters.ToListAsync();
//        }

//        // GET: api/AbeCodeMasters/5
//        [HttpGet("GetAbeCodeMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<AbeCodeMaster>> GetAbeCodeMaster( long id)
//        {
//            if (_context.AbeCodeMasters == null)
//            {
//                return NotFound();
//            }
//            var abeCodeMaster = await _context.AbeCodeMasters.FindAsync(id);

//            if (abeCodeMaster == null)
//            {
//                return NotFound();
//            }

//            return abeCodeMaster;
//        }

//        // PUT: api/AbeCodeMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutAbeCodeMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutAbeCodeMaster( long id, AbeCodeMaster abeCodeMaster)
//        {
//            if (id != abeCodeMaster.AbeCodeSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)abeCodeMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{abeCodeMaster.IntCompanyId}' not found." });
//                }

//            }

//            abeCodeMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(abeCodeMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!AbeCodeMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/AbeCodeMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostAbeCodeMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<AbeCodeMaster>> PostAbeCodeMaster( AbeCodeMaster abeCodeMaster)
//        {
//            if (_context.AbeCodeMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.AbeCodeMasters'  is null.");
//            }
//            if (abeCodeMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            abeCodeMaster.DtUpdatedDate = DateTime.UtcNow;
//            abeCodeMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.AbeCodeMasters.Add(abeCodeMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)abeCodeMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{abeCodeMaster.IntCompanyId}' not found." });
//                }
                
//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetAbeCodeMaster", new {  id = abeCodeMaster.AbeCodeSeqId }, abeCodeMaster);
//        }

//        //// DELETE: api/AbeCodeMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteAbeCodeMaster(long id)
//        //{
//        //    if (_context.AbeCodeMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var abeCodeMaster = await _context.AbeCodeMasters.FindAsync(id);
//        //    if (abeCodeMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.AbeCodeMasters.Remove(abeCodeMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool AbeCodeMasterExists(long id)
//        {
//            return (_context.AbeCodeMasters?.Any(e => e.AbeCodeSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
