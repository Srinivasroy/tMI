﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ReportsDomainMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ReportsDomainMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ReportsDomainMasters
//        [HttpGet("GetReportsDomainMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<ReportsDomainMaster>>> GetReportsDomainMasters()
//        {
//            if (_context.ReportsDomainMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.ReportsDomainMasters.ToListAsync();
//        }

//        // GET: api/ReportsDomainMasters/5
//        [HttpGet("GetReportsDomainMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ReportsDomainMaster>> GetReportsDomainMaster( long id)
//        {
//            if (_context.ReportsDomainMasters == null)
//            {
//                return NotFound();
//            }
//            var reportsDomainMaster = await _context.ReportsDomainMasters.FindAsync(id);

//            if (reportsDomainMaster == null)
//            {
//                return NotFound();
//            }

//            return reportsDomainMaster;
//        }

//        // PUT: api/ReportsDomainMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutReportsDomainMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutReportsDomainMaster( long id, ReportsDomainMaster reportsDomainMaster)
//        {
//            if (id != reportsDomainMaster.IntId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)reportsDomainMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{reportsDomainMaster.IntCompanyId}' not found." });
//                }

//            }

//            reportsDomainMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(reportsDomainMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ReportsDomainMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ReportsDomainMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostReportsDomainMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<ReportsDomainMaster>> PostReportsDomainMaster( ReportsDomainMaster reportsDomainMaster)
//        {
//            if (_context.ReportsDomainMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.ReportsDomainMasters'  is null.");
//            }
//            if (reportsDomainMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            reportsDomainMaster.DtUpdatedDate = DateTime.UtcNow;
//            reportsDomainMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.ReportsDomainMasters.Add(reportsDomainMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)reportsDomainMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{reportsDomainMaster.IntCompanyId}' not found." });
//                }

//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetReportsDomainMaster", new {  id = reportsDomainMaster.IntId }, reportsDomainMaster);
//        }

//        //// DELETE: api/ReportsDomainMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteReportsDomainMaster(long id)
//        //{
//        //    if (_context.ReportsDomainMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var reportsDomainMaster = await _context.ReportsDomainMasters.FindAsync(id);
//        //    if (reportsDomainMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ReportsDomainMasters.Remove(reportsDomainMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ReportsDomainMasterExists(long id)
//        {
//            return (_context.ReportsDomainMasters?.Any(e => e.IntId == id)).GetValueOrDefault();
//        }
//    }
//}
