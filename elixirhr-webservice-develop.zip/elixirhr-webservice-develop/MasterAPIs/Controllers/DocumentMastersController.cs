﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class DocumentMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public DocumentMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/DocumentMasters
//        [HttpGet("GetDocumentMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<DocumentMaster>>> GetDocumentMasters()
//        {
//          if (_context.DocumentMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.DocumentMasters.ToListAsync();
//        }

//        // GET: api/DocumentMasters/5
//        [HttpGet("GetDocumentMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<DocumentMaster>> GetDocumentMaster(int id)
//        {
//          if (_context.DocumentMasters == null)
//          {
//              return NotFound();
//          }
//            var documentMaster = await _context.DocumentMasters.FindAsync(id);

//            if (documentMaster == null)
//            {
//                return NotFound();
//            }

//            return documentMaster;
//        }

//        // PUT: api/DocumentMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutDocumentMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutDocumentMaster(int id, DocumentMaster documentMaster)
//        {
//            if (id != documentMaster.IntDocId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)documentMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{documentMaster.IntCompanyId}' not found." });
//                }
                

//            }
//            documentMaster.DtUpdatedDate = DateTime.UtcNow;
//            _context.Entry(documentMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!DocumentMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/DocumentMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostDocumentMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<DocumentMaster>> PostDocumentMaster(DocumentMaster documentMaster)
//        {
//          if (_context.DocumentMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.DocumentMasters'  is null.");
//          }
//            if (documentMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            documentMaster.DtUpdatedDate = DateTime.UtcNow;
//            documentMaster.TsCreatedTime = DateTime.UtcNow;
//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)documentMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{documentMaster.IntCompanyId}' not found." });
//                }
               

//                await _context.SaveChangesAsync();


//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            _context.DocumentMasters.Add(documentMaster);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetDocumentMaster", new {  id = documentMaster.IntDocId }, documentMaster);
//        }

//        // DELETE: api/DocumentMasters/5
//       // [HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteDocumentMaster(int id)
//        //{
//        //    if (_context.DocumentMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var documentMaster = await _context.DocumentMasters.FindAsync(id);
//        //    if (documentMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.DocumentMasters.Remove(documentMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool DocumentMasterExists(int id)
//        {
//            return (_context.DocumentMasters?.Any(e => e.IntDocId == id)).GetValueOrDefault();
//        }
//    }
//}
