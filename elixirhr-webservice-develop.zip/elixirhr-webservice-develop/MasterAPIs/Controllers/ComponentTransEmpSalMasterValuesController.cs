﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ComponentTransEmpSalMasterValuesController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public ComponentTransEmpSalMasterValuesController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/ComponentTransEmpSalMasterValues
//        [HttpGet("GetComponentTransEmpSalMasterValues")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<IEnumerable<ComponentTransEmpSalMasterValue>>> GetComponentTransEmpSalMasterValues()
//        {
//          if (_context.ComponentTransEmpSalMasterValues == null)
//          {
//              return NotFound();
//          }
//            return await _context.ComponentTransEmpSalMasterValues.ToListAsync();
//        }

//        // GET: api/ComponentTransEmpSalMasterValues/5
//        [HttpGet("GetComponentTransEmpSalMasterValue/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<ComponentTransEmpSalMasterValue>> GetComponentTransEmpSalMasterValue( long id)
//        {
//          if (_context.ComponentTransEmpSalMasterValues == null)
//          {
//              return NotFound();
//          }
//            var componentTransEmpSalMasterValue = await _context.ComponentTransEmpSalMasterValues.FindAsync(id);

//            if (componentTransEmpSalMasterValue == null)
//            {
//                return NotFound();
//            }

//            return componentTransEmpSalMasterValue;
//        }

//        // PUT: api/ComponentTransEmpSalMasterValues/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutComponentTransEmpSalMasterValue/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<object>> PutComponentTransEmpSalMasterValue( long id, ComponentTransEmpSalMasterValue componentTransEmpSalMasterValue)
//        {
//            if (id != componentTransEmpSalMasterValue.IntCompSalMasValId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)componentTransEmpSalMasterValue.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentTransEmpSalMasterValue.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntCompSeqIdExists((long)componentTransEmpSalMasterValue.IntCompSeqId))
//                {
//                    return Conflict(new { message = $"CompSeq Id '{componentTransEmpSalMasterValue.IntCompSeqId}' not found." });
//                }
//                if (!Helper.IntEmployeeSeqIdExists((long)componentTransEmpSalMasterValue.IntEmployeeSeqId))
//                {
//                    return Conflict(new { message = $"EmployeeSeq Id '{componentTransEmpSalMasterValue.IntEmployeeSeqId}' not found." });
//                }
//                if (!Helper.IntComMCtcMasIdExists((long)componentTransEmpSalMasterValue.IntComMCtcMasId))
//                {
//                    return Conflict(new { message = $"ComMCtcMas Id '{componentTransEmpSalMasterValue.IntComMCtcMasId}' not found." });
//                }

//            }
//            componentTransEmpSalMasterValue.TsUpdatedTime = DateTime.UtcNow;
//            _context.Entry(componentTransEmpSalMasterValue).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ComponentTransEmpSalMasterValueExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/ComponentTransEmpSalMasterValues
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostComponentTransEmpSalMasterValue")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<ComponentTransEmpSalMasterValue>> PostComponentTransEmpSalMasterValue( ComponentTransEmpSalMasterValue componentTransEmpSalMasterValue)
//        {
//          if (_context.ComponentTransEmpSalMasterValues == null)
//          {
//              return Problem("Entity set 'MasterContext.ComponentTransEmpSalMasterValues'  is null.");
//          }
//            if (componentTransEmpSalMasterValue == null)
//            {
//                return Conflict(new { message = "Value should not be null." });
//            }
//            componentTransEmpSalMasterValue.TsCreatedTime = DateTime.UtcNow;
//            componentTransEmpSalMasterValue.TsUpdatedTime = DateTime.UtcNow;
//            _context.ComponentTransEmpSalMasterValues.Add(componentTransEmpSalMasterValue);
           

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)componentTransEmpSalMasterValue.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{componentTransEmpSalMasterValue.IntCompanyId}' not found." });
//                }
//                if (!Helper.IntCompSeqIdExists((long)componentTransEmpSalMasterValue.IntCompSeqId))
//                {
//                    return Conflict(new { message = $"CompSeq Id '{componentTransEmpSalMasterValue.IntCompSeqId}' not found." });
//                }
//                if (!Helper.IntEmployeeSeqIdExists((long)componentTransEmpSalMasterValue.IntEmployeeSeqId))
//                {
//                    return Conflict(new { message = $"EmployeeSeq Id '{componentTransEmpSalMasterValue.IntEmployeeSeqId}' not found." });
//                }
//                if (!Helper.IntComMCtcMasIdExists((long)componentTransEmpSalMasterValue.IntComMCtcMasId))
//                {
//                    return Conflict(new { message = $"ComMCtcMas Id '{componentTransEmpSalMasterValue.IntComMCtcMasId}' not found." });
//                }
//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetComponentTransEmpSalMasterValue", new {  id = componentTransEmpSalMasterValue.IntCompSalMasValId }, componentTransEmpSalMasterValue);
//        }

//        // DELETE: api/ComponentTransEmpSalMasterValues/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteComponentTransEmpSalMasterValue(long id)
//        //{
//        //    if (_context.ComponentTransEmpSalMasterValues == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var componentTransEmpSalMasterValue = await _context.ComponentTransEmpSalMasterValues.FindAsync(id);
//        //    if (componentTransEmpSalMasterValue == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.ComponentTransEmpSalMasterValues.Remove(componentTransEmpSalMasterValue);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool ComponentTransEmpSalMasterValueExists(long id)
//        {
//            return (_context.ComponentTransEmpSalMasterValues?.Any(e => e.IntCompSalMasValId == id)).GetValueOrDefault();
//        }
//    }
//}
