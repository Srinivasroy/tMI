﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public LocationMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/LocationMasters
        [HttpGet("GetLocationMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
            //public async Task<ActionResult<IEnumerable<LocationMaster>>> GetLocationMasters()
            public async Task<ActionResult<LocationMasterViewModel>> GetAllLocationMasters()
            {
            try
            {
                if (_context.LocationMasters == null)
                {
                    return NotFound();
                }
                var locationviewmodel = new LocationMasterViewModel
                {
                    locationMasterlist = await _context.LocationMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                    cityViewModel = new CityViewModel
                    {
                        cityList = await _context.CityMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                        stateList = await _context.StateMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                        countryList = await _context.CountryMasters.Where(x => x.companyId == currentCompanyId).ToListAsync()
                    }
                };


                return locationviewmodel;
                //return await _context.LocationMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/LocationMasters/5
        [HttpGet("GetLocationMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<LocationMaster>> GetLocationMaster(long id)
        {
            var locationMaster = await _context.LocationMasters.FindAsync(id);

            if (locationMaster == null)
            {
                return NotFound();
            }

            return locationMaster;
        }

        // PUT: api/LocationMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutLocationMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutLocationMaster(long id, LocationMaster locationMaster)
        //{
        //    if (id != locationMaster.locationId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(locationMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!LocationMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/LocationMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostLocationMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostLocationMaster(LocationMaster locationMaster)
        {
            try
            {
                if (locationMaster.locationId == 0)
                {
                    if (LocationNameExists(locationMaster.locationName, locationMaster.companyId, locationMaster.countryId, locationMaster.stateId, locationMaster.cityId))
                    {
                        return Conflict(new { message = $"Location  '{locationMaster.locationName}' already exists" });
                    }
                }

                locationMaster.createdTime = DateTime.UtcNow;
                locationMaster.updatedDate = locationMaster.createdTime;
                locationMaster.createdBy = EmailId;
                locationMaster.updatedBy = locationMaster.createdBy;
                _context.LocationMasters.Update(locationMaster);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
                //throw;
            }
            var locationmasterjson = JsonConvert.SerializeObject(locationMaster);
            var _locationmaster = System.Text.Json.JsonSerializer.Deserialize<object>(locationmasterjson);

            return _locationmaster;
            //return CreatedAtAction("GetLocationMaster", new { id = locationMaster.locationId }, locationMaster);
        }

        private bool LocationMasterExists(long id)
        {
            return _context.LocationMasters.Any(e => e.locationId == id);
        }
        private bool LocationNameExists(string? LocationName, long? companyId, long? countryId, long? stateId, long? cityId)
        {
            return _context.LocationMasters.Any(e => e.locationName == LocationName && e.companyId == companyId && e.countryId == countryId && e.stateId == stateId && e.cityId == cityId);
        }
    }
}
