﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class AdditionalMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;
//        private int currentCompanyId = MasterContext.CurrentCompanyId;

//        public AdditionalMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/AdditionalMasters
//        [HttpGet("GetAdditionalMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<IEnumerable<AdditionalMaster>>> GetAdditionalMaster()
//        {
//            try
//            {
//                if (_context.AdditionalMasters == null)
//                {
//                    return NotFound();
//                }
//                return await _context.AdditionalMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
//            }
//            catch (Exception ex)
//            {
//                return Conflict(new { messsage = ex.Message });
//            }
//        }

//        // GET: api/AdditionalMasters/5
//        [HttpGet("GetAdditionalMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<AdditionalMaster>> GetAdditionalMaster(long id)
//        {
//          if (_context.AdditionalMasters == null)
//          {
//              return NotFound();
//          }
//            var additionalMaster = await _context.AdditionalMasters.FindAsync(id);

//            if (additionalMaster == null)
//            {
//                return NotFound();
//            }

//            return additionalMaster;
//        }

//        // PUT: api/AdditionalMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutAdditionalMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<IActionResult> PutAdditionalMaster(long id, AdditionalMaster additionalMaster)
//        {
//            if (id != additionalMaster.additionalMasterId)
//            {
//                return BadRequest();
//            }

//            _context.Entry(additionalMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!AdditionalMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/AdditionalMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostAdditionalMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<ActionResult<AdditionalMaster>> PostAdditionalMaster(AdditionalMaster additionalMaster)
//        {
//          if (_context.AdditionalMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.AdditionalMaster'  is null.");
//          }
//            _context.AdditionalMasters.Add(additionalMaster);
//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateException)
//            {
//                if (AdditionalMasterExists(additionalMaster.additionalMasterId))
//                {
//                    return Conflict();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return CreatedAtAction("GetAdditionalMaster", new { id = additionalMaster.additionalMasterId }, additionalMaster);
//        }

//        // DELETE: api/AdditionalMasters/5
//        [HttpDelete("{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

//        public async Task<IActionResult> DeleteAdditionalMaster(long id)
//        {
//            if (_context.AdditionalMasters == null)
//            {
//                return NotFound();
//            }
//            var additionalMaster = await _context.AdditionalMasters.FindAsync(id);
//            if (additionalMaster == null)
//            {
//                return NotFound();
//            }

//            _context.AdditionalMasters.Remove(additionalMaster);
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }

//        private bool AdditionalMasterExists(long id)
//        {
//            return (_context.AdditionalMasters?.Any(e => e.additionalMasterId == id)).GetValueOrDefault();
//        }
//    }
//}
