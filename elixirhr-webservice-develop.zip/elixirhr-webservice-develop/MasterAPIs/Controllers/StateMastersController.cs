﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;
using ExcelDataReader;
using MasterAPIs.Models.Helper;
using MySqlConnector;
using System.Data;
using Newtonsoft.Json;
using System.Collections;
using static MasterAPIs.Models.Helper.Helper;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StateMastersController : ControllerBase
    {
        private readonly MasterContext _context;
        private int currentCompanyId = MasterContext.CurrentCompanyId;
        private string EmailId = MasterContext.Email;
        public StateMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/StateMasters
        // GET: api/StateMasters
        [HttpGet("GetStateMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetStateMasters()
        {
            try
            {
                if (_context.StateMasters == null)
                {
                    return NotFound();
                }
                var statelist = await (from name in _context.CountryMasters
                                       join id in _context.StateMasters
                                       on name.countryId
                                       equals id.countryId
                                       select new
                                       {
                                           name.countryName,
                                           id.stateName,
                                           id.stateId,
                                           id.countryId,
                                           id.status
                                       }
                ).ToListAsync();
                //var cityViewModel = new CityViewModel
                //{                 //       countryList = await _context.CountryMasters.Where(x => x.companyId == currentCompanyId).ToListAsync(),
                //       stateList = await _context.StateMasters.Where(x => x.companyId == currentCompanyId).ToListAsync()
                //};
                var statemasterjson = JsonConvert.SerializeObject(statelist);
                ArrayList statemasterlist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(statemasterjson);
                return statemasterlist;
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/StateMasters/5
        [HttpGet("GetStateMaster/{countryId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetStateMaster(long countryId)
        {
            var stateMaster = await _context.StateMasters.Where(c => c.countryId == countryId).ToListAsync();

            if (stateMaster == null)
            {
                return NotFound();
            }

            var statemasterjson = JsonConvert.SerializeObject(stateMaster);
            ArrayList statemasterlist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(statemasterjson);
            return statemasterlist;
        }

        // PUT: api/StateMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("PutStateMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> PutStateMaster(long id, StateMaster stateMaster)
        {
            var StateNameExists = _context.StateMasters.Where(x => x.stateName == stateMaster.stateName.ToString() && x.countryId == stateMaster.countryId && x.companyId == currentCompanyId).FirstOrDefault();
            if (id != stateMaster.stateId)
            {
                return BadRequest();
            }
            else if (StateNameExists != null)
            {
                return Conflict(new { message = $"State  {stateMaster.stateName} with country  already exists" });
            }

            _context.Entry(stateMaster).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StateMasterExists(id))
                {
                    return NotFound();
                }
                else if (StateMasterNameExists(stateMaster.stateName))
                {
                    return Conflict(new { message = $"State name '{stateMaster.stateName}' already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/StateMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostStateMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostStateMaster(StateMaster stateMaster)
        {
            try
            {
                //var name1= from name in _context.CountryMasters join id in _context.StateMasters on name.countryId equals id.countryId select name.countryName;
                var StateNameExists = _context.StateMasters.Where(x => x.stateName == stateMaster.stateName.ToString() && x.countryId == stateMaster.countryId && x.companyId == currentCompanyId).FirstOrDefault();
                if (StateNameExists != null)
                {
                    return Conflict(new { message = $"State  {stateMaster.stateName} with country  already exists" });
                }
                stateMaster.createdTime = DateTime.UtcNow;
                stateMaster.updatedDate = stateMaster.createdTime;
                _context.StateMasters.Add(stateMaster);

                await _context.SaveChangesAsync();
            }
            catch
            {

                if (StateMasterNameExists(stateMaster.stateName))
                {
                    return Conflict(new { message = $"State name '{stateMaster.stateName}' already exists !!!" });
                }
                else
                {
                    throw;
                }
            }
            var statemasterjson = JsonConvert.SerializeObject(stateMaster);
            var _statemaster = System.Text.Json.JsonSerializer.Deserialize<object>(statemasterjson);

            return _statemaster;
            //return CreatedAtAction("GetStateMaster", new { id = stateMaster.stateId }, stateMaster);
        }

        //added by shwe 

        [HttpPost("BulkUpload")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<object>> BulkUpload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return Conflict(new { message = "No file was uploaded !!!" });
            }

            if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
                && !Path.GetExtension(file.FileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                //return new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" };
                return Conflict(new { message = "Invalid file format. Only Excel files (.xlsx, .xls) are supported!!!" });
            }
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            // Create a stream to read the Excel file
            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);

                // Create an ExcelDataReader instance to read the stream
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    });

                    var dataTable = result.Tables[0];
                    if (dataTable.Rows.Count == 0)
                    {
                        return Conflict(new { message = "The uploaded file does not contain any state and country data!" });
                    }
                    var countryList = await _context.CountryMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();
                    var countryRows = dataTable.Select().Distinct().ToList();

                    //comparing country from db and excel data
                    var countryNotFound = (
                    from country in countryRows
                    where !countryList.Any(x => x.countryName == country["country"].ToString())
                    select country["country"]);
                    if (countryNotFound != null && countryNotFound.Count() > 0)
                    {
                        return Conflict(new { messsage = "Countries not found " });
                    }
                    var ExcelStates = dataTable.AsEnumerable().Select(States => new
                    {
                        StateName = States["state"].ToString(),
                        CountryName = States["country"].ToString()
                    }).ToList();

                    var newStateList = (from est in ExcelStates
                                        join cnt in _context.CountryMasters on est.CountryName equals cnt.countryName
                                        join st in _context.StateMasters on est.StateName equals st.stateName into nst
                                        from estn in nst.DefaultIfEmpty(new StateMaster())
                                        select new StateMaster
                                        {
                                            stateId = (estn.stateId <= 0 ? 0 : estn.stateId),
                                            stateName = est.StateName,
                                            countryId = cnt.countryId,
                                            companyId = currentCompanyId,
                                            createdBy = (estn.stateId <= 0 ? EmailId : estn.createdBy),
                                            createdTime = (estn.stateId <= 0 ? DateTime.UtcNow : estn.createdTime),
                                            updatedBy = EmailId,
                                            updatedDate = DateTime.UtcNow,
                                            status = (int)Statuses.Approved
                                        }
                                        ).ToList();
                    try
                    {
                        _context.StateMasters.UpdateRange(newStateList);
                        await _context.SaveChangesAsync();
                        return new { message = "File uploaded sucessfully!!!", status = "success" };
                    }
                    catch (Exception ex)
                    {
                        return Conflict(ex.Message);
                    }
                }
            }
        }

        // DELETE: api/StateMaster/5
        [HttpDelete("StateDelete/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteStateMaster(long id)
        {
            var state = await _context.StateMasters.FindAsync(id);
            if (state == null)
            {
                return NotFound();
            }
            _context.StateMasters.Remove(state);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool StateMasterExists(long id)
        {
            return _context.StateMasters.Any(e => e.stateId == id);
        }
        private bool StateMasterNameExists(string stateName)
        {
            return _context.StateMasters.Any(e => e.stateName == stateName);
        }
    }
}
