﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class TaxSlabOptedforMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public TaxSlabOptedforMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/TaxSlabOptedforMasters
//        [HttpGet("GetTaxSlabOptedforMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<TaxSlabOptedforMaster>>> GetTaxSlabOptedforMasters()
//        {
//          if (_context.TaxSlabOptedforMasters == null)
//          {
//              return NotFound();
//          }
//            return await _context.TaxSlabOptedforMasters.ToListAsync();
//        }

//        // GET: api/TaxSlabOptedforMasters/5
//        [HttpGet("GetTaxSlabOptedforMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<TaxSlabOptedforMaster>> GetTaxSlabOptedforMaster( long id)
//        {
//          if (_context.TaxSlabOptedforMasters == null)
//          {
//              return NotFound();
//          }
//            var taxSlabOptedforMaster = await _context.TaxSlabOptedforMasters.FindAsync(id);

//            if (taxSlabOptedforMaster == null)
//            {
//                return NotFound();
//            }

//            return taxSlabOptedforMaster;
//        }

//        // PUT: api/TaxSlabOptedforMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut(("PutTaxSlabOptedforMaster/{id}"))]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutTaxSlabOptedforMaster( long id, TaxSlabOptedforMaster taxSlabOptedforMaster)
//        {
//            if (id != taxSlabOptedforMaster.IntTaxSlabOptedforId)
//            {
//                return BadRequest();
//            }

//            if (id >= 1)
//            {

//                if (!Helper.IntCompanyIdExists((long)taxSlabOptedforMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{taxSlabOptedforMaster.IntCompanyId}' not found." });
//                }

//            }

//            taxSlabOptedforMaster.DtUpdatedTime = DateTime.UtcNow;
//            _context.Entry(taxSlabOptedforMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!TaxSlabOptedforMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/TaxSlabOptedforMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostTaxSlabOptedforMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<TaxSlabOptedforMaster>> PostTaxSlabOptedforMaster( TaxSlabOptedforMaster taxSlabOptedforMaster)
//        {
//          if (_context.TaxSlabOptedforMasters == null)
//          {
//              return Problem("Entity set 'MasterContext.TaxSlabOptedforMasters'  is null.");
//          }

//            if (taxSlabOptedforMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }

//            taxSlabOptedforMaster.DtUpdatedTime = DateTime.UtcNow;
//            taxSlabOptedforMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.TaxSlabOptedforMasters.Add(taxSlabOptedforMaster);
//            try
//            {

//                if (!Helper.IntCompanyIdExists((long)taxSlabOptedforMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{taxSlabOptedforMaster.IntCompanyId}' not found." });
//                }

//                await _context.SaveChangesAsync();

//            }
//            catch (DbUpdateException)
//            {
//                throw;
//            }
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetTaxSlabOptedforMaster", new {  id = taxSlabOptedforMaster.IntTaxSlabOptedforId }, taxSlabOptedforMaster);
//        }

//        // DELETE: api/TaxSlabOptedforMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeleteTaxSlabOptedforMaster(long id)
//        //{
//        //    if (_context.TaxSlabOptedforMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var taxSlabOptedforMaster = await _context.TaxSlabOptedforMasters.FindAsync(id);
//        //    if (taxSlabOptedforMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.TaxSlabOptedforMasters.Remove(taxSlabOptedforMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool TaxSlabOptedforMasterExists(long id)
//        {
//            return (_context.TaxSlabOptedforMasters?.Any(e => e.IntTaxSlabOptedforId == id)).GetValueOrDefault();
//        }
//    }
//}
