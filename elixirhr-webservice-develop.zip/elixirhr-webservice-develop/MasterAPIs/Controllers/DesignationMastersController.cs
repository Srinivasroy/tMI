﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authorization;

namespace MasterAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DesignationMastersController : ControllerBase
    {
        private readonly MasterContext _context;

        private int currentCompanyId = MasterContext.CurrentCompanyId;

        public DesignationMastersController(MasterContext context)
        {
            _context = context;
        }

        // GET: api/DesignationMasters
        [HttpGet("GetDesignationMasters")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<DesignationMaster>>> GetDesignationMasters()
        {
            try
            {
                if (_context.DesignationMasters == null)
                {
                    return NotFound();
                }
                //var gradeMasterViewModel = new GradeMasterViewModel
                //{

                //    gradelist = await _context.GradeMasters.Where(x => x.companyId == currentCompanyId).ToListAsync()
                //};
                //return gradeMasterViewModel;
                return await _context.DesignationMasters.Where(x => x.companyId == currentCompanyId).ToListAsync();


            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
        }

        // GET: api/DesignationMasters/5
        [HttpGet("GetDesignationMaster/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<DesignationMaster>> GetDesignationMaster(long id)
        {
            var designationMaster = await _context.DesignationMasters.FindAsync(id);

            if (designationMaster == null)
            {
                return NotFound();
            }

            return designationMaster;
        }

        //// PUT: api/DesignationMasters/5
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("PutDesignationMaster/{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> PutDesignationMaster(long id, DesignationMaster designationMaster)
        //{
        //    if (id != designationMaster.Id)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(designationMaster).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!DesignationMasterExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/DesignationMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostDesignationMaster")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostDesignationMaster(DesignationMaster designationMaster)
        {
            try
            {
                if (string.IsNullOrEmpty(designationMaster.designationName))
                {
                    return Conflict("DesignationName can not be null");
                }

                if (designationMaster.designationId > 0)
                {
                    designationMaster.updatedBy = MasterContext.Email;
                    designationMaster.updatedDate = DateTime.UtcNow;
                    _context.DesignationMasters.Update(designationMaster);
                    await _context.SaveChangesAsync();

                    return new { message = "Data updated successfully !!!" };
                }

                designationMaster.createdBy = MasterContext.Email;
                designationMaster.updatedBy = designationMaster.createdBy;
                designationMaster.createdTime = DateTime.UtcNow;
                designationMaster.updatedDate = DateTime.UtcNow;
                designationMaster.companyId = currentCompanyId;
                _context.DesignationMasters.Add(designationMaster);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { messsage = ex.Message });
            }
            return new { message = "Data Created successfully !!!" };
        }

        // DELETE: api/DesignationMasters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteDesignationMaster(long id)
        //{
        //    var designationMaster = await _context.DesignationMasters.FindAsync(id);
        //    if (designationMaster == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.DesignationMasters.Remove(designationMaster);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool DesignationMasterExists(long id)
        {
            return _context.DesignationMasters.Any(e => e.designationId == id);
        }
    }
}
