﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MasterAPIs.Models.Master;
//using Microsoft.AspNetCore.Authorization;
//using Master.Models.Helper;

//namespace MasterAPIs.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class PhysicalStatusMastersController : ControllerBase
//    {
//        private readonly MasterContext _context;

//        public PhysicalStatusMastersController(MasterContext context)
//        {
//            _context = context;
//        }

//        // GET: api/PhysicalStatusMasters
//        [HttpGet("GetPhysicalStatusMasters")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<IEnumerable<PhysicalStatusMaster>>> GetPhysicalStatusMasters()
//        {
//            if (_context.PhysicalStatusMasters == null)
//            {
//                return NotFound();
//            }
//            return await _context.PhysicalStatusMasters.ToListAsync();
//        }

//        // GET: api/PhysicalStatusMasters/5
//        [HttpGet("GetPhysicalStatusMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<PhysicalStatusMaster>> GetPhysicalStatusMaster( long id)
//        {
//            if (_context.PhysicalStatusMasters == null)
//            {
//                return NotFound();
//            }
//            var physicalStatusMaster = await _context.PhysicalStatusMasters.FindAsync(id);

//            if (physicalStatusMaster == null)
//            {
//                return NotFound();
//            }

//            return physicalStatusMaster;
//        }

//        // PUT: api/PhysicalStatusMasters/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("PutPhysicalStatusMaster/{id}")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<object>> PutPhysicalStatusMaster( long id, PhysicalStatusMaster physicalStatusMaster)
//        {
//            if (id != physicalStatusMaster.PhysicalStatusSeqId)
//            {
//                return BadRequest();
//            }
//            if (id >= 1)
//            {
//                if (!Helper.IntCompanyIdExists((long)physicalStatusMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{physicalStatusMaster.IntCompanyId}' not found." });
//                }

//            }

//            physicalStatusMaster.DtUpdatedDate = DateTime.UtcNow;

//            _context.Entry(physicalStatusMaster).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!PhysicalStatusMasterExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/PhysicalStatusMasters
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost("PostPhysicalStatusMaster")]
//        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
//        public async Task<ActionResult<PhysicalStatusMaster>> PostPhysicalStatusMaster( PhysicalStatusMaster physicalStatusMaster)
//        {
//            if (_context.PhysicalStatusMasters == null)
//            {
//                return Problem("Entity set 'MasterContext.PhysicalStatusMasters'  is null.");
//            }
//            if (physicalStatusMaster == null)
//            {
//                return Conflict(new { message = "Value cannot be null" });
//            }
//            physicalStatusMaster.DtUpdatedDate = DateTime.UtcNow;
//            physicalStatusMaster.TsCreatedTime = DateTime.UtcNow;
//            _context.PhysicalStatusMasters.Add(physicalStatusMaster);

//            try
//            {
//                if (!Helper.IntCompanyIdExists((long)physicalStatusMaster.IntCompanyId))
//                {
//                    return Conflict(new { message = $"Company Id '{physicalStatusMaster.IntCompanyId}' not found." });
//                }

//            }

//            catch (DbUpdateException)
//            {
//                throw;
//            }

//            await _context.SaveChangesAsync();
//            return CreatedAtAction("GetPhysicalStatusMaster", new {  id = physicalStatusMaster.PhysicalStatusSeqId }, physicalStatusMaster);
//        }

//        //// DELETE: api/PhysicalStatusMasters/5
//        //[HttpDelete("{id}")]
//        //public async Task<IActionResult> DeletePhysicalStatusMaster(long id)
//        //{
//        //    if (_context.PhysicalStatusMasters == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    var physicalStatusMaster = await _context.PhysicalStatusMasters.FindAsync(id);
//        //    if (physicalStatusMaster == null)
//        //    {
//        //        return NotFound();
//        //    }

//        //    _context.PhysicalStatusMasters.Remove(physicalStatusMaster);
//        //    await _context.SaveChangesAsync();

//        //    return NoContent();
//        //}

//        private bool PhysicalStatusMasterExists(long id)
//        {
//            return (_context.PhysicalStatusMasters?.Any(e => e.PhysicalStatusSeqId == id)).GetValueOrDefault();
//        }
//    }
//}
