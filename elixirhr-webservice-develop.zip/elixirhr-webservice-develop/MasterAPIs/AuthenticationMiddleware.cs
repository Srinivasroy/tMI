﻿//using Master.Models.client10;
using MasterAPIs.Models.Master;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc.Controllers;
using System.IdentityModel.Tokens.Jwt;

namespace MasterAPIs
{
    public class AuthenticationMiddleware
    {
        private readonly RequestDelegate _next;


        public AuthenticationMiddleware(RequestDelegate next)
        {
            this._next = next;

        }
        public async Task Invoke(HttpContext context)
        {
            try
            {
                var token = await context.GetTokenAsync("access_token") ?? context.Request.Headers["Authorization"];
                var schemaName = GetPropertyFromToken(token, "CurrentDbName");
                var handler = new JwtSecurityTokenHandler();
                var jwtSecurityToken = handler.ReadJwtToken(token);
                if (schemaName != null)
                {
                    string envName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");


                    IConfigurationRoot configuration = new ConfigurationBuilder()
         .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
         .AddJsonFile("appsettings.json")
         .AddJsonFile($"appsettings.{envName}.json")
         .Build();
                    var ConnectionString = configuration.GetConnectionString("MasterDatabase").ToString();
                    System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
                    builder.ConnectionString = ConnectionString;
                    builder["database"] = schemaName;
                    if (schemaName != null)
                    {
                        MasterContext.ConnectionString = builder.ConnectionString;
                        var controllerActionDescriptor = context.GetEndpoint().Metadata.GetMetadata<ControllerActionDescriptor>();
                        var controllerName = controllerActionDescriptor.ControllerName;
                        var actionName = controllerActionDescriptor.ActionName;
                        var propValue = jwtSecurityToken.Claims.First(claim => claim.Type == "CurrentCompanyId").Value;
                        MasterContext.CurrentCompanyId = Convert.ToInt32(jwtSecurityToken.Claims.First(claim => claim.Type == "CurrentCompanyId").Value);
                        MasterContext.CurrentDbName = jwtSecurityToken.Claims.First(claim => claim.Type == "CurrentDbName").Value;
                        MasterContext.ParentCompanyId = Convert.ToInt32(jwtSecurityToken.Claims.First(claim => claim.Type == "ParentCompanyId").Value);
                        MasterContext.ParentDbName = jwtSecurityToken.Claims.First(claim => claim.Type == "ParentDbName").Value;
                        MasterContext.CurrentRoleId = Convert.ToInt32(jwtSecurityToken.Claims.First(claim => claim.Type == "CurrentRoleId").Value);
                        MasterContext.CurrentRoleName = jwtSecurityToken.Claims.First(claim => claim.Type == "CurrentRoleName").Value;
                        MasterContext.Email = jwtSecurityToken.Claims.First(claim => claim.Type == System.Security.Claims.ClaimTypes.Email).Value;
                        await _next.Invoke(context);
                    }
                    else
                    {
                        // no authorization header    
                        context.Response.StatusCode = 401; //Unauthorized    
                        return;
                    }
                }
                else
                {
                    // no authorization header    
                    context.Response.StatusCode = 401; //Unauthorized    
                    return;
                }
            }
            catch (Exception e)
            {
                // no authorization header    
                context.Response.StatusCode = 400;
                throw;
            }
        }

        public static object GetPropertyFromToken(string token, string propName)
        {



            token = token.Replace("Bearer ", string.Empty);
            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(token);
            try
            {
                var propValue = jwtSecurityToken.Claims.First(claim => claim.Type == propName).Value;
                return propValue;
            }
            catch (Exception ex)
            {
                //
            }

            return DBNull.Value;
        }
    }
}


