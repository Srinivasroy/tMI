﻿namespace MasterAPIs.Models.Master
{
    public class CategoryMaster
    {
        public long categoryId { get; set; }
        public string? empCategoryName { get; set; }
        public long? companyId { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public string? tenure { get; set; }
        public int? status { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
    }
}
