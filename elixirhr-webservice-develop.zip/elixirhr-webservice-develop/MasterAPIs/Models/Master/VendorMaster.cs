﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class VendorMaster
    {
        public long VendorSeqId { get; set; }
        public string? VendorName { get; set; }
        public long? VendorCategoryId { get; set; }
        public string? VendorCode { get; set; }
        public string? VendorAddress { get; set; }
        public string? EmailId { get; set; }
        public string? Name1 { get; set; }
        public string? Name2 { get; set; }
        public string? Phone1 { get; set; }
        public string? Phone2 { get; set; }
        public string? EmailId1 { get; set; }
        public string? EmailId2 { get; set; }
        public string? Preferred { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
    }
}
