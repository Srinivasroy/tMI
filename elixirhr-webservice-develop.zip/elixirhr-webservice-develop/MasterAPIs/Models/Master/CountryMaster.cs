﻿namespace MasterAPIs.Models.Master
{
    public class CountryMaster
    {
        public long countryId { get; set; }
        public string? countryName { get; set; }
        public string? countryCode { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
        public long? companyId { get; set; }

        public int? status { get; set; }
    }
}
