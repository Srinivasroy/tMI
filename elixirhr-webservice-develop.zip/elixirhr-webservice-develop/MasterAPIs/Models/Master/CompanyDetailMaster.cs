﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class CompanyDetailMaster
    {
        //public CompanyDetailMaster()
        //{
        //    ComponentMasCtcMasters = new HashSet<ComponentMasCtcMaster>();
        //    ComponentTransEmpSalMasterValues = new HashSet<ComponentTransEmpSalMasterValue>();
        //    DocumentMasters = new HashSet<DocumentMaster>();
        //    EmployeeMasters = new HashSet<EmployeeMaster>();
        //    PfDetailMasters = new HashSet<PfDetailMaster>();
        //}


        public long CompanySeqId { get; set; }

        [Required]
        public long? IntClientId { get; set; }
        public string? CompanyName { get; set; }
        public string? CompanyAddress { get; set; }
        public string? PanNo { get; set; }
        public string? TanNo { get; set; }
        public long? CompanyLogo { get; set; }
        public string? PfReg { get; set; }
        public string? EsiReg { get; set; }
        public string? VchPfReg { get; set; }
        public string? VchEsiReg { get; set; }
        public string? VchCompanyId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchEmpCodeFormula { get; set; }
        public long? IntIncrementBy { get; set; }
        public long? IntLastEmpNo { get; set; }
        public string? VchEmpCodeAssigned { get; set; }
        public string? VchLogoPath { get; set; }

        //public virtual ICollection<ComponentMasCtcMaster> ComponentMasCtcMasters { get; set; }
        //public virtual ICollection<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; }
        //public virtual ICollection<DocumentMaster> DocumentMasters { get; set; }
        //public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
        //public virtual ICollection<PfDetailMaster> PfDetailMasters { get; set; }

    }
}
