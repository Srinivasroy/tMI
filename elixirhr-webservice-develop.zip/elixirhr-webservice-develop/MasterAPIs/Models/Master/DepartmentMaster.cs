﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public class DepartmentMaster
    {
        public long departmentId { get; set; }
        public string? departmentName { get; set; }
        public string? createdBy { get; set; }
        public DateTime? createdTime { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? updatedDate { get; set; }

        [Required(ErrorMessage = "Company Id is mandatory")]
        public long? companyId { get; set; }
       
       
        public string? deptShortName { get; set; }
        public int? status { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
    
       

    }
}
