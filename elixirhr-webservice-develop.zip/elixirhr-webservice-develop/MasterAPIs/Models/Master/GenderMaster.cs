﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace MasterAPIs.Models.Master
{
    public class GenderMaster
    {
        public long genderId { get; set; }
        [Required(ErrorMessage = "gender is mandatory")]
        public string? gender { get; set; }
        public long? companyId { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [JsonIgnore]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public string? updatedBy { get; set; }

        public int? status { get; set; }

    }
}
