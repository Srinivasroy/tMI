﻿namespace MasterAPIs.Models.Master
{
    public class BankMaster
    {
        public long bankId { get; set; }
        public string? bankName { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
        public int? status { get; set; }
        public long? companyId { get; set; }
    }
}
