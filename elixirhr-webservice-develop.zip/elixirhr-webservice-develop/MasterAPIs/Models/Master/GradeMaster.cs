﻿using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public class GradeMaster
    {
        public long gradeId { get; set; }
        [Required(ErrorMessage = "RCSGradeName is mandatory")]
        public string? RCSgradeName { get; set; }
        public string? RCSgradeShortName { get; set; }
        public long? companyId { get; set; }
        [Required(ErrorMessage = "LocationId is mandatory")]
        public int? locationId { get; set; }
        public string? locationName { get; set; }
        public string? createdBy { get; set; }
        public int? status { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
    }
}
