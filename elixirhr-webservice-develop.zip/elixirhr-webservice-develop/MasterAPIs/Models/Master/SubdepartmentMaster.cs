﻿using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public class SubdepartmentMaster
    {
        public long subdepartmentId { get; set; }
        [Required(ErrorMessage = "DepartmentId is mandatory")]
        public long? departmentId { get; set; }
        [Required(ErrorMessage = "SubDepartment is mandatory")]
        public string? subDepartment { get; set; }
        [Required(ErrorMessage = "CompanyId is mandatory")]
        public long? companyId { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public int? status { get; set; }
    }
}
