﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class EmployeeMaster
    {

        

        //public EmployeeMaster()
        //{
        //    ClientUserMasters = new HashSet<ClientUserMaster>();
        //    ComponentMasCtcMasters = new HashSet<ComponentMasCtcMaster>();
        //    ComponentTransEmpSalMasterValues = new HashSet<ComponentTransEmpSalMasterValue>();
        //    PfDetailMasters = new HashSet<PfDetailMaster>();
        //}


        public long EmployeeSeqId { get; set; }
        public string? EmpCode { get; set; }
        public string? EmpName { get; set; }
        public string? ReportTo { get; set; }
        public string? Gender { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ProbationDate { get; set; }
        public int? ProbationDays { get; set; }
        public DateTime? ConfirmationDate { get; set; }
        public DateTime? ResignationDate { get; set; }
        public DateTime? LeavingDate { get; set; }
        public string? Company { get; set; }
        public string? Division { get; set; }
        public string? Branch { get; set; }

        [Required]
        public long? Category { get; set; }
        public string? Status { get; set; }
        public string? Grade { get; set; }

        [Required]
        public long? Designation { get; set; }

        [Required]
        public long? Department { get; set; }

        [Required]
        public long? Departments { get; set; }

        [Required]
        public long? Costcenter { get; set; }

        [Required]
        public long? Location { get; set; }

        [Required]
        public long? LeaveGroup { get; set; }

        [Required]
        public long? PhysicalStatus { get; set; }

        [Required]
        public long? EmploymentType { get; set; }

        [Required]
        public long? BankName { get; set; }

        [Required]
        public long? TaxSlabOpted { get; set; }

        [Required]
        public long? AbeCodeValue { get; set; }

        [Required]
        public long? ItsRoleSfiaValue { get; set; }

        [Required]
        public long? MidpointValue { get; set; }

        [Required]
        public long? RcslevelValue { get; set; }

        [Required]
        public long? Subdepartment { get; set; }

        [Required]
        public long? ProductivityFactor { get; set; }

        [Required]
        public long? MaritalStatus { get; set; }
        public string? PtLocation { get; set; }
        public double? CtcAmount { get; set; }
        public long? Role { get; set; }
        public string? Reference { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public long? SalaryDtl { get; set; }
        public long? PersonalInfo { get; set; }
        public decimal? DouNewCtc { get; set; }
        public decimal? DouCurrCtc { get; set; }

        [Required]
        public long? IntGradeId { get; set; }
        public string? VchReptCode { get; set; }
        public string? VchPanCode { get; set; }
        public string? VchMailid { get; set; }

        [Required]
        public long? IntCompanyRoleId { get; set; }

        [Required]
        public long? IntCompanyId { get; set; }
        public string? VchPassword { get; set; }
        public long? EmpDetailInfoSeq { get; set; }
        public long? IntNimineeSeqId { get; set; }
        public decimal? IntEmpSalaryDtls { get; set; }
        public string? VarPerMiddleName { get; set; }
        public string? VarPerLastName { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? RoleChangeDate { get; set; }
        public string? VchRoleAssignBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchReptName { get; set; }
        public string? VchProfilePath { get; set; }
        public byte[]? EmpPhotoBlob { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public string? VchOperation { get; set; }
        public string? VchSchemaKey { get; set; }
        public int? IntAppraisalCount { get; set; }
        public string? VchRmFlag { get; set; }
        public string? VchPwdChangeReq { get; set; }
        public string? VchPwdResetKey { get; set; }
        public string? VchSignupReq { get; set; }
        public string? VchSignupResetKey { get; set; }
        public string? VchOldPwd1 { get; set; }
        public string? VchOldPwd2 { get; set; }
        public DateTime? TsPwdChangeDate { get; set; }
        public string? VchPwdExpired { get; set; }
        public string? CnfPending { get; set; }
        public string? ExitInitiationPending { get; set; }

        [Required]
        public long? IntRcsgradeId { get; set; }
        public int? IntConfExtendedTimes { get; set; }
        public string? HireType { get; set; }
        public string? OncallAllowanceEligibility { get; set; }
        public string? ShiftAllowanceEligibility { get; set; }
        public string? TypeOfWorker { get; set; }
        public string? Billing { get; set; }
        public string? ProfessionalShiftAllowanceEligibility { get; set; }
        public string? VchBusinessPartner { get; set; }
        public string? VchBusinessUnit { get; set; }
        public string? VchGroup { get; set; }
        public string? VchGroups { get; set; }
        public string? TotalExperience { get; set; }
        public string? Ldap { get; set; }
        public string? SapEmployeeNo { get; set; }
        public DateTime? GroupDoj { get; set; }
        public string? SapPositionId { get; set; }
        public string? VarKycPfNo { get; set; }
        public string? VchOldPf { get; set; }
        public float? IntPrivilegeLeave { get; set; }
        public float? IntCasualLeave { get; set; }
        public float? IntSickLeave { get; set; }
        public int? IntMaternityLeave { get; set; }
        public int? IntPaternityLeave { get; set; }
        public int? IntMiscarriageLeave { get; set; }
        public int? IntOptionalLeave { get; set; }
        public int? IntCovaccineLeave { get; set; }
        public DateTime? DpdhlJoining { get; set; }
        public string? ActionCode { get; set; }
        public string? ReasonCode { get; set; }
        public string? RcsFlag { get; set; }
        public string? SapFlag { get; set; }
        public string? DescFlag { get; set; }
        public string? SapSalaryFlag { get; set; }
        public string? SalaryFlag { get; set; }


       

        //public virtual EmployeeCategoryMaster? CategoryNavigation { get; set; }
        //public virtual CostcenterMaster? CostcenterNavigation { get; set; }
        //public virtual DepartmentMaster? DepartmentNavigation { get; set; }
        //public virtual DepartmentsMaster? DepartmentsNavigation { get; set; }
        //public virtual DesignationMaster? DesignationNavigation { get; set; }
        //public virtual EmploymentTypeMaster? EmploymentTypeNavigation { get; set; }
        //public virtual CompanyDetailMaster? IntCompany { get; set; }
        //public virtual RcsgradeMaster? IntRcsgrade { get; set; }
        //public virtual ItsRoleSfiaMaster? ItsRoleSfiaValueNavigation { get; set; }
        //public virtual LeaveGroupMaster? LeaveGroupNavigation { get; set; }
        //public virtual LocationMaster? LocationNavigation { get; set; }
        //public virtual TaxSlabOptedforMaster? TaxSlabOptedNavigation { get; set; }
        //public virtual ICollection<ClientUserMaster> ClientUserMasters { get; set; }
        //public virtual ICollection<ComponentMasCtcMaster> ComponentMasCtcMasters { get; set; }
        //public virtual ICollection<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; }
        //public virtual ICollection<PfDetailMaster> PfDetailMasters { get; set; }

    }
}
