namespace MasterAPIs.Models.Master
{
    public class BranchMaster
    {
        public long branchId { get; set; }

        public long companyId { get; set; }

        public string? branchName { get; set; }
      
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }

        public DateTime? createdTime { get; set; }
        public DateTime? updatedTime { get; set; }

        public int? status { get; set; }
    }

}
