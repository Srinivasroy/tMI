﻿namespace MasterAPIs.Models.Master
{
    public class GradeMasterViewModel
    {
        public List<GradeMaster> gradelist { get; set; }

    }
}
