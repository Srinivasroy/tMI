﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class DocumentMaster
    {
        public int IntDocId { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// HRP,HRA,HRR,LG
        /// </summary>
        public string? VchDocName { get; set; }
        public string? VchDocDescription { get; set; }
        public string? VchActive { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }

        //public virtual CompanyDetailMaster? IntCompany { get; set; }
    }
}
