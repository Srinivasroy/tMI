﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace MasterAPIs.Models.Master
{
    public partial class MasterAttribute
    {
        [JsonIgnore]
        public long Id { get; set; }
        public string? Name { get; set; }
        public string? DisplayName { get; set; }
        public long? ParentId { get; set; }
        public string? Status { get; set; }
        [JsonIgnore]
        public int? OrderNo { get; set; }
        public string? Comments { get; set; }
        public int? NotificationId { get; set; }
        [JsonIgnore]
        public int? ApprovedOrderNo { get; set; }
        public long? IntCompanyId { get; set; }
    }

    public class ChangeOrderObject
    {
        public List<int> actualOrder { get; set; }
        public List<int> changeOrder { get; set; }
    }
}
