using MessagePack;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public class MaritalStatusMaster
    {
        [System.ComponentModel.DataAnnotations.Key]
        public long maritalStatusId { get; set; }
        [Required(ErrorMessage = "maritalStatus is mandatory")]
        public string? maritalStatus { get; set; }
        public DateTime updatedDate { get; set; }

        public DateTime createdTime { get; set; }
        public long companyId { get; set; }
        public string? updatedBy { get; set; }
        public string? createdBy { get; set; }
        public int? status { get; set; }

       

    }
}
