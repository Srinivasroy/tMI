﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class ComponentTransEmpSalMasterValue
    {
        public long IntCompSalMasValId { get; set; }
        /// <summary>
        /// Reference from component_mas_creation
        /// </summary>
        /// 
        [Required]
        public long? IntCompSeqId { get; set; }

        [Required]
        public long? IntEmployeeSeqId { get; set; }

        [Required]
        public long? IntComMCtcMasId { get; set; }
        public string? VchComponentName { get; set; }
        public long? IntNumValue { get; set; }
        public string? VchStrValue { get; set; }
        public DateTime? DtDateValue { get; set; }
        public string? VchValueAssiged { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public byte[]? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }

        [Required]
        public long? IntCompanyId { get; set; }
        public string? VchTransactionId { get; set; }
        public string? VchCompShortName { get; set; }
        public string? VchShowView { get; set; }
        public string? VchShowPayslip { get; set; }

        //public virtual ComponentMasCtcMaster? IntComMCtcMas { get; set; }
        //public virtual CompanyDetailMaster? IntCompany { get; set; }
        //public virtual EmployeeMaster? IntEmployeeSeq { get; set; }
    }
}
