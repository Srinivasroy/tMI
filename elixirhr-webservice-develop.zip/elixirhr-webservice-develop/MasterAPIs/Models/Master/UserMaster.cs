﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class UserMaster
    {
        public long UserSeqId { get; set; }
        public string? UserFirstname { get; set; }
        public string? UserLastname { get; set; }
        public string? UserId { get; set; }
        public string? UserPassword { get; set; }
        public short? Isproxy { get; set; }
        public string? ProxyFor { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedTs { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreatedTs { get; set; }
        public long? FileSeqid { get; set; }
        public string? UserEmail { get; set; }
        public long? RoleSeqid { get; set; }
        public string? UserMobileNo { get; set; }
        public long? IntLocationSeqId { get; set; }
        public string? VchStatus { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }

        [Required]
        public int IntCompanyId { get; set; }
    }
}
