﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class ReportsDomainMaster
    {
        public long IntId { get; set; }
        public string? VchDomainName { get; set; }
        public string? VchPackageName { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
    }
}
