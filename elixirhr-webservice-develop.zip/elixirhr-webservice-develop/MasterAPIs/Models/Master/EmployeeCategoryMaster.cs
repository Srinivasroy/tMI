﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class EmployeeCategoryMaster
    {
        //public EmployeeCategoryMaster()
        //{
        //    EmployeeMasters = new HashSet<EmployeeMaster>();
        //}

        public long EmployeeCategorySeqId { get; set; }
        public string? EmpCategoryName { get; set; }
        public string? Tenure { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchActive { get; set; }
        public DateTime? DtFromDate { get; set; }
        public DateTime? DtToDate { get; set; }
        public string? VchTransactionId { get; set; }
        public string? VchModified { get; set; }

        //public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
    }
}
