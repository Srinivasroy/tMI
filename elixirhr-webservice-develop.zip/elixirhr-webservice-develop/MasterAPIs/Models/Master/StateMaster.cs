using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public class StateMaster
    {
       
            public long stateId { get; set; }

        [Required(ErrorMessage = "stateName is mandatory")]
            public string? stateName { get; set; }
          
            public string? createdBy { get; set; }
            public DateTime? createdTime { get; set; }
            public string? updatedBy { get; set; }
            public DateTime? updatedDate { get; set; }
             [Required(ErrorMessage = "companyId is mandatory")]
            public long? companyId { get; set; }
            public long? countryId { get; set; }

        //[Required(ErrorMessage = "countryName is mandatory")]
        //public string? countryName { get; set; }
            public int? status { get; set; }
  }
}
