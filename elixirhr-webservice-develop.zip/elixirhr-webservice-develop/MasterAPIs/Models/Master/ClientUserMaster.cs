﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class ClientUserMaster
    {
        public long ClientSeqId { get; set; }
        public string? UserName { get; set; }
        public string? UserMailid { get; set; }
        public string? UserMobileno { get; set; }
        public string? UserCode { get; set; }
        public string? AdminOrUser { get; set; }
        public string? VchStatus { get; set; }
        public string? UserPassword { get; set; }

        [Required]
        public long? IntClientUserRoleId { get; set; }

        [Required]
        public long? IntCompanyRoleId { get; set; }

        [Required]
        public long? IntEmpSeqId { get; set; }
        public string? VchUserCreatedBy { get; set; }

        [Required]
        public long? IntCompanyId { get; set; }

        [Required]
        public long? IntClientId { get; set; }
        public long? IntOtpValue { get; set; }
        public string? VchOtpVerifyStatus { get; set; }

        [Required]
        public long? IntClientModuleGrpId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public string? VchGender { get; set; }
        public string? VchProfilePath { get; set; }
        public byte[]? BlobEmployeePhoto { get; set; }
        public string? VchSchemaKey { get; set; }
        public string? VchClientUserCompanies { get; set; }
        public string? VchPwdChangeReq { get; set; }
        public string? VchPwdResetKey { get; set; }
        public string? VchOldPwd1 { get; set; }
        public string? VchOldPwd2 { get; set; }
        public DateTime? TsPwdChangeDate { get; set; }
        public string? VchPwdExpired { get; set; }

        //public virtual EmployeeMaster? IntEmpSeq { get; set; }
    }
}
