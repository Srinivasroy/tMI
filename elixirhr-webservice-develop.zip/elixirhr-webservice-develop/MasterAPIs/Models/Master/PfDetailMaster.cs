﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class PfDetailMaster
    {
        public long IntPfId { get; set; }
        public string? RelationName { get; set; }
        public string? Relation { get; set; }
        public string? FreshMembership { get; set; }
        public string? PrevEpfMember { get; set; }
        public string? PrevPensionMember { get; set; }
        public string? WithdrawnPrevEpfpensionAmt { get; set; }
        public string? PreviousUanNumber { get; set; }
        public string? Nationality { get; set; }
        public string? InternationalWorker { get; set; }
        public string? NameAsPerAadharCard { get; set; }
        public string? NameAsPerPancard { get; set; }
        public string? BankAccountNo { get; set; }
        public string? IfscCode { get; set; }
        public string? NameAsPerBank { get; set; }
        public string? MobileNo { get; set; }
        public string? EmailId { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? DtUpdatedDate { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
        /// <summary>
        /// reference from employee master(employee_master)
        /// </summary>
        [Required]
        public long? IntEmpId { get; set; }

        //public virtual CompanyDetailMaster? IntCompany { get; set; }
        //public virtual EmployeeMaster? IntEmp { get; set; }
    }
}
