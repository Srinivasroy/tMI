﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace MasterAPIs.Models.Master
{
    public partial class CostcenterMaster
    {
        public long costCenterId { get; set; }
        public string? costCenterName { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public int? status { get; set; }
        public long? companyId { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
    }
}
