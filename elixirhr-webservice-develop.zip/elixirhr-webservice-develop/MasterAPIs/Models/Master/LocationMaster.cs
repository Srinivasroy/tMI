﻿using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public class LocationMaster
    {
        public long locationId { get; set; }
        [Required(ErrorMessage = "LocationName is mandatory")]
        public string? locationName { get; set; }
        public string? locationShortName { get; set; }
        [Required(ErrorMessage = "CountryId is mandatory")]
        public long? countryId { get; set; }
        [Required(ErrorMessage = "StateId is mandatory")]
        public long? stateId { get; set; }
        [Required(ErrorMessage = "CityId is mandatory")]
        public long? cityId { get; set; }
        public string? panNumber { get; set; }
        public string? tanNumber { get; set; }
        public string? factoryRegistrationNo { get; set; }
        public string? shopEstablishmentRegNo { get; set; }
        public string? pfSubCode { get; set; }
        public string? esiCode { get; set; }
        public string? profTaxRegistrationCode { get; set; }
        public string? lwfRegistrationCode { get; set; }
        public int? status { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        //public string? countryName { get; set; }
        //public string? stateName { get; set; }
        //public string? cityName { get; set; }
        //public string? Modified { get; set; }
        [Required(ErrorMessage = "CompanyId is mandatory")]
        public long? companyId { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public DateTime? createdTime { get; set; }


    }
}
