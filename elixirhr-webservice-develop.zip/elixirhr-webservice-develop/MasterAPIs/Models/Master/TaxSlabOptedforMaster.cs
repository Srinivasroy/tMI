﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class TaxSlabOptedforMaster
    {
        //public TaxSlabOptedforMaster()
        //{
        //    EmployeeMasters = new HashSet<EmployeeMaster>();
        //}

        public long IntTaxSlabOptedforId { get; set; }
        public string? VchTaxSlabOptedforName { get; set; }
        public DateTime? DtUpdatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }

        [Required]
        public long? IntCompanyId { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchCreatedBy { get; set; }
        public string? VchTransactionId { get; set; }

        //public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
    }
}
