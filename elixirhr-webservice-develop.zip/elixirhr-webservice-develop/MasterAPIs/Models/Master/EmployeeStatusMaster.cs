﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace MasterAPIs.Models.Master
{
    public class EmployeeStatusMaster
    {
        public long employeeStatusId { get; set; }
        [Required(ErrorMessage = "employeeStatus is mandatory")]
        public String? employeeStatus { get; set; }
        public int? status { get; set; }
        public long? companyId { get; set; }
        [JsonIgnore]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
    }
}
