﻿namespace MasterAPIs.Models.Master
{
    public class LocationMasterViewModel
    {
        public List<LocationMaster> locationMasterlist { get; set; }
        public CityViewModel cityViewModel  { get; set; }
    }
}
