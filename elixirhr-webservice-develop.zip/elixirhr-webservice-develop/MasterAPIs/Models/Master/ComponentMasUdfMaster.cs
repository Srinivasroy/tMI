﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class ComponentMasUdfMaster
    {
        public long IntUdfSeqId { get; set; }
        public string? VchFunctionName { get; set; }
        public string? VchSysFunctionName { get; set; }
        public DateTime? TSCreatedDate { get; set; }
        public DateTime? DTUpdatedDate { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
    }
}
