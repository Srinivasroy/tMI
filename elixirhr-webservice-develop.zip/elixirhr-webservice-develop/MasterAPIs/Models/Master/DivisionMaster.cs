﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace MasterAPIs.Models.Master
{
    public class DivisionMaster
    {
        public long divisionId { get; set; }
        [Required(ErrorMessage = "division is mandatory")]
        public string? division { get; set; }
        public long? companyId { get; set; }
        public int? status { get; set; }
        [JsonIgnore]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
    }
}
