﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using MasterAPIs.Models.Master;


namespace MasterAPIs.Models.Master
{
    public partial class MasterContext : DbContext
    {
        public MasterContext()
        {
        }

        public MasterContext(DbContextOptions<MasterContext> options)
            : base(options)
        {
        }

        public static int ParentCompanyId
        {
            get;
            set;
        }
        public static string ParentDbName
        {
            get;
            set;
        }
        public static int CurrentCompanyId
        {
            get;
            set;
        }
        public static string CurrentDbName
        {
            get;
            set;
        }
        public static int CurrentRoleId
        {
            get;
            set;
        }
        public static string CurrentRoleName
        {
            get;
            set;
        }
        public static string Email
        {
            get;
            set;
        }

        public virtual DbSet<CityMaster> CityMasters { get; set; } = null!;
        public virtual DbSet<GenderMaster> GenderMasters { get; set; } = null!;
        public virtual DbSet<MasterAttribute> Masters { get; set; } = null!;
        public virtual DbSet<AbeCodeMaster> AbeCodeMasters { get; set; } = null!;
        public virtual DbSet<BankNameMaster> BankNameMasters { get; set; } = null!;
        public virtual DbSet<BankMaster> BankMasters { get; set; } = null!;

        public virtual DbSet<CategoryMaster> Categories { get; set; } = null!;
        public virtual DbSet<ClientUserMaster> ClientUserMasters { get; set; } = null!;
        public virtual DbSet<CompanyDetailMaster> CompanyDetailMasters { get; set; } = null!;
        public virtual DbSet<ComponentMasCtcMaster> ComponentMasCtcMasters { get; set; } = null!;
        public virtual DbSet<ComponentMasUdfMaster> ComponentMasUdfMasters { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalMaster> ComponentTransEmpSalMasters { get; set; } = null!;
        public virtual DbSet<ComponentTransEmpSalMasterValue> ComponentTransEmpSalMasterValues { get; set; } = null!;
        public virtual DbSet<ConfigMasDynamicEmpMasterField> ConfigMasDynamicEmpMasterFields { get; set; } = null!;
        public virtual DbSet<ConfigMasTmiSuperAdminMaster> ConfigMasTmiSuperAdminMasters { get; set; } = null!;
        public virtual DbSet<CostcenterMaster> CostcenterMasters { get; set; } = null!;
        public virtual DbSet<CountryMaster> CountryMasters { get; set; } = null!;
        public virtual DbSet<DepartmentMaster> DepartmentMasters { get; set; } = null!;
        public virtual DbSet<DepartmentsMaster> DepartmentsMasters { get; set; } = null!;
        public virtual DbSet<DesignationMaster> DesignationMasters { get; set; } = null!;
        public virtual DbSet<DivisionMaster> DivisionMasters { get; set; } = null!;
        public virtual DbSet<DocumentMaster> DocumentMasters { get; set; } = null!;
        public virtual DbSet<DomainMaster> DomainMasters { get; set; } = null!;
        public virtual DbSet<EmployeeCategoryMaster> EmployeeCategoryMasters { get; set; } = null!;
        public virtual DbSet<EmployeeMaster> EmployeeMasters { get; set; } = null!;
        public virtual DbSet<EmploymentTypeMaster> EmploymentTypeMasters { get; set; } = null!;

        public virtual DbSet<EmployeeStatusMaster> EmployeeStatusMasters { get; set; } = null!;
        public virtual DbSet<GradeMaster> GradeMasters { get; set; } = null!;
        public virtual DbSet<ItsRoleSfiaMaster> ItsRoleSfiaMasters { get; set; } = null!;
        public virtual DbSet<LeaveGroupMaster> LeaveGroupMasters { get; set; } = null!;
        public virtual DbSet<LocationMaster> LocationMasters { get; set; } = null!;

        public virtual DbSet<MidpointMaster> MidpointMasters { get; set; } = null!;
        public virtual DbSet<PfDetailMaster> PfDetailMasters { get; set; } = null!;
        public virtual DbSet<QualificationMaster> QualificationMasters { get; set; } = null!;
        public virtual DbSet<RcsgradeMaster> RcsgradeMasters { get; set; } = null!;
        public virtual DbSet<RcslevelMaster> RcslevelMasters { get; set; } = null!;
        public virtual DbSet<ReportsDomainMaster> ReportsDomainMasters { get; set; } = null!;
        public virtual DbSet<SkillMaster> SkillMasters { get; set; } = null!;
        public virtual DbSet<TaxSlabOptedforMaster> TaxSlabOptedforMasters { get; set; } = null!;
        public virtual DbSet<UserMaster> UserMasters { get; set; } = null!;
        public virtual DbSet<VendorCategoryMaster> VendorCategoryMasters { get; set; } = null!;
        public virtual DbSet<VendorMaster> VendorMasters { get; set; } = null!;
        public virtual DbSet<PhysicalStatusMaster> PhysicalStatusMasters { get; set; } = null!;

        public virtual DbSet<ProductivityFactorMaster> ProductivityFactorMasters { get; set; } = null!;
        public virtual DbSet<MaritalStatusMaster> MaritalStatusMasters { get; set; } = null!;
        public virtual DbSet<SubdepartmentMaster> SubdepartmentMasters { get; set; } = null!;

        public virtual DbSet<StateMaster> StateMasters { get; set; } = null!;

        public virtual DbSet<BranchMaster> BranchMasters { get; set; } = null!;
        public virtual DbSet<AdditionalMaster> AdditionalMasters { get; set; } = null!;




        //public static string? ConnectionString { get; set; } = "server=127.0.0.1;port=3306;database=common_schema;uid=root;pwd=Test";
        public static string? ConnectionString { get; set; } = "";
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                string envName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                IConfigurationRoot configuration = new ConfigurationBuilder()
             .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
              .AddJsonFile("appsettings.json")
             .AddJsonFile($"appsettings.{envName}.json")
             .Build();
                optionsBuilder.UseMySql(ConnectionString, Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.28-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("latin1_swedish_ci")
               .HasCharSet("latin1");


            modelBuilder.Entity<BranchMaster>(entity =>
           {
               entity.HasKey(e => e.branchId)
                   .HasName("PRIMARY");

               entity.ToTable("branch_master");

               entity.Property(e => e.branchId)
               .ValueGeneratedOnAdd()
                   .HasColumnName("BranchId");

               entity.Property(e => e.branchName)
                   .HasMaxLength(45)
                   .HasColumnName("BranchName");

               entity.Property(e => e.companyId)
               .HasColumnName("CompanyId");

               entity.Property(e => e.createdBy)
                   .HasMaxLength(45)
                   .HasColumnName("CreatedBy");

               entity.Property(e => e.createdTime)
                  .HasColumnType("datetime")
                   .HasColumnName("CreatedTime");



               entity.Property(e => e.updatedBy)
                   .HasMaxLength(45)
                   .HasColumnName("UpdatedBy");

               entity.Property(e => e.updatedTime)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedTime");

               entity.Property(e => e.status)
            .HasColumnName("Status");
           });

            modelBuilder.Entity<AdditionalMaster>(entity =>
            {
                entity.HasKey(e => e.additionalMasterId)
                .HasName("PRIMARY");

                entity.ToTable("additional_master");

                entity.Property(e => e.additionalMasterId)
                .ValueGeneratedNever()
                .HasColumnName("AdditionalMasterId");

                entity.Property(e => e.name)
                .HasMaxLength(45)
                .HasColumnName("Name");

                entity.Property(e => e.description)
                .HasMaxLength(45)
                .HasColumnName("Description");

                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                .HasMaxLength(45)
                .HasColumnName("CreatedBy");


                entity.Property(e => e.createdTime)
                .HasColumnType("datetime")
                .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                .HasMaxLength(45)
                .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                .HasColumnType("datetime")
                .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                .HasColumnName("Status");
            });

            modelBuilder.Entity<StateMaster>(entity =>
            {
                entity.HasKey(e => e.stateId)
                    .HasName("PRIMARY");

                entity.ToTable("state_master");

                entity.Property(e => e.stateId)
                .ValueGeneratedOnAdd()
                .HasColumnName("StateId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.countryId).HasColumnName("CountryId");

                //entity.Property(e => e.countryName)
                //    .HasMaxLength(50)
                //    .HasColumnName("countryName");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.stateName)
                    .HasMaxLength(100)
                    .HasColumnName("StateName");

                entity.Property(e => e.status)
                .HasColumnName("Status");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");


            });

            modelBuilder.Entity<MasterAttribute>(entity =>
            {
                entity.ToTable("master");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApprovedOrderNo).HasColumnName("APPROVED_ORDER_NO");

                entity.Property(e => e.Comments)
                    .HasMaxLength(45)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.DisplayName)
                    .HasMaxLength(45)
                    .HasColumnName("DISPLAY_NAME");

                entity.Property(e => e.Name)
                    .HasMaxLength(45)
                    .HasColumnName("NAME");

                entity.Property(e => e.NotificationId).HasColumnName("NOTIFICATION_ID");

                entity.Property(e => e.OrderNo).HasColumnName("ORDER_NO");

                entity.Property(e => e.ParentId).HasColumnName("PARENT_ID");

                entity.Property(e => e.Status)
                    .HasMaxLength(45)
                    .HasColumnName("STATUS");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");
            });

            modelBuilder.Entity<ProductivityFactorMaster>(entity =>
            {
                entity.HasKey(e => e.ProductivityFactorSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("productivity_factor_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");


                entity.HasIndex(e => e.IntCompanyId, "fk_prod_fac_mas_int_companyid_idx");

                entity.Property(e => e.ProductivityFactorSeqId).HasColumnName("PRODUCTIVITY_FACTOR_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.ProductivityFactorValue)
                    .HasMaxLength(100)
                    .HasColumnName("PRODUCTIVITY_FACTOR_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.UseCollation("latin1_swedish_ci")
                .HasCharSet("latin1");

            modelBuilder.Entity<AbeCodeMaster>(entity =>
            {
                entity.HasKey(e => e.AbeCodeSeqId)
                    .HasName("PRIMARY");


                entity.ToTable("abe_code_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_abecode_master_company_id");

                entity.Property(e => e.AbeCodeSeqId).HasColumnName("ABE_CODE_SEQ_ID");

                entity.Property(e => e.AbeCodeValue)
                    .HasMaxLength(100)
                    .HasColumnName("ABE_CODE_VALUE");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<BankNameMaster>(entity =>
            {
                entity.HasKey(e => e.BankNameSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("bank_name_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_bank_name_master_int_companyid");

                entity.Property(e => e.BankNameSeqId).HasColumnName("BANK_NAME_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchBankName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_BANK_NAME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });


            modelBuilder.Entity<BankMaster>(entity =>
            {
                entity.HasKey(e => e.bankId)
                    .HasName("PRIMARY");

                entity.ToTable("bank_master");



                entity.HasIndex(e => e.bankId, "bank_id_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.bankId).HasColumnName("BankId");

                entity.Property(e => e.bankName)
                    .HasMaxLength(45)
                    .HasColumnName("BankName");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");



            });

            modelBuilder.Entity<CategoryMaster>(entity =>
            {
                entity.HasKey(e => e.categoryId)
                    .HasName("PRIMARY");

                entity.ToTable("category_master");

                entity.Property(e => e.categoryId)
                    .ValueGeneratedNever()
                    .HasColumnName("CategoryId");

                entity.Property(e => e.empCategoryName)
                    .HasMaxLength(50)
                    .HasColumnName("CategoryName");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.fromDate).HasColumnName("FromDate");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.tenure)
                    .HasMaxLength(50)
                    .HasColumnName("Tenure");

                entity.Property(e => e.toDate).HasColumnName("ToDate");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
            });

            modelBuilder.Entity<GenderMaster>(entity =>
            {
                entity.HasKey(e => e.genderId)
                  .HasName("PRIMARY");

                entity.ToTable("gender_master");

                entity.Property(e => e.genderId)
                .HasColumnName("GenderId");


                entity.Property(e => e.gender)
                    .HasMaxLength(45)
                    .HasColumnName("Gender");

                entity.Property(e => e.status)
               .HasColumnName("Status");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<CityMaster>(entity =>
            {
                entity.HasKey(e => e.cityId)
                  .HasName("PRIMARY");

                entity.ToTable("city_master");

                entity.Property(e => e.cityId).HasColumnName("CityId");


                entity.Property(e => e.cityName)
                    .HasMaxLength(45)
                    .HasColumnName("CityName");

                //entity.Property(e => e.stateName)
                //    .HasMaxLength(45)
                //    .HasColumnName("state_name");

                entity.Property(e => e.stateId).HasColumnName("StateId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");


                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

                entity.Property(e => e.status).HasColumnName("Status");
            });


            modelBuilder.Entity<ClientUserMaster>(entity =>
            {
                entity.HasKey(e => e.ClientSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("client_user_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientUserRoleId, "FK_CLIEUSEMAS_CLI_USER_ROLE_ID_idx");

                entity.HasIndex(e => e.IntCompanyRoleId, "FK_CLIUSEMAS_COMP_ROLE_ID_idx");

                entity.HasIndex(e => e.IntCompanyId, "FK_CLIUSEMAS_COMPANY_ID");

                entity.HasIndex(e => e.IntEmpSeqId, "INT_EMP_SEQ_ID");

                entity.HasIndex(e => e.IntClientId, "fk_cl_use_mas_clientid");

                entity.HasIndex(e => e.IntClientModuleGrpId, "fk_cl_use_mas_clientmodgrpid");

                entity.Property(e => e.ClientSeqId).HasColumnName("CLIENT_SEQ_ID");

                entity.Property(e => e.AdminOrUser)
                    .HasMaxLength(45)
                    .HasColumnName("ADMIN_OR_USER");

                entity.Property(e => e.BlobEmployeePhoto)
                    .HasColumnType("mediumblob")
                    .HasColumnName("blob_employee_photo");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntClientModuleGrpId).HasColumnName("INT_CLIENT_MODULE_GRP_ID");

                entity.Property(e => e.IntClientUserRoleId).HasColumnName("INT_CLIENT_USER_ROLE_ID");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("INT_COMPANY_ROLE_ID");

                entity.Property(e => e.IntEmpSeqId).HasColumnName("INT_EMP_SEQ_ID");

                entity.Property(e => e.IntOtpValue).HasColumnName("int_otp_value");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsPwdChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_pwd_change_date");

                entity.Property(e => e.UserCode)
                    .HasMaxLength(45)
                    .HasColumnName("USER_CODE");

                entity.Property(e => e.UserMailid)
                    .HasMaxLength(60)
                    .HasColumnName("USER_MAILID");

                entity.Property(e => e.UserMobileno)
                    .HasMaxLength(45)
                    .HasColumnName("USER_MOBILENO");

                entity.Property(e => e.UserName)
                    .HasMaxLength(50)
                    .HasColumnName("USER_NAME");

                entity.Property(e => e.UserPassword)
                    .HasMaxLength(80)
                    .HasColumnName("user_password");

                entity.Property(e => e.VchClientUserCompanies)
                    .HasColumnType("text")
                    .HasColumnName("vch_client_user_companies");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchGender)
                    .HasMaxLength(10)
                    .HasColumnName("vch_gender");

                entity.Property(e => e.VchOldPwd1)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd1");

                entity.Property(e => e.VchOldPwd2)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd2");

                entity.Property(e => e.VchOtpVerifyStatus)
                    .HasMaxLength(3)
                    .HasColumnName("vch_otp_verify_status");

                entity.Property(e => e.VchProfilePath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_profile_path");

                entity.Property(e => e.VchPwdChangeReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_change_req");

                entity.Property(e => e.VchPwdExpired)
                    .HasMaxLength(2)
                    .HasColumnName("vch_pwd_expired");

                entity.Property(e => e.VchPwdResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pwd_reset_key");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VchUserCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_USER_CREATED_BY");



                //entity.HasOne(d => d.IntEmpSeq)
                //    .WithMany(p => p.ClientUserMasters)
                //    .HasForeignKey(d => d.IntEmpSeqId)
                //    .HasConstraintName("client_user_master_ibfk_1");
            });

            modelBuilder.Entity<CompanyDetailMaster>(entity =>
            {
                entity.HasKey(e => e.CompanySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("company_detail_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntClientId, "int_client_id");

                entity.Property(e => e.CompanySeqId).HasColumnName("COMPANY_SEQ_ID");

                entity.Property(e => e.CompanyAddress)
                    .HasMaxLength(300)
                    .HasColumnName("COMPANY_ADDRESS");

                entity.Property(e => e.CompanyLogo).HasColumnName("COMPANY_LOGO");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(50)
                    .HasColumnName("COMPANY_NAME");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EsiReg)
                    .HasMaxLength(50)
                    .HasColumnName("ESI_REG");

                entity.Property(e => e.IntClientId).HasColumnName("int_client_id");

                entity.Property(e => e.IntIncrementBy).HasColumnName("int_increment_by");

                entity.Property(e => e.IntLastEmpNo).HasColumnName("int_last_emp_no");

                entity.Property(e => e.PanNo)
                    .HasMaxLength(45)
                    .HasColumnName("PAN_NO");

                entity.Property(e => e.PfReg)
                    .HasMaxLength(50)
                    .HasColumnName("PF_REG");

                entity.Property(e => e.TanNo)
                    .HasMaxLength(45)
                    .HasColumnName("TAN_NO");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCompanyId)
                    .HasMaxLength(20)
                    .HasColumnName("VCH_COMPANY_ID");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmpCodeAssigned)
                    .HasMaxLength(3)
                    .HasColumnName("vch_emp_code_assigned");

                entity.Property(e => e.VchEmpCodeFormula)
                    .HasMaxLength(200)
                    .HasColumnName("vch_emp_code_formula");

                entity.Property(e => e.VchEsiReg)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_ESI_REG");

                entity.Property(e => e.VchLogoPath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_logo_path");

                entity.Property(e => e.VchPfReg)
                    .HasMaxLength(30)
                    .HasColumnName("VCH_PF_REG");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });



            modelBuilder.Entity<ComponentMasCtcMaster>(entity =>
            {
                entity.HasKey(e => e.IntComMCtcMasId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_ctc_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_company_seq_id");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_component_ctc_seq_id");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.DouCtcAmount)
                    .HasColumnType("double(20,2)")
                    .HasColumnName("dou_ctc_amount");

                entity.Property(e => e.DtEffectiveDate).HasColumnName("dt_effective_date");

                entity.Property(e => e.DtSalUpdatedDate).HasColumnName("dt_sal_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchCtcModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_ctc_modified");

                entity.Property(e => e.VchMoveView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_move_view");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                //entity.HasOne(d => d.IntCompany)
                //    .WithMany(p => p.ComponentMasCtcMasters)
                //    .HasForeignKey(d => d.IntCompanyId)
                //    .HasConstraintName("fk_company_seq_id");

                //entity.HasOne(d => d.IntEmployeeSeq)
                //    .WithMany(p => p.ComponentMasCtcMasters)
                //    .HasForeignKey(d => d.IntEmployeeSeqId)
                //    .HasConstraintName("fk_component_ctc_seq_id");
            });

            modelBuilder.Entity<ComponentMasUdfMaster>(entity =>
            {
                entity.HasKey(e => e.IntUdfSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_mas_udf_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_comp_mas_udf_master_companyid");

                entity.Property(e => e.IntUdfSeqId).HasColumnName("int_udf_seq_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.VchFunctionName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_function_name");

                entity.Property(e => e.VchSysFunctionName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_sys_function_name");

                entity.Property(e => e.TSCreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_date");

                entity.Property(e => e.DTUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");
            });

            modelBuilder.Entity<ComponentTransEmpSalMaster>(entity =>
            {
                entity.HasKey(e => e.IntCompSalMasSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_sal_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_com_trans_emp_sal_mas_int_companyid");

                entity.Property(e => e.IntCompSalMasSeqId).HasColumnName("int_comp_sal_mas_seq_id");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");
            });

            modelBuilder.Entity<ComponentTransEmpSalMasterValue>(entity =>
            {
                entity.HasKey(e => e.IntCompSalMasValId)
                    .HasName("PRIMARY");

                entity.ToTable("component_trans_emp_sal_master_values");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompSeqId, "fk_com_t_empsal_comp_seq_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_com_t_empsal_company_seq_id");

                entity.HasIndex(e => e.IntEmployeeSeqId, "fk_com_t_empsal_emp_seq_id");

                entity.HasIndex(e => e.IntComMCtcMasId, "fk_comp_t_sal_mas_values_ctcmasid");

                entity.Property(e => e.IntCompSalMasValId).HasColumnName("int_comp_sal_mas_val_id");

                entity.Property(e => e.DtDateValue).HasColumnName("dt_date_value");

                entity.Property(e => e.IntComMCtcMasId).HasColumnName("int_com_m_ctc_mas_id");

                entity.Property(e => e.IntCompSeqId)
                    .HasColumnName("int_comp_seq_id")
                    .HasComment("Reference from component_mas_creation");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.IntEmployeeSeqId).HasColumnName("int_employee_seq_id");

                entity.Property(e => e.IntNumValue).HasColumnName("int_num_value");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchCompShortName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_comp_short_name");

                entity.Property(e => e.VchComponentName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_component_name");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchShowPayslip)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_payslip");

                entity.Property(e => e.VchShowView)
                    .HasMaxLength(3)
                    .HasColumnName("vch_show_view");

                entity.Property(e => e.VchStrValue)
                    .HasMaxLength(255)
                    .HasColumnName("vch_str_value");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(100)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.VchValueAssiged)
                    .HasMaxLength(9)
                    .HasColumnName("vch_value_assiged");

                //entity.HasOne(d => d.IntComMCtcMas)
                //    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                //    .HasForeignKey(d => d.IntComMCtcMasId)
                //    .HasConstraintName("fk_comp_t_sal_mas_values_ctcmasid");

                //entity.HasOne(d => d.IntCompany)
                //    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                //    .HasForeignKey(d => d.IntCompanyId)
                //    .HasConstraintName("fk_com_t_empsal_company_seq_id");

                //entity.HasOne(d => d.IntEmployeeSeq)
                //    .WithMany(p => p.ComponentTransEmpSalMasterValues)
                //    .HasForeignKey(d => d.IntEmployeeSeqId)
                //    .HasConstraintName("fk_com_t_empsal_emp_seq_id");
            });

            modelBuilder.Entity<ConfigMasDynamicEmpMasterField>(entity =>
            {
                entity.HasKey(e => e.IntDynamicEmpMasId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_dynamic_emp_master_fields");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntDynamicEmpMasId).HasColumnName("int_dynamic_emp_mas_id");

                entity.Property(e => e.TsCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("ts_created_by");

                entity.Property(e => e.TsCreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_updated_time");

                entity.Property(e => e.VchRoleName)
                    .HasMaxLength(500)
                    .HasColumnName("vch_role_name");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchSchemaUsed)
                    .HasMaxLength(45)
                    .HasColumnName("vch_schema_used");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_config_mas_dynamic_emp_mast_field_comp_id");
            });

            modelBuilder.Entity<ConfigMasTmiSuperAdminMaster>(entity =>
            {
                entity.HasKey(e => e.IntTmisaId)
                    .HasName("PRIMARY");

                entity.ToTable("config_mas_tmi_super_admin_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTmisaId).HasColumnName("int_tmisa_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.TsUpdatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_UPDATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.IntCompanyId)
                   .HasColumnName("int_company_id");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchTmisaCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_tmisa_code");

                entity.Property(e => e.VchTmisaEmailid)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmisa_emailid");

                entity.Property(e => e.VchTmisaEmpCode)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmisa_emp_code");

                entity.Property(e => e.VchTmisaName)
                    .HasMaxLength(100)
                    .HasColumnName("vch_tmisa_name");

                entity.Property(e => e.VchTmisaPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_tmisa_password");

                entity.Property(e => e.VchTmisaPhoneno)
                    .HasMaxLength(15)
                    .HasColumnName("vch_tmisa_phoneno");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<CostcenterMaster>(entity =>
            {
                entity.HasKey(e => e.costCenterId)
                  .HasName("PRIMARY");

                entity.ToTable("costcenter_master");

                entity.Property(e => e.costCenterId).HasColumnName("CostCenterId");


                entity.Property(e => e.costCenterName)
                    .HasMaxLength(45)
                    .HasColumnName("CostCenterName");

                entity.Property(e => e.fromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FromDate");

                entity.Property(e => e.toDate)
                   .HasColumnType("datetime")
                   .HasColumnName("ToDate");

                entity.Property(e => e.status)
                    .HasColumnName("Status");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<CountryMaster>(entity =>
            {
                entity.HasKey(e => e.countryId)
                    .HasName("PRIMARY");

                entity.ToTable("country_master");

                entity.HasIndex(e => e.countryId, "country_id_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.countryId).HasColumnName("CountryId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.countryName)
                    .HasMaxLength(45)
                    .HasColumnName("CountryName");

                entity.Property(e => e.countryCode)
                  .HasMaxLength(6)
                  .HasColumnName("CountryCode");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status).HasColumnName("Status");
            });

            modelBuilder.Entity<DepartmentMaster>(entity =>
            {
                entity.HasKey(e => e.departmentId)
                  .HasName("PRIMARY");

                entity.ToTable("department_master");

                entity.Property(e => e.departmentId).HasColumnName("DepartmentId");


                entity.Property(e => e.departmentName)
                    .HasMaxLength(45)
                    .HasColumnName("DeptsName");

                //entity.Property(e => e.locationName)
                //    .HasMaxLength(45)
                //    .HasColumnName("location_name");



                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.deptShortName)
                    .HasMaxLength(45)
                    .HasColumnName("DeptShortName");

                entity.Property(e => e.status)
                    .HasColumnName("Status");

                entity.Property(e => e.fromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FromDate");

                entity.Property(e => e.toDate)
                   .HasColumnType("datetime")
                   .HasColumnName("ToDate");



                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<DepartmentsMaster>(entity =>
            {
                entity.HasKey(e => e.DeptsSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("departments_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DeptsSeqId).HasColumnName("DEPTS_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "Fk_Departments_Company_Id");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.DeptsName)
                    .HasMaxLength(100)
                    .HasColumnName("DEPTS_NAME");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LocationSeqId).HasColumnName("LOCATION_SEQ_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_ACTIVE");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchDeptsShortName)
                    .HasMaxLength(5)
                    .HasColumnName("VCH_DEPTS_SHORT_NAME");

                entity.Property(e => e.VchLocationName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_LOCATION_NAME");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<DesignationMaster>(entity =>
         {
             entity.ToTable("designation_master");

             entity.HasKey(e => e.designationId)
                   .HasName("PRIMARY");

             entity.Property(e => e.designationId)
             .HasColumnName("DesignationId");



             entity.Property(e => e.companyId)
             .HasColumnName("CompanyId");

             entity.Property(e => e.createdBy)
                 .HasMaxLength(50)
                 .HasColumnName("CreatedBY");

             entity.Property(e => e.createdTime)
                  .HasColumnType("datetime")
                 .HasColumnName("CreatedTime");

             entity.Property(e => e.deptShortName)
                 .HasMaxLength(50)
                 .HasColumnName("DeptShortName");



             entity.Property(e => e.designationName)
                 .HasMaxLength(100)
                 .HasColumnName("DesignationName");

             entity.Property(e => e.designationShortName)
                 .HasMaxLength(100)
                 .HasColumnName("DesignationShortName");

             entity.Property(e => e.fromDate)
             .HasColumnType("datetime")
             .HasColumnName("FromDate");

             entity.Property(e => e.rCSGradeId)
             .HasColumnName("RCSGradeId");



             entity.Property(e => e.toDate)
             .HasColumnType("datetime")
             .HasColumnName("ToDate");

             entity.Property(e => e.updatedBy)
                 .HasMaxLength(60)
                 .HasColumnName("UpdatedBy");

             entity.Property(e => e.updatedDate)
                 .HasColumnType("datetime")
                 .HasColumnName("UpdatedDate");

             entity.Property(e => e.status)
          .HasColumnName("Status");
         });

            modelBuilder.Entity<DivisionMaster>(entity =>
            {
                entity.HasKey(e => e.divisionId)
                    .HasName("PRIMARY");

                entity.ToTable("division_master");

                //entity.HasCharSet("utf8mb4")
                //    .UseCollation("utf8mb4_0900_ai_ci");

                entity.HasIndex(e => e.divisionId, "division_id_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.divisionId).HasColumnName("DivisionId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.division)
                    .HasMaxLength(45)
                    .HasColumnName("DivisionName");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
            });

            modelBuilder.Entity<DocumentMaster>(entity =>
            {
                entity.HasKey(e => e.IntDocId)
                    .HasName("PRIMARY");

                entity.ToTable("document_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_bin");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_mas_company_id");

                entity.Property(e => e.IntDocId).HasColumnName("int_doc_id");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(3)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchDocDescription)
                    .HasMaxLength(300)
                    .HasColumnName("vch_doc_description");

                entity.Property(e => e.VchDocName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_doc_name")
                    .HasComment("HRP,HRA,HRR,LG");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by");

                //entity.HasOne(d => d.IntCompany)
                //    .WithMany(p => p.DocumentMasters)
                //    .HasForeignKey(d => d.IntCompanyId)
                //    .HasConstraintName("fk_doc_mas_company_id");
            });

            modelBuilder.Entity<DomainMaster>(entity =>
            {
                entity.HasKey(e => e.DomainSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("domain_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.DomainSeqId).HasColumnName("DOMAIN_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "fk_domain_master_Companyid");

                entity.Property(e => e.DomainName)
                    .HasMaxLength(100)
                    .HasColumnName("DOMAIN_NAME");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeCategoryMaster>(entity =>
            {
                entity.HasKey(e => e.EmployeeCategorySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_category_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_emp_cat_mas_int_companyid");

                entity.Property(e => e.EmployeeCategorySeqId).HasColumnName("EMPLOYEE_CATEGORY_SEQ_ID");

                entity.Property(e => e.DtFromDate).HasColumnName("dt_from_date");

                entity.Property(e => e.DtToDate).HasColumnName("dt_to_date");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmpCategoryName)
                    .HasMaxLength(100)
                    .HasColumnName("EMP_CATEGORY_NAME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Tenure)
                    .HasMaxLength(45)
                    .HasColumnName("TENURE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchActive)
                    .HasMaxLength(10)
                    .HasColumnName("vch_active");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchModified)
                    .HasMaxLength(3)
                    .HasColumnName("vch_modified");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeMaster>(entity =>
            {
                entity.HasKey(e => e.EmployeeSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.AbeCodeValue, "FK_EMP_ABE_CODE");

                entity.HasIndex(e => e.LeaveGroup, "FK_EMP_Leave_Group");

                entity.HasIndex(e => e.Departments, "FK_EMP_MAS_DEPARTMENTS_MASTER");

                entity.HasIndex(e => e.BankName, "FK_EMP_bank_name");

                entity.HasIndex(e => e.EmploymentType, "FK_EMP_employment_type");

                entity.HasIndex(e => e.ItsRoleSfiaValue, "FK_EMP_its_role");

                entity.HasIndex(e => e.MaritalStatus, "FK_EMP_marital_status_type");

                entity.HasIndex(e => e.MidpointValue, "FK_EMP_midpoint_value");

                entity.HasIndex(e => e.PhysicalStatus, "FK_EMP_physical_status");

                entity.HasIndex(e => e.ProductivityFactor, "FK_EMP_productivity_factor");

                entity.HasIndex(e => e.RcslevelValue, "FK_EMP_rcslevel_value");

                entity.HasIndex(e => e.Subdepartment, "FK_EMP_subdepartment");

                entity.HasIndex(e => e.TaxSlabOpted, "FK_EMP_tax_slab");

                entity.HasIndex(e => e.IntCompanyId, "fk_emp_mas_company_id");

                entity.HasIndex(e => e.IntCompanyRoleId, "fk_emp_mas_company_role");

                entity.HasIndex(e => e.IntRcsgradeId, "fk_emp_master_rcs_grade_idx");

                entity.HasIndex(e => e.Designation, "fk_employee_master_1");

                entity.HasIndex(e => e.Costcenter, "fk_employee_master_2");

                entity.HasIndex(e => e.Department, "fk_employee_master_3");

                entity.HasIndex(e => e.Location, "fk_employee_master_4");

                entity.HasIndex(e => e.Category, "fk_employee_master_5");

                entity.HasIndex(e => e.IntGradeId, "fk_empmas_grade_id");

                entity.Property(e => e.EmployeeSeqId).HasColumnName("employee_seq_id");

                entity.Property(e => e.AbeCodeValue).HasColumnName("abe_code_value");

                entity.Property(e => e.ActionCode)
                    .HasMaxLength(5)
                    .HasColumnName("action_code");

                entity.Property(e => e.BankName).HasColumnName("bank_name");

                entity.Property(e => e.Billing)
                    .HasMaxLength(20)
                    .HasColumnName("billing");

                entity.Property(e => e.Branch)
                    .HasMaxLength(45)
                    .HasColumnName("branch");

                entity.Property(e => e.Category).HasColumnName("category");

                entity.Property(e => e.CnfPending)
                    .HasMaxLength(3)
                    .HasColumnName("cnf_pending");

                entity.Property(e => e.Company)
                    .HasMaxLength(45)
                    .HasColumnName("company");

                entity.Property(e => e.ConfirmationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("confirmation_date");

                entity.Property(e => e.Costcenter).HasColumnName("costcenter");

                entity.Property(e => e.CtcAmount).HasColumnName("ctc_amount");

                entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");

                entity.Property(e => e.Department).HasColumnName("department");

                entity.Property(e => e.Departments).HasColumnName("departments");

                entity.Property(e => e.DescFlag)
                    .HasMaxLength(5)
                    .HasColumnName("desc_flag");

                entity.Property(e => e.Designation).HasColumnName("designation");

                entity.Property(e => e.Division)
                    .HasMaxLength(45)
                    .HasColumnName("division");

                entity.Property(e => e.DouCurrCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_curr_ctc");

                entity.Property(e => e.DouNewCtc)
                    .HasPrecision(10, 2)
                    .HasColumnName("dou_new_ctc");

                entity.Property(e => e.DpdhlJoining).HasColumnName("DPDHL_JOINING");

                entity.Property(e => e.DtUpdatedDate)
                    .HasMaxLength(6)
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EffectiveDate).HasColumnName("effective_date");

                entity.Property(e => e.EmpCode)
                    .HasMaxLength(45)
                    .HasColumnName("emp_code");

                entity.Property(e => e.EmpDetailInfoSeq).HasColumnName("emp_detail_info_seq");

                entity.Property(e => e.EmpName)
                    .HasMaxLength(100)
                    .HasColumnName("emp_name");

                entity.Property(e => e.EmpPhotoBlob)
                    .HasColumnType("mediumblob")
                    .HasColumnName("emp_photo_blob");

                entity.Property(e => e.EmploymentType).HasColumnName("employment_type");

                entity.Property(e => e.ExitInitiationPending)
                    .HasMaxLength(3)
                    .HasColumnName("exit_initiation_pending");

                entity.Property(e => e.Gender)
                    .HasMaxLength(45)
                    .HasColumnName("gender");

                entity.Property(e => e.Grade)
                    .HasMaxLength(45)
                    .HasColumnName("grade");

                entity.Property(e => e.GroupDoj).HasColumnName("group_doj");

                entity.Property(e => e.HireType)
                    .HasMaxLength(20)
                    .HasColumnName("hire_type");

                entity.Property(e => e.IntAppraisalCount).HasColumnName("int_appraisal_count");

                entity.Property(e => e.IntCasualLeave).HasColumnName("int_casual_leave");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntCompanyRoleId).HasColumnName("int_company_role_id");

                entity.Property(e => e.IntConfExtendedTimes).HasColumnName("int_conf_extended_times");

                entity.Property(e => e.IntCovaccineLeave).HasColumnName("int_covaccine_leave");

                entity.Property(e => e.IntEmpSalaryDtls)
                    .HasPrecision(20)
                    .HasColumnName("int_emp_salary_dtls");

                entity.Property(e => e.IntGradeId).HasColumnName("int_grade_id");

                entity.Property(e => e.IntMaternityLeave).HasColumnName("int_maternity_leave");

                entity.Property(e => e.IntMiscarriageLeave).HasColumnName("int_miscarriage_leave");

                entity.Property(e => e.IntNimineeSeqId).HasColumnName("int_niminee_seq_id");

                entity.Property(e => e.IntOptionalLeave).HasColumnName("int_optional_leave");

                entity.Property(e => e.IntPaternityLeave).HasColumnName("int_paternity_leave");

                entity.Property(e => e.IntPrivilegeLeave).HasColumnName("int_privilege_leave");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("int_rcsgrade_id");

                entity.Property(e => e.IntSickLeave).HasColumnName("int_sick_leave");

                entity.Property(e => e.ItsRoleSfiaValue).HasColumnName("its_role_sfia_value");

                entity.Property(e => e.JoinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("join_date");

                entity.Property(e => e.Ldap)
                    .HasMaxLength(15)
                    .HasColumnName("ldap");

                entity.Property(e => e.LeaveGroup).HasColumnName("leave_group");

                entity.Property(e => e.LeavingDate)
                    .HasColumnType("datetime")
                    .HasColumnName("leaving_date");

                entity.Property(e => e.Location).HasColumnName("location");

                entity.Property(e => e.MaritalStatus).HasColumnName("marital_status");

                entity.Property(e => e.MidpointValue).HasColumnName("midpoint_value");

                entity.Property(e => e.OncallAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("oncall_allowance_eligibility");

                entity.Property(e => e.PersonalInfo).HasColumnName("personal_info");

                entity.Property(e => e.PhysicalStatus).HasColumnName("physical_status");

                entity.Property(e => e.ProbationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("probation_date");

                entity.Property(e => e.ProbationDays).HasColumnName("probation_days");

                entity.Property(e => e.ProductivityFactor).HasColumnName("productivity_factor");

                entity.Property(e => e.ProfessionalShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("professional_shift_allowance_eligibility");

                entity.Property(e => e.PtLocation)
                    .HasMaxLength(45)
                    .HasColumnName("pt_location");

                entity.Property(e => e.RcsFlag)
                    .HasMaxLength(5)
                    .HasColumnName("rcs_flag");

                entity.Property(e => e.RcslevelValue).HasColumnName("rcslevel_value");

                entity.Property(e => e.ReasonCode)
                    .HasMaxLength(5)
                    .HasColumnName("reason_code");

                entity.Property(e => e.Reference)
                    .HasMaxLength(45)
                    .HasColumnName("reference");

                entity.Property(e => e.ReportTo)
                    .HasMaxLength(45)
                    .HasColumnName("report_to");

                entity.Property(e => e.ResignationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("resignation_date");

                entity.Property(e => e.Role).HasColumnName("role");

                entity.Property(e => e.RoleChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("role_change_date");

                entity.Property(e => e.SalaryDtl).HasColumnName("salary_dtl");

                entity.Property(e => e.SalaryFlag)
                    .HasMaxLength(5)
                    .HasColumnName("salary_flag");

                entity.Property(e => e.SapEmployeeNo)
                    .HasMaxLength(15)
                    .HasColumnName("sap_employee_no");

                entity.Property(e => e.SapFlag)
                    .HasMaxLength(5)
                    .HasColumnName("sap_flag");

                entity.Property(e => e.SapPositionId)
                    .HasMaxLength(15)
                    .HasColumnName("sap_Position_id");

                entity.Property(e => e.SapSalaryFlag)
                    .HasMaxLength(5)
                    .HasColumnName("sap_salary_flag");

                entity.Property(e => e.ShiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("shift_allowance_eligibility");

                entity.Property(e => e.Status)
                    .HasMaxLength(45)
                    .HasColumnName("status");

                entity.Property(e => e.Subdepartment).HasColumnName("subdepartment");

                entity.Property(e => e.TaxSlabOpted).HasColumnName("tax_slab_opted");

                entity.Property(e => e.TotalExperience)
                    .HasMaxLength(15)
                    .HasColumnName("total_experience");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.TsPwdChangeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ts_pwd_change_date");

                entity.Property(e => e.TypeOfWorker)
                    .HasMaxLength(20)
                    .HasColumnName("type_of_worker");

                entity.Property(e => e.VarKycPfNo)
                    .HasMaxLength(25)
                    .HasColumnName("VAR_KYC_PF_NO");

                entity.Property(e => e.VarPerLastName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_last_name");

                entity.Property(e => e.VarPerMiddleName)
                    .HasMaxLength(100)
                    .HasColumnName("var_per_middle_name");

                entity.Property(e => e.VchBusinessPartner)
                    .HasMaxLength(100)
                    .HasColumnName("vch_business_partner");

                entity.Property(e => e.VchBusinessUnit)
                    .HasMaxLength(100)
                    .HasColumnName("vch_business_unit");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by");

                entity.Property(e => e.VchGroup)
                    .HasMaxLength(100)
                    .HasColumnName("vch_group");

                entity.Property(e => e.VchGroups)
                    .HasMaxLength(50)
                    .HasColumnName("vch_groups");

                entity.Property(e => e.VchMailid)
                    .HasMaxLength(50)
                    .HasColumnName("vch_mailid");

                entity.Property(e => e.VchOldPf)
                    .HasMaxLength(25)
                    .HasColumnName("VCH_OLD_PF");

                entity.Property(e => e.VchOldPwd1)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd1");

                entity.Property(e => e.VchOldPwd2)
                    .HasMaxLength(80)
                    .HasColumnName("vch_old_pwd2");

                entity.Property(e => e.VchOperation)
                    .HasMaxLength(3)
                    .HasColumnName("vch_operation");

                entity.Property(e => e.VchPanCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pan_code");

                entity.Property(e => e.VchPassword)
                    .HasMaxLength(80)
                    .HasColumnName("vch_password");

                entity.Property(e => e.VchProfilePath)
                    .HasMaxLength(2000)
                    .HasColumnName("vch_profile_path");

                entity.Property(e => e.VchPwdChangeReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_pwd_change_req");

                entity.Property(e => e.VchPwdExpired)
                    .HasMaxLength(2)
                    .HasColumnName("vch_pwd_expired");

                entity.Property(e => e.VchPwdResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_pwd_reset_key");

                entity.Property(e => e.VchReptCode)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_code");

                entity.Property(e => e.VchReptName)
                    .HasMaxLength(50)
                    .HasColumnName("vch_rept_name");

                entity.Property(e => e.VchRmFlag)
                    .HasMaxLength(3)
                    .HasColumnName("vch_rm_flag");

                entity.Property(e => e.VchRoleAssignBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_role_assign_by");

                entity.Property(e => e.VchSchemaKey)
                    .HasMaxLength(100)
                    .HasColumnName("vch_schema_key");

                entity.Property(e => e.VchSignupReq)
                    .HasMaxLength(3)
                    .HasColumnName("vch_signup_req");

                entity.Property(e => e.VchSignupResetKey)
                    .HasMaxLength(50)
                    .HasColumnName("vch_signup_reset_key");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_updated_by");

                //entity.HasOne(d => d.CategoryNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.Category)
                //    .HasConstraintName("fk_employee_master_5");

                //entity.HasOne(d => d.CostcenterNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.Costcenter)
                //    .HasConstraintName("fk_employee_master_2");

                //entity.HasOne(d => d.DepartmentNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.Department)
                //    .HasConstraintName("fk_employee_master_3");

                //entity.HasOne(d => d.DepartmentsNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.Departments)
                //    .HasConstraintName("FK_EMP_MAS_DEPARTMENTS_MASTER");

                //entity.HasOne(d => d.DesignationNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.Designation)
                //    .HasConstraintName("fk_employee_master_1");

                //entity.HasOne(d => d.EmploymentTypeNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.EmploymentType)
                //    .HasConstraintName("FK_EMP_employment_type");

                //entity.HasOne(d => d.IntCompany)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.IntCompanyId)
                //    .HasConstraintName("fk_emp_mas_company_id");

                //entity.HasOne(d => d.IntRcsgrade)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.IntRcsgradeId)
                //    .HasConstraintName("fk_emp_master_rcs_grade_idx");

                //entity.HasOne(d => d.ItsRoleSfiaValueNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.ItsRoleSfiaValue)
                //    .HasConstraintName("FK_EMP_its_role");

                //entity.HasOne(d => d.LeaveGroupNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.LeaveGroup)
                //    .HasConstraintName("FK_EMP_Leave_Group");

                //entity.HasOne(d => d.LocationNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.Location)
                //    .HasConstraintName("fk_employee_master_4");

                //entity.HasOne(d => d.TaxSlabOptedNavigation)
                //    .WithMany(p => p.EmployeeMasters)
                //    .HasForeignKey(d => d.TaxSlabOpted)
                //    .HasConstraintName("FK_EMP_tax_slab");
            });

            modelBuilder.Entity<EmploymentTypeMaster>(entity =>
            {
                entity.HasKey(e => e.IntEmploymentTypeId)
                    .HasName("PRIMARY");

                entity.ToTable("employment_type_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntEmploymentTypeId).HasColumnName("INT_EMPLOYMENT_TYPE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.HasIndex(e => e.IntCompanyId, "fk_emp_type_master_company_id");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchEmploymentTypeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_EMPLOYMENT_TYPE_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<EmployeeStatusMaster>(entity =>
            {
                entity.HasKey(e => e.employeeStatusId)
                    .HasName("PRIMARY");

                entity.ToTable("employee_status_master");

                entity.Property(e => e.employeeStatusId).HasColumnName("EmpStatusId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.employeeStatus)
                    .HasMaxLength(45)
                    .HasColumnName("EmpStatus");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
            });

            modelBuilder.Entity<GradeMaster>(entity =>
            {
                entity.HasKey(e => e.gradeId)
                    .HasName("PRIMARY");

                entity.ToTable("grade_master");

                entity.HasIndex(e => e.gradeId, "grade_id_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.gradeId).HasColumnName("GradeId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.fromDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FromDate");

                entity.Property(e => e.RCSgradeName)
                    .HasMaxLength(45)
                    .HasColumnName("GradeName");

                entity.Property(e => e.RCSgradeShortName)
                    .HasMaxLength(45)
                    .HasColumnName("GradeShortName");

                entity.Property(e => e.locationId).HasColumnName("LocationId");

                entity.Property(e => e.locationName)
                    .HasMaxLength(45)
                    .HasColumnName("LocationName");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.toDate)
                    .HasColumnType("date")
                    .HasColumnName("ToDate");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("date")
                    .HasColumnName("UpdatedDate");
            });

            modelBuilder.Entity<ItsRoleSfiaMaster>(entity =>
            {
                entity.HasKey(e => e.IntItsRoleSfiaId)
                    .HasName("PRIMARY");

                entity.ToTable("its_role_sfia_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntItsRoleSfiaId).HasColumnName("INT_ITS_ROLE_SFIA_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchItsRoleSfiaValue)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_ITS_ROLE_SFIA_VALUE");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<LeaveGroupMaster>(entity =>
            {
                entity.HasKey(e => e.LeaveGroupSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("leave_group_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.LeaveGroupSeqId).HasColumnName("LEAVE_GROUP_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.LeaveGroupName)
                    .HasMaxLength(100)
                    .HasColumnName("LEAVE_GROUP_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<LocationMaster>(entity =>
            {
                entity.HasKey(e => e.locationId)
                  .HasName("PRIMARY");

                entity.ToTable("location_master");

                entity.Property(e => e.locationId).HasColumnName("LocationId");


                entity.Property(e => e.locationName)
                    .HasMaxLength(45)
                    .HasColumnName("LocationName");

                entity.Property(e => e.countryId).HasColumnName("CountryId");

                entity.Property(e => e.stateId).HasColumnName("StateId");

                entity.Property(e => e.cityId).HasColumnName("CityId");

                entity.Property(e => e.panNumber)
                    .HasMaxLength(45)
                    .HasColumnName("PanNumber");

                entity.Property(e => e.tanNumber)
                    .HasMaxLength(45)
                    .HasColumnName("TanNumber");

                entity.Property(e => e.factoryRegistrationNo)
                    .HasMaxLength(45)
                    .HasColumnName("FactoryRegistrationNo");

                entity.Property(e => e.shopEstablishmentRegNo)
                    .HasMaxLength(45)
                    .HasColumnName("ShopEstablishmentRegNo");

                entity.Property(e => e.pfSubCode)
                    .HasMaxLength(45)
                    .HasColumnName("PfSubCode");

                entity.Property(e => e.esiCode)
                    .HasMaxLength(45)
                    .HasColumnName("EsiCode");

                entity.Property(e => e.profTaxRegistrationCode)
                    .HasMaxLength(45)
                    .HasColumnName("ProfTaxRegistrationCode");

                entity.Property(e => e.lwfRegistrationCode)
                    .HasMaxLength(45)
                    .HasColumnName("LwfRegistrationCode");

                entity.Property(e => e.locationShortName)
                    .HasMaxLength(45)
                    .HasColumnName("LocationShortName");

                entity.Property(e => e.status)
                    .HasColumnName("Status");

                entity.Property(e => e.fromDate)
                   .HasColumnType("datetime")
                   .HasColumnName("FromDate");

                entity.Property(e => e.toDate)
                   .HasColumnType("datetime")
                   .HasColumnName("ToDate");

                //entity.Property(e => e.countryName)
                //  .HasMaxLength(45)
                //  .HasColumnName("country_name");

                //entity.Property(e => e.stateName)
                //  .HasMaxLength(45)
                //  .HasColumnName("state_name");

                //entity.Property(e => e.cityName)
                //  .HasMaxLength(45)
                //  .HasColumnName("city_name");

                //entity.Property(e => e.Modified)
                //  .HasMaxLength(45)
                //  .HasColumnName("modified");

                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

            });


            modelBuilder.Entity<MidpointMaster>(entity =>
            {
                entity.HasKey(e => e.MidpointSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("midpoint_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.MidpointSeqId).HasColumnName("MIDPOINT_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.MidpointValue)
                    .HasMaxLength(100)
                    .HasColumnName("MIDPOINT_VALUE");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasIndex(e => e.IntCompanyId, "fk_midpoint_master_company_id");
            });

            modelBuilder.Entity<PfDetailMaster>(entity =>
            {
                entity.HasKey(e => e.IntPfId)
                    .HasName("PRIMARY");

                entity.ToTable("pf_detail_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_doc_mas_pf_company_id");

                entity.HasIndex(e => e.IntEmpId, "fk_ex_pf_details_emp_id");

                entity.Property(e => e.IntPfId).HasColumnName("int_pf_id");

                entity.Property(e => e.BankAccountNo)
                    .HasMaxLength(50)
                    .HasColumnName("Bank_Account_No");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_updated_date");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(100)
                    .HasColumnName("Email_ID");

                entity.Property(e => e.FreshMembership)
                    .HasMaxLength(5)
                    .HasColumnName("Fresh_Membership");

                entity.Property(e => e.IfscCode)
                    .HasMaxLength(20)
                    .HasColumnName("IFSC_code");

                entity.Property(e => e.IntCompanyId).HasColumnName("int_company_id");

                entity.Property(e => e.IntEmpId)
                    .HasColumnName("int_emp_id")
                    .HasComment("reference from employee master(employee_master)");

                entity.Property(e => e.InternationalWorker)
                    .HasMaxLength(50)
                    .HasColumnName("International_Worker");

                entity.Property(e => e.MobileNo)
                    .HasMaxLength(14)
                    .HasColumnName("Mobile_NO");

                entity.Property(e => e.NameAsPerAadharCard)
                    .HasMaxLength(50)
                    .HasColumnName("Name_As_Per_AadharCard");

                entity.Property(e => e.NameAsPerBank)
                    .HasMaxLength(50)
                    .HasColumnName("Name_As_Per_Bank");

                entity.Property(e => e.NameAsPerPancard)
                    .HasMaxLength(50)
                    .HasColumnName("Name_As_Per_PANCard");

                entity.Property(e => e.Nationality).HasMaxLength(5);

                entity.Property(e => e.PrevEpfMember)
                    .HasMaxLength(5)
                    .HasColumnName("Prev_EPF_Member");

                entity.Property(e => e.PrevPensionMember)
                    .HasMaxLength(5)
                    .HasColumnName("prev_Pension_Member");

                entity.Property(e => e.PreviousUanNumber)
                    .HasMaxLength(50)
                    .HasColumnName("Previous_UAN_Number");

                entity.Property(e => e.Relation)
                    .HasMaxLength(15)
                    .HasColumnName("relation");

                entity.Property(e => e.RelationName)
                    .HasMaxLength(50)
                    .HasColumnName("Relation_Name");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("ts_created_time");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("vch_created_by")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("vch_updated_by")
                    .UseCollation("utf8_bin");

                entity.Property(e => e.WithdrawnPrevEpfpensionAmt)
                    .HasMaxLength(5)
                    .HasColumnName("Withdrawn_Prev_EPFPension_Amt");

                //entity.HasOne(d => d.IntCompany)
                //    .WithMany(p => p.PfDetailMasters)
                //    .HasForeignKey(d => d.IntCompanyId)
                //    .HasConstraintName("fk_doc_mas_pf_company_id");

                //entity.HasOne(d => d.IntEmp)
                //    .WithMany(p => p.PfDetailMasters)
                //    .HasForeignKey(d => d.IntEmpId)
                //    .HasConstraintName("fk_ex_pf_details_emp_id");
            });

            modelBuilder.Entity<QualificationMaster>(entity =>
            {
                entity.HasKey(e => e.QualificationSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("qualification_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "FK_Qualification_Company_Id");

                entity.Property(e => e.QualificationSeqId).HasColumnName("QUALIFICATION_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.QualificationName)
                    .HasMaxLength(100)
                    .HasColumnName("QUALIFICATION_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<RcsgradeMaster>(entity =>
            {
                entity.HasKey(e => e.IntRcsgradeId)
                    .HasName("PRIMARY");

                entity.ToTable("rcsgrade_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntRcsgradeId).HasColumnName("INT_RCSGRADE_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchRcsgradeName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_RCSGRADE_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasIndex(e => e.IntCompanyId, "fk_rcsgrade_master_company_id");
            });

            modelBuilder.Entity<ReportsDomainMaster>(entity =>
            {
                entity.HasKey(e => e.IntId)
                    .HasName("PRIMARY");

                entity.ToTable("reports_domain_masters");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntId).HasColumnName("int_id");

                //entity.Property(e => e.IntId)
                //    .ValueGeneratedNever()
                //    .HasColumnName("int_id");

                entity.HasIndex(e => e.IntCompanyId, "fk_reports_domain_masters_companyid");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchDomainName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_DOMAIN_NAME");

                entity.Property(e => e.VchPackageName)
                    .HasMaxLength(100)
                    .HasColumnName("VCH_PACKAGE_NAME");
            });




            modelBuilder.Entity<RcslevelMaster>(entity =>
            {
                entity.HasKey(e => e.RcslevelSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("rcslevel_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.RcslevelSeqId).HasColumnName("RCSLEVEL_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.RcslevelName)
                    .HasMaxLength(100)
                    .HasColumnName("RCSLEVEL_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });







            modelBuilder.Entity<SkillMaster>(entity =>
              {
                  entity.HasKey(e => e.SkillSeqId)
                      .HasName("PRIMARY");

                  entity.ToTable("skill_master");

                  entity.HasCharSet("utf8")
                      .UseCollation("utf8_general_ci");

                  entity.HasIndex(e => e.IntCompanyId, "fk_skill_mas_int_companyid");

                  entity.Property(e => e.SkillSeqId).HasColumnName("SKILL_SEQ_ID");

                  entity.Property(e => e.DomainNameId)
                      .HasPrecision(20)
                      .HasColumnName("DOMAIN_NAME_ID");

                  entity.Property(e => e.DtUpdatedDate)
                      .HasColumnType("datetime")
                      .HasColumnName("DT_UPDATED_DATE");

                  entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                  entity.Property(e => e.SkillName)
                      .HasMaxLength(100)
                      .HasColumnName("SKILL_NAME");

                  entity.Property(e => e.TsCreatedTime)
                      .HasMaxLength(6)
                      .HasColumnName("TS_CREATED_TIME");

                  entity.Property(e => e.VchCreatedBy)
                      .HasMaxLength(50)
                      .HasColumnName("VCH_CREATED_BY");

                  entity.Property(e => e.VchDomainName)
                      .HasMaxLength(100)
                      .HasColumnName("vch_domain_name");

                  entity.Property(e => e.VchTransactionId)
                      .HasMaxLength(100)
                      .HasColumnName("vch_transaction_id");

                  entity.Property(e => e.VchUpdatedBy)
                      .HasMaxLength(50)
                      .HasColumnName("VCH_UPDATED_BY");
              });

            modelBuilder.Entity<TaxSlabOptedforMaster>(entity =>
            {
                entity.HasKey(e => e.IntTaxSlabOptedforId)
                    .HasName("PRIMARY");

                entity.ToTable("tax_slab_optedfor_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.IntTaxSlabOptedforId).HasColumnName("INT_TAX_SLAB_OPTEDFOR_ID");

                entity.Property(e => e.DtUpdatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_TIME");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTaxSlabOptedforName)
                    .HasMaxLength(60)
                    .HasColumnName("VCH_TAX_SLAB_OPTEDFOR_NAME");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(80)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.HasIndex(e => e.IntCompanyId, "fk_tax_slab_optedfor_master_company_id");
            });

            modelBuilder.Entity<UserMaster>(entity =>
            {
                entity.HasKey(e => e.UserSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("user_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.UserSeqId).HasColumnName("USER_SEQ_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedTs)
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_TS");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.FileSeqid).HasColumnName("FILE_SEQID");

                entity.Property(e => e.IntLocationSeqId).HasColumnName("INT_LOCATION_SEQ_ID");

                entity.Property(e => e.Isproxy).HasColumnName("ISPROXY");

                entity.Property(e => e.ProxyFor)
                    .HasMaxLength(45)
                    .HasColumnName("PROXY_FOR");

                entity.Property(e => e.RoleSeqid).HasColumnName("ROLE_SEQID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedTs)
                    .HasMaxLength(6)
                    .HasColumnName("UPDATED_TS");

                entity.Property(e => e.UserEmail)
                    .HasMaxLength(60)
                    .HasColumnName("USER_EMAIL");

                entity.Property(e => e.UserFirstname)
                    .HasMaxLength(50)
                    .HasColumnName("USER_FIRSTNAME");

                entity.Property(e => e.UserId)
                    .HasMaxLength(20)
                    .HasColumnName("USER_ID");

                entity.Property(e => e.UserLastname)
                    .HasMaxLength(50)
                    .HasColumnName("USER_LASTNAME");

                entity.Property(e => e.UserMobileNo)
                    .HasMaxLength(20)
                    .HasColumnName("USER_MOBILE_NO");

                entity.Property(e => e.UserPassword)
                    .HasMaxLength(45)
                    .HasColumnName("USER_PASSWORD");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchStatus)
                    .HasMaxLength(3)
                    .HasColumnName("VCH_STATUS");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.IntCompanyId)
                  .HasMaxLength(50)
                  .HasColumnName("INT_COMPANY_ID");
            });

            modelBuilder.Entity<VendorCategoryMaster>(entity =>
            {
                entity.HasKey(e => e.VendorCategorySeqId)
                    .HasName("PRIMARY");

                entity.ToTable("vendor_category_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.VendorCategorySeqId).HasColumnName("VENDOR_CATEGORY_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "fk_vendor_category_master_companyid");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VendorCategoryName)
                    .HasMaxLength(100)
                    .HasColumnName("VENDOR_CATEGORY_NAME");
            });

            modelBuilder.Entity<VendorMaster>(entity =>
            {
                entity.HasKey(e => e.VendorSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("vendor_master");

                entity.HasCharSet("utf8")
                    .UseCollation("utf8_general_ci");

                entity.HasIndex(e => e.IntCompanyId, "fk_ven_mas_int_companyid");

                entity.Property(e => e.VendorSeqId).HasColumnName("VENDOR_SEQ_ID");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(100)
                    .HasColumnName("EMAIL_ID");

                entity.Property(e => e.EmailId1)
                    .HasMaxLength(100)
                    .HasColumnName("EMAIL_ID1");

                entity.Property(e => e.EmailId2)
                    .HasMaxLength(100)
                    .HasColumnName("EMAIL_ID2");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.Name1)
                    .HasMaxLength(50)
                    .HasColumnName("NAME1");

                entity.Property(e => e.Name2)
                    .HasMaxLength(50)
                    .HasColumnName("NAME2");

                entity.Property(e => e.Phone1)
                    .HasMaxLength(45)
                    .HasColumnName("PHONE_1");

                entity.Property(e => e.Phone2)
                    .HasMaxLength(45)
                    .HasColumnName("PHONE_2");

                entity.Property(e => e.Preferred)
                    .HasMaxLength(40)
                    .HasColumnName("PREFERRED");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");

                entity.Property(e => e.VendorAddress)
                    .HasMaxLength(50)
                    .HasColumnName("VENDOR_ADDRESS");

                entity.Property(e => e.VendorCategoryId).HasColumnName("VENDOR_CATEGORY_ID");

                entity.Property(e => e.VendorCode)
                    .HasMaxLength(50)
                    .HasColumnName("VENDOR_CODE");

                entity.Property(e => e.VendorName)
                    .HasMaxLength(100)
                    .HasColumnName("VENDOR_NAME");
            });


            modelBuilder.Entity<MaritalStatusMaster>(entity =>
            {
                entity.ToTable("marital_status_master");


                entity.Property(e => e.maritalStatusId)
                .HasColumnName("Id");

                entity.Property(e => e.maritalStatus)
                 .HasMaxLength(100)
                     .HasColumnName("Name");

                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasMaxLength(6)
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
             .HasColumnName("Status");
            });

            modelBuilder.Entity<PhysicalStatusMaster>(entity =>
            {
                entity.HasKey(e => e.PhysicalStatusSeqId)
                    .HasName("PRIMARY");

                entity.ToTable("physical_status_master");

                entity.HasCharSet("utf8mb3")
                    .UseCollation("utf8_general_ci");

                entity.Property(e => e.PhysicalStatusSeqId).HasColumnName("PHYSICAL_STATUS_SEQ_ID");

                entity.HasIndex(e => e.IntCompanyId, "fk_physical_status_master_companyid");

                entity.Property(e => e.DtUpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("DT_UPDATED_DATE");

                entity.Property(e => e.IntCompanyId).HasColumnName("INT_COMPANY_ID");

                entity.Property(e => e.PhysicalStatusName)
                    .HasMaxLength(100)
                    .HasColumnName("PHYSICAL_STATUS_NAME");

                entity.Property(e => e.TsCreatedTime)
                    .HasMaxLength(6)
                    .HasColumnName("TS_CREATED_TIME");

                entity.Property(e => e.VchCreatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_CREATED_BY");

                entity.Property(e => e.VchTransactionId)
                    .HasMaxLength(100)
                    .HasColumnName("vch_transaction_id");

                entity.Property(e => e.VchUpdatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("VCH_UPDATED_BY");
            });

            modelBuilder.Entity<SubdepartmentMaster>(entity =>
            {
                entity.HasKey(e => e.subdepartmentId)
                  .HasName("PRIMARY");

                entity.ToTable("subdepartment_master");

                entity.Property(e => e.subdepartmentId).HasColumnName("SubDepartmentId");


                entity.Property(e => e.subDepartment)
                    .HasMaxLength(45)
                    .HasColumnName("SubDepartmentName");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

                entity.Property(e => e.departmentId)
                .HasColumnName("DepartmentId");

                entity.Property(e => e.status)
              .HasColumnName("Status");

            });


            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);


    }
}
