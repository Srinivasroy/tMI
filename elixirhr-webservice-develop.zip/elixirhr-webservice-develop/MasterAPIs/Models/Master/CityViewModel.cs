﻿namespace MasterAPIs.Models.Master
{
    public class CityViewModel
    {
        public List<CountryMaster> countryList { get; set; }
        public List<StateMaster> stateList { get; set; }
        public List<CityMaster> cityList { get; set; }
    }

}
