﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class ComponentTransEmpSalMaster
    {
        public long IntCompSalMasSeqId { get; set; }
        public long? IntEmployeeSeqId { get; set; }
        [Required]
        public long? IntCompanyId { get; set; }
        public long? IntComMCtcMasId { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
    }
}
