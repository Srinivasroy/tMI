﻿namespace MasterAPIs.Models.Master
{
    public class DepartmentViewModel
    {
        public List<DepartmentMaster> departmentlist { get; set; }
        public List<SubdepartmentMaster> subdepartmentlist { get; set; }
    }
}
