﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterAPIs.Models.Master
{
    public partial class ConfigMasTmiSuperAdminMaster
    {
        public long IntTmisaId { get; set; }
        public string? VchTmisaEmpCode { get; set; }
        public string? VchTmisaCode { get; set; }
        public string? VchTmisaPassword { get; set; }
        public string? VchTmisaName { get; set; }
        public string? VchTmisaEmailid { get; set; }
        public string? VchTmisaPhoneno { get; set; }
        public string? VchActive { get; set; }
        public string? VchCreatedBy { get; set; }
        public DateTime? TsCreatedTime { get; set; }
        public string? VchUpdatedBy { get; set; }
        public DateTime? TsUpdatedTime { get; set; }
        public string? VchSchemaKey { get; set; }
        [Required]
        public int IntCompanyId { get; set; }

    }
}
