namespace MasterAPIs.Models.Master
{
    public class DesignationMaster
    {
        public long designationId { get; set; }
        public string? designationName { get; set; }
     
    
        public string? updatedBy { get; set; }
        public string? deptShortName { get; set; }
        public string? designationShortName { get; set; }
        public DateTime? updatedDate { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public long companyId { get; set; }
        public long rCSGradeId { get; set; }

        public int? status { get; set; }
        public string? createdBy { get; set; }
   
      

    }
}
