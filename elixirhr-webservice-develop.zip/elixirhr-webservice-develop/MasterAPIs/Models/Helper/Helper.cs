﻿namespace MasterAPIs.Models.Helper
{
    public class Helper
    {
        public enum Statuses
        {
            Approved = 1,
            Pending = 2,
            Rejected = 3,
            Deleted = 4,
            InProgress = 5,
            Draft = 6
        }
    }
}
