﻿using Microsoft.AspNetCore.Mvc.Filters;
using OAuthAPI.Controllers;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.ActionFilters
{
    public class ValidationFilterAttribute : IActionFilter
    {
        private readonly ILogger<ValidationFilterAttribute> _logger;

        public ValidationFilterAttribute(ILogger<ValidationFilterAttribute> logger)
        {
            this._logger = logger;
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
            _logger.LogInformation("############## ---------------- OnActionExecuting New ---------------------- ####################");
            // our code before action executes
            string controller = context.RouteData.Values["controller"].ToString();
            string action = context.RouteData.Values["action"].ToString();
            if (action == "PostGetToken")
            {
                foreach (var argument in context.ActionArguments)
                {
                    object parameterValue = (object)argument.Value;
                    var nameOfProperty = "Email";
                    var propertyInfo = parameterValue.GetType().GetProperty(nameOfProperty);
                    AuditTrail auditTrail = new AuditTrail ();
                    if (propertyInfo != null)
                    {
                        auditTrail.email = (string)propertyInfo.GetValue(parameterValue, null);
                    }
                    string parameterName = argument.Key;
                    Common_Schema_Context dbContext = new Common_Schema_Context();
                    AuditTrailsController auditTrailsController = new AuditTrailsController(dbContext);
                    auditTrail.screenName = "Login";
                    auditTrail.time = DateTime.UtcNow;
                    auditTrail.actionName = action;
                    auditTrailsController.PostAuditTrail(auditTrail);
                }
            }
            else
            {
                AuditTrail auditTrail = new AuditTrail();
                foreach (var argument in context.ActionArguments)
                {
                    object parameterValue = (object)argument.Value;
                    var nameOfProperty = "UpdatedBy";
                    var propertyInfo = parameterValue.GetType().GetProperty(nameOfProperty);
                    if (propertyInfo != null)
                    {
                        auditTrail.email =(string) propertyInfo.GetValue(parameterValue, null);
                    }
                    var screenNameProperty = "ScreenName";
                    var screenNamePropertyInfo = parameterValue.GetType().GetProperty(screenNameProperty);
                    if (screenNamePropertyInfo != null)
                    {
                        auditTrail.screenName = (string)screenNamePropertyInfo.GetValue(parameterValue, null);
                    }
                    auditTrail.time = DateTime.UtcNow;
                    
                    string parameterName = argument.Key;
                    Common_Schema_Context dbContext = new Common_Schema_Context();
                    AuditTrailsController auditTrailsController = new AuditTrailsController(dbContext);
                    auditTrail.time = DateTime.UtcNow;
                    auditTrail.actionName = action;
                    auditTrailsController.PostAuditTrail(auditTrail);
                }
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            // our code after action executes
            _logger.LogInformation("############## OnActionExecuted ####################");
        }
    }
}
