﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using OAuthAPI.Models;
namespace OAuthAPI.Extensions
{
    public static class AddJWTTokenServicesExtensions
    {
        public static void AddJWTTokenServices(this IServiceCollection Services, IConfiguration Configuration)
        {
            // Add Jwt Setings
            var bindJwtSettings = new JwtSettings();
            Configuration.Bind("JsonWebTokenKeys", bindJwtSettings);
            Services.AddSingleton(bindJwtSettings);
            Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {

                options.RequireHttpsMetadata = false;
                options.SaveToken = true;
                options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                {
                    ValidateIssuerSigningKey = bindJwtSettings.ValidateIssuerSigningKey,
                    IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(bindJwtSettings.IssuerSigningKey)),
                    ValidateIssuer = bindJwtSettings.ValidateIssuer,
                    ValidIssuer = bindJwtSettings.ValidIssuer,
                    ValidateAudience = bindJwtSettings.ValidateAudience,
                    ValidAudience = bindJwtSettings.ValidAudience,
                    RequireExpirationTime = bindJwtSettings.RequireExpirationTime,
                    ValidateLifetime = bindJwtSettings.RequireExpirationTime,
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero //TimeSpan.FromMinutes(DateTime.UtcNow.AddMinutes(5)),
                };
                options.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = async (context) =>
                    {
                        Console.WriteLine("Printing in the delegate OnAuthFailed");
                    },
                    OnChallenge = async (context) =>
                    {
                        Console.WriteLine("Printing in the delegate OnChallenge");

                        // this is a default method
                        // the response statusCode and headers are set here
                        context.HandleResponse();

                        // AuthenticateFailure property contains 
                        // the details about why the authentication has failed
                        if (context.AuthenticateFailure != null)
                        {
                            context.Response.StatusCode = 401;

                            // we can write our own custom response content here
                            await context.HttpContext.Response.WriteAsync("Token Validation Has Failed. Request Access Denied");
                        }
                        else
                        {
                            // we can write our own custom response content here
                            await context.HttpContext.Response.WriteAsync("No valid token !!!");
                        }
                    }
                };
            });
        }
    }
}