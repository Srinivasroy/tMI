﻿using Microsoft.IdentityModel.Tokens;
using OAuthAPI.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace OAuthAPI.JwtHelpers
{
    public static class JwtHelpers
    {
        public static IEnumerable<Claim> GetClaims(this UserTokens userAccounts, Guid Id)
        {
           
            IConfigurationRoot configuration = new ConfigurationBuilder()
           .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
           .AddJsonFile("appsettings.json")
           .Build();
            var expTime = configuration.GetValue<int>(
           "ExpTimeInMins");
            IEnumerable<Claim> claims = new Claim[] {
                new Claim("EmployeeId", userAccounts.EmployeeId.ToString()),
                    new Claim(ClaimTypes.Name, userAccounts.UserName),
                    new Claim(ClaimTypes.Email, userAccounts.EmailId),
                    new Claim(ClaimTypes.NameIdentifier, Id.ToString()),
                    new Claim("ParentCompanyId",userAccounts.ParentCompanyId.ToString()),
                    new Claim("ParentDbName",userAccounts.ParentDbName),
                    new Claim("CurrentCompanyId",userAccounts.CurrentCompanyId.ToString()),
                    new Claim("CurrentDbName",userAccounts.CurrentDbName),
                    new Claim("CurrentRoleId",userAccounts.CurrentRoleId.ToString()),
                    new Claim("CurrentRoleName",userAccounts.CurrentRoleName.ToString()),
                    new Claim(ClaimTypes.Expiration, DateTime.UtcNow.AddMinutes(expTime).ToString("MMM ddd dd yyyy HH:mm:ss tt"))
            };
            return claims;
        }
        public static IEnumerable<Claim> GetClaims(this UserTokens userAccounts, out Guid Id)
        {
            Id = Guid.NewGuid();
            return GetClaims(userAccounts, Id);
        }
        public static UserTokens GenTokenkey(UserTokens model, JwtSettings jwtSettings)
        {
            try
            {
                
                IConfigurationRoot configuration = new ConfigurationBuilder()
           .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
           .AddJsonFile("appsettings.json")
           .Build();
                var expTime = configuration.GetValue<int>(
               "ExpTimeInMins");
                var UserToken = new UserTokens();
                if (model == null) throw new ArgumentException(nameof(model));
                // Get secret key
                var key = System.Text.Encoding.ASCII.GetBytes(jwtSettings.IssuerSigningKey);
                Guid Id = Guid.Empty;
                DateTime expireTime = DateTime.UtcNow.AddMinutes(expTime);
                UserToken.Validaty = expireTime.ToString("MM-dd-yyyy hh:mm:ss");
                var JWToken = new JwtSecurityToken(issuer: jwtSettings.ValidIssuer, audience: jwtSettings.ValidAudience, claims: GetClaims(model, out Id), notBefore: DateTime.UtcNow, expires: DateTime.UtcNow.AddMinutes(expTime), signingCredentials: new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256));
                UserToken.Token = new JwtSecurityTokenHandler().WriteToken(JWToken);
                UserToken.UserName = model.UserName;
                UserToken.EmployeeId = model.EmployeeId;
                UserToken.GuidId = Id;
                UserToken.EmailId = model.EmailId;
                UserToken.ParentCompanyId = model.ParentCompanyId;
                UserToken.ParentDbName = model.ParentDbName;
                UserToken.CurrentCompanyId = model.CurrentCompanyId;
                UserToken.CurrentDbName = model.CurrentDbName;
                UserToken.CurrentRoleId = model.CurrentRoleId;
                UserToken.CurrentRoleName = model.CurrentRoleName;


                return UserToken;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static string GetEmailFromToken(string token)
        {
            token = token.Replace("Bearer ", string.Empty);
            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(token);
            var Email = jwtSecurityToken.Claims.First(claim => claim.Type == ClaimTypes.Email).Value;
            return Email;
        }

        public static object GetPropertyFromToken(string token, string propName)
        {



            token = token.Replace("Bearer ", string.Empty);
            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(token);
            try
            {
                var propValue = jwtSecurityToken.Claims.First(claim => claim.Type == propName).Value;
                return propValue;
            }
            catch (Exception ex)
            {
                //
            }



            return DBNull.Value;
        }
    }
}
