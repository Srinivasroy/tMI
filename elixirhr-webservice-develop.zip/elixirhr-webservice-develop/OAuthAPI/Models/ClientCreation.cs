﻿using System;
using System.Collections.Generic;

namespace OAuthAPI.models
{
    public partial class ClientCreation
    {
        public long ClientId { get; set; }
        public string? ClientCode { get; set; }
        public string? ClientName { get; set; }
        public string? Emailid { get; set; }
        public string? Mobileno { get; set; }
        public long? CompanyCount { get; set; }
        public string? Status { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
