﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.Models
{
    public class ClientSetup
    {

        [JsonIgnore]
        [Key]
        public long clientId { get; set; }
        //[Required(ErrorMessage = "Client code is required !!!")]
      //  public string? clientCode { get; set; }
        [Required(ErrorMessage = "Client name is required !!!")]
        public string? clientName { get; set; }
        public string? mobileNo { get; set; }
        //public long? companyCount { get; set; }
        public int? status { get; set; }

        public string? address1 { get; set; }

        public string? address2 { get; set; }

        public string? address3 { get; set; }
        [Required(ErrorMessage = "stateId is required !!!")]
        public long? stateId { get; set; }
        public string? pincode { get; set; }

        public string? pan { get; set; }
        public string? tan { get; set; }

        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required !!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
      //  public long? makerId { get; set; } = 0;
        //public long? checkerId { get; set; } = 0;

        public string? rejectionReason { get; set; }

        public bool? twoWayAuthentication { get; set; }
        public bool? isSms { get; set; }
        public bool? isEmail { get; set; }

        public Boolean? isOwnerClient { get; set; }
        [Required(ErrorMessage = "countryId is required !!!")]
        public long? countryId { get; set; }




        [JsonIgnore]
        [Key]
        public long employeePersonalDetailId { get; set; }
        public string? firstName { get; set; }
        public string? middleName { get; set; }
        public string? lastName { get; set; }
        public string? fatherName { get; set; }
        public DateTime? dob { get; set; }
        public string? gender { get; set; }
        public string? maritalStatus { get; set; }
        public string? religion { get; set; }
       
        [Required(ErrorMessage = "Company Id is mandatory")]
        public long? companyId { get; set; }
        [JsonIgnore]
        public long? groupId { get; set; }
        public long? roleId { get; set; }

        public string? mobileNo1 { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [Required(ErrorMessage = "Email is mandatory")]
        [DataType(DataType.EmailAddress)]
        public string? email { get; set; }
        //[Required(ErrorMessage = "Password is mandatory")]
        public string? password { get; set; }
       

        public string? countryCode { get; set; }
        public string? employeeImageUrl { get; set; }

      
        public bool? isCompanyAdmin { get; set; }

        public bool? isClientAdmin { get; set; } = false;

        public string? roleIds { get; set; }

    }
}
