﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using OAuthAPI.models.common_schema;
using Microsoft.AspNetCore.Http.Extensions;
using OAuthAPI.Models.Common_Schema;


namespace OAuthAPI.models.common_schema
{
    public partial class Common_Schema_Context : DbContext
    {
        public static bool _IsOwnerCompany = false;
        public Common_Schema_Context()
        {

        }

        public Common_Schema_Context(DbContextOptions<Common_Schema_Context> options)
            : base(options)
        {
        }

        public static int ParentCompanyId
        {
            get;
            set;
        }
        public static string ParentDbName
        {
            get;
            set;
        }
        public static int CurrentCompanyId
        {
            get;
            set;
        }
        public static string CurrentDbName
        {
            get;
            set;
        }
        public static int CurrentRoleId
        {
            get;
            set;
        }
        public static string CurrentRoleName
        {
            get;
            set;
        }
        public static bool IsOwnerCompany
        {
            //change
            get { return true; }
            set { _IsOwnerCompany = true; }
        }
        public DbSet<ClientCreation> ClientCreation { get; set; }
        public virtual DbSet<MasterAttribute> Masters { get; set; } = null!;
        public virtual DbSet<MasterOrgMapper> MasterOrgMappers { get; set; } = null!;
        public virtual DbSet<CommonMaster> CommonMaster { get; set; } = null!;
        public virtual DbSet<CommonMasterScreenMapper> CommonMasterScreenMapper { get; set; } = null!;
        public virtual DbSet<DefaultMaster> DefaultMaster { get; set; } = null!;
        public virtual DbSet<DefaultMasterScreenMapper> DefaultMasterScreenMapper { get; set; } = null!;
        public virtual DbSet<OrganisationDomainMapper> OrganisationDomainMapper { get; set; } = null!;
        public virtual DbSet<ClientOrganisationMapper> ClientOrganisationMappers { get; set; } = null!;
        public virtual DbSet<EmailContent> EmailContents { get; set; } = null!;
        public virtual DbSet<EmailConfiguration> EmailConfigurations { get; set; } = null!;
        public virtual DbSet<EmployeeAddressDetail> EmployeeAddressDetails { get; set; } = null!;
        public virtual DbSet<EmployeeNomineeDetail> EmployeeNomineeDetails { get; set; } = null!;
        public virtual DbSet<EmployeePersonalDetail> EmployeePersonalDetails { get; set; } = null!;
        public virtual DbSet<EmployeeProfessionalDetail> EmployeeProfessionalDetails { get; set; } = null!;
        public virtual DbSet<GroupRoleMapper> GroupRoleMappers { get; set; } = null!;
        public virtual DbSet<Module> Modules { get; set; } = null!;
        public virtual DbSet<ModuleOrganisationMapper> ModuleOrganisationMappers { get; set; } = null!;
        public virtual DbSet<Organisation> Organisations { get; set; } = null!;
        public virtual DbSet<OrganisationGroupMapper> OrganisationGroupMappers { get; set; } = null!;
        public virtual DbSet<PasswordConfiguration> PasswordConfigurations { get; set; } = null!;
        public virtual DbSet<RoleOrganisationMapper> RoleOrganisationMappers { get; set; } = null!;
        public virtual DbSet<Screen> Screens { get; set; } = null!;
        public virtual DbSet<ScreenPermission> ScreenPermissions { get; set; } = null!;
        public virtual DbSet<State> States { get; set; } = null!;
        public virtual DbSet<Status> Statuses { get; set; } = null!;
        public virtual DbSet<TrackPassword> TrackPasswords { get; set; } = null!;
        public virtual DbSet<UserGroup> UserGroups { get; set; } = null!;
        public virtual DbSet<UserRole> UserRoles { get; set; } = null!;
        public virtual DbSet<CompanyAddressDetail> CompanyAddressDetails { get; set; } = null!;
        public virtual DbSet<ClientUserRoleMapper> ClientUserRoleMappers { get; set; } = null!;
        public virtual DbSet<CompanyUserRoleMapper> CompanyUserRoleMappers { get; set; } = null!;
        public virtual DbSet<MasterChangesTracker> MasterChangesTrackers { get; set; } = null!;
        public virtual DbSet<DefaultCompanyScript> DefaultCompanyScripts { get; set; } = null!;



        public virtual DbSet<Department> Departments { get; set; } = null!;
        public virtual DbSet<Designation> Designations { get; set; } = null!;
        public virtual DbSet<Document> Documents { get; set; } = null!;
        public virtual DbSet<AuditTrail> AuditTrails { get; set; } = null!;
        public virtual DbSet<BankDetail> BankDetails { get; set; } = null!;
        public virtual DbSet<Costcenter> Costcenters { get; set; } = null!;
        public virtual DbSet<LeaveType> LeaveTypes { get; set; } = null!;
        public virtual DbSet<Location> Locations { get; set; } = null!;
        public virtual DbSet<GradeDetail> GradeDetails { get; set; } = null!;
        public virtual DbSet<EmployeeCodeConfig> EmployeeCodeConfig { get; set; } = null!;
        public virtual DbSet<OtherField> OtherFields { get; set; } = null!;
        public virtual DbSet<StorageAllocation> StorageAllocation { get; set; } = null!;
        public virtual DbSet<AdditionalMaster> AdditionalMasters { get; set; } = null!;

        public virtual DbSet<MastersHierarchy> MastersHierarchy { get; set; } = null!;
        public virtual DbSet<CommonMasterCompanyMapper> CommonMasterCompanyMapper { get; set; } = null!;
        public virtual DbSet<DefaultMasterCompanyMapper> DefaultMasterCompanyMapper { get; set; } = null!;
        public virtual DbSet<SmsConfiguration> SmsConfigurations { get; set; } = null!;

        public virtual DbSet<UserLoginLog> UserLoginLog { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                 string envName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                IConfigurationRoot configuration = new ConfigurationBuilder()
            //.SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
            .AddJsonFile($"appsettings.{envName}.json", optional: true, reloadOnChange: false)
            .Build();
                string cnnstr = configuration.GetConnectionString("TMI_Connection");
                optionsBuilder.UseMySql(configuration.GetConnectionString("TMI_Connection"), Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.27-mysql"));
            }
        }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<UserLoginLog>(entity =>
            {
                entity.ToTable("user_login_log");

                entity.HasKey(e => e.logId)
                .HasName("PRIMARY");

                entity.Property(e => e.logId)
                .HasColumnName("LogId");

                 entity.Property(e => e.userId)
                .HasColumnName("UserId");

                entity.Property(e => e.loginTime)
               .HasColumnType("datetime")
               .HasColumnName("LogInTime");

                entity.Property(e => e.logoutTime)
               .HasColumnType("datetime")
               .HasColumnName("LogOutTime");

                entity.Property(e => e.companyId)
                 .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                .HasMaxLength(45)
                .HasColumnName("CreatedBy");


                entity.Property(e => e.createdTime)
                .HasColumnType("datetime")
                .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                .HasMaxLength(45)
                .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedTime)
                .HasColumnType("datetime")
                .HasColumnName("UpdatedTime");


            });




            modelBuilder.Entity<SmsConfiguration>(entity =>
            {
                entity.ToTable("sms_configuration");

                entity.Property(e => e.smsConfigId).HasColumnName("SmsConfigId");

                entity.Property(e => e.apiKey)
                    .HasMaxLength(200)
                    .HasColumnName("ApiKey");

                entity.Property(e => e.apiSecretKey)
                    .HasMaxLength(45)
                    .HasColumnName("ApiSecretKey");

                entity.Property(e => e.companyId)
                   .HasColumnName("CompanyId");

            });




            modelBuilder.Entity<CommonMasterCompanyMapper>(entity =>
            {
                entity.HasKey(e => e.commonMasterCompanyMapperID)
                .HasName("PRIMARY");

                entity.ToTable("common_master_company_mapper");

                entity.Property(e => e.commonMasterCompanyMapperID)

                .HasColumnName("CommonMasterCompanyMapperID");

                entity.Property(e => e.commonMasterID)
                .HasColumnName("CommonMasterID");



                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                .HasMaxLength(45)
                .HasColumnName("CreatedBy");


                entity.Property(e => e.createdTime)
                .HasColumnType("datetime")
                .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                .HasMaxLength(45)
                .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                .HasColumnType("datetime")
                .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                .HasColumnName("Status");
            });

            modelBuilder.Entity<DefaultMasterCompanyMapper>(entity =>
            {
                entity.HasKey(e => e.defaultMasterCompanyMapperID)
                .HasName("PRIMARY");

                entity.ToTable("default_master_company_mapper");

                entity.Property(e => e.defaultMasterCompanyMapperID)
                .HasColumnName("DefaultMasterCompanyMapperID");

                entity.Property(e => e.defaultMasterID)
                .HasColumnName("DefaultMasterID");



                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                .HasMaxLength(45)
                .HasColumnName("CreatedBy");


                entity.Property(e => e.createdTime)
                .HasColumnType("datetime")
                .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                .HasMaxLength(45)
                .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                .HasColumnType("datetime")
                .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                .HasColumnName("Status");
            });

            modelBuilder.Entity<MastersHierarchy>(entity =>
            {
                entity.HasKey(e => e.hierarchyID)
                .HasName("PRIMARY");

                entity.ToTable("masters_hierarchy");

                entity.Property(e => e.hierarchyID)
                .ValueGeneratedOnAdd()
                .HasColumnName("HierarchyID");

                entity.Property(e => e.parentType)
                .HasMaxLength(45)
                .HasColumnName("ParentType");

                entity.Property(e => e.childType)
                .HasMaxLength(45)
                .HasColumnName("ChildType");

                entity.Property(e => e.parentID)
              .HasColumnName("ParentID");

                entity.Property(e => e.childID)
              .HasColumnName("ChildID");

                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                .HasMaxLength(45)
                .HasColumnName("CreatedBy");


                entity.Property(e => e.createdTime)
                .HasColumnType("datetime")
                .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                .HasMaxLength(45)
                .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                .HasColumnType("datetime")
                .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                .HasColumnName("Status");
            });

            modelBuilder.Entity<AdditionalMaster>(entity =>
            {
                entity.HasKey(e => e.additionalMasterId)
                .HasName("PRIMARY");

                entity.ToTable("additional_master");

                entity.Property(e => e.additionalMasterId)
                .ValueGeneratedOnAdd()
                .HasColumnName("AdditionalMasterId");

                entity.Property(e => e.name)
                .HasMaxLength(45)
                .HasColumnName("Name");

                entity.Property(e => e.description)
                .HasMaxLength(45)
                .HasColumnName("Description");

                entity.Property(e => e.companyId)
                .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                .HasMaxLength(45)
                .HasColumnName("CreatedBy");


                entity.Property(e => e.createdTime)
                .HasColumnType("datetime")
                .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedBy)
                .HasMaxLength(45)
                .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                .HasColumnType("datetime")
                .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                .HasColumnName("Status");
            });

            modelBuilder.Entity<StorageAllocation>(entity =>
            {
                entity.HasKey(e => e.storageAllocationID)
                  .HasName("PRIMARY");

                entity.ToTable("storage_allocation");

                entity.Property(e => e.storageAllocationID)
                .HasColumnName("StorageAllocationId");


                entity.Property(e => e.storageAllocation)
                    .HasMaxLength(100)
                    .HasColumnName("StorageAllocation");

                entity.Property(e => e.perUserStorage)
                    .HasMaxLength(100)
                    .HasColumnName("PerUserStorage");

                entity.Property(e => e.userGroupCount)
                      .HasColumnName("UserGroupCount");

                entity.Property(e => e.userCount)
                  .HasColumnName("UserCount");


                entity.Property(e => e.createdBy)
                      .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                                   .HasMaxLength(50)
                                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                   .HasColumnName("Status");

                entity.Property(e => e.companyID)
          .HasColumnName("CompanyId");

            });

            modelBuilder.Entity<CommonMaster>(entity =>
            {
                entity.HasKey(e => e.commonMasterId)
                  .HasName("PRIMARY");

                entity.ToTable("common_master");

                entity.Property(e => e.commonMasterId)
                .HasColumnName("CommonMasterId");


                entity.Property(e => e.commonMasterName)
                    .HasMaxLength(45)
                    .HasColumnName("CommonMasterName");

                entity.Property(e => e.commonMasterDisplayName)
                    .HasMaxLength(45)
                    .HasColumnName("CommonMasterDisplayName");

                entity.Property(e => e.createdBy)
                      .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                                   .HasMaxLength(50)
                                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
               .HasColumnName("Status");


                entity.Property(e => e.isCompulsory)
              .HasColumnName("IsCompulsory");

                entity.Property(e => e.defaultparentID)
             .HasColumnName("DefaultParentID");

                entity.Property(e => e.defaultparentType)
             .HasColumnName("DefaultParentType");

            });

            //modelBuilder.Entity<StateMaster>(entity =>
            //{
            //    entity.HasKey(e => e.StateSEQId)
            //      .HasName("PRIMARY");

            //    entity.ToTable("state_master");

            //    entity.Property(e => e.StateSEQId)
            //    .HasColumnName("State_SEQ_Id");


            //    entity.Property(e => e.StateName)
            //        .HasMaxLength(45)
            //        .HasColumnName("State_Name");

            //    entity.Property(e => e.CountryId)
            //        .HasColumnName("Country_Id");

            //    entity.Property(e => e.CreatedBy)
            //          .HasMaxLength(50)
            //          .HasColumnName("created_by");

            //    entity.Property(e => e.UpdatedBy)
            //                       .HasMaxLength(50)
            //                       .HasColumnName("updated_by");

            //    entity.Property(e => e.CreatedTime)
            //        .HasColumnType("datetime")
            //        .HasColumnName("created_Time");

            //    entity.Property(e => e.UpdatedDate)
            //        .HasColumnType("datetime")
            //        .HasColumnName("updated_date");

            //    entity.Property(e => e.CompanyId)
            //   .HasColumnName("Company_Id");

            //    entity.Property(e => e.CountryName)
            //       .HasMaxLength(50)
            //       .HasColumnName("country_Name");

            //    entity.Property(e => e.TransactionId)
            //        .HasMaxLength(50)
            //       .HasColumnName("transaction_id");

            //});

            modelBuilder.Entity<CommonMasterScreenMapper>(entity =>
            {
                entity.HasKey(e => e.commonMasterScreenMapperId)
                  .HasName("PRIMARY");

                entity.ToTable("common_master_screen_mapper");

                entity.Property(e => e.commonMasterScreenMapperId)
                .HasColumnName("commonmasterscreenmapperid");


                entity.Property(e => e.screenId)
                    .HasColumnName("ScreenId");

                entity.Property(e => e.commonMasterId)
                    .HasColumnName("CommonMasterId");

                entity.Property(e => e.createdBy)
                      .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                                   .HasMaxLength(50)
                                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
               .HasColumnName("Status");

            });

            modelBuilder.Entity<DefaultMaster>(entity =>
            {
                entity.HasKey(e => e.defaultMasterId)
                  .HasName("PRIMARY");

                entity.ToTable("default_master");

                entity.Property(e => e.defaultMasterId)
                .HasColumnName("DefaultMasterId");


                entity.Property(e => e.defaultMasterName)
                    .HasMaxLength(45)
                    .HasColumnName("DefaultMasterName");

                entity.Property(e => e.defaultMasterDisplayName)
                    .HasMaxLength(45)
                    .HasColumnName("DefaultMasterDisplayName");

                entity.Property(e => e.createdBy)
                      .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                                   .HasMaxLength(50)
                                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
               .HasColumnName("Status");

            });

            modelBuilder.Entity<DefaultMasterScreenMapper>(entity =>
            {
                entity.HasKey(e => e.defaultMasterScreenMapperId)
                  .HasName("PRIMARY");

                entity.ToTable("default_master_screen_mapper");

                entity.Property(e => e.defaultMasterScreenMapperId)
                .HasColumnName("DefaultMasterScreenMapperId");


                entity.Property(e => e.screenId)
                    .HasColumnName("ScreenId");

                entity.Property(e => e.defaultMasterId)
                    .HasColumnName("DefaultMasterId");

                entity.Property(e => e.createdBy)
                         .HasMaxLength(50)
                         .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                                   .HasMaxLength(50)
                                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
               .HasColumnName("Status");

            });

            modelBuilder.Entity<OrganisationDomainMapper>(entity =>
            {
                entity.HasKey(e => e.organisationDomainMapperId)
                  .HasName("PRIMARY");

                entity.ToTable("organisation_domain_mapper");

                entity.Property(e => e.organisationDomainMapperId)
                .HasColumnName("OrganisationDomainMapperId");


                entity.Property(e => e.organisationId)
                    .HasColumnName("OrganisationId");

                entity.Property(e => e.domainName)
                    .HasMaxLength(45)
                    .HasColumnName("DomainName");

                entity.Property(e => e.createdBy)
                      .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                       .HasMaxLength(50)
                       .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
               .HasColumnName("Status");

            });

            modelBuilder.Entity<MasterAttribute>(entity =>
            {
                entity.HasKey(e => e.masterId)
                   .HasName("PRIMARY");

                entity.ToTable("master");

                entity.Property(e => e.masterId)
                .HasColumnName("MasterId");


                entity.Property(e => e.displayName)
                    .HasMaxLength(45)
                    .HasColumnName("DisplayName");

                entity.Property(e => e.name)
                    .HasMaxLength(45)
                    .HasColumnName("Name");


                entity.Property(e => e.defaultOrder)
                .HasColumnName("DefaultOrder");



                entity.Property(e => e.status)
                    .HasMaxLength(45)
                    .HasColumnName("Status");

                entity.Property(e => e.createdBy)
                  .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                  .HasMaxLength(45)
                  .HasColumnName("UpdatedBy");

            });

            modelBuilder.Entity<MasterOrgMapper>(entity =>
            {
                entity.HasKey(e => e.masterOrgId)
                    .HasName("PRIMARY");

                entity.ToTable("master_organisation_mapper");

                entity.Property(e => e.masterOrgId).HasColumnName("MasterOrgId");

                entity.Property(e => e.approvedOrderNo).HasColumnName("ApprovedOrderNo");

                entity.Property(e => e.comments)
                    .HasMaxLength(45)
                    .HasColumnName("Comments");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.displayName)
                    .HasMaxLength(100)
                    .HasColumnName("DisplayName");

                entity.Property(e => e.masterId).HasColumnName("MasterId");

                entity.Property(e => e.name)
                    .HasMaxLength(100)
                    .HasColumnName("Name");

                entity.Property(e => e.notificationId).HasColumnName("NotificationId");

                entity.Property(e => e.orderNo).HasColumnName("OrderNo");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");
            });

            //modelBuilder.Entity<MasterOrgMapper>(entity =>
            //{
            //    entity.HasKey(e => e.MasterOrgId)
            //      .HasName("PRIMARY");

            //    //  entity.HasIndex(e => e.MasterId, "mom_masterid");


            //    entity.ToTable("master_organisation_mapper");



            //    entity.Property(e => e.MasterOrgId).HasColumnName("master_org_id");

            //    entity.Property(e => e.MasterId).HasColumnName("master_id");

            //    entity.Property(e => e.CompanyId).HasColumnName("company_id");

            //    entity.Property(e => e.Name).HasColumnName("name");

            //    entity.Property(e => e.DisplayName).HasColumnName("display_name");

            //    entity.Property(e => e.OrderNo).HasColumnName("order_no");

            //    entity.Property(e => e.NotificationId).HasColumnName("notification_id");

            //    entity.Property(e => e.ApprovedOrderNo).HasColumnName("approved_order_no");

            //    entity.Property(e => e.Comments)
            //        .HasMaxLength(45)
            //        .HasColumnName("comments");



            //    // entity.Property(e => e.ParentId).HasColumnName("PARENT_ID");

            //    entity.Property(e => e.Status)
            //        .HasMaxLength(45)
            //        .HasColumnName("status");



            //    entity.Property(e => e.CreatedBy)
            //     .HasMaxLength(45)
            //     .HasColumnName("created_by");

            //    entity.Property(e => e.UpdatedBy)
            //      .HasMaxLength(50)
            //      .HasColumnName("updated_by");
            //});


            //modelBuilder.UseCollation("utf8mb4_0900_ai_ci")
            //    .HasCharSet("utf8mb4");

            modelBuilder.Entity<AuditTrail>(entity =>
            {
                entity.ToTable("audit_trail");

                entity.Property(e => e.auditTrailId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("AuditTrailId");

                entity.Property(e => e.email)
                    .HasMaxLength(45)
                    .HasColumnName("Email");

                entity.Property(e => e.screenName)
                    .HasMaxLength(45)
                    .HasColumnName("ScreenName");

                entity.Property(e => e.actionName)
                    .HasMaxLength(45)
                    .HasColumnName("ActionName");

                entity.Property(e => e.time)
                    .HasColumnType("datetime")
                    .HasColumnName("Time");

                

            });


            modelBuilder.Entity<ClientCreation>(entity =>
            {
                entity.HasKey(e => e.clientId)
                    .HasName("PRIMARY");

                entity.ToTable("client_master");

                entity.Property(e => e.clientId)
                    .HasColumnType("bigint(20)")
                    .ValueGeneratedNever()
                    .HasColumnName("ClientId");

                entity.Property(e => e.clientCode)
                    .HasMaxLength(50)
                    .HasColumnName("ClientCode");

                entity.Property(e => e.clientName)
                    .HasMaxLength(50)
                    .HasColumnName("ClientName");

                entity.Property(e => e.companyCount)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CompanyCount");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.address1)
                    .HasMaxLength(200)
                    .HasColumnName("Address1");

                entity.Property(e => e.address2)
                   .HasMaxLength(200)
                   .HasColumnName("Address2");

                entity.Property(e => e.address3)
                   .HasMaxLength(200)
                   .HasColumnName("Address3");

                entity.Property(e => e.stateId)
                   .HasColumnType("bigint")
                   .HasColumnName("StateId");

                entity.Property(e => e.pincode)
                   .HasMaxLength(200)
                   .HasColumnName("Pincode");

                entity.Property(e => e.pan)
                  .HasMaxLength(200)
                  .HasColumnName("PAN");

                entity.Property(e => e.tan)
                  .HasMaxLength(200)
                  .HasColumnName("TAN");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.mobileNo)
                    .HasMaxLength(10)
                    .HasColumnName("MobileNo");

                entity.Property(e => e.status)
                    .HasColumnType("int(1)")
                    .HasColumnName("Status");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.checkerId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CheckerId");

                entity.Property(e => e.makerId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("MakerId");

                entity.Property(e => e.rejectionReason)
                 .HasMaxLength(200)
                 .HasColumnName("RejectionReason");

                entity.Property(e => e.twoWayAuthentication)
                 .HasColumnType("bit")
                 .HasColumnName("TwoWayAuthentication");

                entity.Property(e => e.isSms)
                 .HasColumnType("bit")
                 .HasColumnName("IsSMS");

                entity.Property(e => e.isEmail)
                 .HasColumnType("bit")
                 .HasColumnName("IsEmail");

                entity.Property(e => e.countryId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CountryId");

                entity.Property(e => e.isOwnerClient)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsOwnerClient");
            });


            modelBuilder.Entity<CompanyAddressDetail>(entity =>
            {
                entity.HasKey(e => e.addressId)
                    .HasName("PRIMARY");

                entity.ToTable("company_address_details");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.addressId)
                    .HasColumnType("bigint(20)")
                    .ValueGeneratedNever()
                    .HasColumnName("AddressId");

                entity.Property(e => e.branch)
                    .HasMaxLength(45)
                    .HasColumnName("Branch");

                entity.Property(e => e.companyAddress)
                    .HasMaxLength(300)
                    .HasColumnName("CompanyAddress");

                entity.Property(e => e.companyId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.division)
                    .HasMaxLength(45)
                    .HasColumnName("Division");

                entity.Property(e => e.location)
                    .HasMaxLength(45)
                    .HasColumnName("Location");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
            });

            modelBuilder.Entity<BankDetail>(entity =>
            {
                entity.ToTable("bank_details");

                entity.HasIndex(e => e.CompanyId, "company_id");

                entity.Property(e => e.Id)
                    .HasColumnType("int")
                    .HasColumnName("id");

                entity.Property(e => e.AccountNumber).HasColumnName("account_number");

                entity.Property(e => e.BankName)
                    .HasMaxLength(50)
                    .HasColumnName("bank_name");

                entity.Property(e => e.Branch)
                    .HasMaxLength(50)
                    .HasColumnName("branch");

                entity.Property(e => e.CompanyId).HasColumnName("company_id");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .HasColumnName("created_by");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("created_date");

                entity.Property(e => e.IfscCode)
                    .HasMaxLength(50)
                    .HasColumnName("ifsc_code");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .HasColumnName("updated_by");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("updated_date");

                //entity.HasOne(d => d.Company)
                //    .WithMany(p => p.BankDetails)
                //    .HasForeignKey(d => d.CompanyId)
                //    .HasConstraintName("bank_details_ibfk_1");
            });

            modelBuilder.Entity<Costcenter>(entity =>
            {
                entity.ToTable("costcenter");

                entity.HasIndex(e => e.employeeId, "EmployeeId");

                entity.Property(e => e.costCenterId)
                    .ValueGeneratedNever()
                    .HasColumnName("CostCenterId");

                entity.Property(e => e.costcenterName)
                    .HasMaxLength(50)
                    .HasColumnName("CostCenterName");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.employeeId).HasColumnName("EmployeeId");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("departments");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.departmentsId)
                    .ValueGeneratedNever()
                    .HasColumnName("DepartmentsId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.deptsName)
                    .HasMaxLength(100)
                    .HasColumnName("DeptsName");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                //entity.HasOne(d => d.Company)
                //    .WithMany(p => p.Departments)
                //    .HasForeignKey(d => d.CompanyId)
                //    .HasConstraintName("departments_ibfk_1");
            });

            modelBuilder.Entity<DefaultCompanyScript>(entity =>
            {
                entity.ToTable("default_company_script");

                entity.Property(e => e.companyScriptId).HasColumnName("CompanyScriptId");

                entity.Property(e => e.Script)
                    .HasColumnType("text")
                    .HasColumnName("script");
            });

            modelBuilder.Entity<Designation>(entity =>
            {
                entity.ToTable("designation");

                entity.HasIndex(e => e.employeeId, "EmployeeId");

                entity.Property(e => e.designationId)
                    .ValueGeneratedNever()
                    .HasColumnName("DesignationId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.designationName)
                    .HasMaxLength(50)
                    .HasColumnName("DesignationName");

                entity.Property(e => e.employeeId).HasColumnName("employee_id");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                //entity.HasOne(d => d.Employee)
                //    .WithMany(p => p.Designations)
                //    .HasForeignKey(d => d.EmployeeId)
                //    .HasConstraintName("designation_ibfk_1");
            });

            modelBuilder.Entity<Document>(entity =>
            {
                entity.ToTable("documents");

                entity.HasIndex(e => e.companyId, "company_id");

                entity.Property(e => e.docId)
                    .ValueGeneratedNever()
                    .HasColumnName("DocId");

                entity.Property(e => e.activeStatus)
                    .HasMaxLength(5)
                    .HasColumnName("ActiveStatus");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.docDescription)
                    .HasMaxLength(50)
                    .HasColumnName("DocDescription");

                entity.Property(e => e.docName)
                    .HasMaxLength(50)
                    .HasColumnName("DocName");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                    .HasMaxLength(3)
                    .HasColumnName("Status");

                //entity.HasOne(d => d.Company)
                //    .WithMany(p => p.Documents)
                //    .HasForeignKey(d => d.CompanyId)
                //    .HasConstraintName("documents_ibfk_1");
            });

            modelBuilder.Entity<EmailContent>(entity =>
            {
                entity.ToTable("email_content");

                entity.Property(e => e.emailContentId).HasColumnName("EmailContentId");

                entity.Property(e => e.contentId).HasColumnName("ContentId");

                entity.Property(e => e.emailContentText)
                    .HasMaxLength(500)
                    .HasColumnName("EmailContent");

                entity.Property(e => e.subject)
                    .HasMaxLength(400)
                    .HasColumnName("Subject");
            });

            modelBuilder.Entity<EmailConfiguration>(entity =>
            {
                entity.ToTable("email_configuration");

                entity.Property(e => e.emailConfigId).HasColumnName("EmailConfigId");

                entity.Property(e => e.displayName)
                    .HasMaxLength(45)
                    .HasColumnName("DisplayName");

                entity.Property(e => e.host)
                    .HasMaxLength(45)
                    .HasColumnName("Host");

                entity.Property(e => e.password)
                    .HasMaxLength(45)
                    .HasColumnName("Password");

                entity.Property(e => e.port)
                    .HasMaxLength(45)
                    .HasColumnName("Port");

                entity.Property(e => e.type)
                    .HasMaxLength(45)
                    .HasColumnName("Type");

                entity.Property(e => e.userName)
                    .HasMaxLength(45)
                    .HasColumnName("UserName");

                entity.Property(e => e.companyId)
                   .HasColumnName("CompanyId");

                entity.Property(e => e.senderMailId)
                    .HasMaxLength(500)
                    .HasColumnName("SenderMailID");

            });

            modelBuilder.Entity<EmployeeCodeConfig>(entity =>
            {
                entity.ToTable("employee_code_config");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.employeeConfigId)
                    .ValueGeneratedNever()
                    .HasColumnName("EmployeeConfigId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.empCodeFormula)
                    .HasMaxLength(200)
                    .HasColumnName("EmpCodeFormula");

                entity.Property(e => e.empCodeAssigned)
                    .HasMaxLength(3)
                    .HasColumnName("EmpCodeAssigned");

                entity.Property(e => e.incrementBy).HasColumnName("IncrementBy");

                entity.Property(e => e.lastEmpNo).HasColumnName("LastEmpNo");

                entity.Property(e => e.employeeAttribute)
                    .HasMaxLength(100)
                    .HasColumnName("EmployeeAttribute");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                    .HasColumnType("bool")
                    .HasColumnName("Status");

                //entity.HasOne(d => d.Company)
                //    .WithMany(p => p.Departments)
                //    .HasForeignKey(d => d.CompanyId)
                //    .HasConstraintName("departments_ibfk_1");
            });

            modelBuilder.Entity<EmployeeAddressDetail>(entity =>
            {
                entity.ToTable("employee_address_details");

                entity.HasIndex(e => e.employeeId, "employee_id");

                entity.Property(e => e.employeeAddressDetailId)
                    .ValueGeneratedNever()
                    .HasColumnName("EmployeeAddressDetailId");

                entity.Property(e => e.address1)
                    .HasMaxLength(50)
                    .HasColumnName("Address1");

                entity.Property(e => e.address2)
                    .HasMaxLength(50)
                    .HasColumnName("Address2");

                entity.Property(e => e.city)
                    .HasMaxLength(50)
                    .HasColumnName("City");

                entity.Property(e => e.country)
                    .HasMaxLength(50)
                    .HasColumnName("Country");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.employeeId).HasColumnName("EmployeeId");

                entity.Property(e => e.pincode)
                    .HasMaxLength(20)
                    .HasColumnName("Pincode");

                entity.Property(e => e.state)
                    .HasMaxLength(50)
                    .HasColumnName("State");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                //entity.HasOne(d => d.Employee)
                //    .WithMany(p => p.EmployeeAddressDetails)
                //    .HasForeignKey(d => d.EmployeeId)
                //    .HasConstraintName("employee_address_details_ibfk_1");
            });

            modelBuilder.Entity<EmployeeNomineeDetail>(entity =>
            {
                entity.ToTable("employee_nominee_details");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.employeeNomineeDetailsId)
                    .ValueGeneratedNever()
                    .HasColumnName("EmployeeNomineeDetailsId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.dob)
                    .HasColumnType("datetime")
                    .HasColumnName("Dob");

                entity.Property(e => e.name)
                    .HasMaxLength(50)
                    .HasColumnName("Name");

                entity.Property(e => e.relation)
                    .HasMaxLength(20)
                    .HasColumnName("Relation");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<EmployeePersonalDetail>(entity =>
            {
                entity.ToTable("employee_personal_details");

                entity.HasIndex(e => e.companyId, "CompanyId");
                entity.HasIndex(e => e.companyId, "GroupId");
                entity.HasIndex(e => e.companyId, "RoleId");
                entity.Property(e => e.employeePersonalDetailId)

                    .HasColumnName("EmployeePersonalDetailId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.groupId).HasColumnName("GroupId");
                entity.Property(e => e.roleId).HasColumnName("RoleId");
                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.dob)
                    .HasColumnType("datetime")
                    .HasColumnName("Dob");

                entity.Property(e => e.fatherName)
                    .HasMaxLength(100)
                    .HasColumnName("FatherName");

                entity.Property(e => e.firstName)
                    .HasMaxLength(100)
                    .HasColumnName("FirstName");

                entity.Property(e => e.gender)
                    .HasMaxLength(6)
                    .HasColumnName("Gender");

                entity.Property(e => e.lastName)
                    .HasMaxLength(100)
                    .HasColumnName("LastName");

                entity.Property(e => e.maritalStatus)
                    .HasMaxLength(20)
                    .HasColumnName("MaritalStatus");

                entity.Property(e => e.middleName)
                    .HasMaxLength(100)
                    .HasColumnName("MiddleName");

                entity.Property(e => e.mobileNo)
                    .HasMaxLength(20)
                    .HasColumnName("MobileNo");

                entity.Property(e => e.religion)
                    .HasMaxLength(20)
                    .HasColumnName("Religion");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.email)
                    .HasMaxLength(50)
                    .HasColumnName("Email");

                entity.Property(e => e.password)
                   .HasMaxLength(100)
                   .HasColumnName("Password");

                entity.Property(e => e.status)
                  .HasColumnType("int(1)")
                  .HasColumnName("Status");

                entity.Property(e => e.employeeImageUrl)
            .HasMaxLength(100)
            .HasColumnName("EmployeeImageUrl");

                entity.Property(e => e.clientId)
                  .HasColumnType("bigint")
                  .HasColumnName("ClientId");

                entity.Property(e => e.isCompanyAdmin)
                 .HasColumnType("tinyint")
                 .HasColumnName("IsCompanyAdmin");

                entity.Property(e => e.isClientAdmin)
                 .HasColumnType("tinyint")
                 .HasColumnName("IsClientAdmin");


                entity.Property(e => e.roleIds)
                    .HasColumnType("json")
                    .HasColumnName("RoleIds");

                entity.Property(e => e.countryCode)
                    .HasMaxLength(5)
                    .HasColumnName("CountryCode");



            });

            modelBuilder.Entity<EmployeeProfessionalDetail>(entity =>
            {
                entity.ToTable("employee_professional_details");

                entity.HasIndex(e => e.addressId, "AddressId");

                entity.Property(e => e.employeeProfessionaldetailId)
                    .ValueGeneratedNever()
                    .HasColumnName("EmployeeProfessionaldetailId");

                entity.Property(e => e.addressId).HasColumnName("AddressId");

                entity.Property(e => e.confirmationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ConfirmationDate");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.ctc).HasColumnName("ctc");

                entity.Property(e => e.hireType)
                    .HasMaxLength(20)
                    .HasColumnName("HireType");

                entity.Property(e => e.joinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("JoinDate");

                entity.Property(e => e.leavingDate)
                    .HasColumnType("datetime")
                    .HasColumnName("LeavingDate");

                entity.Property(e => e.oncallAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("OncallAllowanceEligibility");

                entity.Property(e => e.probationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ProbationDate");

                entity.Property(e => e.resignationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("ResignationDate");

                entity.Property(e => e.shiftAllowanceEligibility)
                    .HasMaxLength(20)
                    .HasColumnName("ShiftAllowanceEligibility");

                entity.Property(e => e.status)
                    .HasMaxLength(45)
                    .HasColumnName("Status");

                entity.Property(e => e.ctc)
                    .HasColumnName("Ctc");

                entity.Property(e => e.totalExperience)
                    .HasMaxLength(15)
                    .HasColumnName("TotalExperience");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<GradeDetail>(entity =>
            {
                entity.ToTable("grade_details");

                entity.HasIndex(e => e.employeeId, "EmployeeId");

                entity.Property(e => e.gradeId)
                    .ValueGeneratedNever()
                    .HasColumnName("GradeId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.employeeId).HasColumnName("EmployeeId");

                entity.Property(e => e.grade)
                    .HasMaxLength(50)
                    .HasColumnName("Grade");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<GroupRoleMapper>(entity =>
            {
                entity.ToTable("group_role_mapper");

                entity.HasIndex(e => e.groupId, "GroupId");

                entity.HasIndex(e => e.roleId, "RoleId");

                entity.Property(e => e.groupRoleMapperId)
                    .ValueGeneratedNever()
                    .HasColumnName("GroupRoleMapperId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.groupId).HasColumnName("GroupId");

                entity.Property(e => e.roleId).HasColumnName("RoleId");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<LeaveType>(entity =>
            {
                entity.ToTable("leave_type");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.leaveTypeId)
                    .ValueGeneratedNever()
                    .HasColumnName("LeaveTypeId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.leaveDescription)
                    .HasMaxLength(50)
                    .HasColumnName("LeaveDescription");



                entity.Property(e => e.leaveType1)
                    .HasMaxLength(50)
                    .HasColumnName("LeaveType");

                entity.Property(e => e.noOfDays).HasColumnName("NoOfDays");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                   .HasColumnType("bit")
                   .HasColumnName("Status");

                //entity.HasOne(d => d.Company)
                //    .WithMany(p => p.LeaveTypes)
                //    .HasForeignKey(d => d.CompanyId)
                //    .HasConstraintName("leave_type_ibfk_1");
            });

            modelBuilder.Entity<Location>(entity =>
            {
                entity.ToTable("location");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.locationId)
                    .ValueGeneratedNever()
                    .HasColumnName("LocationId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.locationName)
                    .HasMaxLength(100)
                    .HasColumnName("LocationName");

                entity.Property(e => e.country).HasColumnName("CountryId");

                entity.Property(e => e.state).HasColumnName("StateId");
                entity.Property(e => e.city).HasColumnName("CityId");

                entity.Property(e => e.status)
                    .HasMaxLength(10)
                    .HasColumnName("Status");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
            });

            modelBuilder.Entity<MasterChangesTracker>(entity =>
            {
                entity.ToTable("master_changes_tracker");

                entity.Property(e => e.masterChangesTrackerId).HasColumnName("MasterChangesTrackerId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.userId).HasColumnName("UserId");

                entity.Property(e => e.createdBy)
                   .HasMaxLength(50)
                   .HasColumnName("CreatedBy");

                entity.Property(e => e.masterName)
                  .HasMaxLength(50)
                  .HasColumnName("MasterName");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.isOrderChange)
             .HasColumnType("bit")
             .HasColumnName("IsOrderChange");
            });

            modelBuilder.Entity<Module>(entity =>
            {
                entity.ToTable("module_master");

                entity.Property(e => e.moduleId)
                     .ValueGeneratedOnAdd()
                    .HasColumnName("ModuleId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.moduleName)
                    .HasMaxLength(50)
                    .HasColumnName("ModuleName");

                entity.Property(e => e.moduleDescription)
                    .HasMaxLength(200)
                    .HasColumnName("ModuleDescription");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.moduleScript)
                    .HasColumnType("text")
                    .HasColumnName("ModuleScript");

                entity.Property(e => e.status)
                    .HasColumnType("int(11)")
                    .HasColumnName("Status");

                entity.Property(e => e.isDropdown)
                   .HasColumnType("bit(1)")
                   .HasColumnName("IsDropdown");

                entity.Property(e => e.isEnabled)
                   .HasColumnType("bit(1)")
                   .HasColumnName("IsEnabled");

                entity.Property(e => e.versionNo)
                   .HasMaxLength(100)
                   .HasColumnName("VersionNo");

                entity.Property(e => e.parentID)
                   .HasColumnType("bigint()")
                   .HasColumnName("ParentId");

                entity.Property(e => e.moduleUrl)
                   .HasMaxLength(200)
                   .HasColumnName("ModuleUrl");

                entity.Property(e => e.moduleIcon)
                  .HasMaxLength(45)
                  .HasColumnName("ModuleIcon");

                entity.Property(e => e.isCompulsory)
               .HasColumnName("IsCompulsory");


            });

            modelBuilder.Entity<ModuleOrganisationMapper>(entity =>
            {
                entity.ToTable("module_organisation_mapper");

                entity.HasIndex(e => e.companyId, "module_organisation_mapper_company_id_fk_idx");

                entity.HasIndex(e => e.moduleId, "module_organisation_mapper_module_id_fk_idx");

                entity.Property(e => e.moduleOrgMapperId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("ModuleOrgMapperId");

                entity.Property(e => e.companyId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CompanyId");

                entity.Property(e => e.status)
                    .HasColumnType("int(1)")
                    .HasColumnName("Status");

                entity.Property(e => e.moduleId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("ModuleId");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdBy)
                   .HasMaxLength(45)
                  .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                  .HasColumnType("datetime")
                  .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

               

            });

            modelBuilder.Entity<Organisation>(entity =>
            {
                entity.HasKey(e => e.companyId)
                    .HasName("PRIMARY");

                entity.ToTable("organisation");

                entity.HasIndex(e => e.companyName, "company_name_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.organization)
                    .HasMaxLength(100)
                   .HasColumnName("Organization");


                entity.Property(e => e.companyId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CompanyId");

                entity.Property(e => e.clientId)
                   .HasColumnType("bigint(20)")
                   .HasColumnName("ClientId");

                entity.Property(e => e.approved)
                    .HasColumnType("tinyint(4)")
                    .HasColumnName("Approved");

                entity.Property(e => e.companyLogo)
                    .HasMaxLength(100)
                    .HasColumnName("CompanyLogo");

                entity.Property(e => e.companyName)
                    .HasMaxLength(50)
                    .HasColumnName("CompanyName");

                entity.Property(e => e.created)
                    .HasColumnType("tinyint(4)")
                    .HasColumnName("Created");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.esiReg)
                    .HasMaxLength(50)
                    .HasColumnName("EsiReg");

                entity.Property(e => e.panNo)
                    .HasMaxLength(20)
                    .HasColumnName("PanNo");

                entity.Property(e => e.pfReg)
                    .HasMaxLength(50)
                    .HasColumnName("PfReg");

                entity.Property(e => e.status)
                    .HasColumnType("int(1)")
                    .HasColumnName("Status");

                entity.Property(e => e.tanNo)
                    .HasMaxLength(20)
                    .HasColumnName("TanNo");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.schemaName)
                   .HasMaxLength(45)
                   .HasColumnName("SchemaName");

                entity.Property(e => e.checkerId)
                   .HasColumnType("bigint(20)")
                   .HasColumnName("CheckerId");

                entity.Property(e => e.makerId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("MakerId");


                entity.Property(e => e.passwordExpiry)
                    .HasColumnType("int")
                    .HasColumnName("PasswordExpiry");

                entity.Property(e => e.companyAddress1)
                    .HasMaxLength(100)
                    .HasColumnName("Address1");

                entity.Property(e => e.companyAddress2)
                   .HasMaxLength(100)
                   .HasColumnName("Address2");

                entity.Property(e => e.companyAddress3)
                   .HasMaxLength(100)
                   .HasColumnName("Address3");

                entity.Property(e => e.rejectionReason)
                   .HasMaxLength(200)
                   .HasColumnName("RejectionReason");

                entity.Property(e => e.pincode)
                   .HasMaxLength(45)
                   .HasColumnName("Pincode");

                entity.Property(e => e.twoWayAuthentication)
                 .HasColumnType("JSON")
                 .HasColumnName("TwoWayAuthentication");

                entity.Property(e => e.isOwnerCompany)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsOwnerCompany");

                entity.Property(e => e.isCompanyLogo)
                 .HasColumnType("bit")
                 .HasColumnName("IsCompanyLogo");


                entity.Property(e => e.isSms)
                 .HasColumnType("bigint")
                 .HasColumnName("IsSMS");

                entity.Property(e => e.isEmail)
                 .HasColumnType("bigint")
                 .HasColumnName("IsEmail");


                entity.Property(e => e.countryId)
                   .HasColumnType("bigint")
                   .HasColumnName("CountryId");


                entity.Property(e => e.stateId)
                   .HasColumnType("bigint")
                   .HasColumnName("StateId");


            });

            modelBuilder.Entity<OtherField>(entity =>
            {
                entity.HasKey(e => e.fieldId)
                    .HasName("PRIMARY");

                entity.ToTable("other_fields");

                entity.HasIndex(e => e.clientId, "other_client_id_fk_idx");

                entity.HasIndex(e => e.moduleId, "other_module_id_fk_idx");

                entity.Property(e => e.fieldId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("FieldId");

                entity.Property(e => e.clientId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("ClientId");

                entity.Property(e => e.description)
                    .HasMaxLength(200)
                    .HasColumnName("Description");

                entity.Property(e => e.fieldName)
                    .HasMaxLength(45)
                    .HasColumnName("FieldName");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.moduleId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("ModuleId");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.createdTime)
                  .HasColumnType("datetime")
                  .HasColumnName("CreatedTime");
            });

            modelBuilder.Entity<PasswordConfiguration>(entity =>
            {
                entity.ToTable("password_configuration");

                entity.Property(e => e.passConfigId).HasColumnName("PassConfigId");

                entity.Property(e => e.clientId).HasColumnName("ClientId");

                entity.Property(e => e.lowerCase).HasColumnName("LowerCase");

                entity.Property(e => e.maximumLength).HasColumnName("MaximumLength");

                entity.Property(e => e.minimumLength).HasColumnName("MinimumLength");

                entity.Property(e => e.passwordExpiryDays).HasColumnName("PasswordExpiryDays");

                entity.Property(e => e.specialCharacters).HasColumnName("SpecialCharacters");

                entity.Property(e => e.specialCharactersAllowed)
                    .HasMaxLength(45)
                    .HasColumnName("SpecialCharactersAllowed");

                entity.Property(e => e.upperCase).HasColumnName("UpperCase");

                entity.Property(e => e.updatedBy)
                   .HasMaxLength(45)
                   .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedDate)
                   .HasColumnType("datetime")
                   .HasColumnName("UpdatedDate");

                entity.Property(e => e.createdTime)
                  .HasColumnType("datetime")
                  .HasColumnName("CreatedTime");

                entity.Property(e => e.noOfHistory)
                  .HasColumnType("int")
                  .HasColumnName("NoOfHistory");
            });

            modelBuilder.Entity<RoleOrganisationMapper>(entity =>
            {
                entity.ToTable("role_organisation_mapper");

                entity.HasIndex(e => e.companyId, "role_organisation_company_id_fk_idx");

                entity.HasIndex(e => e.roleId, "role_organisation_role_id_fk_idx");

                entity.Property(e => e.roleOrgMapperId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("RoleOrgMapperId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.roleId).HasColumnName("RoleId");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");


            });

            modelBuilder.Entity<Screen>(entity =>
            {
                entity.ToTable("screen");

                entity.HasIndex(e => e.moduleId, "ModuleId");

                entity.Property(e => e.screenId)
                    .ValueGeneratedNever()
                    .HasColumnName("ScreenId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.moduleId).HasColumnName("ModuleId");

                entity.Property(e => e.screenName)
                    .HasMaxLength(50)
                    .HasColumnName("ScreenName");

                entity.Property(e => e.screenURL)
                    .HasMaxLength(200)
                    .HasColumnName("ScreenURL");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                    .HasColumnType("int(1)")
                    .HasColumnName("Status");

                entity.Property(e => e.isApproveAllowed)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsApproveAllowed");

                entity.Property(e => e.isAllowedToOwner)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsAllowedToOwner");

                entity.Property(e => e.isAllowedToClient)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsAllowedToClient");

                entity.Property(e => e.isDefaultCreate)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsDefaultCreate");

                entity.Property(e => e.isDefaultRead)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsDefaultRead");

                entity.Property(e => e.isDefaultUpdate)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsDefaultUpdate");

                entity.Property(e => e.isDefaultDelete)
                    .HasColumnType("tinyint")
                    .HasColumnName("IsDefaultDelete");

                entity.HasOne(d => d.module)

                    .WithMany(p => p.Screens)
                    .HasForeignKey(d => d.moduleId)
                    .HasConstraintName("screen_ibfk_1");

                entity.Property(e => e.parentId)
                  .HasColumnType("bigint")
                  .HasColumnName("ParentId");
            });

            modelBuilder.Entity<ScreenPermission>(entity =>
            {
                entity.ToTable("screen_permission");

                entity.HasIndex(e => e.roleId, "role_id");

                entity.HasIndex(e => e.screenId, "screen_id");

                entity.Property(e => e.screenPermissionId)
                  .ValueGeneratedOnAdd()
                    .HasColumnName("ScreenPermissionId");

                entity.Property(e => e.create)
                    .HasColumnName("Create");

                entity.Property(e => e.read)
                    .HasColumnName("Read");

                entity.Property(e => e.update)
                    .HasColumnName("Update");

                entity.Property(e => e.delete)
                    .HasColumnName("Delete");

                entity.Property(e => e.approve)
                   .HasColumnName("Approve");

                entity.Property(e => e.roleId).HasColumnName("RoleId");

                entity.Property(e => e.screenId).HasColumnName("ScreenId");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(45)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(45)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.status)
                    .HasColumnType("int(1)")
                    .HasColumnName("Status");

                entity.Property(e => e.createdTime)
                   .HasColumnType("datetime")
                   .HasColumnName("CreatedTime");

            });

            modelBuilder.Entity<TrackPassword>(entity =>
            {
                entity.ToTable("track_password");

                entity.Property(e => e.trackPassId).HasColumnName("TrackPassId");

                entity.Property(e => e.employeeId).HasColumnName("EmployeeId");

                entity.Property(e => e.lastChanged)
                    .HasColumnType("datetime")
                    .HasColumnName("LastChanged");

                entity.Property(e => e.password)
                    .HasMaxLength(200)
                    .HasColumnName("Password");
            });

            modelBuilder.Entity<UserGroup>(entity =>
            {
                entity.ToTable("user_group");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.userGroupId)
                    .ValueGeneratedNever()
                    .HasColumnName("UserGroupId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.groupName)
                    .HasMaxLength(50)
                    .HasColumnName("GroupName");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.isMultiCompany)
                   .HasColumnType("bit")
                   .HasColumnName("IsMultiCompany");

            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.ToTable("user_role");

                entity.HasIndex(e => e.companyId, "CompanyId");

                entity.Property(e => e.userRoleId)
                    .HasColumnName("UserRoleId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdBy)
                    .HasMaxLength(50)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.roleName)
                    .HasMaxLength(50)
                    .HasColumnName("RoleName");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(50)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

                entity.Property(e => e.isMultiCompany)
                    .HasColumnType("bit(1)")
                    .HasColumnName("IsMultiCompany");
                entity.Property(e => e.status)
                   .HasColumnType("int")
                   .HasColumnName("Status");

                entity.Property(e => e.actualStatus)
                  .HasMaxLength(10)
                  .HasColumnName("ActualStatus");

            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.ToTable("state_master");

                entity.Property(e => e.stateId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("StateId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.countryId).HasColumnName("CountryId");

                entity.Property(e => e.createdBy)
                           .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.createdTime)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedTime");

                entity.Property(e => e.stateName)
                    .HasMaxLength(100)
                    .HasColumnName("StateName");

                entity.Property(e => e.status)
                .HasColumnName("Status");

                entity.Property(e => e.updatedBy)
                    .HasMaxLength(60)
                    .HasColumnName("UpdatedBy");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");


            });

            modelBuilder.Entity<Status>(entity =>
            {
                entity.ToTable("status");

                entity.HasIndex(e => e.statusName, "status_name_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.statusId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("StatusId");

                entity.Property(e => e.statusName)
                    .HasMaxLength(20)
                    .HasColumnName("StatusName");
            });

            modelBuilder.Entity<ClientOrganisationMapper>(entity =>
            {
                entity.ToTable("client_organisation_mapper");

                entity.HasIndex(e => e.clientId, "c_o_m_client_id_fk_idx");

                entity.HasIndex(e => e.companyId, "client_org_map_company_id_fk_idx");

                entity.Property(e => e.clientOrganisationMapperId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("ClientOrganisationMapperId");

                entity.Property(e => e.clientId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("ClientId");

                entity.Property(e => e.companyId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CompanyId");

                entity.Property(e => e.status)
                    .HasColumnType("int(1)")
                    .HasColumnName("Status");

                entity.Property(e => e.createdBy)
                   .HasColumnType("varchar(45)")
                   .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
              .HasColumnType("varchar(45)")
              .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
             .HasColumnType("datetime")
             .HasColumnName("CreatedTime");

                entity.Property(e => e.updatedDate)
             .HasColumnType("datetime")
             .HasColumnName("UpdatedTime");


            });

            modelBuilder.Entity<OrganisationGroupMapper>(entity =>
            {
                entity.ToTable("organisation_group_mapper");

                entity.HasIndex(e => e.companyId, "org_group_company_id_fk_idx");

                entity.HasIndex(e => e.groupId, "org_group_group_id_fk_idx");

                entity.Property(e => e.orgGrpMapperId)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("OrgGrpMapperId");

                entity.Property(e => e.companyId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("CompanyId");

                entity.Property(e => e.groupId)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("GroupId");

                entity.Property(e => e.createdBy)
                      .HasMaxLength(50)
                      .HasColumnName("CreatedBy");

                entity.Property(e => e.updatedBy)
                      .HasMaxLength(50)
                      .HasColumnName("UpdatedBy");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");

            });

            modelBuilder.Entity<ClientUserRoleMapper>(entity =>
            {
                entity.ToTable("client_user_role_mapper");

                entity.HasIndex(e => e.clientId, "fk_client_id_clienturm_idx");

                entity.HasIndex(e => e.employeeId, "fk_employee_id_clienturm");

                entity.HasIndex(e => e.roleId, "fk_role_id_clienturm_idx");

                entity.HasIndex(e => e.status, "fk_status_clienturn_idx");

                entity.Property(e => e.clientUserRoleMapperId).HasColumnName("ClientUserRoleMapperId");

                entity.Property(e => e.clientId)
                .HasColumnName("ClientId");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.employeeId).HasColumnName("EmployeeId");

                entity.Property(e => e.roleId).HasColumnName("RoleId");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
                entity.Property(e => e.createdBy)
                   .HasMaxLength(50)
                   .HasColumnName("CreatedBy");
                entity.Property(e => e.updatedBy)
                   .HasMaxLength(50)
                   .HasColumnName("UpdatedBy");
            });


            modelBuilder.Entity<CompanyUserRoleMapper>(entity =>
            {
                entity.ToTable("company_user_role_mapper");

                entity.HasIndex(e => e.companyId, "fk_company_id_curm_idx");

                entity.HasIndex(e => e.employeeId, "fk_employee_id_curm");

                entity.HasIndex(e => e.roleId, "fk_role_id_curm_idx");

                entity.HasIndex(e => e.status, "fk_status_curm_idx");

                entity.Property(e => e.userRoleMapperId)
                .HasColumnName("UserRoleMapperId");

                entity.Property(e => e.companyId).HasColumnName("CompanyId");

                entity.Property(e => e.createdDate)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDate");

                entity.Property(e => e.employeeId).HasColumnName("EmployeeId");

                entity.Property(e => e.roleId).HasColumnName("RoleId");

                entity.Property(e => e.status).HasColumnName("Status");

                entity.Property(e => e.updatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("UpdatedDate");
                entity.Property(e => e.createdBy)
                   .HasMaxLength(50)
                   .HasColumnName("CreatedBy");
                entity.Property(e => e.updatedBy)
                   .HasMaxLength(50)
                   .HasColumnName("UpdatedBy");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);


    }
}



