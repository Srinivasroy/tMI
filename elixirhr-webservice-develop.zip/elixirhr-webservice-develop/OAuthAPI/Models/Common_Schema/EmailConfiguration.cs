﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.models.common_schema
{
    public partial class EmailConfiguration
    {
        [Key]
        public int emailConfigId { get; set; }
        public string? userName { get; set; }
        public string? password { get; set; }
        public string? host { get; set; }
        public string? port { get; set; }
        public string? displayName { get; set; }
        public string? type { get; set; }
         public int companyId { get; set; }
        public string? senderMailId { get; set; }

    }
}
