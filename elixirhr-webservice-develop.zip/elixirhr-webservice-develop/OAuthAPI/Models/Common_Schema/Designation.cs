﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.models.common_schema
{
    public partial class Designation
    {
        [JsonIgnore]
        [Key]
        public long designationId { get; set; }
        public string? designationName { get; set; }
        [Required(ErrorMessage = "CreatedBy is required!!!")]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [Required(ErrorMessage = "Employee Id is mandatory")]
        public long? employeeId { get; set; }
        [JsonIgnore]
        public virtual EmployeePersonalDetail? Employee { get; set; }

    }
}
