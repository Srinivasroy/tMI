﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.models.common_schema
{
    public partial class BankDetail
    {
        public string? BankName { get; set; }
        public string? Branch { get; set; }
        public string? IfscCode { get; set; }
        public long? AccountNumber { get; set; }
        [JsonIgnore]
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Company Id is mandatory")]
        public long? CompanyId { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required !!!")]
        public string? UpdatedBy { get; set; }
        [JsonIgnore]
        public DateTime? UpdatedDate { get; set; }
        [Required(ErrorMessage = "CreatedBy is required !!!")]
        public string? CreatedBy { get; set; }
        [JsonIgnore]
        public DateTime? CreatedDate { get; set; }

        //public virtual Organisation? Company { get; set; }
    }
}
