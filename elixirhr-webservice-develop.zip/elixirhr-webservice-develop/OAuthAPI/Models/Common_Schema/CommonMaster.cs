﻿using System.ComponentModel.DataAnnotations;
namespace OAuthAPI.Models.Common_Schema
{
    public class CommonMaster
    {
        [Key]
        public int commonMasterId { get; set; }
        public string? commonMasterName { get; set; }
        public string? commonMasterDisplayName { get; set; }
        public DateTime? createdDate { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public int status { get; set; }
        public bool isCompulsory { get; set; } = false;

        public int defaultparentID { get; set; }
        public string defaultparentType { get; set; }
    }
}
