﻿using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.Models.Common_Schema
{
    public class DefaultMasterScreenMapper
    {
        [Key]
        public int defaultMasterScreenMapperId { get; set; }
        public int screenId { get; set; }
        public int defaultMasterId { get; set; }
        public DateTime? createdDate { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public int status { get; set; }
    }
}
