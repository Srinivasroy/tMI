﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.models.common_schema
{
    public partial class ClientOrganisationMapper
    {
        [JsonIgnore]
        [Key]
        public int clientOrganisationMapperId { get; set; }
        public long? clientId { get; set; }
        public long? companyId { get; set; }

        public int? status { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string updatedBy { get; set; }

        public DateTime updatedDate { get; set; }

    }

    public partial class ClientOrganisationsMapper
    {
        public long? clientId { get; set; }
        public List<int>? companyIds { get; set; }
        public int? status { get; set; }
        [Required]
        public string createdBy { get; set; }
        [Required]
        public string updatedBy { get; set; }
    }
}
