﻿using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.Models.Common_Schema
{
    public class AccessControl
    {
        public AccessEmployeeDetails EmployeeDetails = new AccessEmployeeDetails();
        public AccessClientDetails ClientDetails = new AccessClientDetails();
        public CompanyDetails CompanyDetails = new CompanyDetails();
        public Boolean IsCompanyChecker = false;
        public Boolean IsCompanyMaker = false;
        public Boolean IsClientChecker = false;
        public Boolean IsClientMaker = false;
        public String ServerName = null;
    }

    public class AccessEmployeeDetails
    {
        [Key]
        public long employeeId { get; set; }
        public string employeeName { get; set; }
        public string? employeeImage { get; set; }
        public string employeeEmailId { get; set; }

        public string? employeeRole { get; set; }

        public List<string> employeeRoleList { get; set; }

        public int? employeeRoleId { get; set; }

        public bool showMultipleCompanyCheckbox { get; set; } = false;

        public int? employeeClientId { get; set; }

        public bool isCompanyAdmin { get; set; }

        public bool isClientAdmin { get; set; }
    }

    public class AccessClientDetails
    {
        public long clientId { get; set; }
        public string clientName { get; set; }

    }

    public class Company
    {
        public long companyId { get; set; }
        public string? companyName { get; set; }
        public Boolean? companyLogo { get; set; }
        public string? schemaName { get; set; }
        public Boolean? isMaker { get; set; }
        public Boolean? isChecker { get; set; }
        public bool isCompanyAdmin { get; set; }

        public bool isClientAdmin { get; set; }
        public List<ModulesAccess> AccessControls = new List<ModulesAccess>();
    }
    public class ModulesAccess
    {
        public long moduleId { get; set; }
        public string moduleName { get; set; }
        public long? parentId { get; set; }
        public List<AccessScreen> Screens = new List<AccessScreen>();
        public bool? isDropdown = false;
        public string? moduleIcon { get; set; }
        public string? moduleURL { get; set; }


    }

    public class FirstLevelModule
    {
        public List<ModulesAccess> FirstLevel = new List<ModulesAccess>();
        public List<ModulesAccess> SecondLevel = new List<ModulesAccess>();
    }

    public class AccessScreen
    {
        public string screenName { get; set; }

        public long? screenId { get; set; }

        public int? parentId { get; set; }
        public bool? create { get; set; }
        public bool? read { get; set; }
        public bool? update { get; set; }

        public bool? delete { get; set; }

        public bool? approve { get; set; }
        public string? screenURL { get; set; }

        public List<AccessScreen> SubMenu = new List<AccessScreen>();

        public bool? isRemove = false;

    }
    public class NextLevelAccessScreen
    {
        public string? moduleName;
        public List<AccessScreen> screens = new List<AccessScreen>();
    }
    public class CompanyDetails
    {
        public long? defaultCompanyId { get; set; }
        public string? defaultCompanyName { get; set; }
        public List<Company> Companies = new List<Company>();
    }
}

