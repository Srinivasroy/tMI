﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.models.common_schema
{
    public partial class Document
    {
        [JsonIgnore]
        [Key]
        public long docId { get; set; }
        public string? docName { get; set; }
        public string? docDescription { get; set; }
        public string? activeStatus { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "CreatedBy is required!!!")]
        public string? createdBy { get; set; }
        [Required(ErrorMessage = "Company Id is mandatory")]
        public long? companyId { get; set; }
        public bool status { get; set; } = true;

        [JsonIgnore]
        public virtual Organisation? Company { get; set; }

    }
}
