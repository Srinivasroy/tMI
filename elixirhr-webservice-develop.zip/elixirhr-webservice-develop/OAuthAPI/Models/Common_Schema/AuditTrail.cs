﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.models.common_schema
{
    public partial class AuditTrail
    {
        [Key]
        public int auditTrailId { get; set; }
        public string? screenName { get; set; }
        public string? email { get; set; }

        public string? actionName { get; set; }
        public DateTime? time { get; set; }
    }
}
