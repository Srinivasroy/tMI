﻿using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.Models.Common_Schema
{
    public class CommonMasterScreenMapper
    {
        [Key]
        public int commonMasterScreenMapperId { get; set; }
        public int screenId { get; set; }
        public int commonMasterId { get; set; }
        public DateTime? createdDate { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }

        public int status { get; set; }
    }
}
