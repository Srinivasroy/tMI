﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.models.common_schema
{
    public partial class DefaultCompanyScript
    {
        [Key]
        public int companyScriptId { get; set; }
        public string? Script { get; set; }
    }
}
