﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.Models.Common_Schema
{
    public partial class CompanyAddressDetail
    {
        [JsonIgnore]
        [Key]
        public long addressId { get; set; }
        [Required(ErrorMessage = "Company Id is mandatory !!!")]
        public string? companyAddress { get; set; }
        public string? division { get; set; }
        public string? branch { get; set; }
        public string? location { get; set; }
        [Required(ErrorMessage ="Company Id is mandatory !!!")]
        public long? companyId { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [Required(ErrorMessage = "CreatedBy is required!!!")]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdDate { get; set; }
    }
}
