﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.models.common_schema
{
    public partial class Department
    {
        [JsonIgnore]
        [Key]
        public long departmentsId { get; set; }
        public string? deptsName { get; set; }
        [Required(ErrorMessage = "CreatedBy is required!!!")]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [Required(ErrorMessage = "Company Id is mandatory")]
        public long? companyId { get; set; }
        [JsonIgnore]
        public virtual Organisation? company { get; set; }
    }
}
