﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations;
namespace OAuthAPI.models.common_schema
{

    public class ClientCreation
    {
        [JsonIgnore]
        [Key]
        public long clientId { get; set; }
        //[Required(ErrorMessage = "Client code is required !!!")]
        public string? clientCode { get; set; }
        [Required(ErrorMessage = "Client name is required !!!")]
        public string? clientName { get; set; }
        public string? mobileNo { get; set; }
        public long? companyCount { get; set; }
        public int? status { get; set; }

        public string? address1 { get; set; }

        public string? address2 { get; set; }

        public string? address3 { get; set; }
        [Required(ErrorMessage = "stateId is required !!!")]
        public long? stateId { get; set; }
        public string? pincode { get; set; }

        public string? pan { get; set; }
        public string? tan { get; set; }

        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required !!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        public long? makerId { get; set; } = 0;
        public long? checkerId { get; set; } = 0;

        public string? rejectionReason { get; set; }

        public bool? twoWayAuthentication { get; set; }
        public bool? isSms { get; set; }
        public bool? isEmail { get; set; }

        public Boolean? isOwnerClient { get; set; }
        [Required(ErrorMessage = "countryId is required !!!")]
        public long? countryId { get; set; }

       

    }
    public class ClientCompanyCreation
    {
        [Required(ErrorMessage = "Client name is required !!!")]
        public string? clientName { get; set; }
        [Required(ErrorMessage = "Company name is required !!!")]
        public string? companyName { get; set; }
        [Required(ErrorMessage = "Company name is required !!!")]
        public long? clientId { get; set; } = 0;
        [JsonIgnore]
        public long? companyMakerId { get; set; }
        [JsonIgnore]
        public long? companyCheckerId { get; set; }
        [JsonIgnore]
        public long? clientMakerId { get; set; }
        [JsonIgnore]
        public long? clientCheckerId { get; set; }
        [JsonIgnore]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [JsonIgnore]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }


        public string? organization { get; set; }
        public long companyId { get; set; }
        public string? companyAddress1 { get; set; }

        public List<Users> clientUsers { get; set; }
        public List<Users> companyUsers { get; set; }

    }

    public class UpdateClientCompanyCreation
    {
        [Required(ErrorMessage = "Client name is required !!!")]
        public string? clientName { get; set; }
        [Required(ErrorMessage = "Company name is required !!!")]
        public string? companyName { get; set; }
        [Required(ErrorMessage = "Company name is required !!!")]
        public long? clientId { get; set; } = 0;
        public long? companyId { get; set; }
        [JsonIgnore]
        public long? companyMakerId { get; set; }
        [JsonIgnore]
        public long? companyCheckerId { get; set; }
        [JsonIgnore]
        public long? clientMakerId { get; set; }
        [JsonIgnore]
        public long? clientCheckerId { get; set; }
        [JsonIgnore]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [JsonIgnore]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }

        public List<Users> clientUsers { get; set; }
        public List<Users> companyUsers { get; set; }
    }

    public class Users
    {
        public long? employeeId { get; set; }
        public long? roleId { get; set; }

    }

}
