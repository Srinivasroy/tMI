﻿namespace OAuthAPI.Models.Common_Schema
{
    public class AdditionalMaster
    {
        
            public long additionalMasterId { get; set; }
            public string? name { get; set; }
            public string? description { get; set; }
            public string? createdBy { get; set; }
            public string? updatedBy { get; set; }
            public DateTime? createdTime { get; set; }
            public DateTime? updatedDate { get; set; }
            public long? status { get; set; }
            public long? companyId { get; set; }
       
    }
}
