﻿using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.Models.Common_Schema
{
    public class DefaultMaster
    {
        [Key]
        public int defaultMasterId { get; set; }
        public string? defaultMasterName { get; set; }
        public string? defaultMasterDisplayName { get; set; }
        public DateTime? createdDate { get; set; }
        public DateTime? updatedDate { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public int status { get; set; }
    }
    
}
