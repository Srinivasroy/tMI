﻿namespace OAuthAPI.Models.Common_Schema
{
    public class CommonMasterCompanyMapper
    {
        public int commonMasterCompanyMapperID { get; set; }

        public int commonMasterID { get; set; }
        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
        public long? status { get; set; }
        public long? companyId { get; set; }
    }
}
