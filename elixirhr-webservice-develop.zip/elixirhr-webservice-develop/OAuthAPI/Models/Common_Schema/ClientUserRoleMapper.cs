﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.Models.Common_Schema
{
    public partial class ClientUserRoleMapper
    {
        [Key]
        public int clientUserRoleMapperId { get; set; }
        [Required(ErrorMessage = "Client Id is required !!!")]
        public long? clientId { get; set; }
        public long? employeeId { get; set; }
        public long? roleId { get; set; }
        public int? status { get; set; }
        [JsonIgnore]
        public DateTime? createdDate { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [JsonIgnore]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public string? updatedBy { get; set; }
    }
}
