﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.models.common_schema
{
    public class EmployeeAddressDetail
    {
        [JsonIgnore]
        [Key]
        public long employeeAddressDetailId { get; set; }
        public string? address1 { get; set; }
        public string? address2 { get; set; }
        public string? city { get; set; }
        public string? state { get; set; }
        public string? pincode { get; set; }
        public string? country { get; set; }
        [Required(ErrorMessage = "Employee Id is mandatory")]
        public long? employeeId { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "CreatedBy is required!!!")]
        public string? createdBy { get; set; }

       
    }

    }
