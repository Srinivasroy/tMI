﻿namespace OAuthAPI.Models.Common_Schema
{
    public class DefaultMasterCompanyMapper
    {
        public int defaultMasterCompanyMapperID { get; set; }

        public int defaultMasterID { get; set; }

        public string? createdBy { get; set; }
        public string? updatedBy { get; set; }
        public DateTime? createdTime { get; set; }
        public DateTime? updatedDate { get; set; }
        public long? status { get; set; }
        public long? companyId { get; set; }
    }
}

