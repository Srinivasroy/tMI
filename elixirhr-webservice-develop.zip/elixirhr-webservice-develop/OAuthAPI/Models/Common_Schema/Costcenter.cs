﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OAuthAPI.models.common_schema
{
    public partial class Costcenter
    {
        [JsonIgnore]
        [Key]
        public long costCenterId { get; set; }
        [Required(ErrorMessage = "Costcenter name is mandatory !!!")]
        public string? costcenterName { get; set; }
        [Required(ErrorMessage = "Createdby field is mandatory !!!")]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        [Required(ErrorMessage ="Employee Id is mandatory !!!")]
        public long? employeeId { get; set; }

        //public virtual EmployeeProfessionalDetail? Employee { get; set; }
    }
}
