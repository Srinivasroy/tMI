﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OAuthAPI.models.common_schema
{
    public partial class EmailContent
    {
        [Key]
        public int emailContentId { get; set; }
        public string? subject { get; set; }
        public string? emailContentText { get; set; }
        public int? contentId { get; set; }

    }
}
