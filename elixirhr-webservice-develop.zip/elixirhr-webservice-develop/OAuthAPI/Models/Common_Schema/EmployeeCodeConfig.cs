﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Models.Common_Schema
{
    public partial class EmployeeCodeConfig
    {
        [JsonIgnore]
        [Key]
        public long employeeConfigId { get; set; }
        public string? empCodeFormula { get; set; }
        public string? empCodeAssigned { get; set; }
        public long incrementBy { get; set; }
        public long lastEmpNo { get; set; }
        public string? employeeAttribute { get; set; }
        [Required(ErrorMessage = "CreatedBy is required!!!")]
        public string? createdBy { get; set; }
        [JsonIgnore]
        public DateTime? createdTime { get; set; }
        [Required(ErrorMessage = "UpdatedBy is required!!!")]
        public string? updatedBy { get; set; }
        [JsonIgnore]
        public DateTime? updatedDate { get; set; }
        public long? companyId { get; set; }
        [JsonIgnore]
        public bool status { get; set; } = true;
        [JsonIgnore]
        public virtual Organisation? Company { get; set; }
    }
}
