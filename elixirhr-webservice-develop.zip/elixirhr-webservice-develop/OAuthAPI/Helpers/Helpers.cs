﻿using System.Security.Cryptography;
using System.Text;

namespace OAuthAPI.Helpers
{
    public static class Helpers
    {
        public static string SHA256Hash(string password)
        {
            SHA256CryptoServiceProvider _crtyptoSP = new SHA256CryptoServiceProvider();

            byte[] _passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
            _passwordBytes = _crtyptoSP.ComputeHash(_passwordBytes);
            System.Text.StringBuilder _stringB = new System.Text.StringBuilder();

            foreach (byte _byte in _passwordBytes)
            {
                _stringB.Append(_byte.ToString("x2").ToLower());
            }

            return _stringB.ToString();
        }

        public static String DecryptSHA256Hash(String value)
        {
            StringBuilder Sb = new StringBuilder();

            using (SHA256 hash = SHA256Managed.Create())
            {
                Encoding enc = Encoding.UTF8;
                Byte[] result = hash.ComputeHash(enc.GetBytes(value));

                foreach (Byte b in result)
                    Sb.Append(b.ToString("x2"));
            }

            return Sb.ToString();
        }


        public static string EmailEncrypt(string plainText)
        {
            string key = "0123456789ABCDEF0123456789ABCDEF";
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            byte[] ivBytes = new byte[16]; // Initialization Vector

            using (Aes aes = Aes.Create())
            {
                aes.Key = keyBytes;
                aes.IV = ivBytes;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                        cryptoStream.Write(plainBytes, 0, plainBytes.Length);
                        cryptoStream.FlushFinalBlock();

                        byte[] encryptedBytes = memoryStream.ToArray();
                        return Convert.ToBase64String(encryptedBytes);
                    }
                }
            }
        }

        public static string EmailDecrypt(string encryptedText)
        {
            string key = "0123456789ABCDEF0123456789ABCDEF";
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            byte[] ivBytes = new byte[16]; // Initialization Vector

            byte[] encryptedBytes = Convert.FromBase64String(encryptedText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = keyBytes;
                aes.IV = ivBytes;

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream(encryptedBytes))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        byte[] decryptedBytes = new byte[encryptedBytes.Length];
                        int decryptedByteCount = cryptoStream.Read(decryptedBytes, 0, decryptedBytes.Length);

                        return Encoding.UTF8.GetString(decryptedBytes, 0, decryptedByteCount);
                    }
                }
            }
        }
    }
}
