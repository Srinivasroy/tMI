﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Transfer;

namespace OAuthAPI.Helpers
{
    public class AmazonUploader
    {
        public bool sendMyFileToS3(System.IO.Stream localFilePath, string bucketName, string subDirectoryInBucket, string fileNameInS3)
        {
            var basicAWSCredentials = new BasicAWSCredentials("AKIAYVGKWR4LRJBJX6FF", "G/UNp+2t5NvEpzF8E/fa2iiNfqtYP9PCAhMMJcM5");
            //IAmazonS3 client = new AmazonS3Client(RegionEndpoint.APSouth1);
            IAmazonS3 client = new AmazonS3Client(basicAWSCredentials);
            TransferUtility utility = new TransferUtility(client);
            TransferUtilityUploadRequest request = new TransferUtilityUploadRequest();

            if (subDirectoryInBucket == "" || subDirectoryInBucket == null)
            {
                request.BucketName = bucketName; //no subdirectory just bucket name  
            }
            else
            {   // subdirectory and bucket name  
                request.BucketName = bucketName + @"/" + subDirectoryInBucket;
            }
            request.Key = fileNameInS3; //file name up in S3  
            request.InputStream = localFilePath;
            
            utility.Upload(request); //commensing the transfer  

            return true; //indicate that the file was sent  
        }
    }
}
