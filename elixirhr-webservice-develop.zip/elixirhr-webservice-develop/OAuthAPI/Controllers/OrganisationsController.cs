﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AutoMapper;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.company_schema;
using OAuthAPI.models.Helpers;
using OAuthAPI.Models;
using OAuthAPI.Models.Common_Schema;
using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganisationsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        private readonly ILogger<OrganisationsController> _logger;

        private static Random random = new Random();
        private string UserEmailID = string.Empty;

        public OrganisationsController(Common_Schema_Context context, ILogger<OrganisationsController> logger)
        {
            _context = context;
            this._logger = logger;


        }

        // GET: api/Organisations/1
        [HttpGet("Organisations/{EmployeeId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ArrayList> GetOrganisations(long EmployeeId, bool? GetAll = false)
        {
            if (GetAll == true)
            {
                var organisations = await (from org in _context.Organisations
                                           join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                           from statusValue in StatusesV.DefaultIfEmpty()
                                           join userorg in _context.CompanyUserRoleMappers on org.companyId equals userorg.companyId
                                           //where (userorg.employeeId == EmployeeId)  //GetAll == true ||
                                           join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                           from clientV in Clients.DefaultIfEmpty()
                                           where org.isOwnerCompany != true
                                           select new
                                           {
                                               org.organization,
                                               org.companyId,
                                               org.companyName,
                                               org.clientId,
                                               clientV.clientName,
                                               org.status,
                                               statusValue.statusName,
                                               org.panNo,
                                               org.tanNo,
                                               org.pfReg,
                                               org.esiReg,
                                               org.createdBy,
                                               org.createdTime,
                                               org.updatedBy,
                                               org.updatedDate,
                                               org.companyLogo,
                                               org.schemaName,
                                               org.passwordExpiry,
                                               org.makerId,
                                               org.checkerId,
                                               org.companyAddress1,
                                               org.companyAddress2,
                                               org.companyAddress3,
                                               org.pincode,
                                               org.twoWayAuthentication,
                                               isClientApproved = clientV.status == (int)Statuses.Approved ? 1 : 0,
                                               clientStatus = clientV.status
                                           }
                                       ).Distinct().OrderByDescending(org => org.updatedDate).ToListAsync();


                var userMappedCompanies = await _context.CompanyUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();

                List<object> companyWithPermissions = new List<object>();

                organisations.ForEach((organisation) =>
                {

                    var isMapped = userMappedCompanies.Where(c => c.companyId == organisation.companyId).FirstOrDefault();

                    if (isMapped != null)
                    {
                        var screenPermissions = (from sp in _context.ScreenPermissions
                                                 where sp.roleId == isMapped.roleId && sp.status == (int)Statuses.Approved
                                                 join screen in _context.Screens on sp.screenId equals screen.screenId into Screens
                                                 from screenV in Screens.DefaultIfEmpty()
                                                 select new
                                                 {
                                                     sp.roleId,
                                                     sp.read,
                                                     sp.approve,
                                                     sp.create,
                                                     sp.update,
                                                     sp.delete,
                                                     screenV.screenName,
                                                     sp.screenId
                                                 }
                                                       ).ToList();

                        var cInfo = screenPermissions.Where(s => s.screenName.ToLower().Trim() == "company information").FirstOrDefault();
                        object permissionObj = new { };
                        if (cInfo != null)
                        {
                            permissionObj = new { cInfo.create, cInfo.read, cInfo.update, cInfo.delete, cInfo.approve };

                        }
                        else { permissionObj = new { create = false, read = false, update = false, delete = false, approve = false }; }
                        var obj = new
                        {
                            organisation.organization,
                            organisation.companyId,
                            organisation.companyName,
                            organisation.clientId,
                            organisation.clientName,
                            organisation.status,
                            organisation.statusName,
                            organisation.panNo,
                            organisation.tanNo,
                            organisation.pfReg,
                            organisation.esiReg,
                            organisation.createdBy,
                            organisation.createdTime,
                            organisation.updatedBy,
                            organisation.updatedDate,
                            organisation.companyLogo,
                            organisation.schemaName,
                            organisation.passwordExpiry,
                            organisation.makerId,
                            organisation.checkerId,
                            organisation.companyAddress1,
                            organisation.companyAddress2,
                            organisation.companyAddress3,
                            organisation.pincode,
                            organisation.twoWayAuthentication,
                            organisation.isClientApproved,
                            organisation.clientStatus,

                            employeePermission = permissionObj
                        };
                        companyWithPermissions.Add(obj);
                    }
                    else
                    {
                        var obj = new
                        {
                            organisation.organization,
                            organisation.companyId,
                            organisation.companyName,
                            organisation.clientId,
                            organisation.clientName,
                            organisation.status,
                            organisation.statusName,
                            organisation.panNo,
                            organisation.tanNo,
                            organisation.pfReg,
                            organisation.esiReg,
                            organisation.createdBy,
                            organisation.createdTime,
                            organisation.updatedBy,
                            organisation.updatedDate,
                            organisation.companyLogo,
                            organisation.schemaName,
                            organisation.passwordExpiry,
                            organisation.makerId,
                            organisation.checkerId,
                            organisation.companyAddress1,
                            organisation.companyAddress2,
                            organisation.companyAddress3,
                            organisation.pincode,
                            organisation.twoWayAuthentication,
                            organisation.isClientApproved,
                            organisation.clientStatus,


                            employeePermission = new { create = false, read = false, update = false, delete = false, approve = false }
                        };
                        companyWithPermissions.Add(obj);
                    }
                });

                var _organisationJson = JsonConvert.SerializeObject(companyWithPermissions);
                ArrayList _organisationList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_organisationJson);
                return _organisationList;

            }
            else
            {
                var _organisation = await (from org in _context.Organisations
                                          // where org.status == (int)Statuses.Approved
                                           join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                           from statusValue in StatusesV.DefaultIfEmpty()
                                           join userorg in _context.CompanyUserRoleMappers on org.companyId equals userorg.companyId
                                           where (userorg.employeeId == EmployeeId)  //GetAll == true ||
                                           join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                           from clientV in Clients.DefaultIfEmpty()
                                           where org.isOwnerCompany != true
                                           select new
                                           {
                                               org.organization,
                                               org.companyId,
                                               org.companyName,
                                               org.clientId,
                                               clientV.clientName,
                                               org.status,
                                               statusValue.statusName,
                                               org.panNo,
                                               org.tanNo,
                                               org.pfReg,
                                               org.esiReg,
                                               org.createdBy,
                                               org.createdTime,
                                               org.updatedBy,
                                               org.updatedDate,
                                               org.companyLogo,
                                               org.schemaName,
                                               org.passwordExpiry,
                                               org.makerId,
                                               org.checkerId,
                                               org.companyAddress1,
                                               org.companyAddress2,
                                               org.companyAddress3,
                                               org.pincode,
                                               org.twoWayAuthentication,
                                               isClientApproved = clientV.status == (int)Statuses.Approved ? 1 : 0,
                                               clientStatus = clientV.status
                                           }
                                           ).OrderByDescending(org => org.updatedDate).ToListAsync();

                var userMappedCompanies = await _context.CompanyUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();

                List<object> companyWithPermissions = new List<object>();

                _organisation.ForEach((organisation) =>
                {

                    var isMapped = userMappedCompanies.Where(c => c.companyId == organisation.companyId).FirstOrDefault();

                    if (isMapped != null)
                    {
                        var screenPermissions = (from sp in _context.ScreenPermissions
                                                 where sp.roleId == isMapped.roleId && sp.status == (int)Statuses.Approved
                                                 join screen in _context.Screens on sp.screenId equals screen.screenId into Screens
                                                 from screenV in Screens.DefaultIfEmpty()
                                                 select new
                                                 {
                                                     sp.roleId,
                                                     sp.read,
                                                     sp.approve,
                                                     sp.create,
                                                     sp.update,
                                                     sp.delete,
                                                     screenV.screenName,
                                                     sp.screenId
                                                 }
                                                       ).ToList();

                        var cInfo = screenPermissions.Where(s => s.screenName.ToLower().Trim() == "company information").FirstOrDefault();
                        object permissionObj = new { };
                        if (cInfo != null)
                        {
                            permissionObj = new { cInfo.create, cInfo.read, cInfo.update, cInfo.delete, cInfo.approve };

                        }
                        else { permissionObj = new { create = false, read = false, update = false, delete = false, approve = false }; }
                        var obj = new
                        {
                            organisation.organization,
                            organisation.companyId,
                            organisation.companyName,
                            organisation.clientId,
                            organisation.clientName,
                            organisation.status,
                            organisation.statusName,
                            organisation.panNo,
                            organisation.tanNo,
                            organisation.pfReg,
                            organisation.esiReg,
                            organisation.createdBy,
                            organisation.createdTime,
                            organisation.updatedBy,
                            organisation.updatedDate,
                            organisation.companyLogo,
                            organisation.schemaName,
                            organisation.passwordExpiry,
                            organisation.makerId,
                            organisation.checkerId,
                            organisation.companyAddress1,
                            organisation.companyAddress2,
                            organisation.companyAddress3,
                            organisation.pincode,
                            organisation.twoWayAuthentication,
                            organisation.isClientApproved,
                            organisation.clientStatus,

                            employeePermission = permissionObj
                        };
                        companyWithPermissions.Add(obj);
                    }
                    else
                    {
                        var obj = new
                        {
                            organisation.organization,
                            organisation.companyId,
                            organisation.companyName,
                            organisation.clientId,
                            organisation.clientName,
                            organisation.status,
                            organisation.statusName,
                            organisation.panNo,
                            organisation.tanNo,
                            organisation.pfReg,
                            organisation.esiReg,
                            organisation.createdBy,
                            organisation.createdTime,
                            organisation.updatedBy,
                            organisation.updatedDate,
                            organisation.companyLogo,
                            organisation.schemaName,
                            organisation.passwordExpiry,
                            organisation.makerId,
                            organisation.checkerId,
                            organisation.companyAddress1,
                            organisation.companyAddress2,
                            organisation.companyAddress3,
                            organisation.pincode,
                            organisation.twoWayAuthentication,
                            organisation.isClientApproved,
                            organisation.clientStatus,


                            employeePermission = new { create = false, read = false, update = false, delete = false, approve = false }
                        };
                        companyWithPermissions.Add(obj);
                    }
                });

                var _organisationJson = JsonConvert.SerializeObject(companyWithPermissions);
                ArrayList _organisationList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_organisationJson);
                return _organisationList;
            }
        }


        // GET: api/Organisations/5
        [HttpGet("{companyID}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetOrganisation(long companyID)
        {
            //var organisation = await _context.Organisations.FindAsync(id);
            UserEmailID = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            var _organisation = await (from org in _context.Organisations.Where(x => x.status != (int)Statuses.Deleted)
                                       where org.companyId == companyID
                                       join statusValue in _context.Statuses on org.status equals statusValue.statusId
                                       join clientV in _context.ClientCreation on org.clientId equals clientV.clientId
                                       select new OrganisationSetup
                                       {

                                           organization = org.organization,
                                           companyId = org.companyId,
                                           companyName = org.companyName,
                                           clientId = org.clientId,
                                           clientName = clientV.clientName,
                                           status = org.status,
                                           statusName = statusValue.statusName,
                                           panNo = org.panNo,
                                           tanNo = org.tanNo,
                                           pfReg = org.pfReg,
                                           esiReg = org.esiReg,
                                           passwordExpiry = org.passwordExpiry,
                                           companyAddress1 = org.companyAddress1,
                                           companyAddress2 = org.companyAddress2,
                                           companyAddress3 = org.companyAddress3,
                                           pincode = org.pincode,
                                           twoWayAuthentication = org.twoWayAuthentication,
                                           isEmail = org.isEmail,
                                           isSms = org.isSms,
                                           stateId = org.stateId == 1 ? null : org.stateId,
                                           countryId = org.countryId == 1 ? null : org.countryId,

                                       }).FirstOrDefaultAsync();


            if (_organisation == null)
            {
                return NotFound();
            }
            var OrganisationStorage = await _context.StorageAllocation.Where(c => c.status == (int)Statuses.Approved && c.companyID == companyID).FirstOrDefaultAsync();
            if (OrganisationStorage == null)
            {
                OrganisationStorage = new StorageAllocation
                {
                    storageAllocationID = 0,
                    companyID = companyID,

                };
            }
            _organisation.storageAllocation = OrganisationStorage;

            var CompanyAdminUser = _context.EmployeePersonalDetails.Where(c => (c.status == (int)Statuses.Approved || c.status == (int)Statuses.Rejected) && c.companyId == companyID
                                                                                    && c.isCompanyAdmin == true).FirstOrDefault();
            if (CompanyAdminUser != null)
            {
                _organisation.employeePersonalDetailId = CompanyAdminUser.employeePersonalDetailId;
                _organisation.firstName = CompanyAdminUser.firstName;
                _organisation.middleName = CompanyAdminUser.middleName;
                _organisation.lastName = CompanyAdminUser.lastName;
                _organisation.emailID = CompanyAdminUser.email;
                _organisation.mobileNumber = CompanyAdminUser.mobileNo;
                _organisation.isCompanyAdmin = CompanyAdminUser.isCompanyAdmin;
                _organisation.isClientAdmin = CompanyAdminUser.isClientAdmin;
                _organisation.roleId = CompanyAdminUser.roleId;
                _organisation.roleIds = CompanyAdminUser.roleIds;
            }

            var OrganisationDefaultMasterMappers = await (from dm in _context.DefaultMaster.Where(c => c.status == (int)Statuses.Approved)
                                                          join dmcm in _context.DefaultMasterCompanyMapper.Where(c => c.companyId == companyID)
                                                          on dm.defaultMasterId equals dmcm.defaultMasterID into dmcm
                                                          from dmcm1 in dmcm.DefaultIfEmpty()
                                                          select new OrganisationDefaultMasterMapper
                                                          {
                                                              defaultMasterName = dm.defaultMasterName,
                                                              defaultMasterDisplayName = dm.defaultMasterDisplayName,
                                                              defaultMasterCompanyMapperID = (dmcm1.defaultMasterCompanyMapperID == null ? 0 :
                                                                                                    dmcm1.defaultMasterCompanyMapperID),
                                                              defaultMasterID = dm.defaultMasterId,
                                                              companyId = companyID,
                                                              status = (dmcm1.defaultMasterCompanyMapperID != null ? (int)dmcm1.status : (int)Statuses.Approved),
                                                          }).ToListAsync();

            _organisation.organisationDefaultMaster = OrganisationDefaultMasterMappers;

            var OrganisationCommonMasterMappers = await (from cm in _context.CommonMaster.Where(c => c.status == (int)Statuses.Approved)
                                                         join cmcm in _context.CommonMasterCompanyMapper.Where(c => c.companyId == companyID)
                                                         on cm.commonMasterId equals cmcm.commonMasterID into cmcm
                                                         from cmcm1 in cmcm.DefaultIfEmpty()
                                                         select new OrganisationCommonMasterMapper
                                                         {
                                                             commonMasterName = cm.commonMasterName,
                                                             commonMasterDisplayName = cm.commonMasterDisplayName,
                                                             commonMasterCompanyMapperID = (cmcm1.commonMasterCompanyMapperID == null ? 0 :
                                                                                                   cmcm1.commonMasterCompanyMapperID),
                                                             commonMasterID = cm.commonMasterId,
                                                             companyId = companyID,
                                                             status = (cmcm1.commonMasterCompanyMapperID != null ? (int)cmcm1.status : (int)Statuses.Approved),
                                                             isCompulsory = cm.isCompulsory
                                                         }).ToListAsync();

            _organisation.organisationCommonMaster = OrganisationCommonMasterMappers;

            var OrganisationAdditionalMaster = await _context.AdditionalMasters.Where(c => c.status == (int)Statuses.Approved && c.companyId == companyID).ToListAsync();

            _organisation.organisationAdditionalMaster = OrganisationAdditionalMaster;

            var moduleOrganisationMappers = await (from module in _context.Modules.Where(c => c.isEnabled == true && c.status == (int)Statuses.Approved)
                                                   join parent in _context.Modules.Where(c => c.isEnabled == true && c.status == (int)Statuses.Approved)
                                                   on module.parentID equals parent.moduleId into parent1
                                                   from parent2 in parent1.DefaultIfEmpty()
                                                   join moduleOrgMapper in _context.ModuleOrganisationMappers.Where(m => m.companyId == companyID)
                                                   on module.moduleId equals moduleOrgMapper.moduleId into mm
                                                   from mom in mm.DefaultIfEmpty()
                                                   select new
                                                   {
                                                       moduleID = module.moduleId,
                                                       moduleOrganisationMapperID = (mom.moduleOrgMapperId == null ? 0 : mom.moduleOrgMapperId),
                                                       moduleName = module.moduleName,
                                                       companyID = companyID,
                                                       parentID = parent2.parentID == null ? module.moduleId : parent2.moduleId,
                                                       parentName = parent2.parentID == null ? module.moduleName : parent2.moduleName,
                                                       versionNo = module.versionNo,
                                                       isSelected = (mom.moduleId != null && mom.status == 1 ? true : false),
                                                       isCompulsory = module.isCompulsory

                                                   }).ToListAsync();


            var parentIds = moduleOrganisationMappers.DistinctBy(x => x.parentID).DistinctBy(x => x.parentName).ToList();

            List<ParentModules> parentList = new List<ParentModules>();

            foreach (var parentId in parentIds)
            {
                var modules = (from childs in moduleOrganisationMappers.Where(x => x.parentID == parentId.parentID)
                               select new OrganisationModules
                               {
                                   moduleID = childs.moduleID,
                                   moduleOrganisationMapperID = childs.moduleOrganisationMapperID,
                                   moduleName = childs.moduleName,
                                   companyID = companyID,
                                   parentID = childs.parentID,
                                   parentName = childs.parentName,
                                   versionNo = childs.versionNo,
                                   isSelected = childs.isSelected,
                                   isCompulsory = childs.isCompulsory

                               }).OrderBy(x => x.versionNo).ToList();

                var parent = new ParentModules
                {
                    parentID = parentId.parentID,
                    parentName = parentId.parentName,
                    isCompulsory = parentId.isCompulsory,
                    organisationModules = (List<OrganisationModules>)modules
                  
                };
                parentList.Add(parent);
            }
            _organisation.companyModules = parentList;

            var OrganisationHierarchy = await _context.MastersHierarchy.Where(c => c.status == (int)Statuses.Approved && companyID == c.companyId).ToListAsync();

            _organisation.mastersHierarchy = OrganisationHierarchy;




            var _organisationJson = JsonConvert.SerializeObject(_organisation);
            object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
            return _organisationValue;
        }

        // GET: api/GetCompaniesForUserId/5
        [HttpGet("GetPendingList/{UserId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetPendingList(long UserId)
        {
            //var organisation = await _context.Organisations.FindAsync(id);
            try
            {
                var userData = await _context.EmployeePersonalDetails.Where(user => user.employeePersonalDetailId == UserId).FirstOrDefaultAsync();

                if (userData != null)
                {
                    // For super admin need to show all the pending statuses
                    if (userData.roleId == (int)RoleIds.SuperAdmin)
                    {
                        var _organisation = await (from org in _context.Organisations
                                                   where org.status == (int)Statuses.Pending || org.status == (int)Statuses.Draft
                                                   join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                                   from statusValue in StatusesV.DefaultIfEmpty()
                                                   join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                                   from clientV in Clients.DefaultIfEmpty()
                                                   select new
                                                   {

                                                       org.companyId,
                                                       org.companyName,
                                                       org.clientId,
                                                       clientV.clientName,
                                                       org.status,
                                                       statusValue.statusName,
                                                       org.makerId,
                                                       org.checkerId,
                                                       org.schemaName
                                                   }
                                                   ).ToListAsync();
                        var _clients = await (from client in _context.ClientCreation
                                              where client.status == (int)Statuses.Pending || client.status == (int)Statuses.Draft
                                              join status in _context.Statuses on client.status equals status.statusId into StatusesV
                                              from statusV in StatusesV.DefaultIfEmpty()
                                              select new
                                              {
                                                  client.clientId,
                                                  client.clientName,
                                                  client.status,
                                                  statusV.statusName,
                                                  client.makerId,
                                                  client.checkerId
                                              }
                                              ).ToListAsync();
                        var _masters = await (from master in _context.MasterChangesTrackers
                                              where master.status == (int)Statuses.Pending
                                              join status in _context.Statuses on master.status equals status.statusId into StatusesV
                                              from statusV in StatusesV.DefaultIfEmpty()
                                              join company in _context.Organisations on master.companyId equals company.companyId into CompaniesV
                                              from companyV in CompaniesV.DefaultIfEmpty()
                                              select new
                                              {
                                                  master.masterChangesTrackerId,
                                                  master.companyId,
                                                  master.status,
                                                  statusV.statusName,
                                                  companyV.makerId,
                                                  companyV.checkerId,
                                                  master.masterName,
                                                  companyV.companyName,
                                                  companyV.schemaName
                                              }
                                              ).ToListAsync();
                        var finalList = new List<object>();

                        _organisation.ForEach(org =>
                        {
                            var obj = new
                            {
                                id = org.companyId,
                                dataType = 1,
                                dataTypeName = "CompanyInfo",
                                status = org.statusName,
                                makerId = org.makerId,
                                checkerId = org.checkerId,
                                name = $"{org.companyName} pending for approval",
                                isChecker = true,
                                url = "configClientCompanyCreation.xhtml",
                                schemaName = org.schemaName,
                                serverName = GetServerName(),
                                companyOrClientName = org.companyName
                            };
                            finalList.Add(obj);
                        });

                        _clients.ForEach(client =>
                        {
                            var obj = new
                            {
                                id = client.clientId,
                                dataType = 2,
                                dataTypeName = "ClientInfo",
                                status = client.statusName,
                                makerId = client.makerId,
                                checkerId = client.checkerId,
                                name = $"{client.clientName} pending for approval",
                                isChecker = true,
                                url = "clientSelection.xhtml",
                                schemaName = "",
                                serverName = GetServerName(),
                                companyOrClientName = client.clientName
                            };
                            finalList.Add(obj);
                        });

                        _masters.ForEach(master =>
                        {
                            var obj = new
                            {
                                id = master.masterChangesTrackerId,
                                dataType = 3,
                                dataTypeName = "MasterInfo",
                                status = master.statusName,
                                makerId = master.makerId,
                                checkerId = master.checkerId,
                                name = $"{master.masterName} pending for approval ({master.companyName})",
                                isChecker = true,
                                url = "masterCreation.xhtml",
                                schemaName = master.schemaName,
                                serverName = GetServerName(),
                                companyOrClientName = master.companyName
                            };
                            finalList.Add(obj);
                        });

                        var _organisationJson = JsonConvert.SerializeObject(finalList);
                        object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
                        return _organisationValue;
                    }
                    else
                    {
                        var _organisation = await (from org in _context.Organisations
                                                   where (org.makerId == UserId || org.checkerId == UserId) && (org.status == (int)Statuses.Pending || org.status == (int)Statuses.Draft)
                                                   join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                                   from statusValue in StatusesV.DefaultIfEmpty()
                                                   join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                                   from clientV in Clients.DefaultIfEmpty()
                                                   select new
                                                   {
                                                       org.companyId,
                                                       org.companyName,
                                                       org.clientId,
                                                       clientV.clientName,
                                                       org.status,
                                                       statusValue.statusName,
                                                       org.makerId,
                                                       org.checkerId,
                                                       org.schemaName
                                                   }
                                                       ).ToListAsync();
                        var _clients = await (from client in _context.ClientCreation
                                              where (client.makerId == UserId || client.checkerId == UserId) && (client.status == (int)Statuses.Pending || client.status == (int)Statuses.Draft)
                                              join status in _context.Statuses on client.status equals status.statusId into StatusesV
                                              from statusValue in StatusesV.DefaultIfEmpty()

                                              select new
                                              {
                                                  client.clientId,
                                                  client.clientName,
                                                  client.status,
                                                  statusValue.statusName,
                                                  client.makerId,
                                                  client.checkerId
                                              }
                                                      ).ToListAsync();

                        var companies = await _context.Organisations.Where(company => company.checkerId == UserId).Select(comp => comp.companyId).ToListAsync();


                        var mastersList = await (from master in _context.MasterChangesTrackers
                                                 where master.status == (int)Statuses.Pending
                                                 join status in _context.Statuses on master.status equals status.statusId into Statuses
                                                 from statusV in Statuses.DefaultIfEmpty()
                                                 join company in _context.Organisations on master.companyId equals company.companyId into Companies
                                                 from companyV in Companies.DefaultIfEmpty()
                                                 select new
                                                 {
                                                     master.masterChangesTrackerId,
                                                     master.companyId,
                                                     companyV.companyName,
                                                     companyV.makerId,
                                                     companyV.checkerId,
                                                     master.status,
                                                     statusV.statusName,
                                                     master.updatedBy,
                                                     master.createdBy,
                                                     master.updatedDate,
                                                     master.createdDate,
                                                     master.masterName,
                                                     companyV.schemaName
                                                 }
                                                 ).ToListAsync();

                        var finalList = new List<object>();

                        _organisation.ForEach(org =>
                        {

                            var obj = new
                            {
                                id = org.companyId,
                                dataType = 1,
                                dataTypeName = "CompanyInfo",
                                status = org.statusName,
                                makerId = org.makerId,
                                checkerId = org.checkerId,
                                name = $"{org.companyName}",
                                isChecker = org.checkerId == UserId ? true : false,
                                url = "configClientCompanyCreation.xhtml",
                                schemaName = org.schemaName,
                                serverName = GetServerName(),
                                companyOrClientName = org.companyName
                            };
                            finalList.Add(obj);
                        });

                        _clients.ForEach(client =>
                        {
                            var obj = new
                            {
                                id = client.clientId,
                                dataType = 2,
                                dataTypeName = "ClientInfo",
                                status = client.statusName,
                                makerId = client.makerId,
                                checkerId = client.checkerId,
                                name = $"{client.clientName}",
                                isChecker = client.checkerId == UserId ? true : false,
                                url = "clientSelection.xhtml",
                                schemaName = "",
                                serverName = GetServerName(),
                                companyOrClientName = client.clientName
                            };
                            finalList.Add(obj);
                        });

                        mastersList.ForEach(master =>
                        {
                            if (master.companyId != null && companies.IndexOf((long)master.companyId) > -1)
                            {
                                var obj = new
                                {
                                    id = master.masterChangesTrackerId,
                                    dataType = 3,
                                    dataTypeName = "MasterInfo",
                                    status = master.statusName,
                                    makerId = master.makerId,
                                    checkerId = master.checkerId,
                                    isChecker = master.checkerId == UserId ? true : false,
                                    name = $"{master.masterName} pending for approval ({master.companyName})",
                                    url = "masterCreation.xhtml",
                                    schemaName = master.schemaName,
                                    serverName = GetServerName(),
                                    companyOrClientName = master.companyName
                                };
                                finalList.Add(obj);
                            }

                        });

                        var _organisationJson = JsonConvert.SerializeObject(finalList);
                        object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
                        return _organisationValue;
                    }
                }

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return new List<object>();
        }

        //[HttpGet("GetConsolidatedPendingList/{UserId}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<ActionResult<object>> GetConsolidatedPendingList(long UserId)
        //{
        //    //var organisation = await _context.Organisations.FindAsync(id);
        //    try
        //    {
        //        var userData = await _context.EmployeePersonalDetails.Where(user => user.employeePersonalDetailId == UserId).FirstOrDefaultAsync();

        //        if (userData != null)
        //        {
        //            // For super admin need to show all the pending statuses
        //            if (userData.roleId == (int)RoleIds.SuperAdmin)
        //            {
        //                var _organisation = await (from org in _context.Organisations
        //                                           where org.status == (int)Statuses.Pending || org.status == (int)Statuses.Draft   //&& org.isOwnerCompany != true
        //                                           join status in _context.Statuses on org.status equals status.statusId into StatusesV
        //                                           from statusValue in StatusesV.DefaultIfEmpty()
        //                                           join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
        //                                           from clientV in Clients.DefaultIfEmpty()
        //                                           where org.isOwnerCompany != true && clientV.isOwnerClient != true
        //                                           select new
        //                                           {
        //                                               org.companyId,
        //                                               org.companyName,
        //                                               org.clientId,
        //                                               clientV.clientName,
        //                                               org.status,
        //                                               statusValue.statusName,
        //                                               org.makerId,
        //                                               org.checkerId,
        //                                               org.schemaName
        //                                           }
        //                                           ).ToListAsync();
        //                var _clients = await (from client in _context.ClientCreation
        //                                      where client.status == (int)Statuses.Pending || client.status == (int)Statuses.Draft && client.isOwnerClient != true
        //                                      join status in _context.Statuses on client.status equals status.statusId into StatusesV
        //                                      from statusV in StatusesV.DefaultIfEmpty()
        //                                      join org in _context.Organisations on client.clientId equals org.clientId into Organisations
        //                                      from organizationv in Organisations.DefaultIfEmpty()
        //                                      where organizationv.isOwnerCompany != true && client.isOwnerClient != true
        //                                      select new
        //                                      {
        //                                          client.clientId,
        //                                          client.clientName,
        //                                          client.status,
        //                                          statusV.statusName,
        //                                          client.makerId,
        //                                          client.checkerId
        //                                      }
        //                                      ).ToListAsync();
        //                var _masters = await (from master in _context.MasterChangesTrackers
        //                                      where master.status == (int)Statuses.Pending
        //                                      join status in _context.Statuses on master.status equals status.statusId into StatusesV
        //                                      from statusV in StatusesV.DefaultIfEmpty()
        //                                      join company in _context.Organisations on master.companyId equals company.companyId into CompaniesV
        //                                      from companyV in CompaniesV.DefaultIfEmpty()
        //                                      select new
        //                                      {
        //                                          master.masterChangesTrackerId,
        //                                          master.companyId,
        //                                          master.status,
        //                                          statusV.statusName,
        //                                          companyV.makerId,
        //                                          companyV.checkerId,
        //                                          master.masterName,
        //                                          companyV.companyName,
        //                                          companyV.schemaName,
        //                                          master.isOrderChange
        //                                      }
        //                                      ).ToListAsync();
        //                var finalList = new List<object>();

        //                _organisation.ForEach(org =>
        //                {
        //                    var obj = new
        //                    {
        //                        id = org.companyId,
        //                        dataType = 1,
        //                        dataTypeName = "CompanyInfo",
        //                        status = org.statusName,
        //                        makerId = org.makerId,
        //                        checkerId = org.checkerId,
        //                        name = $"{org.companyName} pending for approval",
        //                        isChecker = true,
        //                        url = "configClientCompanyCreation.xhtml",
        //                        schemaName = org.schemaName,
        //                        serverName = GetServerName(),
        //                        companyOrClientName = org.companyName
        //                    };
        //                    finalList.Add(obj);
        //                });

        //                _clients.ForEach(client =>
        //                {
        //                    var obj = new
        //                    {
        //                        id = client.clientId,
        //                        dataType = 2,
        //                        dataTypeName = "ClientInfo",
        //                        status = client.statusName,
        //                        makerId = client.makerId,
        //                        checkerId = client.checkerId,
        //                        name = $"{client.clientName} pending for approval",
        //                        isChecker = true,
        //                        url = "clientSelection.xhtml",
        //                        schemaName = "",
        //                        serverName = GetServerName(),
        //                        companyOrClientName = client.clientName
        //                    };
        //                    finalList.Add(obj);
        //                });

        //                _masters.ForEach(master =>
        //                {
        //                    var obj = new
        //                    {
        //                        id = master.masterChangesTrackerId,
        //                        dataType = 3,
        //                        dataTypeName = "MasterInfo",
        //                        status = master.statusName,
        //                        makerId = master.makerId,
        //                        checkerId = master.checkerId,
        //                        name = $"{master.masterName} pending for approval ({master.companyName})",
        //                        isChecker = true,
        //                        url = "masterCreation.xhtml",
        //                        schemaName = master.schemaName,
        //                        serverName = GetServerName(),
        //                        companyOrClientName = master.companyName,
        //                        isOrderChange = master.isOrderChange
        //                    };
        //                    finalList.Add(obj);
        //                });

        //                var _organisationJson = JsonConvert.SerializeObject(finalList);
        //                object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
        //                return _organisationValue;
        //            }
        //            else
        //            {
        //                var _organisation = await (from org in _context.Organisations
        //                                           where (org.makerId == UserId || org.checkerId == UserId) && (org.status == (int)Statuses.Pending || org.status == (int)Statuses.Draft)
        //                                           join status in _context.Statuses on org.status equals status.statusId into StatusesV
        //                                           from statusValue in StatusesV.DefaultIfEmpty()
        //                                           join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
        //                                           from clientV in Clients.DefaultIfEmpty()
        //                                           select new
        //                                           {
        //                                               org.companyId,
        //                                               org.companyName,
        //                                               org.clientId,
        //                                               clientV.clientName,
        //                                               org.status,
        //                                               statusValue.statusName,
        //                                               org.makerId,
        //                                               org.checkerId,
        //                                               org.schemaName
        //                                           }
        //                                               ).ToListAsync();
        //                var _clients = await (from client in _context.ClientCreation
        //                                      where (client.makerId == UserId || client.checkerId == UserId) && (client.status == (int)Statuses.Pending || client.status == (int)Statuses.Draft)
        //                                      join status in _context.Statuses on client.status equals status.statusId into StatusesV
        //                                      from statusValue in StatusesV.DefaultIfEmpty()

        //                                      select new
        //                                      {
        //                                          client.clientId,
        //                                          client.clientName,
        //                                          client.status,
        //                                          statusValue.statusName,
        //                                          client.makerId,
        //                                          client.checkerId
        //                                      }
        //                                              ).ToListAsync();

        //                var companies = await _context.Organisations.Where(company => company.checkerId == UserId || company.makerId == UserId).Select(comp => comp.companyId).ToListAsync();


        //                var mastersList = await (from master in _context.MasterChangesTrackers
        //                                         where master.status == (int)Statuses.Pending
        //                                         join status in _context.Statuses on master.status equals status.statusId into Statuses
        //                                         from statusV in Statuses.DefaultIfEmpty()
        //                                         join company in _context.Organisations on master.companyId equals company.companyId into Companies
        //                                         from companyV in Companies.DefaultIfEmpty()
        //                                         select new
        //                                         {
        //                                             master.masterChangesTrackerId,
        //                                             master.companyId,
        //                                             companyV.companyName,
        //                                             companyV.makerId,
        //                                             companyV.checkerId,
        //                                             master.status,
        //                                             statusV.statusName,
        //                                             master.updatedBy,
        //                                             master.createdBy,
        //                                             master.updatedDate,
        //                                             master.createdDate,
        //                                             master.masterName,
        //                                             companyV.schemaName,
        //                                             master.isOrderChange
        //                                         }
        //                                         ).ToListAsync();

        //                //var finalList = new List<object>();
        //                var makersList = new List<object>();
        //                var checkersList = new List<object>();

        //                _organisation.ForEach(org =>
        //                {

        //                    var obj = new
        //                    {
        //                        id = org.companyId,
        //                        dataType = 1,
        //                        dataTypeName = "CompanyInfo",
        //                        status = org.statusName,
        //                        makerId = org.makerId,
        //                        checkerId = org.checkerId,
        //                        name = $"{org.companyName}",
        //                        isChecker = org.checkerId == UserId ? true : false,
        //                        url = "configClientCompanyCreation.xhtml",
        //                        schemaName = org.schemaName,
        //                        serverName = GetServerName(),
        //                        companyOrClientName = org.companyName
        //                    };
        //                    if (org.makerId == UserId)
        //                    {
        //                        makersList.Add(obj);
        //                    }
        //                    if (org.checkerId == UserId)
        //                    {
        //                        checkersList.Add(obj);
        //                    }
        //                });

        //                _clients.ForEach(client =>
        //                {
        //                    var obj = new
        //                    {
        //                        id = client.clientId,
        //                        dataType = 2,
        //                        dataTypeName = "ClientInfo",
        //                        status = client.statusName,
        //                        makerId = client.makerId,
        //                        checkerId = client.checkerId,
        //                        name = $"{client.clientName}",
        //                        isChecker = client.checkerId == UserId ? true : false,
        //                        url = "clientSelection.xhtml",
        //                        schemaName = "",
        //                        serverName = GetServerName(),
        //                        companyOrClientName = client.clientName
        //                    };
        //                    if (client.makerId == UserId)
        //                    {
        //                        makersList.Add(obj);
        //                    }
        //                    if (client.checkerId == UserId)
        //                    {
        //                        checkersList.Add(obj);
        //                    }
        //                });

        //                mastersList.ForEach(master =>
        //                {
        //                    if (master.companyId != null && companies.IndexOf((long)master.companyId) > -1)
        //                    {
        //                        var obj = new
        //                        {
        //                            id = master.masterChangesTrackerId,
        //                            dataType = 3,
        //                            dataTypeName = "MasterInfo",
        //                            status = master.statusName,
        //                            makerId = master.makerId,
        //                            checkerId = master.checkerId,
        //                            isChecker = master.checkerId == UserId ? true : false,
        //                            name = $"{master.masterName} pending for approval ({master.companyName})",
        //                            url = "masterCreation.xhtml",
        //                            schemaName = master.schemaName,
        //                            serverName = GetServerName(),
        //                            companyOrClientName = master.companyName,
        //                            ssOrderChange = master.isOrderChange
        //                        };
        //                        if (master.makerId == UserId)
        //                        {
        //                            makersList.Add(obj);
        //                        }
        //                        if (master.checkerId == UserId)
        //                        {
        //                            checkersList.Add(obj);
        //                        }
        //                    }

        //                });

        //                var _organisationJson = JsonConvert.SerializeObject(new { MakersPendingList = makersList, CheckersPendingList = checkersList });
        //                object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
        //                return _organisationValue;
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return Conflict(new { message = $"Error: {ex.Message}" });
        //    }
        //    return new List<object>();
        //}

        [HttpGet("GetConsolidatedPendingList/{UserId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetConsolidatedPendingList(long UserId)
        {
            try
            {
                var userData = await _context.EmployeePersonalDetails.Where(user => user.employeePersonalDetailId == UserId).FirstOrDefaultAsync();
                if (userData != null)
                {
                    if (userData.roleId == (int)RoleIds.SuperAdmin)
                    {
                        var _organisation = await (from org in _context.Organisations
                                                   where org.status != (int)Statuses.Deleted //|| org.status == (int)Statuses.Draft //&& org.isOwnerCompany != true
                                                   join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                                   from statusValue in StatusesV.DefaultIfEmpty()
                                                   join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                                   from clientV in Clients.DefaultIfEmpty()
                                                   where org.isOwnerCompany != true && clientV.isOwnerClient != true
                                                   select new
                                                   {
                                                       org.companyId,
                                                       org.companyName,
                                                       org.clientId,
                                                       clientV.clientName,
                                                       org.status,
                                                       statusValue.statusName,
                                                       org.makerId,
                                                       org.checkerId,
                                                       org.schemaName,
                                                       status1 = clientV.status
                                                   }
                                                   ).ToListAsync();
                        var _clients = await (from client in _context.ClientCreation
                                              where client.status != (int)Statuses.Deleted //|| client.status == (int)Statuses.Draft && client.isOwnerClient != true
                                              join status in _context.Statuses on client.status equals status.statusId into StatusesV
                                              from statusV in StatusesV.DefaultIfEmpty()
                                              join org in _context.Organisations on client.clientId equals org.clientId into Organisations
                                              from organizationv in Organisations.DefaultIfEmpty()
                                              where organizationv.isOwnerCompany != true && client.isOwnerClient != true
                                              select new
                                              {
                                                  client.clientId,
                                                  client.clientName,
                                                  client.status,
                                                  statusV.statusName,
                                                  client.makerId,
                                                  client.checkerId
                                              }
                                              ).Distinct().ToListAsync();
                        var _masters = await (from master in _context.MasterChangesTrackers
                                              where master.status == (int)Statuses.Pending
                                              join status in _context.Statuses on master.status equals status.statusId into StatusesV
                                              from statusV in StatusesV.DefaultIfEmpty()
                                              join company in _context.Organisations on master.companyId equals company.companyId into CompaniesV
                                              from companyV in CompaniesV.DefaultIfEmpty()
                                              select new
                                              {
                                                  master.masterChangesTrackerId,
                                                  master.companyId,
                                                  master.status,
                                                  statusV.statusName,
                                                  companyV.makerId,
                                                  companyV.checkerId,
                                                  master.masterName,
                                                  companyV.companyName,
                                                  companyV.schemaName,
                                                  master.isOrderChange
                                              }
                                              ).ToListAsync();
                        var finalList = new List<object>();

                        _organisation.ForEach(org =>
                        {
                            var obj = new
                            {
                                id = org.companyId,
                                dataType = 1,
                                dataTypeName = "CompanyInfo",
                                status = org.statusName,
                                makerId = org.makerId,
                                checkerId = org.checkerId,
                                name = $"{org.companyName} pending for approval",
                                isChecker = true,
                                url = "configClientCompanyCreation.xhtml",
                                schemaName = org.schemaName,
                                serverName = GetServerName(),
                                companyOrClientName = org.companyName,
                                isClientApproved = org.status1 == (int)Statuses.Approved ? 1 : 0,
                            };
                            finalList.Add(obj);
                        });

                        _clients.ForEach(client =>
                        {
                            var obj = new
                            {
                                id = client.clientId,
                                dataType = 2,
                                dataTypeName = "ClientInfo",
                                status = client.statusName,
                                makerId = client.makerId,
                                checkerId = client.checkerId,
                                name = $"{client.clientName} pending for approval",
                                isChecker = true,
                                url = "clientSelection.xhtml",
                                schemaName = "",
                                serverName = GetServerName(),
                                companyOrClientName = client.clientName,
                                isClientApproved = client.status == (int)Statuses.Approved ? 1 : 0,
                            };
                            finalList.Add(obj);
                        });

                        _masters.ForEach(master =>
                        {
                            var obj = new
                            {
                                id = master.masterChangesTrackerId,
                                dataType = 3,
                                dataTypeName = "MasterInfo",
                                status = master.statusName,
                                makerId = master.makerId,
                                checkerId = master.checkerId,
                                name = $"{master.masterName} pending for approval ({master.companyName})",
                                isChecker = true,
                                url = "masterCreation.xhtml",
                                schemaName = master.schemaName,
                                serverName = GetServerName(),
                                companyOrClientName = master.companyName,
                                isOrderChange = master.isOrderChange
                            };
                            finalList.Add(obj);
                        });

                        var _organisationJson = JsonConvert.SerializeObject(finalList);
                        object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
                        return _organisationValue;
                    }
                    else
                    {
                        var _organization = await (from company in _context.CompanyUserRoleMappers
                                                   where company.employeeId == UserId
                                                   join org in _context.Organisations on company.companyId equals org.companyId into organization
                                                   from orgV in organization.DefaultIfEmpty()
                                                   where orgV.status != (int)Statuses.Deleted && orgV.isOwnerCompany != true
                                                   //where orgV.status == (int)Statuses.Pending || orgV.status == (int)Statuses.Draft || orgV.status == (int)Statuses.Rejected
                                                   join status in _context.Statuses on orgV.status equals status.statusId into StatusesV
                                                   from statusValue in StatusesV.DefaultIfEmpty()
                                                   join client1 in _context.ClientCreation on orgV.clientId equals client1.clientId into clients1
                                                   from clientV1 in clients1.DefaultIfEmpty()
                                                   select new
                                                   {
                                                       orgV.companyId,
                                                       orgV.companyName,
                                                       orgV.clientId,
                                                       //clientV.clientName,
                                                       orgV.status,
                                                       statusValue.statusName,
                                                       //orgV.checkerId,
                                                       orgV.schemaName,
                                                       status1 = clientV1.status
                                                   }).ToListAsync();

                        var _clients = await (from CR in _context.ClientUserRoleMappers
                                              where CR.employeeId == UserId
                                              join client in _context.ClientCreation on CR.clientId equals client.clientId into clients
                                              from clientV in clients.DefaultIfEmpty()
                                              where clientV.status != (int)Statuses.Deleted && clientV.isOwnerClient != true
                                              //where clientV.status == (int)Statuses.Pending || clientV.status == (int)Statuses.Draft || clientV.status == (int)Statuses.Rejected
                                              join status in _context.Statuses on clientV.status equals status.statusId into StatusesV
                                              from statusValue in StatusesV.DefaultIfEmpty()
                                              select new
                                              {
                                                  clientV.clientId,
                                                  clientV.clientName,
                                                  clientV.status,
                                                  statusValue.statusName,
                                                  clientV.makerId,
                                                  clientV.checkerId
                                              }).ToListAsync();

                        var _masters = await (from master in _context.MasterChangesTrackers
                                              where master.status == (int)Statuses.Pending
                                              join status in _context.Statuses on master.status equals status.statusId into StatusesV
                                              from statusV in StatusesV.DefaultIfEmpty()
                                              join company in _context.Organisations on master.companyId equals company.companyId into CompaniesV
                                              from companyV in CompaniesV.DefaultIfEmpty()
                                              select new
                                              {
                                                  master.masterChangesTrackerId,
                                                  master.companyId,
                                                  master.status,
                                                  statusV.statusName,
                                                  companyV.makerId,
                                                  companyV.checkerId,
                                                  master.masterName,
                                                  companyV.companyName,
                                                  companyV.schemaName,
                                                  master.isOrderChange
                                              }
                                              ).ToListAsync();

                        var finalList = new List<object>();


                        var userMappedCompanies = await _context.CompanyUserRoleMappers.Where(c => c.employeeId == UserId).ToListAsync(); //added now 
                        List<object> companyWithPermissions = new List<object>();                                                         //added 

                        _organization.ForEach(org =>
                        {
                            //added now
                            var isMapped = userMappedCompanies.Where(c => c.companyId == org.companyId).FirstOrDefault();
                            if (isMapped != null)
                            {
                                var screenPermissions = (from sp in _context.ScreenPermissions
                                                         where sp.roleId == isMapped.roleId && sp.status == (int)Statuses.Approved
                                                         join screen in _context.Screens on sp.screenId equals screen.screenId into Screens
                                                         from screenV in Screens.DefaultIfEmpty()
                                                         select new
                                                         {
                                                             sp.roleId,
                                                             sp.read,
                                                             sp.approve,
                                                             sp.create,
                                                             sp.update,
                                                             sp.delete,
                                                             screenV.screenName,
                                                             sp.screenId
                                                         }
                                                               ).ToList();

                                var cInfo = screenPermissions.Where(s => s.screenName.ToLower().Trim() == "company information").FirstOrDefault();
                                object permissionObj = new { };
                                if (cInfo != null)
                                {
                                    permissionObj = new { cInfo.create, cInfo.read, cInfo.update, cInfo.delete, cInfo.approve };

                                }
                                else { permissionObj = new { create = false, read = false, update = false, delete = false, approve = false }; }

                                //till here

                                var obj = new
                                {
                                    id = org.companyId,
                                    dataType = 1,
                                    dataTypeName = "CompanyInfo",
                                    status = org.statusName,
                                    // makerId = org.makerId,
                                    //checkerId = org.checkerId,
                                    name = $"{org.companyName} pending for approval",
                                    isChecker = true,
                                    url = "configClientCompanyCreation.xhtml",
                                    schemaName = org.schemaName,
                                    serverName = GetServerName(),
                                    companyOrClientName = org.companyName,
                                    employeePermission = permissionObj,   // added now
                                    isClientApproved = org.status1 == (int)Statuses.Approved ? 1 : 0,
                                };
                                finalList.Add(obj);
                            }
                        });

                        var userMappedClients = await _context.ClientUserRoleMappers.Where(c => c.employeeId == UserId).ToListAsync();  //added now
                        List<object> clientWithPermissions = new List<object>();                                                       //added now
                        _clients.ForEach(client =>
                        {
                            //added now 
                            var isMapped = userMappedClients.Where(c => c.clientId == client.clientId).FirstOrDefault();

                            if (isMapped != null)
                            {
                                var screenPermissions = (from sp in _context.ScreenPermissions
                                                         where sp.roleId == isMapped.roleId && sp.status == (int)Statuses.Approved
                                                         join screen in _context.Screens on sp.screenId equals screen.screenId into Screens
                                                         from screenV in Screens.DefaultIfEmpty()
                                                         select new
                                                         {
                                                             sp.roleId,
                                                             sp.read,
                                                             sp.approve,
                                                             sp.create,
                                                             sp.update,
                                                             sp.delete,
                                                             screenV.screenName,
                                                             sp.screenId
                                                         }
                                                               ).ToList();

                                var cInfo = screenPermissions.Where(s => s.screenName.ToLower().Trim() == "client information").FirstOrDefault();
                                object permissionObj = new { };
                                if (cInfo != null)
                                {
                                    permissionObj = new { cInfo.create, cInfo.read, cInfo.update, cInfo.delete, cInfo.approve };

                                }
                                else { permissionObj = new { create = false, read = false, update = false, delete = false, approve = false }; }

                                var obj = new
                                {
                                    id = client.clientId,
                                    dataType = 2,
                                    dataTypeName = "ClientInfo",
                                    status = client.statusName,
                                    //makerId = client.makerId,
                                    //checkerId = client.checkerId,
                                    name = $"{client.clientName} pending for approval",
                                    isChecker = true,
                                    url = "clientSelection.xhtml",
                                    schemaName = "",
                                    serverName = GetServerName(),
                                    companyOrClientName = client.clientName,
                                    employeePermission = permissionObj,
                                    isClientApproved = client.status == (int)Statuses.Approved ? 1 : 0,
                                };
                                finalList.Add(obj);
                            }
                        });

                        _masters.ForEach(master =>
                        {
                            var obj = new
                            {
                                id = master.masterChangesTrackerId,
                                dataType = 3,
                                dataTypeName = "MasterInfo",
                                status = master.statusName,
                                makerId = master.makerId,
                                checkerId = master.checkerId,
                                name = $"{master.masterName} pending for approval ({master.companyName})",
                                isChecker = true,
                                url = "masterCreation.xhtml",
                                schemaName = master.schemaName,
                                serverName = GetServerName(),
                                companyOrClientName = master.companyName,
                                isOrderChange = master.isOrderChange
                            };
                            finalList.Add(obj);
                        });

                        var _organisationJson = JsonConvert.SerializeObject(finalList);
                        object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
                        return _organisationValue;
                    }
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return new List<object>();
        }

        // GET: api/Organisations/5
        [HttpGet("GetCompaniesForClientId/{ClientId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetCompaniesForClientId(long ClientId)
        {
            //var organisation = await _context.Organisations.FindAsync(id);
            var _organisation = await (from org in _context.Organisations
                                       where org.clientId == ClientId
                                       join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                       from statusValue in StatusesV.DefaultIfEmpty()
                                       join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                       from clientV in Clients.DefaultIfEmpty()
                                       join clientOrg in _context.ClientOrganisationMappers on org.clientId equals clientOrg.clientId into ClientsOrg
                                       from clientOrgV in ClientsOrg.DefaultIfEmpty()
                                       select new
                                       {
                                           companyId = org.companyId,
                                           companyName = org.companyName,
                                           clientId = org.clientId,
                                           clientV.clientName,
                                           org.status,
                                           statusValue.statusName,
                                           org.panNo,
                                           org.tanNo,
                                           org.pfReg,
                                           org.esiReg,
                                           org.createdBy,
                                           org.createdTime,
                                           org.updatedBy,
                                           org.updatedDate,
                                           org.companyLogo,
                                           org.schemaName,
                                           org.passwordExpiry,
                                           org.companyAddress1,
                                           org.companyAddress2,
                                           org.companyAddress3
                                       }
                                           ).ToListAsync();
            _organisation = _organisation.DistinctBy(company => company.companyId).ToList();
            var clientOrgs = await _context.ClientOrganisationMappers.Where(clientOrg => clientOrg.clientId == ClientId).ToListAsync();
            List<object> filteredValue = new List<object>();
            // Filter and push only the matched records.
            _organisation.ForEach(org =>
            {
                var index = clientOrgs.FindIndex(clientOrg => clientOrg.clientId == ClientId && clientOrg.companyId == org.companyId);
                if (index > -1)
                {
                    filteredValue.Add(new
                    {
                        org.companyId,
                        org.companyName,
                        org.clientId,
                        org.clientName,
                        org.status,
                        org.statusName,
                        org.panNo,
                        org.tanNo,
                        org.pfReg,
                        org.esiReg,
                        org.createdBy,
                        org.createdTime,
                        org.updatedBy,
                        org.updatedDate,
                        org.companyLogo,
                        org.schemaName,
                        isMapped = true,
                        org.passwordExpiry,
                        org.companyAddress1,
                        org.companyAddress2,
                        org.companyAddress3
                    });
                }
                else
                {
                    filteredValue.Add(new
                    {
                        org.companyId,
                        org.companyName,
                        org.clientId,
                        org.clientName,
                        org.status,
                        org.statusName,
                        org.panNo,
                        org.tanNo,
                        org.pfReg,
                        org.esiReg,
                        org.createdBy,
                        org.createdTime,
                        org.updatedBy,
                        org.updatedDate,
                        org.companyLogo,
                        org.schemaName,
                        isMapped = false,
                        org.passwordExpiry,
                        org.companyAddress1,
                        org.companyAddress2,
                        org.companyAddress3

                    });
                }
            });
            if (_organisation == null)
            {
                return NotFound();
            }

            var _organisationJson = JsonConvert.SerializeObject(filteredValue);
            object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
            return _organisationValue;
        }

        // GET: api/Organisations/5
        [HttpGet("GetCompayIdForCompanyName/{CompanyName}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<int>> GetCompayIdForCompanyName(string CompanyName)
        {
            //var organisation = await _context.Organisations.FindAsync(id);
            var companyId = await _context.Organisations.Where(org => org.companyName.ToLower().Trim() == CompanyName.ToLower().Trim()).FirstOrDefaultAsync();
            return companyId != null ? (int)companyId.companyId : 0;
        }

        // GET: api/Organisations/5
        [HttpGet("GetRelatedCompaniesForCompanyId/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetRelatedCompaniesForCompanyId(long CompanyId)
        {
            //var organisation = await _context.Organisations.FindAsync(id);
            var company = await _context.Organisations.Where(org => org.companyId == CompanyId).FirstOrDefaultAsync();

            var _organisation = await (from org in _context.Organisations
                                       where org.clientId == company.clientId && org.status == (int)Statuses.Approved
                                       join status in _context.Statuses on org.status equals status.statusId into StatusesV
                                       from statusValue in StatusesV.DefaultIfEmpty()
                                       join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                       from clientV in Clients.DefaultIfEmpty()

                                       select new
                                       {
                                           companyId = org.companyId,
                                           companyName = org.companyName,
                                           clientId = org.clientId,
                                           clientV.clientName,
                                           org.status,
                                           statusValue.statusName,
                                           org.panNo,
                                           org.tanNo,
                                           org.pfReg,
                                           org.esiReg,
                                           org.createdBy,
                                           org.createdTime,
                                           org.updatedBy,
                                           org.updatedDate,
                                           org.companyLogo,
                                           org.schemaName,
                                           org.passwordExpiry,
                                           org.companyAddress1,
                                           org.companyAddress2,
                                           org.companyAddress3
                                       }
                                           ).ToListAsync();
            _organisation = _organisation.DistinctBy(company => company.companyId).ToList();

            if (_organisation == null)
            {
                return NotFound();
            }

            var _organisationJson = JsonConvert.SerializeObject(_organisation);
            object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
            return _organisationValue;
        }

        // PUT: api/Organisations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutOrganisation(long id, Organisation organisation)
        {
            //if (id != organisation.Id)
            //{
            //    return BadRequest();
            //}
            if (!Helper.OrganisationIdExists(id))
            {
                return NotFound();
            }
            organisation.updatedDate = DateTime.UtcNow;
            organisation.companyId = id;
            if (organisation.isSms == true || organisation.isEmail == true)
            {
                organisation.isSms = organisation.isSms;
                organisation.isEmail = organisation.isEmail;
                _context.Entry(organisation).State = EntityState.Modified;
            }
            else
            {
                return Conflict(new { message = "Email or SMS needed" });
            }

            try
            {

                if (organisation.schemaName == "")
                {
                    organisation.schemaName = Regex.Replace(organisation.companyName.ToLower(), @"\s+", "_");
                }
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Helper.OrganisationIdExists(id))
                {
                    return NotFound();
                }

                else
                {
                    throw;
                }
            }
            catch (DbUpdateException ex)
            {
                //if (OrganisationNameExists(organisation.CompanyName))
                //{
                //    return Conflict(new { message = $"A company with the name '{organisation.CompanyName}' was already found." });
                //}
                //else
                //{
                //    throw;
                //}
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            //return Ok(organisation);
            return new { message = "Record updated successfully !!!" };
            //return NoContent();
        }

        // PUT: api/Organisations/ChangeOrganisationStatus/5/1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ReadData/{SchemaName}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> ReadData(string SchemaName)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                   .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                   .AddJsonFile("appsettings.json")
                   .Build();
            string connStr = configuration.GetConnectionString("TMI_Connection");
            _logger.LogInformation("############## Before connection ####################");
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                conn.Open();
                string sql = "SELECT * FROM employee_personal_details";
                using var cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                var dataTable = new DataTable();
                dataTable.Load(rdr);
                string JSONString = string.Empty;
                JSONString = JsonConvert.SerializeObject(dataTable);
                var obj = System.Text.Json.JsonSerializer.Deserialize<object>(JSONString);
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            finally
            {
                conn.Close();
            }
            return new { };
        }

        // PUT: api/Organisations/ChangeOrganisationStatus/5/1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeOrganisationStatus/{CompanyId}/{Status}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> ChangeOrganisationStatus(long CompanyId, int Status, string RejectionReason)
        {
            //if (id != organisation.Id)
            //{
            //    return BadRequest();
            //}
            if (Status == (int)Statuses.Rejected && (RejectionReason == null || RejectionReason == ""))
            {
                return Conflict(new { message = "Reason for rejection Mandatory." });
            }
            _logger.LogInformation("############## ChangeOrganisationStatus execution Started ####################");
            if (!Helper.OrganisationIdExists(CompanyId))
            {
                return NotFound();
            }
            var organisation = await _context.Organisations.Where(org => org.companyId == CompanyId).FirstOrDefaultAsync();
            organisation.updatedDate = DateTime.UtcNow;
            organisation.companyId = CompanyId;

            try
            {
                if (organisation.status == (int)Statuses.Pending && Status == (int)Statuses.Approved)
                {
                    if (organisation.clientId == null)
                    {
                        return Conflict(new { message = "Company is not assigned to any client !!!" });
                    }
                    var client = await _context.ClientCreation.Where(client => client.clientId == organisation.clientId).FirstOrDefaultAsync();

                    // If client is not approved through error !!!
                    if (client == null || (client != null && client.status != (int)Statuses.Approved))
                    {
                        return Conflict(new { message = "Client details is not approved yet !!!" });
                    }

                    var schemaName = client.clientName;

                    schemaName = $"{Regex.Replace(schemaName.ToLower(), @"\s+", "_")}";
                    organisation.schemaName = schemaName;
                    organisation.status = (int)Statuses.Approved;
                    _context.Entry(organisation).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                    // Insert company data in the Client Schema
                    IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json")
                .Build();
                    string connStr = configuration.GetConnectionString("CompayCreationConnnection");

                    MySqlConnection conn = new MySqlConnection(connStr);
                    conn.Open();
                    string sql = $"use `{schemaName}`;";
                    MySqlScript script = new MySqlScript(conn);
                    script.Query = sql;
                    int count = script.Execute();
                    // Inserting company data and default masters
                    sql = $"INSERT INTO `company_detail_master` (`COMPANY_SEQ_ID`, `int_client_id`) VALUES ('{organisation.companyId}', '{organisation.clientId}');";
                    sql += $"INSERT INTO `master` (`NAME`, `DISPLAY_NAME`, `PARENT_ID`, `STATUS`, `ORDER_NO`, `NOTIFICATION_ID`, `APPROVED_ORDER_NO`,`INT_COMPANY_ID`) VALUES ('Department', 'Department', '0', '1', '1', '0', '1','{organisation.companyId}');";
                    sql += $"INSERT INTO `master` (`NAME`, `DISPLAY_NAME`, `PARENT_ID`, `STATUS`, `ORDER_NO`, `NOTIFICATION_ID`, `APPROVED_ORDER_NO`,`INT_COMPANY_ID`) VALUES ('Designation', 'Designation', '0', '1', '2', '0', '2','{organisation.companyId}');";
                    sql += $"INSERT INTO `master` (`NAME`, `DISPLAY_NAME`, `PARENT_ID`, `STATUS`, `ORDER_NO`, `NOTIFICATION_ID`, `APPROVED_ORDER_NO`,`INT_COMPANY_ID`) VALUES ('Category', 'Category', '0', '1', '3', '0', '3','{organisation.companyId}');";
                    sql += $"INSERT INTO `master` (`NAME`, `DISPLAY_NAME`, `PARENT_ID`, `STATUS`, `ORDER_NO`, `NOTIFICATION_ID`, `APPROVED_ORDER_NO`,`INT_COMPANY_ID`) VALUES ('Grade', 'Grade', '0', '1', '4', '0', '4','{organisation.companyId}');";
                    sql += $"INSERT INTO `master` (`NAME`, `DISPLAY_NAME`, `PARENT_ID`, `STATUS`, `ORDER_NO`, `NOTIFICATION_ID`, `APPROVED_ORDER_NO`,`INT_COMPANY_ID`) VALUES ('Cost Center', 'Cost Center', '0', '1', '5', '0', '5','{organisation.companyId}');";
                    script.Query = sql;
                    script.Execute();
                    script.Delimiter = ";";
                    conn.Close();
                }
                else
                {
                    organisation.status = Status;
                    if (Status == (int)Statuses.Rejected)
                    {
                        organisation.rejectionReason = RejectionReason;
                    }
                }
                // Change status for company Admin
                var pendingAdminUser = await _context.EmployeePersonalDetails.Where(emp => emp.isCompanyAdmin == true && emp.companyId == CompanyId).FirstOrDefaultAsync();
                if (pendingAdminUser != null)
                {
                    pendingAdminUser.status = Status;
                    _context.Entry(pendingAdminUser).State = EntityState.Modified;
                }

                //// Change status for ModuleOrganisations - If the company is disabled, all modules will be disabled
                if (Status == (int)Statuses.Deleted)
                {
                    var moduleOrganisationMappers = await _context.ModuleOrganisationMappers.Where(mod => mod.companyId == CompanyId).ToListAsync();

                    moduleOrganisationMappers.ForEach(modOrg =>
                    {
                        modOrg.status = Status;
                        _context.Entry(modOrg).State = EntityState.Modified;
                    });
                }


                _context.Entry(organisation).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                _logger.LogInformation($"############## DbUpdateConcurrencyException ####################", ex.Message);
                if (!Helper.OrganisationIdExists(CompanyId))
                {
                    return NotFound();
                }

                else
                {
                    throw;
                }
            }
            catch (DbUpdateException ex)
            {
                _logger.LogInformation($"############## DbUpdateException ####################", ex.Message);
                throw;
            }
            catch (Exception ex)
            {

            }
            //return Ok(organisation);
            return new { message = "Record updated successfully !!!" };
            //return NoContent();
        }

        // POST: api/Organisations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPost]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<ActionResult<object>> PostOrganisation(Organisation_Response organisation)
        //{
        //    if (EmployeeEmailExists(organisation.email))
        //    {
        //        return Conflict(new { message = $"An email Id '{organisation.email}' was already found." });
        //    }
        //    string schemaName = $"{Regex.Replace(organisation.companyName.ToLower(), @"\s+", "_")}_{DateTime.UtcNow.ToString("yyyyMMddHHmmssffff")}";
        //    var _organisation = new Organisation()
        //    {
        //        companyName = organisation.companyName,
        //        panNo = organisation.panNo,
        //        tanNo = organisation.tanNo,
        //        pfReg = organisation.pfReg,
        //        esiReg = organisation.esiReg,
        //        createdBy = organisation.createdBy,
        //        updatedBy = organisation.updatedBy,
        //        status = organisation.status,
        //        updatedDate = DateTime.UtcNow,
        //        createdTime = DateTime.UtcNow,
        //        clientId = organisation.clientId,
        //        schemaName = schemaName,
        //        checkerId = organisation.checkerId,
        //        makerId = organisation.makerId,
        //        passwordExpiry = organisation.passwordExpiry,
        //        companyAddress1 = organisation.companyAddress1,
        //        companyAddress2 = organisation.companyAddress2,
        //        companyAddress3 = organisation.companyAddress3,
        //        organization = organisation.organization,
        //        stateId = organisation.stateId,
        //        countryId = organisation.countryId,

        //    };
        //    if (organisation.isEmail == true || organisation.isSms == true)
        //    {
        //        organisation.isSms = organisation.isSms;
        //        organisation.isEmail = organisation.isEmail;
        //        // Post method will be always in pending status.
        //        _organisation.status = (int)Statuses.Pending;
        //        _context.Organisations.Add(_organisation);
        //    }
        //    else
        //    {
        //        return Conflict(new { message = "Email or SMS needed" });
        //    }


        //    try
        //    {

        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateException)
        //    {
        //        if (Helper.OrganisationIdExists(_organisation.companyId))
        //        {
        //            return Conflict(new { message = $"A company with the id '{_organisation.companyId}' was already found." });
        //        }
        //        else if (OrganisationNameExists(organisation.companyName))
        //        {
        //            return Conflict(new { message = $"A company with the name '{_organisation.companyName}' was already found." });
        //        }
        //        else if (!Helper.OrganisationIdExists(_organisation.companyId))
        //        {
        //            return Conflict(new { message = $"A company with the id '{_organisation.companyId}' does not exist." });
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }
        //    var company = await _context.Organisations.Where(org => org.schemaName == schemaName).FirstOrDefaultAsync();
        //    var result = new { company.companyId, company.companyName, company.clientId };
        //    return result;
        //    //return CreatedAtAction("GetOrganisation", new { id = _organisation.Id }, _organisation);
        //}


        // POST: api/Organisations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostOrganisation(OrganisationSetup organisation)
        {
            // var OrgTran = _context.Database.BeginTransaction(IsolationLevel.Serializable);
            //try
            //{


            UserEmailID = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            var EmailExist = await _context.EmployeePersonalDetails.Where(e => e.companyId == organisation.companyId &&
                                                    e.employeePersonalDetailId != organisation.employeePersonalDetailId && e.email == organisation.emailID).FirstOrDefaultAsync();
            if (EmailExist != null)
            {
                return Conflict(new { message = $"An email Id '{organisation.emailID}' was already found." });
            }
            var Num = _context.EmployeePersonalDetails.Where(n => n.mobileNo == organisation.mobileNumber && n.employeePersonalDetailId != organisation.employeePersonalDetailId).FirstOrDefault();
            if (Num != null )
            {
                return Conflict(new { message = "MobileNumber already found." });
            }

            var _organisation = await _context.Organisations.Where(e => e.companyId == organisation.companyId).FirstOrDefaultAsync();
            if (_organisation == null)
            {
                return Conflict(new { message = "Organisation not found." });
            }
            _organisation.companyName = organisation.companyName;
            _organisation.panNo = organisation.panNo;
            _organisation.tanNo = organisation.tanNo;
            _organisation.pfReg = organisation.pfReg;
            _organisation.esiReg = organisation.esiReg;
            _organisation.updatedBy = UserEmailID;
            _organisation.status = organisation.status;
            _organisation.updatedDate = DateTime.UtcNow;
            _organisation.clientId = organisation.clientId;
            _organisation.schemaName = _organisation.schemaName;
            _organisation.passwordExpiry = organisation.passwordExpiry;
            _organisation.companyAddress1 = organisation.companyAddress1;
            _organisation.companyAddress2 = organisation.companyAddress2;
            _organisation.companyAddress3 = organisation.companyAddress3;
            _organisation.organization = organisation.organization;
            _organisation.stateId = (organisation.stateId == null ? 1 : (long)organisation.stateId);// StateID is hardcoded as 1 since we must have to supply not null value to a reference key column
            _organisation.countryId = (organisation.countryId == null ? 1 : (long)organisation.countryId);// CountryID is hardcoded as 1 since we must have to supply not null value to a reference key column
            _organisation.isSms = organisation.isSms;
            _organisation.isEmail = organisation.isEmail;
            _organisation.companyId = organisation.companyId;
            _organisation.pincode = organisation.pincode;
            _organisation.twoWayAuthentication = organisation.twoWayAuthentication;



            if (organisation.isEmail == false && organisation.isSms == false)
            {
                return Conflict(new { message = "Email or SMS needed" });
            }
            _context.Organisations.Update(_organisation);
            if (organisation.organisationAdditionalMaster != null && organisation.organisationAdditionalMaster.Count > 0)
            {
                var lastID = _context.AdditionalMasters.Max(e => (int?)e.additionalMasterId);
                if(lastID == null)
                {
                    lastID = 0;
                }
                foreach (var am in organisation.organisationAdditionalMaster)
                {
                    var oldID = am.additionalMasterId;
                    if (am.additionalMasterId < 0)
                    {
                        lastID++;
                        am.additionalMasterId = (long)lastID;
                        _context.AdditionalMasters.Add(am);


                        foreach (var mh in organisation.mastersHierarchy)
                        {
                            if (oldID < 0)
                            {
                                if (mh.parentID == oldID && mh.parentType == "A")
                                {
                                    mh.parentID = am.additionalMasterId;
                                }
                                else if (mh.childID == oldID && mh.childType == "A")
                                {
                                    mh.childID = am.additionalMasterId;
                                }
                            }
                            mh.companyId = organisation.companyId;
                        }
                    }
                    else
                    {
                        _context.AdditionalMasters.Update(am);
                    }


                }


            }
            if (organisation.organisationDefaultMaster != null && organisation.organisationDefaultMaster.Count > 0)
            {
                var odmm = (from odm in organisation.organisationDefaultMaster
                            join odcm in _context.DefaultMasterCompanyMapper
                            on odm.defaultMasterCompanyMapperID equals odcm.defaultMasterCompanyMapperID into odm1
                            from odm2 in odm1.DefaultIfEmpty()
                            select new DefaultMasterCompanyMapper
                            {
                                defaultMasterCompanyMapperID = odm.defaultMasterCompanyMapperID,
                                companyId = organisation.companyId,
                                defaultMasterID = odm.defaultMasterID,
                                createdBy = (odm2 == null ? UserEmailID : odm2.createdBy),
                                createdTime = (odm2 == null ? DateTime.UtcNow : odm2.createdTime),
                                updatedBy = UserEmailID,
                                updatedDate = DateTime.UtcNow,
                                status = odm.status
                            }).ToList();
                _context.DefaultMasterCompanyMapper.UpdateRange(odmm);

            }
            if (organisation.organisationCommonMaster != null && organisation.organisationCommonMaster.Count > 0)
            {
                var odmm = (from odm in organisation.organisationCommonMaster
                            join odcm in _context.CommonMasterCompanyMapper
                            on odm.commonMasterCompanyMapperID equals odcm.commonMasterCompanyMapperID into odm1
                            from odm2 in odm1.DefaultIfEmpty()
                            select new CommonMasterCompanyMapper
                            {
                                commonMasterCompanyMapperID = odm.commonMasterCompanyMapperID,
                                companyId = organisation.companyId,
                                commonMasterID = odm.commonMasterID,
                                createdBy = (odm2 == null ? UserEmailID : odm2.createdBy),
                                createdTime = (odm2 == null ? DateTime.UtcNow : odm2.createdTime),
                                updatedBy = UserEmailID,
                                updatedDate = DateTime.UtcNow,
                                status = odm.status
                            }).ToList();
                _context.CommonMasterCompanyMapper.UpdateRange(odmm);
            }
            if (organisation.companyModules != null && organisation.companyModules.Count > 0)
            {
                var companymodules = organisation.companyModules[0].organisationModules;
                for (int ictr = 1; ictr < organisation.companyModules.Count; ictr++)
                {
                    companymodules.AddRange(organisation.companyModules[ictr].organisationModules);
                }
                var odmm = (from odm in companymodules
                            join odcm in _context.ModuleOrganisationMappers
                            on odm.moduleOrganisationMapperID equals odcm.moduleOrgMapperId into odm1
                            from odm2 in odm1.DefaultIfEmpty()
                            select new ModuleOrganisationMapper
                            {
                                moduleOrgMapperId = odm.moduleOrganisationMapperID,
                                companyId = organisation.companyId,
                                moduleId = odm.moduleID,
                                createdBy = (odm2 == null ? UserEmailID : odm2.createdBy),
                                //createdTime = (odm2 == null ? DateTime.UtcNow : odm2.createdTime),
                                updatedBy = UserEmailID,
                                updatedDate = DateTime.UtcNow,
                                status = (int)(odm.isSelected ? Statuses.Approved : Statuses.Deleted),
                                //  isCompulsory = odm.isCompulsory
                                
                               
                            }).ToList();
                
                _context.ModuleOrganisationMappers.UpdateRange(odmm);
            }

            var EmployeeDetails = _context.EmployeePersonalDetails.Where(e => e.companyId == organisation.companyId &&
                                                 e.employeePersonalDetailId != organisation.employeePersonalDetailId).FirstOrDefault();
            if (EmployeeDetails == null)
            {
                EmployeeDetails = new EmployeePersonalDetail
                {
                    createdBy = UserEmailID,
                    createdTime = DateTime.UtcNow,
                    employeePersonalDetailId = organisation.employeePersonalDetailId,
                    password = RandomString(9),
                    status = (int)Statuses.Approved,
                };

            }
            EmployeeDetails.employeePersonalDetailId = organisation.employeePersonalDetailId;
            EmployeeDetails.firstName = organisation.firstName;
            EmployeeDetails.middleName = organisation.middleName;
            EmployeeDetails.lastName = organisation.lastName;
            EmployeeDetails.email = organisation.emailID;
            EmployeeDetails.mobileNo = organisation.mobileNumber;
            EmployeeDetails.companyId = organisation.companyId;
            EmployeeDetails.clientId = organisation.clientId;
            EmployeeDetails.updatedBy = UserEmailID;
            EmployeeDetails.updatedDate = DateTime.UtcNow;
            EmployeeDetails.password = EmployeeDetails.password;

            bool isValid = Regex.IsMatch(organisation.mobileNumber, @"^\d{10}$");

            if (!isValid)
            {
                return Conflict(new { message = "Invalid MobileNumber." });

            }
            if (organisation.roleId != null)
            {
                EmployeeDetails.roleId = organisation.roleId;
            }
            else
            {
                EmployeeDetails.roleId = 1;
            }
            if (organisation.roleIds != null)
            {
                EmployeeDetails.roleIds = organisation.roleIds;
            }
            else
            {
                EmployeeDetails.roleIds = "[1]";
            }
            EmployeeDetails.isCompanyAdmin = organisation.isCompanyAdmin;
            EmployeeDetails.isClientAdmin = organisation.isClientAdmin;
            EmployeeDetails.companyId = organisation.companyId;
            _context.EmployeePersonalDetails.Update(EmployeeDetails);
            if (organisation.storageAllocation != null)
            {
                organisation.storageAllocation.createdBy = (organisation.storageAllocation.createdBy == null ? UserEmailID : organisation.storageAllocation.createdBy);
                organisation.storageAllocation.createdTime = (organisation.storageAllocation.createdTime == null ? DateTime.UtcNow : organisation.storageAllocation.createdTime);
                organisation.storageAllocation.updatedBy = UserEmailID;
                organisation.storageAllocation.updatedDate = DateTime.UtcNow;
                organisation.storageAllocation.companyID = organisation.companyId;
                _context.StorageAllocation.Update(organisation.storageAllocation);
            }

            if (organisation.mastersHierarchy != null)
            {
                var tmpmasterHierarchy = (from mh in _context.MastersHierarchy.Where(e => e.companyId == organisation.companyId)
                                         // join om in (from om3 in organisation.mastersHierarchy select om3) on mh.hierarchyID equals om.hierarchyID //into om1
                                         // from om2 in om1.DefaultIfEmpty()
                                          select mh).ToList();
                 
                _context.MastersHierarchy.RemoveRange(tmpmasterHierarchy);                          

                foreach (var a in organisation.mastersHierarchy)
                {
                    if (a.hierarchyID < 0)
                    {
                        a.hierarchyID = 0;
                        a.createdBy = UserEmailID;
                        a.createdTime = DateTime.UtcNow;
                    }
                    a.companyId = organisation.companyId;
                    a.updatedBy = UserEmailID;
                    a.updatedDate = DateTime.UtcNow;

                }
                _context.MastersHierarchy.UpdateRange(organisation.mastersHierarchy);
            }
            try
            {

                await _context.SaveChangesAsync();
                //await OrgTran.CommitAsync();
                //OrgTran.Dispose();
                //OrgTran = null;
            }
            catch (DbUpdateException ex)
            {
                if (Helper.OrganisationIdExists(_organisation.companyId))
                {
                    return Conflict(new { message = $"A company with the id '{_organisation.companyId}' was already found." });
                }
                else if (OrganisationNameExists(organisation.companyName))
                {
                    return Conflict(new { message = $"A company with the name '{_organisation.companyName}' was already found." });
                }
                else if (!Helper.OrganisationIdExists(_organisation.companyId))
                {
                    return Conflict(new { message = $"A company with the id '{_organisation.companyId}' does not exist." });
                }
                else
                {
                    throw;
                }
            }
            //var company = await _context.Organisations.Where(org => org.schemaName == schemaName).FirstOrDefaultAsync();
            // var result = new { company.companyId, company.companyName, company.clientId };
            //return new { message = "Company Details Updated successfully !!!" };
            //return CreatedAtAction("GetOrganisation", new { id = _organisation.Id }, _organisation);
            var EmployeeDetailsJson = JsonConvert.SerializeObject(EmployeeDetails);
            return System.Text.Json.JsonSerializer.Deserialize<object>(EmployeeDetailsJson);
        }
        //catch (Exception ex)
        //{

        //}
        //finally
        //{
        //    if (OrgTran != null)
        //    {
        //        await OrgTran.RollbackAsync();
        //        OrgTran.Dispose();
        //    }
        //}


        // DELETE: api/Organisations/5
        // There is no hard delete as per the specification, status will be changed to false/0
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteOrganisation(long id)
        {
            var organisation = await _context.Organisations.FindAsync(id);
            if (organisation == null)
            {
                return NotFound();
            }
            organisation.status = 0;
            _context.Organisations.Update(organisation);
            await _context.SaveChangesAsync();

            return NoContent();
        }


        //New Api for Logo upload created by Shwetha --------------------------------------------------------
        [HttpPost("UploadLogo")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> UploadLogo([FromForm] Organization_Logo organisation)
        {
            try
            {
                Organisation org = _context.Organisations.Where(o => o.companyId == organisation.companyId).FirstOrDefault();
                //    new Organisation
                //{
                //    companyId = organisation.companyId,
                //    //companyLogo = organisation.logoPath,
                //    companyName = organisation.companyName
                //};

                if (organisation.formFile != null)
                {
                    if (organisation.formFile.Length < 50 * 1024) //organisation.formFile != null &&
                    {
                        string[] extensions = { ".jpg", ".png" };
                        if (extensions.Any(x => x.Equals(Path.GetExtension(organisation.formFile.FileName.ToLower()), StringComparison.OrdinalIgnoreCase)))
                        {
                            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
                            var logoUrl = await FileUploadAsync(organisation.formFile, org.companyId.ToString());

                            org.companyLogo = logoUrl;
                            org.updatedBy = userEmail;
                            org.updatedDate = DateTime.UtcNow;
                            org.isCompanyLogo = (bool)organisation.isCompanyLogo ? true : false;

                        }
                        else
                        {
                            return Conflict(new { message = $"Only .png/.jpg are allowed to upload !!!" });
                        }
                    }
                    else
                    {
                        return Conflict(new { message = $"The file size exceeds the maximum allowed size of 50KB. !!!" });
                    }
                }
                else
                {
                    return Conflict(new { message = $"File not choosen !!!" });
                }

                _context.Organisations.Update(org);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new { message = $"Error while uploading Logo!!!" });
            }
            return new { message = "Logo Updated Successfully !!!" };

            //var organisationJson = JsonConvert.SerializeObject(organisation);
            //return System.Text.Json.JsonSerializer.Deserialize<object>(organisationJson);

        }

        private async Task<string> FileUploadAsync(IFormFile file, string companyId)
        {
            try
            {
                var fileName = Path.GetFileName(file.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Images", companyId, fileName);
                bool exists = System.IO.Directory.Exists(Path.GetDirectoryName(filePath));

                if (!exists)
                    System.IO.Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
                return filePath;
            }
            catch (DbUpdateException)
            {
                throw;
            }


        }

        //added by shwetha
        [HttpGet("GetCompanyLogo/{Id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetCompanyLogo(long Id)
        {

            var List = await (from org in _context.Organisations
                              where org.companyId == Id
                              select new
                              {
                                  org.companyId,
                                  org.companyName,
                                  org.companyLogo,
                                  org.isCompanyLogo,
                                  img = string.Empty,
                              }).ToListAsync();
            if (List.Count > 0)
            {
                if (!string.IsNullOrEmpty(List[0].companyLogo))
                {
                    byte[] bytes = System.IO.File.ReadAllBytes(List[0].companyLogo);
                    var retuList = (from org in List
                                    where org.companyId == Id
                                    select new
                                    {
                                        org.companyId,
                                        org.companyName,
                                        org.companyLogo,
                                        org.isCompanyLogo,
                                        img = bytes,
                                    }).ToList();
                    return retuList;
                }
                return List[0];
            }
            return Conflict("Company Not Found");
        }


        // DELETE: api/RemoveLogo
        [HttpDelete("RemoveLogo/{Id}/{isCompanyLogo}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> RemoveLogo(long Id, bool isCompanyLogo)
        {
            //var organisation = await _context.Organisations.FindAsync(companyId); bool isCompanyLogo /{isCompanyLogo}
            Organisation org = _context.Organisations.Where(o => o.companyId == Id).FirstOrDefault();

            Organization_Logo organisation = new Organization_Logo();
            if (org == null)
            {
                return NotFound();
            }
            org.companyLogo = null;
            org.isCompanyLogo = isCompanyLogo;    //(bool)organisation.isCompanyLogo ? true : false;
            _context.Organisations.Update(org);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //Account Management Report Api by shwetha
        [HttpGet("CompanyStorageReport/{UserId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> CompanyStorageReport(long UserId)
        {
            try
            {
                var userData = await _context.EmployeePersonalDetails.Where(user => user.employeePersonalDetailId == UserId).FirstOrDefaultAsync();
                if (userData != null)
                {
                    if (userData.roleId == (int)RoleIds.SuperAdmin)
                    {

                        var storageReport = await (from org in _context.Organisations
                                                   where org.status == (int)Statuses.Approved && org.isOwnerCompany != true
                                                   join storage in _context.StorageAllocation on org.companyId equals storage.companyID into storageV
                                                   from storageValue in storageV.DefaultIfEmpty()
                                                   join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                                   from clientV in Clients.DefaultIfEmpty()
                                                       //where org.isOwnerCompany != true && clientV.isOwnerClient != true
                                                   select new
                                                   {
                                                       org.companyName,
                                                       storageValue.storageAllocation,
                                                       storageConsumption = storageValue.userCount * Convert.ToInt32(storageValue.perUserStorage),
                                                       storageValue.userGroupCount,
                                                       storageValue.userCount,
                                                       storageValue.perUserStorage,
                                                       userAverageConsumption = "-"
                                                   }).ToListAsync();


                        var _organisationJson = JsonConvert.SerializeObject(storageReport);
                        object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
                        return _organisationValue;

                    }
                    else
                    {
                        var storageReport1 = await (from company in _context.CompanyUserRoleMappers
                                                    where company.employeeId == UserId
                                                    join org in _context.Organisations on company.companyId equals org.companyId into organization
                                                    from orgV in organization.DefaultIfEmpty()
                                                    where orgV.status == (int)Statuses.Approved && orgV.isOwnerCompany != true
                                                    join storage in _context.StorageAllocation on orgV.companyId equals storage.companyID into storageV
                                                    from storageValue in storageV.DefaultIfEmpty()
                                                    select new
                                                    {
                                                        orgV.companyName,
                                                        storageValue.storageAllocation,
                                                        storageConsumption = storageValue.userCount * Convert.ToInt32(storageValue.perUserStorage),
                                                        storageValue.userGroupCount,
                                                        storageValue.userCount,
                                                        storageValue.perUserStorage,
                                                        userAverageConsumption = "-"
                                                    }).ToListAsync();

                        var _organisationJson = JsonConvert.SerializeObject(storageReport1);
                        object _organisationValue = System.Text.Json.JsonSerializer.Deserialize<object>(_organisationJson);
                        return _organisationValue;

                    }
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return new List<object>();
        }

        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }


        private bool OrganisationNameExists(string CompanyName)
        {
            return _context.Organisations.Any(e => e.companyName == CompanyName);
        }
        private bool OrganisationIdExists(long companyId)
        {
            return _context.Organisations.Any(e => e.companyId == companyId);
        }

        private bool EmployeeEmailExists(string email)
        {
            return _context.EmployeePersonalDetails.Any(e => e.email == email);
        }
    }
}
