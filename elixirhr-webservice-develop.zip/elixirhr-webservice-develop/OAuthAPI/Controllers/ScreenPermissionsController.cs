﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;
using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScreenPermissionsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public ScreenPermissionsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/ScreenPermissions
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetScreenPermissions()
        {
            //var _screenPermissions = await _context.ScreenPermissions.ToListAsync();
            var _screenPermissions = await (from SP in _context.ScreenPermissions
                                            where SP.status == (int)Statuses.Approved
                                            join screen in _context.Screens on SP.screenId equals screen.screenId into Screens
                                            from screenV in Screens.DefaultIfEmpty()
                                            join role in _context.UserRoles on SP.roleId equals role.userRoleId into Roles
                                            from roleV in Roles.DefaultIfEmpty()
                                            select new
                                            {
                                                SP.screenPermissionId,
                                                SP.roleId,
                                                roleV.roleName,
                                                SP.screenId,
                                                screenV.screenName,
                                                SP.create,
                                                SP.read,
                                                SP.update,
                                                SP.delete,
                                                SP.createdBy,
                                                SP.createdTime,
                                                SP.updatedBy,
                                                SP.updatedDate
                                            }
                                            ).ToListAsync();
            var _screenPermissionsjson = JsonConvert.SerializeObject(_screenPermissions);
            ArrayList _screenPermissionslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_screenPermissionsjson);
            return _screenPermissionslist;
        }

        // GET: api/ScreenPermissions/GetScreensForRoleId/{RoleId}
        [HttpGet("GetScreensForRoleId/{RoleId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetScreensForRoleId(int RoleId)
        {
            //var _screenPermissions = await _context.ScreenPermissions.ToListAsync();
            var _screenPermissions = await (from SP in _context.ScreenPermissions
                                            where SP.status == (int)Statuses.Approved && SP.roleId == RoleId
                                            join screen in _context.Screens on SP.screenId equals screen.screenId into Screens
                                            from screenV in Screens.DefaultIfEmpty()
                                            join role in _context.UserRoles on SP.roleId equals role.userRoleId into Roles
                                            from roleV in Roles.DefaultIfEmpty()
                                            orderby SP.screenId
                                            select new
                                            {
                                                SP.screenPermissionId,
                                                screenV.moduleId,
                                                SP.roleId,
                                                roleV.roleName,
                                                SP.screenId,
                                                screenV.screenName,
                                                SP.create,
                                                SP.read,
                                                SP.update,
                                                SP.delete,
                                                SP.approve,
                                                SP.createdBy,
                                                SP.createdTime,
                                                SP.updatedBy,
                                                SP.updatedDate
                                            }
                                            ).ToListAsync();
            var _screenPermissionsjson = JsonConvert.SerializeObject(_screenPermissions);
            ArrayList _screenPermissionslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_screenPermissionsjson);
            return _screenPermissionslist;
        }


        // GET: api/ScreenPermissions/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetScreenPermission(long id)
        {
            //var screenPermission = await _context.ScreenPermissions.FindAsync(id);
            var screenPermission = await (from SP in _context.ScreenPermissions
                                          where SP.screenPermissionId == id
                                          join screen in _context.Screens on SP.screenId equals screen.screenId into Screens
                                          from screenV in Screens.DefaultIfEmpty()
                                          join role in _context.UserRoles on SP.roleId equals role.userRoleId into Roles
                                          from roleV in Roles.DefaultIfEmpty()
                                          select new
                                          {
                                              SP.screenPermissionId,
                                              SP.roleId,
                                              roleV.roleName,
                                              SP.screenId,
                                              screenV.screenName,
                                              SP.create,
                                              SP.read,
                                              SP.update,
                                              SP.delete,
                                              SP.createdBy,
                                              SP.createdTime,
                                              SP.updatedBy,
                                              SP.updatedDate
                                          }
                                            ).ToListAsync();
            if (screenPermission == null)
            {
                return NotFound();
            }

            var screenPermissionjson = JsonConvert.SerializeObject(screenPermission);
            var _screenPermission = System.Text.Json.JsonSerializer.Deserialize<object>(screenPermissionjson);

            return _screenPermission;
        }

        // PUT: api/ScreenPermissions/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutScreenPermissions(long id, ScreenPermission screenPermission)
        {
            if (!ScreenPermissionExists(id))
            {
                return Conflict(new { message = $"ScreenPermission Id '{screenPermission.screenPermissionId}' not found." });
            }
            if (!RoleExists((long)screenPermission.roleId))
            {
                return Conflict(new { message = $"Role Id '{screenPermission.roleId}' not found." });
            }
            if (!ScreenExists((long)screenPermission.screenId))
            {
                return Conflict(new { message = $"Screen Id '{screenPermission.screenId}' not found." });
            }
            //if (ScreenPermissionExists(id) && RoleExists((long)screenPermission.RoleId) && ScreenExists((long)screenPermission.ScreenId))
            //{
            //    return new { message = "exist" };
            //}
            screenPermission.screenPermissionId = id;
            screenPermission.updatedDate = DateTime.UtcNow;
            _context.Entry(screenPermission).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScreenPermissionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        //// POST: api/ScreenPermissions
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPost]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<ActionResult<object>> PostScreenPermissions(ScreenPermission screenPermission)
        //{
        //    _context.ScreenPermissions.Add(screenPermission);
        //    try
        //    {

        //        if (!RoleExists((long)screenPermission.RoleId))
        //        {
        //            return Conflict(new { message = $"Role Id '{screenPermission.RoleId}' not found." });
        //        }
        //        if (!ScreenExists((long)screenPermission.ScreenId))
        //        {
        //            return Conflict(new { message = $"Screen Id '{screenPermission.ScreenId}' not found." });
        //        }
        //        screenPermission.Id = _context.ScreenPermissions.Count() + 1;
        //        screenPermission.CreatedTime = DateTime.UtcNow;
        //        screenPermission.UpdatedDate = screenPermission.CreatedTime;

        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateException)
        //    {
        //        if (ScreenPermissionExists(screenPermission.Id))
        //        {
        //            return Conflict(new { message = $"A screenPermission with the id '{screenPermission.Id}' was already found." });
        //        }
        //        else
        //        {
        //            throw;
        //        }

        //    }

        //    var screenPermissionjson = JsonConvert.SerializeObject(screenPermission);
        //    var _screenPermission = System.Text.Json.JsonSerializer.Deserialize<object>(screenPermissionjson);

        //    return _screenPermission;
        //}

        // POST: api/ScreenPermissions
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPost("PostScreenPermissions/{CompanyId}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<ActionResult<object>> PostScreenPermissions(long CompanyId, ScreensPermission screensPermission)
        //{


        //    if (screensPermission.screens.Count() > 0)
        //    {
        //        //added by shwetha
        //        var comapanyRoles = _context.RoleOrganisationMappers.Where(c => c.companyId == CompanyId).Select(e => new { e.roleId }).Distinct().ToList();

        //        var existingScreensForRoles = _context.ScreenPermissions.Where(SP => SP.roleId != screensPermission.roleId && SP.status == (int)Statuses.Approved).ToList();
        //        var output = (from esfr in existingScreensForRoles
        //                      join roles in _context.UserRoles on esfr.roleId equals roles.userRoleId
        //                      join cr in comapanyRoles on roles.userRoleId equals cr.roleId
        //                      from cfsr in screensPermission.screens
        //                      where (esfr.screenId == cfsr.screenId && esfr.create == cfsr.create && esfr.read == cfsr.read &&
        //                              esfr.approve == cfsr.approve && esfr.delete == cfsr.delete && esfr.update == cfsr.update)

        //                      select new
        //                      {
        //                          RoleId = esfr.roleId,
        //                          RoleName = roles.roleName,
        //                          ScreenId = cfsr.screenId
        //                      }).ToList();
        //        var counts = output.GroupBy(x => x.RoleName).Where(grp => grp.Count() == screensPermission.screens.Count())
        //         .Select(g => new { g.Key, Count = g.Count() }).Select(e => e.Key.ToString());

        //        if (counts.Count() > 0)
        //        {
        //            //Modified code by Srinivas
        //            var RoleNames = string.Join(", ", counts);

        //            return Conflict(new { message = "User Group " + RoleNames + " with similar user rights already exist." });
        //        }

        //        foreach (var screen in screensPermission.screens)
        //        {
        //            if (!ScreenPermissionExists((long)screen.screenId, (long)screensPermission.roleId))
        //            {
        //                ScreenPermission screenPermission = new ScreenPermission
        //                {

        //                    roleId = screensPermission.roleId,
        //                    screenId = screen.screenId,
        //                    create = screen.create,
        //                    delete = screen.delete,
        //                    update = screen.update,
        //                    read = screen.read,
        //                    approve = screen.approve,
        //                    updatedBy = screensPermission.updatedBy,
        //                    updatedDate = DateTime.UtcNow,
        //                    createdBy = screensPermission.createdBy,
        //                    createdTime = DateTime.UtcNow,
        //                    status = (int)Statuses.Approved
        //                };
        //                _context.ScreenPermissions.Add(screenPermission);
        //                try
        //                {

        //                    if (!RoleExists((long)screenPermission.roleId))
        //                    {
        //                        return Conflict(new { message = $"Role Id '{screenPermission.roleId}' not found." });
        //                    }
        //                    if (!ScreenExists((long)screenPermission.screenId))
        //                    {
        //                        return Conflict(new { message = $"Screen Id '{screenPermission.screenId}' not found." });
        //                    }
        //                    var lastScreenPermission = _context.ScreenPermissions.OrderBy(screen => screen.screenPermissionId).LastOrDefault();

        //                    screenPermission.screenPermissionId = lastScreenPermission == null ? 1 : lastScreenPermission.screenPermissionId + 1;
        //                    screenPermission.createdTime = DateTime.UtcNow;
        //                    screenPermission.updatedDate = screenPermission.createdTime;

        //                    _context.SaveChanges();

        //                }
        //                catch (DbUpdateException)
        //                {
        //                    if (ScreenPermissionExists(screenPermission.screenPermissionId))
        //                    {
        //                        return Conflict(new { message = $"A screenPermission with the id '{screenPermission.screenPermissionId}' was already found." });
        //                    }
        //                    else
        //                    {
        //                        throw;
        //                    }

        //                }
        //            }
        //            // If is already existing with status Deleted, change it to Approved
        //            else
        //            {
        //                var screenToUpdate = _context.ScreenPermissions.Where(m => m.screenId == (long)screen.screenId && m.roleId == screensPermission.roleId).FirstOrDefault();
        //                if (screenToUpdate.status == (int)Statuses.Deleted)
        //                {
        //                    // If all the values are false, we need to remove the data from DB
        //                    if (screen.create == false && screen.read == false && screen.update == false && screen.delete == false && screen.approve == false)
        //                    {
        //                        screenToUpdate.status = (int)Statuses.Deleted;
        //                    }
        //                    else
        //                    {
        //                        screenToUpdate.status = (int)Statuses.Approved;
        //                        _context.Entry(screenToUpdate).State = EntityState.Modified;
        //                    }
        //                    screenToUpdate.updatedDate = DateTime.UtcNow;
        //                    screenToUpdate.updatedBy = screensPermission.updatedBy;
        //                    //_context.ModuleOrganisationMappers.Remove(moduleToRemove);
        //                    _context.SaveChanges();
        //                }
        //                else
        //                {
        //                    // If all the values are false, we need to remove the data from DB
        //                    if (screen.create == false && screen.read == false && screen.update == false && screen.delete == false && screen.approve == false)
        //                    {
        //                        screenToUpdate.status = (int)Statuses.Deleted;
        //                    }
        //                    else
        //                    {
        //                        screenToUpdate.create = screen.create;
        //                        screenToUpdate.read = screen.read;
        //                        screenToUpdate.update = screen.update;
        //                        screenToUpdate.delete = screen.delete;
        //                        screenToUpdate.approve = screen.approve;
        //                    }
        //                    screenToUpdate.updatedDate = DateTime.UtcNow;
        //                    screenToUpdate.updatedBy = screensPermission.updatedBy;
        //                    _context.Entry(screenToUpdate).State = EntityState.Modified;
        //                    _context.SaveChanges();


        //                }
        //            }

        //        }

        //        // Remove the screens, which are not in the requested list
        //        var existingScreensForRole = _context.ScreenPermissions.Where(SP => SP.roleId == screensPermission.roleId).ToList();
        //        foreach (var available in existingScreensForRole)
        //        {
        //            if (screensPermission.screens.Where(screen => screen.screenId == available.screenId).ToList().Count() == 0)
        //            {
        //                var screenToRemove = _context.ScreenPermissions.Where(m => m.screenId == available.screenId && m.roleId == screensPermission.roleId).FirstOrDefault();


        //                if (screenToRemove != null)
        //                {

        //                    screenToRemove.status = (int)Statuses.Deleted;
        //                    screenToRemove.updatedDate = DateTime.UtcNow;
        //                    _context.Entry(screenToRemove).State = EntityState.Modified;
        //                    //_context.ModuleOrganisationMappers.Remove(moduleToRemove);
        //                    _context.SaveChanges();


        //                }

        //            }
        //        }
        //    }
        //    var screenPermissionjson = JsonConvert.SerializeObject(screensPermission);
        //    var _screenPermission = System.Text.Json.JsonSerializer.Deserialize<object>(screenPermissionjson);

        //    return _screenPermission;
        //}
        /// <summary>
        /// /////
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// 

        [HttpPost("PostScreenPermission")]
        // [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostScreenPermissions(long CompanyId, ScreensPermission screensPermission)
        {

            bool create = true; bool approve = true; bool read = true;

            foreach (var sc in screensPermission.screens)
            {

                create = (bool)sc.create;
                approve = (bool)sc.approve;
                read = (bool)sc.read;

                if (create == true && approve == true)
                {
                    return Conflict(new { message = " screen is not allowed for create and approved permission together for same user group " });
                }
                if (create == true || approve == true)
                {
                    sc.read = true;

                }
            }
            if (screensPermission.screens.Count() > 0)
            {
                //added by shwetha
                var comapanyRoles = _context.RoleOrganisationMappers.Where(c => c.companyId == CompanyId).Select(e => new { e.roleId }).Distinct().ToList();

                var existingScreensForRoles = _context.ScreenPermissions.Where(SP => SP.roleId != screensPermission.roleId && SP.status == (int)Statuses.Approved).ToList();
                var output = (from esfr in existingScreensForRoles
                              join roles in _context.UserRoles on esfr.roleId equals roles.userRoleId
                              join cr in comapanyRoles on roles.userRoleId equals cr.roleId
                              from cfsr in screensPermission.screens
                              where (esfr.screenId == cfsr.screenId && esfr.create == cfsr.create && esfr.read == cfsr.read &&
                                      esfr.approve == cfsr.approve && esfr.delete == cfsr.delete && esfr.update == cfsr.update)

                              select new
                              {
                                  RoleId = esfr.roleId,
                                  RoleName = roles.roleName,
                                  ScreenId = cfsr.screenId
                              }).ToList();
                var counts = output.GroupBy(x => x.RoleName).Where(grp => grp.Count() == screensPermission.screens.Count())
                 .Select(g => new { g.Key, Count = g.Count() }).Select(e => e.Key.ToString());

                if (counts.Count() > 0)
                {
                    //Modified code by Srinivas
                    var RoleNames = string.Join(", ", counts);

                    return Conflict(new { message = "User Group " + RoleNames + " with similar user rights already exist." });
                }

                foreach (var screen in screensPermission.screens)
                {
                    if (!ScreenPermissionExists((long)screen.screenId, (long)screensPermission.roleId))
                    {
                        ScreenPermission screenPermission = new ScreenPermission
                        {

                            roleId = screensPermission.roleId,
                            screenId = screen.screenId,
                            create = screen.create,
                            delete = screen.delete,
                            update = screen.update,
                            read = screen.read,
                            approve = screen.approve,
                            updatedBy = screensPermission.updatedBy,
                            updatedDate = DateTime.UtcNow,
                            createdBy = screensPermission.createdBy,
                            createdTime = DateTime.UtcNow,
                            status = (int)Statuses.Approved



                        };
                        _context.ScreenPermissions.Add(screenPermission);
                        try
                        {

                            if (!RoleExists((long)screenPermission.roleId))
                            {
                                return Conflict(new { message = $"Role Id '{screenPermission.roleId}' not found." });
                            }
                            if (!ScreenExists((long)screenPermission.screenId))
                            {
                                return Conflict(new { message = $"Screen Id '{screenPermission.screenId}' not found." });
                            }
                            var lastScreenPermission = _context.ScreenPermissions.OrderBy(screen => screen.screenPermissionId).LastOrDefault();

                            screenPermission.screenPermissionId = lastScreenPermission == null ? 1 : lastScreenPermission.screenPermissionId + 1;
                            screenPermission.createdTime = DateTime.UtcNow;
                            screenPermission.updatedDate = screenPermission.createdTime;

                            _context.SaveChanges();

                        }
                        catch (DbUpdateException)
                        {
                            if (ScreenPermissionExists(screenPermission.screenPermissionId))
                            {
                                return Conflict(new { message = $"A screenPermission with the id '{screenPermission.screenPermissionId}' was already found." });
                            }
                            else
                            {
                                throw;
                            }

                        }
                    }
                    // If is already existing with status Deleted, change it to Approved
                    else
                    {
                        var screenToUpdate = _context.ScreenPermissions.Where(m => m.screenId == (long)screen.screenId && m.roleId == screensPermission.roleId).FirstOrDefault();
                        if (screenToUpdate.status == (int)Statuses.Deleted)
                        {
                            // If all the values are false, we need to remove the data from DB
                            if (screen.create == false && screen.read == false && screen.update == false && screen.delete == false && screen.approve == false)
                            {
                                screenToUpdate.status = (int)Statuses.Deleted;
                            }
                            else
                            {
                                screenToUpdate.status = (int)Statuses.Approved;
                                _context.Entry(screenToUpdate).State = EntityState.Modified;
                            }
                            screenToUpdate.updatedDate = DateTime.UtcNow;
                            screenToUpdate.updatedBy = screensPermission.updatedBy;
                            //_context.ModuleOrganisationMappers.Remove(moduleToRemove);
                            _context.SaveChanges();
                        }
                        else
                        {
                            // If all the values are false, we need to remove the data from DB
                            if (screen.create == false && screen.read == false && screen.update == false && screen.delete == false && screen.approve == false)
                            {
                                screenToUpdate.status = (int)Statuses.Deleted;
                            }
                            else
                            {
                                screenToUpdate.create = screen.create;
                                screenToUpdate.read = screen.read;
                                screenToUpdate.update = screen.update;
                                screenToUpdate.delete = screen.delete;
                                screenToUpdate.approve = screen.approve;
                            }
                            screenToUpdate.updatedDate = DateTime.UtcNow;
                            screenToUpdate.updatedBy = screensPermission.updatedBy;
                            _context.Entry(screenToUpdate).State = EntityState.Modified;
                            _context.SaveChanges();


                        }
                    }

                }

                // Remove the screens, which are not in the requested list
                var existingScreensForRole = _context.ScreenPermissions.Where(SP => SP.roleId == screensPermission.roleId).ToList();
                foreach (var available in existingScreensForRole)
                {
                    if (screensPermission.screens.Where(screen => screen.screenId == available.screenId).ToList().Count() == 0)
                    {
                        var screenToRemove = _context.ScreenPermissions.Where(m => m.screenId == available.screenId && m.roleId == screensPermission.roleId).FirstOrDefault();


                        if (screenToRemove != null)
                        {

                            screenToRemove.status = (int)Statuses.Deleted;
                            screenToRemove.updatedDate = DateTime.UtcNow;
                            _context.Entry(screenToRemove).State = EntityState.Modified;
                            //_context.ModuleOrganisationMappers.Remove(moduleToRemove);
                            _context.SaveChanges();


                        }

                    }
                }
            }
            var screenPermissionjson = JsonConvert.SerializeObject(screensPermission);
            var _screenPermission = System.Text.Json.JsonSerializer.Deserialize<object>(screenPermissionjson);

            return _screenPermission;






        }




        private bool ScreenPermissionExists(long id)
        {
            return _context.ScreenPermissions.Any(e => e.screenPermissionId == id);
        }

        private bool RoleExists(long id)
        {
            return _context.UserRoles.Any(e => e.userRoleId == id);
        }

        private bool ScreenExists(long id)
        {
            return _context.Screens.Any(e => e.screenId == id);
        }

        private bool ScreenPermissionExists(long screenId, long roleId)
        {
            var validate = _context.ScreenPermissions.Where(SP => SP.screenId == screenId && SP.roleId == roleId).FirstOrDefault();
            return validate == null ? false : true;
        }
    }
}
