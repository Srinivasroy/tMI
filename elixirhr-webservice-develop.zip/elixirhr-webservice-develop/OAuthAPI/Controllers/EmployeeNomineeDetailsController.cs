﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeNomineeDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public EmployeeNomineeDetailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        //// GET: api/EmployeeNomineeDetails
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<EmployeeNomineeDetail_Response>>> GetEmployeeNomineeDetails()
        //{
        //    return await _context.EmployeeNomineeDetails.ToListAsync();
        //}

        // GET: api/EmployeeNomineeDetails/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<EmployeeNomineeDetail>> GetEmployeeNomineeDetail(long id)
        {
            var employeeNomineeDetail = await _context.EmployeeNomineeDetails.FindAsync(id);

            if (employeeNomineeDetail == null)
            {
                return NotFound();
            }

            return employeeNomineeDetail;
        }

        // PUT: api/EmployeeNomineeDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutEmployeeNomineeDetail(long id, EmployeeNomineeDetail employeeNomineeDetail)
        {
            if (!EmployeeNomineeDetailExists(id))
            {
                return NotFound();
            }
            employeeNomineeDetail.employeeNomineeDetailsId = id;
            _context.Entry(employeeNomineeDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeNomineeDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/EmployeeNomineeDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<EmployeeNomineeDetail>> PostEmployeeNomineeDetail(EmployeeNomineeDetail employeeNomineeDetail)
        {
            if(employeeNomineeDetail.companyId == null)
            {
                return Conflict( new {Message="Company Id should not be null"});
            }
            if (!Helper.OrganisationIdExists((long)employeeNomineeDetail.companyId))
            {
                return Conflict(new { Message = "Company Id does not exist !!!" });
            }
            _context.EmployeeNomineeDetails.Add(employeeNomineeDetail);
            try
            {
                employeeNomineeDetail.createdTime = DateTime.UtcNow;
                employeeNomineeDetail.updatedDate = DateTime.UtcNow;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (EmployeeNomineeDetailExists(employeeNomineeDetail.employeeNomineeDetailsId))
                {
                    return Conflict(new { Message = "Company Id already exist !!!" });
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetEmployeeNomineeDetail", new { id = employeeNomineeDetail.employeeNomineeDetailsId }, employeeNomineeDetail);
        }

        // DELETE: api/EmployeeNomineeDetails/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteEmployeeNomineeDetail(long id)
        //{
        //    var employeeNomineeDetail = await _context.EmployeeNomineeDetails.FindAsync(id);
        //    if (employeeNomineeDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.EmployeeNomineeDetails.Remove(employeeNomineeDetail);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool EmployeeNomineeDetailExists(long id)
        {
            return _context.EmployeeNomineeDetails.Any(e => e.employeeNomineeDetailsId == id);
        }
        
    }
}
