﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models;
using OAuthAPI.models.common_schema;
using OAuthAPI.Models;
using OAuthAPI.Models.Common_Schema;
using MySql.Data;
using MySql.Data.MySqlClient;
using OAuthAPI.ActionFilters;
using OAuthAPI.Helpers;
using static OAuthAPI.models.Helpers.Helper;
using Microsoft.AspNetCore.Cors;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using MimeKit.Text;
using Nancy.Json;
using System.Net;
using System.ComponentModel.Design;
using System.Text.RegularExpressions;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class AccountController : ControllerBase
    {
        private readonly JwtSettings jwtSettings;
        private readonly Common_Schema_Context _context;
        private readonly ILogger<AccountController> _logger;
        public AccountController(JwtSettings jwtSettings, Common_Schema_Context tmiContext, ILogger<AccountController> logger)
        {
            this.jwtSettings = jwtSettings;
            this._context = tmiContext;
            this._logger = logger;
        }
        //private IEnumerable<Users> logins = new List<Users>() {
        //    new Users() {
        //            Id = Guid.NewGuid(),
        //                EmailId = "adminakp@gmail.com",
        //                UserName = "Admin",
        //                Password = "Admin",
        //        },
        //        new Users() {
        //            Id = Guid.NewGuid(),
        //                EmailId = "adminakp@gmail.com",
        //                UserName = "User1",
        //                Password = "Admin",
        //        }
        //};
        [HttpPost]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<IActionResult> PostGetToken(UserLogins userLogins)
        {
            try
            {

                bool isPasswordExpired = false;
                bool isFirstLogin = false;
               
                _logger.LogInformation("############## PostGetToken execution Started ####################");
                var Token = new UserTokens();
                var users = await _context.EmployeePersonalDetails.ToListAsync();
                string password = Helpers.Helpers.SHA256Hash(userLogins.Password);
                var EmpDeatils = _context.EmployeePersonalDetails.FirstOrDefault(x => x.email.Equals(userLogins.Email));
                var OrgInfo = await _context.Organisations.Where(org => EmpDeatils != null && org.companyId == EmpDeatils.companyId).FirstOrDefaultAsync();
                if (OrgInfo != null)
                {

                    System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
                    builder.ConnectionString = _context.Database.GetConnectionString();
                    _context.Database.CloseConnection();
                    builder["database"] = OrgInfo.schemaName;
                    _context.Database.SetConnectionString(builder.ToString());
                    _context.Database.OpenConnection();
                }
                var Valid = users.Any(x => x.email != null && x.email.Equals(userLogins.Email, StringComparison.OrdinalIgnoreCase) && x.password == password && userLogins.Organization.Equals(OrgInfo.organization, StringComparison.OrdinalIgnoreCase));

                if (Valid)
                {
                    var user = _context.EmployeePersonalDetails.FirstOrDefault(x => x.email != null && x.email.Equals(userLogins.Email));
                    var roleName = await _context.UserRoles.Where(role => user != null && role.userRoleId == user.roleId).FirstOrDefaultAsync();
                    var organisation = await _context.Organisations.Where(org => user != null && org.companyId == user.companyId).FirstOrDefaultAsync();



                    if (roleName != null && roleName.status == (int)Statuses.Deleted)
                    {
                        return Conflict("User role has been disabled !!!");
                    }
                    // One User Login
                    var log = await _context.UserLoginLog.Where(x => x.userId == user.employeePersonalDetailId && x.companyId == user.companyId && x.logoutTime == null).FirstOrDefaultAsync();
                    if (log != null)
                    {
                        return Conflict("Active Session was present");
                    }
                   
                        UserLoginLog logs = new UserLoginLog();
                        logs.userId = user.employeePersonalDetailId;
                        logs.loginTime = DateTime.Now;
                        logs.createdBy = user.email;
                        logs.createdTime = DateTime.Now;
                        logs.companyId = user.companyId;

                        _context.UserLoginLog.Add(logs);
                      
                    
                    var lastTrackPassword = await _context.TrackPasswords.Where(pass => user != null && pass.employeeId == user.employeePersonalDetailId).OrderBy(pass => pass.trackPassId).LastOrDefaultAsync();
                    var trackPasswords = await _context.TrackPasswords.Where(pass => user != null && pass.employeeId == user.employeePersonalDetailId).ToListAsync();
                    // a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3 - This is an encrypted code for 123
                    if (trackPasswords != null && trackPasswords.Count() <= 1)
                    {
                        if (trackPasswords.Count() == 0)// || (trackPasswords.Count() == 1 && trackPasswords.Last().Password == "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"))
                            isFirstLogin = true;
                    }

                    DateTime today = DateTime.UtcNow;
                    if (lastTrackPassword != null && lastTrackPassword.lastChanged != null && organisation != null)
                    {
                        var difference = today.Subtract((DateTime)lastTrackPassword.lastChanged).TotalDays;
                        if (organisation.passwordExpiry != null && difference > organisation.passwordExpiry)
                        {
                            isPasswordExpired = true;
                        }
                    }



                    Token = JwtHelpers.JwtHelpers.GenTokenkey(new UserTokens()
                    {
                        EmailId = user != null && user.email != null ? user.email : "",
                        UserName = user != null ? $"{user.firstName} {user.lastName}" : "",
                        EmployeeId = (long)user.employeePersonalDetailId,
                        CurrentCompanyId = (int)organisation.companyId,//(int)Common_Schema_Context.CurrentCompanyId,   
                        CurrentDbName = organisation.schemaName ?? _context.Database.GetDbConnection().Database,
                        ParentCompanyId = 0,
                        ParentDbName = _context.Database.GetDbConnection().Database,
                        CurrentRoleId = 0,
                        CurrentRoleName = "pleaseChangeCode",


                    }, jwtSettings);
                    Token.isSuperAdmin = EmpDeatils.roleId == 1 ? true : false;
                    Token.IsPasswordExpired = isPasswordExpired;
                    Token.IsFirstLogin = isFirstLogin;
                    Token.isOwnerCompany = organisation.isOwnerCompany;

                    await _context.SaveChangesAsync();

                    if (userLogins.IsLogin == true)
                    {
                        var accessObj = await GetAccessControl1(user.employeePersonalDetailId);
                        var accessControlJson = JsonConvert.SerializeObject(accessObj.Value);
                        Token.accessControl = System.Text.Json.JsonSerializer.Deserialize<object>(accessControlJson);
                    }
                }
                else
                {
                    return BadRequest(new { message = "Invalid Credentials." });
                }
                _logger.LogTrace("############## PostGetToken execution Ended ####################");
                return Ok(Token);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"$$$$$$$$$$$$$$$$$$ Error in PostGetToken $$$$$$$$$$$$$$$$$$$$$$ - \n {ex}");
                return Conflict(new { message = ex.Message });
            }
        }
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> logout(long userId,long companyId)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            var log = await _context.UserLoginLog.Where(x => x.userId == userId && x.companyId == companyId && x.logoutTime == null).FirstOrDefaultAsync();

            log.logoutTime = DateTime.Now;
            log.updatedBy = userEmail;
            log.updatedTime = DateTime.Now;

            _context.UserLoginLog.Update(log);

            await _context.SaveChangesAsync();

            return new { message = "Logout successfully !!!" };
        }

        //public async Task<ActionResult<object>> GetAccessControl(long EmployeeId)
        //public async Task<ActionResult<AccessControl>> GetAccessControl1(long EmployeeId)
        //{

        //    AccessControl accessControl = new AccessControl();
        //    var employeeDetail = await _context.EmployeePersonalDetails.FindAsync(EmployeeId);
        //    AccessEmployeeDetails accessEmployeeDetails = new AccessEmployeeDetails();
        //    var roleName = await _context.UserRoles.Where(role => role.Id == employeeDetail.RoleId).FirstOrDefaultAsync();

        //    if (employeeDetail != null)
        //    {
        //        accessEmployeeDetails.EmployeeId = employeeDetail.Id;
        //        accessEmployeeDetails.EmployeeName = $"{employeeDetail.FirstName} {employeeDetail.LastName}";
        //        accessEmployeeDetails.EmployeeImage = employeeDetail.EmployeeImageUrl;
        //        accessEmployeeDetails.EmployeeEmailId = employeeDetail.Email;
        //        accessEmployeeDetails.EmployeeRole = roleName != null ? roleName.RoleName : "";
        //        accessEmployeeDetails.EmployeeRoleId = employeeDetail.RoleId != null ? (int)employeeDetail.RoleId : 0;
        //        if (employeeDetail.ClientId != null)
        //        {
        //            accessEmployeeDetails.EmployeeClientId = (int)employeeDetail.ClientId;
        //            var organisationsForClient = await _context.Organisations.Where(org => org.ClientId == employeeDetail.ClientId).ToListAsync();
        //            if (organisationsForClient.Count > 1)
        //            {
        //                accessEmployeeDetails.ShowMultipleCompanyCheckbox = employeeDetail.IsClientAdmin != null && (bool)employeeDetail.IsClientAdmin ? true : false;
        //            }
        //        }
        //    }
        //    accessControl.EmployeeDetails = accessEmployeeDetails;
        //    List<Company> companyList = new List<Company>();
        //    if (employeeDetail.RoleId != null)
        //    {

        //        // Retrive data from userRoles
        //        var companiesList = await (from UR in _context.RoleOrganisationMappers
        //                                   where UR.RoleId == (employeeDetail.RoleId == null ? 0 : employeeDetail.RoleId) // && UR.CompanyId == employeeDetail.CompanyId
        //                                   join org in _context.Organisations
        //                                       on UR.CompanyId equals org.CompanyId into company
        //                                   from comp in company.DefaultIfEmpty()
        //                                   join client in _context.ClientCreation
        //                                       on comp.ClientId equals client.ClientId into companyClient
        //                                   from cmpClient in companyClient.DefaultIfEmpty()

        //                                   orderby comp.CompanyId
        //                                   select new
        //                                   {
        //                                       CompanyName = comp.CompanyName,
        //                                       CompanyId = comp.CompanyId != null ? comp.CompanyId : 0,
        //                                       ClientName = cmpClient.ClientName == null ? "" : cmpClient.ClientName,
        //                                       ClientId = cmpClient.ClientId != null ? cmpClient.ClientId : 0,
        //                                       CompanyLogo = comp.CompanyLogo,
        //                                       SchemaName = comp.SchemaName,
        //                                       IsMaker = comp.MakerId == employeeDetail.Id ? true : false,
        //                                       IsChecker = comp.CheckerId == employeeDetail.Id ? true : false
        //                                   }).ToListAsync();

        //        // For TMI Admin, need to have all the companies which have maker and checker Id for the companies
        //        if (employeeDetail.RoleId == (int)UserRoles.TmiAdmin)
        //        {
        //            var tmiAdminCompanies = await (from comp in _context.Organisations
        //                                           where comp.MakerId == employeeDetail.Id || comp.CheckerId == employeeDetail.Id
        //                                           join client in _context.ClientCreation
        //                                 on comp.ClientId equals client.ClientId into companyClient
        //                                           from cmpClient in companyClient.DefaultIfEmpty()
        //                                           select new
        //                                           {
        //                                               CompanyName = comp.CompanyName,
        //                                               CompanyId = comp.CompanyId != null ? comp.CompanyId : 0,
        //                                               ClientName = cmpClient.ClientName == null ? "" : cmpClient.ClientName,
        //                                               ClientId = cmpClient.ClientId != null ? cmpClient.ClientId : 0,
        //                                               CompanyLogo = comp.CompanyLogo,
        //                                               SchemaName = comp.SchemaName,
        //                                               IsMaker = comp.MakerId == employeeDetail.Id ? true : false,
        //                                               IsChecker = comp.CheckerId == employeeDetail.Id ? true : false
        //                                           }
        //                                           ).ToListAsync();
        //            tmiAdminCompanies.ForEach((adminCompany) =>
        //            {
        //                var hasCompany = companiesList.Where(comp => comp.CompanyId == adminCompany.CompanyId).FirstOrDefault();
        //                if (hasCompany == null)
        //                {
        //                    companiesList.Add(adminCompany);
        //                }
        //            });
        //        }
        //        // For TMI Admin, need to have all the companies which have maker and checker Id for the companies
        //        else if (employeeDetail.RoleId == (int)UserRoles.SuperAdmin)
        //        {
        //            var tmiAdminCompanies = await (from comp in _context.Organisations
        //                                           where comp.Status == (int)Statuses.Approved
        //                                           join client in _context.ClientCreation
        //                                 on comp.ClientId equals client.ClientId into companyClient
        //                                           from cmpClient in companyClient.DefaultIfEmpty()
        //                                           select new
        //                                           {
        //                                               CompanyName = comp.CompanyName,
        //                                               CompanyId = comp.CompanyId != null ? comp.CompanyId : 0,
        //                                               ClientName = cmpClient.ClientName == null ? "" : cmpClient.ClientName,
        //                                               ClientId = cmpClient.ClientId != null ? cmpClient.ClientId : 0,
        //                                               CompanyLogo = comp.CompanyLogo,
        //                                               SchemaName = comp.SchemaName,
        //                                               IsMaker = comp.MakerId == employeeDetail.Id ? true : false,
        //                                               IsChecker = comp.CheckerId == employeeDetail.Id ? true : false
        //                                           }
        //                                           ).ToListAsync();
        //            tmiAdminCompanies.ForEach((adminCompany) =>
        //            {
        //                // To avoid duplicate values
        //                var isInList = companiesList.Where(comp => comp.CompanyId == adminCompany.CompanyId).FirstOrDefault();
        //                if (isInList == null)
        //                {
        //                    companiesList.Add(adminCompany);
        //                }
        //            });
        //        }
        //        else if (accessEmployeeDetails.EmployeeRole != null && accessEmployeeDetails.EmployeeRole == "Client Admin")
        //        {
        //            var clientAdminCompanies = await (from comp in _context.Organisations
        //                                              where comp.Status == (int)Statuses.Approved && comp.ClientId == employeeDetail.ClientId
        //                                              join client in _context.ClientCreation
        //                                    on comp.ClientId equals client.ClientId into companyClient
        //                                              from cmpClient in companyClient.DefaultIfEmpty()
        //                                              select new
        //                                              {
        //                                                  CompanyName = comp.CompanyName,
        //                                                  CompanyId = comp.CompanyId != null ? comp.CompanyId : 0,
        //                                                  ClientName = cmpClient.ClientName == null ? "" : cmpClient.ClientName,
        //                                                  ClientId = cmpClient.ClientId != null ? cmpClient.ClientId : 0,
        //                                                  CompanyLogo = comp.CompanyLogo,
        //                                                  SchemaName = comp.SchemaName,
        //                                                  IsMaker = comp.MakerId == employeeDetail.Id ? true : false,
        //                                                  IsChecker = comp.CheckerId == employeeDetail.Id ? true : false
        //                                              }
        //                                           ).ToListAsync();
        //            clientAdminCompanies.ForEach((adminCompany) =>
        //            {
        //                // To avoid duplicate values
        //                var isInList = companiesList.Where(comp => comp.CompanyId == adminCompany.CompanyId).FirstOrDefault();
        //                if (isInList == null)
        //                {
        //                    companiesList.Add(adminCompany);
        //                }
        //            });
        //        }

        //        if (companiesList.Count() > 0)
        //        {
        //            AccessClientDetails accessClientDetails = new AccessClientDetails()
        //            {
        //                ClientId = companiesList[0].ClientId,
        //                ClientName = companiesList[0].ClientName
        //            };
        //            accessControl.ClientDetails = accessClientDetails;
        //            foreach (var company in companiesList)
        //            {
        //                Company companyDetail = new Company()
        //                {
        //                    CompanyId = company.CompanyId,
        //                    CompanyLogo = company.CompanyLogo,
        //                    CompanyName = company.CompanyName,
        //                    SchemaName = company.SchemaName == null ? "" : company.SchemaName,
        //                    IsMaker = company.IsMaker,
        //                    IsChecker = company.IsChecker
        //                };
        //                companyList.Add(companyDetail);
        //            }
        //        }



        //        var screenPermissions = (from moduleOrgMapper in _context.ModuleOrganisationMappers
        //                                 join module in _context.Modules
        //                                      on moduleOrgMapper.ModuleId equals module.Id into ModulesMapper
        //                                 from MP in ModulesMapper.DefaultIfEmpty()
        //                                 join screen in _context.Screens
        //                                      on MP.Id equals screen.ModuleId into ScreensList
        //                                 from allowedScreens in ScreensList.DefaultIfEmpty()
        //                                 join screenPermission in _context.ScreenPermissions
        //                                 on allowedScreens.Id equals screenPermission.ScreenId into SP
        //                                 from SPs in SP.DefaultIfEmpty()
        //                                 where (SPs.RoleId == (employeeDetail.RoleId == null ? 0 : employeeDetail.RoleId) && SPs.Status == (int)Statuses.Approved 
        //                                 &&
        //                                 (SPs.Approve == true || SPs.Create == true || SPs.Delete == true || SPs.Read == true || SPs.Update == true))
        //                                 // ... other joins here
        //                                 // ... other conditions here
        //                                 //orderby groupRole.GroupId
        //                                 select new
        //                                 {
        //                                     allowedScreens.ScreenName,
        //                                     SPs.Create,
        //                                     SPs.Read,
        //                                     SPs.Update,
        //                                     SPs.Delete,
        //                                     MP.ModuleName,
        //                                     MP.Id,
        //                                     moduleOrgMapper.CompanyId,
        //                                     allowedScreens.ScreenURL,
        //                                     ScreenId = allowedScreens.Id,
        //                                     MP.IsDropdown,
        //                                     SPs.Approve,
        //                                     MP.Status,
        //                                     allowedScreens.ParentId
        //                                 }).ToList();





        //        List<ScreensPermissionForLogin> spForLogins = new List<ScreensPermissionForLogin>();

        //        foreach (var sp in screenPermissions)
        //        {
        //            var count = companiesList.Where(lst=> lst.CompanyId == sp.CompanyId).ToList();
        //            if (count.Count() > 0)
        //            {
        //                ScreensPermissionForLogin screensPermissionForLogin = new ScreensPermissionForLogin
        //                {
        //                    Approve = sp.Approve,
        //                    Status = sp.Status,
        //                    CompanyId = sp.CompanyId,
        //                    Create = sp.Create,
        //                    Delete = sp.Delete,
        //                    Id = sp.Id,
        //                    IsDropdown = sp.IsDropdown,
        //                    ModuleName = sp.ModuleName,
        //                    ParentId = sp.ParentId,
        //                    Read = sp.Read,
        //                    ScreenId = sp.ScreenId,
        //                    ScreenName = sp.ScreenName,
        //                    ScreenURL = sp.ScreenURL,
        //                    Update = sp.Update
        //                };
        //                spForLogins.Add(screensPermissionForLogin);
        //            }
        //        }

        //        if (employeeDetail.IsClientAdmin == true)
        //        {
        //            var ClientAdminScreens = await _context.ScreenPermissions.Where(sp => sp.RoleId == employeeDetail.RoleId).ToListAsync();
        //            var SPs = (from screenPermission in ClientAdminScreens
        //                       join screen in _context.Screens
        //                       on screenPermission.ScreenId equals screen.Id into Screens
        //                       from screensV in Screens.DefaultIfEmpty()
        //                       join module in _context.Modules
        //                       on screensV.ModuleId equals module.Id into _Modules
        //                       from moduleV in _Modules.DefaultIfEmpty()
        //                       select new
        //                       {
        //                           ScreenName = screensV.ScreenName,
        //                           Create = screenPermission.Create,
        //                           Read = screenPermission.Read,
        //                           Update = screenPermission.Update,
        //                           Delete = screenPermission.Delete,
        //                           ModuleName = moduleV.ModuleName,
        //                           Id = moduleV.Id,
        //                           CompanyId = employeeDetail.CompanyId,
        //                           ScreenURL = screensV.ScreenURL,
        //                           ScreenId = screensV.Id,
        //                           IsDropdown = true,
        //                           Approve = screenPermission.Approve,
        //                           Status = 1,
        //                           ParentId = screensV.ParentId
        //                       }).ToList();
        //            foreach (var sp in SPs)
        //            {
        //                ScreensPermissionForLogin screensPermissionForLogin = new ScreensPermissionForLogin
        //                {
        //                    Approve = sp.Approve,
        //                    Status = sp.Status,
        //                    CompanyId = sp.CompanyId,
        //                    Create = sp.Create,
        //                    Delete = sp.Delete,
        //                    Id = sp.Id,
        //                    IsDropdown = sp.IsDropdown,
        //                    ModuleName = sp.ModuleName,
        //                    ParentId = sp.ParentId,
        //                    Read = sp.Read,
        //                    ScreenId = sp.ScreenId,
        //                    ScreenName = sp.ScreenName,
        //                    ScreenURL = sp.ScreenURL,
        //                    Update = sp.Update
        //                };
        //                spForLogins.Add(screensPermissionForLogin);
        //            }
        //        }

        //        var Modules = spForLogins.Where(sp => sp.Status == (int)Statuses.Approved).GroupBy(module => module.CompanyId).ToList();


        //        foreach (var module in Modules)
        //        {
        //            List<ModulesAccess> modulesAccessList = new List<ModulesAccess>();
        //            var companyModules = module.GroupBy(m => m.ModuleName).ToList();

        //            foreach (var companyModule in companyModules)
        //            {
        //                ModulesAccess modulesAccess = new ModulesAccess();
        //                modulesAccess.ModuleName = companyModule.Key;
        //                var screens = companyModule.ToList();

        //                foreach (var screen in screens)
        //                {
        //                    modulesAccess.ModuleId = (long)screen.Id;
        //                    modulesAccess.IsDropdown = screen.IsDropdown;
        //                    modulesAccess.ParentId = screen.ParentId;
        //                    AccessScreen accessScreen = new AccessScreen()
        //                    {
        //                        ScreenName = screen.ScreenName,
        //                        ScreenId = screen.ScreenId,
        //                        ParentId = screen.ParentId,
        //                        Create = screen.Create,
        //                        Read = screen.Read,
        //                        Update = screen.Update,
        //                        Delete = screen.Delete,
        //                        Approve = screen.Approve,
        //                        ScreenURL = screen.ScreenURL
        //                    };
        //                    // Avoid duplicate screen.
        //                    if (modulesAccess.Screens.Where(scn => scn.ScreenName == screen.ScreenName).ToList().Count() == 0)
        //                    {
        //                        modulesAccess.Screens.Add(accessScreen);
        //                    }
        //                }
        //                // Avoid duplicate module.
        //                if (modulesAccessList.Where(m => m.ModuleName == modulesAccess.ModuleName).ToList().Count() == 0)
        //                {
        //                    modulesAccessList.Add(modulesAccess);
        //                }
        //            }
        //            // Map the the screens with the respective Parent child relationships. :: Start

        //            dynamic MyDynamic = new System.Dynamic.ExpandoObject();

        //            List<ModulesAccess> finalModuleList = new List<ModulesAccess>();
        //            foreach (var moduleAccess in modulesAccessList)
        //            {
        //                ModulesAccess finalModulesAccess = new ModulesAccess();
        //                finalModulesAccess.ModuleId = moduleAccess.ModuleId;
        //                finalModulesAccess.ModuleName = moduleAccess.ModuleName;
        //                foreach (var screen in moduleAccess.Screens)
        //                {
        //                    // First level list
        //                    screen.SubMenu = GetSubMenus(moduleAccess.Screens, screen);
        //                    // Remove the clustered items
        //                    if (screen.SubMenu.Count() > 0)
        //                    {
        //                        foreach (var subMenu in screen.SubMenu)
        //                        {
        //                            var remove = moduleAccess.Screens.Where(srn => srn.ScreenId == subMenu.ScreenId).FirstOrDefault();
        //                            if (remove != null)
        //                            {
        //                                remove.IsRemove = true;
        //                            }
        //                        }
        //                    }
        //                    foreach (var subMenuScreens in screen.SubMenu)
        //                    {
        //                        // Second level list
        //                        subMenuScreens.SubMenu = GetSubMenus(moduleAccess.Screens, subMenuScreens);
        //                        // Remove the clustered items
        //                        if (subMenuScreens.SubMenu.Count() > 0)
        //                        {
        //                            foreach (var subMenu in subMenuScreens.SubMenu)
        //                            {
        //                                var remove = moduleAccess.Screens.Where(srn => srn.ScreenId == subMenu.ScreenId).FirstOrDefault();
        //                                if (remove != null)
        //                                {
        //                                    remove.IsRemove = true;
        //                                }
        //                            }
        //                        }
        //                    }

        //                }
        //                moduleAccess.Screens = moduleAccess.Screens.Where(srn => srn.IsRemove == false).ToList();
        //            }



        //            // ::END
        //            var index = companyList.FindIndex(com => com.CompanyId == module.Key);
        //            if (index > -1)
        //            {
        //                companyList[index].AccessControls = modulesAccessList;
        //            }
        //        }

        //        //}
        //    }
        //    accessControl.CompanyDetails.Companies = companyList;

        //    // Retrive default company value
        //    var defaultCompany = await _context.Organisations.Where(org => org.CompanyId == employeeDetail.CompanyId).FirstOrDefaultAsync();
        //    accessControl.CompanyDetails.DefaultCompanyId = defaultCompany != null ? defaultCompany.CompanyId : 0;
        //    accessControl.CompanyDetails.DefaultCompanyName = defaultCompany != null ? defaultCompany.CompanyName : "";
        //    var defaultClient = await _context.ClientCreation.Where(client => client.ClientId == accessControl.ClientDetails.ClientId).FirstOrDefaultAsync();
        //    if (defaultCompany != null && defaultCompany.MakerId == accessControl.EmployeeDetails.EmployeeId)
        //    {
        //        accessControl.IsCompanyMaker = true;
        //    }
        //    if (defaultCompany != null && defaultCompany.CheckerId == accessControl.EmployeeDetails.EmployeeId)
        //    {
        //        accessControl.IsCompanyChecker = true;
        //    }
        //    if (defaultClient != null && defaultClient.MakerId == accessControl.EmployeeDetails.EmployeeId)
        //    {
        //        accessControl.IsClientMaker = true;
        //    }
        //    if (defaultClient != null && defaultClient.CheckerId == accessControl.EmployeeDetails.EmployeeId)
        //    {
        //        accessControl.IsClientChecker = true;
        //    }
        //    accessControl.ServerName = GetServerName();
        //    var accessControlJson = JsonConvert.SerializeObject(accessControl);
        //    if (accessControlJson == null)
        //    {
        //        return NotFound();
        //    }
        //    //return System.Text.Json.JsonSerializer.Deserialize<object>(accessControlJson);
        //    return accessControl;
        //}
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<AccessControl>> GetAccessControl1(long EmployeeId)
        {

            AccessControl accessControl = new AccessControl();
            var employeeDetail = await _context.EmployeePersonalDetails.FindAsync(EmployeeId);
            AccessEmployeeDetails accessEmployeeDetails = new AccessEmployeeDetails();
            var roleName = await _context.UserRoles.Where(role => role.userRoleId == employeeDetail.roleId).FirstOrDefaultAsync();

            if (employeeDetail != null)
            {
                accessEmployeeDetails.employeeId = employeeDetail.employeePersonalDetailId;
                accessEmployeeDetails.employeeName = $"{employeeDetail.firstName} {employeeDetail.lastName}";
                accessEmployeeDetails.employeeImage = employeeDetail.employeeImageUrl;
                accessEmployeeDetails.employeeEmailId = employeeDetail.email;
                accessEmployeeDetails.employeeRole = roleName != null ? roleName.roleName : "";
                accessEmployeeDetails.employeeRoleId = employeeDetail.roleId != null ? (int)employeeDetail.roleId : 0;
                //accessEmployeeDetails.isCompanyAdmin = (bool)employeeDetail.isCompanyAdmin ? true : false;
                //accessEmployeeDetails.isClientAdmin = (bool)employeeDetail.isClientAdmin ? true : false;/ 
                if (employeeDetail.clientId != null)
                {
                    accessEmployeeDetails.employeeClientId = (int)employeeDetail.clientId;
                    var organisationsForClient = await _context.Organisations.Where(org => org.clientId == employeeDetail.clientId).ToListAsync();
                    if (organisationsForClient.Count > 1)
                    {
                        accessEmployeeDetails.showMultipleCompanyCheckbox = employeeDetail.isClientAdmin != null && (bool)employeeDetail.isClientAdmin ? true : false;
                    }
                }
            }
            accessControl.EmployeeDetails = accessEmployeeDetails;
            List<Company> companyList = new List<Company>();
            //if (employeeDetail.RoleId != null)
            //{
            if (employeeDetail.roleIds != null)
            {
                long[] roleIds = new JavaScriptSerializer().Deserialize<long[]>(employeeDetail.roleIds);
                var EmployeeRoleList = _context.UserRoles.Where(u => roleIds.Contains(u.userRoleId)).ToList();
                accessEmployeeDetails.employeeRoleList = EmployeeRoleList.Select(u => u.roleName).ToList();
            }

            // Retrive data from userRoles
            var companiesList = await (from CURM in _context.CompanyUserRoleMappers
                                       where CURM.employeeId == employeeDetail.employeePersonalDetailId // && UR.CompanyId == employeeDetail.CompanyId
                                       join org in _context.Organisations
                                           on CURM.companyId equals org.companyId into company
                                       from comp in company.DefaultIfEmpty()
                                       join client in _context.ClientCreation
                                           on comp.clientId equals client.clientId into companyClient
                                       from cmpClient in companyClient.DefaultIfEmpty()

                                       orderby comp.companyId
                                       select new
                                       {
                                           CompanyName = comp.companyName,
                                           CompanyId = comp.companyId != null ? comp.companyId : 0,
                                           ClientName = cmpClient.clientName == null ? "" : cmpClient.clientName,
                                           ClientId = cmpClient.clientId != null ? cmpClient.clientId : 0,
                                           CompanyLogo = comp.companyLogo,
                                           SchemaName = comp.schemaName,
                                           IsMaker = comp.makerId == employeeDetail.employeePersonalDetailId ? true : false,
                                           IsChecker = comp.checkerId == employeeDetail.employeePersonalDetailId ? true : false
                                       }).ToListAsync();

            if (employeeDetail.companyId == 1)
            {
                var TMICompany = await (from org in _context.Organisations
                                        where org.companyId == 1

                                        join client in _context.ClientCreation
                                            on org.clientId equals client.clientId into companyClient
                                        from cmpClient in companyClient.DefaultIfEmpty()

                                        orderby org.companyId
                                        select new
                                        {
                                            CompanyName = org.companyName,
                                            CompanyId = org.companyId != null ? org.companyId : 0,
                                            ClientName = cmpClient.clientName == null ? "" : cmpClient.clientName,
                                            ClientId = cmpClient.clientId != null ? cmpClient.clientId : 0,
                                            CompanyLogo = org.companyLogo,
                                            SchemaName = org.schemaName,
                                            IsMaker = org.makerId == employeeDetail.employeePersonalDetailId ? true : false,
                                            IsChecker = org.checkerId == employeeDetail.employeePersonalDetailId ? true : false
                                        }).FirstOrDefaultAsync();
                companiesList.Add(TMICompany);
            }

            // For Super Admin, need to have all the companies
            if (employeeDetail.roleId == (int)UserRoles.SuperAdmin)
            {
                var tmiAdminCompanies = await (from comp in _context.Organisations
                                               where comp.status == (int)Statuses.Approved
                                               join client in _context.ClientCreation
                                     on comp.clientId equals client.clientId into companyClient
                                               from cmpClient in companyClient.DefaultIfEmpty()
                                               select new
                                               {
                                                   CompanyName = comp.companyName,
                                                   CompanyId = comp.companyId != null ? comp.companyId : 0,
                                                   ClientName = cmpClient.clientName == null ? "" : cmpClient.clientName,
                                                   ClientId = cmpClient.clientId != null ? cmpClient.clientId : 0,
                                                   CompanyLogo = comp.companyLogo,
                                                   SchemaName = comp.schemaName,
                                                   IsMaker = comp.makerId == employeeDetail.employeePersonalDetailId ? true : false,
                                                   IsChecker = comp.checkerId == employeeDetail.employeePersonalDetailId ? true : false,


                                               }
                                               ).ToListAsync();
                tmiAdminCompanies.ForEach((adminCompany) =>
                {
                    // To avoid duplicate values
                    var isInList = companiesList.Where(comp => comp.CompanyId == adminCompany.CompanyId).FirstOrDefault();
                    if (isInList == null)
                    {
                        companiesList.Add(adminCompany);
                    }
                });
            }


            if (companiesList.Count() > 0)
            {
                AccessClientDetails accessClientDetails = new AccessClientDetails()
                {
                    clientId = companiesList[0].ClientId,
                    clientName = companiesList[0].ClientName
                };
                accessControl.ClientDetails = accessClientDetails;
                foreach (var company in companiesList)
                {
                    Company companyDetail = new Company()
                    {
                        companyId = company.CompanyId,
                        companyLogo = company.CompanyLogo != null ? true : false,
                        companyName = company.CompanyName,
                        schemaName = company.SchemaName == null ? "" : company.SchemaName,
                        isMaker = company.IsMaker,
                        isChecker = company.IsChecker,
                        isCompanyAdmin = (bool)employeeDetail.isCompanyAdmin ? true : false,
                        isClientAdmin = (bool)employeeDetail.isClientAdmin ? true : false

                    };
                    companyList.Add(companyDetail);
                }
            }



            var screenPermissions = (from moduleOrgMapper in _context.ModuleOrganisationMappers
                                     where moduleOrgMapper.status == (int)Statuses.Approved
                                     join module in _context.Modules
                                    on moduleOrgMapper.moduleId equals module.moduleId into ModulesMapper
                                     from MP in ModulesMapper.DefaultIfEmpty()
                                     join screen in _context.Screens
                                     on MP.moduleId equals screen.moduleId into ScreensList
                                     from allowedScreens in ScreensList.DefaultIfEmpty()
                                     join screenPermission in _context.ScreenPermissions
                                     on allowedScreens.screenId equals screenPermission.screenId into SP
                                     from SPs in SP.DefaultIfEmpty()
                                     join curm in _context.CompanyUserRoleMappers on SPs.roleId equals curm.roleId
                                     where ((curm.employeeId == employeeDetail.employeePersonalDetailId && SPs.status == (int)Statuses.Approved)
                                     &&
                                     (SPs.approve == true || SPs.create == true || SPs.delete == true || SPs.read == true || SPs.update == true))
                                     // ... other joins here
                                     // ... other conditions here
                                     //orderby groupRole.GroupId
                                     select new
                                     {
                                         allowedScreens.screenName,
                                         SPs.create,
                                         SPs.read,
                                         SPs.update,
                                         SPs.delete,
                                         MP.moduleName,
                                         MP.moduleId,
                                         MP.moduleIcon,
                                         curm.companyId,
                                         allowedScreens.screenURL,
                                         MP.moduleUrl,
                                         ScreenId = allowedScreens.screenId,
                                         MP.isDropdown,
                                         SPs.approve,
                                         MP.status,
                                         allowedScreens.parentId
                                     }).OrderBy(x => x.companyId).ThenBy(x => x.ScreenId).ToList();





            List<ScreensPermissionForLogin> spForLogins = new List<ScreensPermissionForLogin>();

            foreach (var sp in screenPermissions)
            {
                var count = companiesList.Where(lst => lst.CompanyId == sp.companyId).ToList();
                if (count.Count() > 0)
                {
                    ScreensPermissionForLogin screensPermissionForLogin = new ScreensPermissionForLogin
                    {
                        approve = sp.approve,
                        status = sp.status,
                        companyId = sp.companyId,
                        create = sp.create,
                        delete = sp.delete,
                        screenPermissionId = sp.moduleId,
                        isDropdown = sp.isDropdown,
                        moduleName = sp.moduleName,
                        moduleIcon = sp.moduleIcon,
                        parentId = sp.parentId,
                        read = sp.read,
                        screenId = sp.ScreenId,
                        screenName = sp.screenName,
                        screenURL = sp.screenURL,
                        moduleURL = sp.moduleUrl,
                        update = sp.update
                    };
                    spForLogins.Add(screensPermissionForLogin);
                }
            }

            var Modules = spForLogins.Where(sp => sp.status == (int)Statuses.Approved).GroupBy(module => module.companyId).ToList();

            foreach (var module in Modules)
            {
                List<ModulesAccess> modulesAccessList = new List<ModulesAccess>();
                var companyModules = module.GroupBy(m => m.moduleName).ToList();

                foreach (var companyModule in companyModules)
                {
                    ModulesAccess modulesAccess = new ModulesAccess();
                    modulesAccess.moduleName = companyModule.Key;
                    modulesAccess.moduleIcon = companyModule.Key;

                    var screens = companyModule.ToList();

                    foreach (var screen in screens)
                    {
                        modulesAccess.moduleId = (long)screen.screenId;
                        modulesAccess.isDropdown = screen.isDropdown;
                        modulesAccess.parentId = screen.parentId;
                        modulesAccess.moduleIcon = screen.moduleIcon;
                        modulesAccess.moduleURL = screen.moduleURL;



                        AccessScreen accessScreen = new AccessScreen()
                        {
                            screenName = screen.screenName,
                            screenId = screen.screenId,
                            parentId = screen.parentId,
                            create = screen.create,
                            read = screen.read,
                            update = screen.update,
                            delete = screen.delete,
                            approve = screen.approve,
                            screenURL = screen.screenURL
                        };
                        // Avoid duplicate screen.
                        if (modulesAccess.Screens.Where(scn => scn.screenName == screen.screenName).ToList().Count() == 0)
                        {
                            modulesAccess.Screens.Add(accessScreen);
                        }
                    }
                    // Avoid duplicate module.
                    if (modulesAccessList.Where(m => m.moduleName == modulesAccess.moduleName).ToList().Count() == 0)
                    {
                        modulesAccessList.Add(modulesAccess);
                    }
                }
                // Map the the screens with the respective Parent child relationships. :: Start

                dynamic MyDynamic = new System.Dynamic.ExpandoObject();

                List<ModulesAccess> finalModuleList = new List<ModulesAccess>();
                foreach (var moduleAccess in modulesAccessList)
                {
                    ModulesAccess finalModulesAccess = new ModulesAccess();
                    finalModulesAccess.moduleId = moduleAccess.moduleId;
                    finalModulesAccess.moduleName = moduleAccess.moduleName;
                    finalModulesAccess.moduleIcon = moduleAccess.moduleIcon;

                    foreach (var screen in moduleAccess.Screens)
                    {
                        // First level list
                        screen.SubMenu = GetSubMenus(moduleAccess.Screens, screen);
                        // Remove the clustered items
                        if (screen.SubMenu.Count() > 0)
                        {
                            foreach (var subMenu in screen.SubMenu)
                            {
                                var remove = moduleAccess.Screens.Where(srn => srn.screenId == subMenu.screenId).FirstOrDefault();
                                if (remove != null)
                                {
                                    remove.isRemove = true;
                                }
                            }
                        }
                        foreach (var subMenuScreens in screen.SubMenu)
                        {
                            // Second level list
                            subMenuScreens.SubMenu = GetSubMenus(moduleAccess.Screens, subMenuScreens);
                            // Remove the clustered items
                            if (subMenuScreens.SubMenu.Count() > 0)
                            {
                                foreach (var subMenu in subMenuScreens.SubMenu)
                                {
                                    var remove = moduleAccess.Screens.Where(srn => srn.screenId == subMenu.screenId).FirstOrDefault();
                                    if (remove != null)
                                    {
                                        remove.isRemove = true;
                                    }
                                }
                            }
                        }

                    }
                    moduleAccess.Screens = moduleAccess.Screens.Where(srn => srn.isRemove == false).ToList();
                }



                // ::END
                var index = companyList.FindIndex(com => com.companyId == module.Key);
                if (index > -1)
                {
                    companyList[index].AccessControls = modulesAccessList;
                }
            }

            //}
            // } // if(RoleId != null) condition end.
            accessControl.CompanyDetails.Companies = companyList;

            // Retrive default company value
            var defaultCompany = await _context.Organisations.Where(org => org.companyId == employeeDetail.companyId).FirstOrDefaultAsync();
            accessControl.CompanyDetails.defaultCompanyId = defaultCompany != null ? defaultCompany.companyId : 0;
            accessControl.CompanyDetails.defaultCompanyName = defaultCompany != null ? defaultCompany.companyName : "";
            var defaultClient = await _context.ClientCreation.Where(client => client.clientId == accessControl.ClientDetails.clientId).FirstOrDefaultAsync();
            if (defaultCompany != null && defaultCompany.makerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsCompanyMaker = true;
            }
            if (defaultCompany != null && defaultCompany.checkerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsCompanyChecker = true;
            }
            if (defaultClient != null && defaultClient.makerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsClientMaker = true;
            }
            if (defaultClient != null && defaultClient.checkerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsClientChecker = true;
            }
            accessControl.ServerName = GetServerName();
            var accessControlJson = JsonConvert.SerializeObject(accessControl);
            if (accessControlJson == null)
            {
                return NotFound();
            }
            //return System.Text.Json.JsonSerializer.Deserialize<object>(accessControlJson);
            return accessControl;
        }

        private List<AccessScreen> GetSubMenus(List<AccessScreen> Screens, AccessScreen screen)
        {
            var hasSubMenu = Screens.Where(srn => srn.parentId == screen.screenId).ToList();
            return hasSubMenu;

        }


        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<ActionResult<object>> GetAccessControl(long EmployeeId)
        public async Task<ActionResult<AccessControl>> GetAccessControl(long EmployeeId)
        {

            AccessControl accessControl = new AccessControl();
            var employeeDetail = await _context.EmployeePersonalDetails.FindAsync(EmployeeId);
            AccessEmployeeDetails accessEmployeeDetails = new AccessEmployeeDetails();
            var roleName = await _context.UserRoles.Where(role => role.userRoleId == employeeDetail.roleId).FirstOrDefaultAsync();

            if (employeeDetail != null)
            {
                accessEmployeeDetails.employeeId = employeeDetail.employeePersonalDetailId;
                accessEmployeeDetails.employeeName = $"{employeeDetail.firstName} {employeeDetail.lastName}";
                accessEmployeeDetails.employeeImage = employeeDetail.employeeImageUrl;
                accessEmployeeDetails.employeeEmailId = employeeDetail.email;
                accessEmployeeDetails.employeeRole = roleName != null ? roleName.roleName : "";
                accessEmployeeDetails.employeeRoleId = employeeDetail.roleId != null ? (int)employeeDetail.roleId : 0;

            }
            accessControl.EmployeeDetails = accessEmployeeDetails;
            List<Company> companyList = new List<Company>();
            if (employeeDetail.roleId != null)
            {

                // Retrive data from userRoles
                //var companiesList = (from UR in _context.UserRoles
                //                     where UR.Id == (employeeDetail.RoleId == null ? 0 : employeeDetail.RoleId) && UR.CompanyId == employeeDetail.CompanyId
                var companiesList = await (from UR in _context.RoleOrganisationMappers
                                           where UR.roleId == (employeeDetail.roleId == null ? 0 : employeeDetail.roleId) // && UR.CompanyId == employeeDetail.CompanyId
                                           join org in _context.Organisations
                                               on UR.companyId equals org.companyId into company
                                           from comp in company.DefaultIfEmpty()
                                           join client in _context.ClientCreation
                                               on comp.clientId equals client.clientId into companyClient
                                           from cmpClient in companyClient.DefaultIfEmpty()

                                           orderby comp.companyId
                                           select new
                                           {
                                               CompanyName = comp.companyName,
                                               CompanyId = comp.companyId != null ? comp.companyId : 0,
                                               ClientName = cmpClient.clientName == null ? "" : cmpClient.clientName,
                                               ClientId = cmpClient.clientId != null ? cmpClient.clientId : 0,
                                               CompanyLogo = comp.companyLogo,
                                               SchemaName = comp.schemaName,
                                               IsMaker = comp.makerId == employeeDetail.employeePersonalDetailId ? true : false,
                                               IsChecker = comp.checkerId == employeeDetail.employeePersonalDetailId ? true : false
                                           }).ToListAsync();

                // For TMI Admin, need to have all the companies which have maker and checker Id for the companies
                if (employeeDetail.roleId == (int)UserRoles.TmiAdmin)
                {
                    //var tmiAdminCompanies = await (from comp in _context.Organisations
                    //                               where comp.makerId == employeeDetail.employeePersonalDetailId || comp.checkerId == employeeDetail.employeePersonalDetailId
                    //                               join client in _context.ClientCreation
                    //                     on comp.clientId equals client.clientId into companyClient
                    //                               from cmpClient in companyClient.DefaultIfEmpty()
                    //                               select new
                    //                               {
                    //                                   CompanyName = comp.companyName,
                    //                                   CompanyId = comp.companyId != null ? comp.companyId : 0,
                    //                                   ClientName = cmpClient.clientName == null ? "" : cmpClient.clientName,
                    //                                   ClientId = cmpClient.clientId != null ? cmpClient.clientId : 0,
                    //                                   CompanyLogo = comp.companyLogo,
                    //                                   SchemaName = comp.schemaName,
                    //                                   IsMaker = comp.makerId == employeeDetail.employeePersonalDetailId ? true : false,
                    //                                   IsChecker = comp.checkerId == employeeDetail.employeePersonalDetailId ? true : false
                    //                               }
                    //                               ).ToListAsync();
                    //tmiAdminCompanies.ForEach((adminCompany) =>
                    //{
                    //    companiesList.Add(adminCompany);
                    //});
                }

                if (companiesList.Count() > 0)
                {
                    AccessClientDetails accessClientDetails = new AccessClientDetails()
                    {
                        clientId = companiesList[0].ClientId,
                        clientName = companiesList[0].ClientName
                    };
                    accessControl.ClientDetails = accessClientDetails;
                    foreach (var company in companiesList)
                    {
                        Company companyDetail = new Company()
                        {
                            companyId = company.CompanyId,
                            companyLogo = company.CompanyLogo != null ? true : false,
                            companyName = company.CompanyName,
                            schemaName = company.SchemaName == null ? "" : company.SchemaName,
                            isMaker = company.IsMaker,
                            isChecker = company.IsChecker
                        };
                        companyList.Add(companyDetail);
                    }
                }


                var screenPermissions = (from UR in _context.UserRoles
                                         where (UR.userRoleId == (employeeDetail.roleId == null ? 0 : employeeDetail.roleId)) //&& UR.CompanyId == employeeDetail.CompanyId
                                         join moduleOrgMapper in _context.ModuleOrganisationMappers
                                            on UR.companyId equals moduleOrgMapper.companyId
                                         join module in _context.Modules
                                              on moduleOrgMapper.moduleId equals module.moduleId into ModulesMapper
                                         from MP in ModulesMapper.DefaultIfEmpty()
                                         join screen in _context.Screens
                                              on MP.moduleId equals screen.moduleId into ScreensList
                                         from allowedScreens in ScreensList.DefaultIfEmpty()
                                         join screenPermission in _context.ScreenPermissions
                                         on allowedScreens.moduleId equals screenPermission.screenId into SP
                                         from SPs in SP.DefaultIfEmpty()
                                         where SPs.roleId == (employeeDetail.roleId == null ? 0 : employeeDetail.roleId)
                                          &&
                                         (SPs.approve == true || SPs.create == true || SPs.delete == true || SPs.read == true || SPs.update == true)
                                         // ... other joins here
                                         // ... other conditions here
                                         //orderby groupRole.GroupId
                                         select new
                                         {
                                             allowedScreens.screenName,
                                             SPs.create,
                                             SPs.read,
                                             SPs.update,
                                             SPs.delete,
                                             MP.moduleName,
                                             MP.moduleId,
                                             UR.companyId,
                                             allowedScreens.screenURL,
                                             MP.isDropdown,
                                             SPs.approve,
                                             MP.status
                                         }).ToList();




                var Modules = screenPermissions.Where(sp => sp.status == (int)Statuses.Approved).GroupBy(module => module.companyId).ToList();


                foreach (var module in Modules)
                {
                    List<ModulesAccess> modulesAccessList = new List<ModulesAccess>();
                    var companyModules = module.GroupBy(m => m.moduleName).ToList();

                    foreach (var companyModule in companyModules)
                    {
                        ModulesAccess modulesAccess = new ModulesAccess();
                        modulesAccess.moduleName = companyModule.Key;
                        var screens = companyModule.ToList();

                        foreach (var screen in screens)
                        {
                            modulesAccess.moduleId = screen.moduleId;
                            modulesAccess.isDropdown = screen.isDropdown;
                            AccessScreen accessScreen = new AccessScreen()
                            {
                                screenName = screen.screenName,
                                create = screen.create,
                                read = screen.read,
                                update = screen.update,
                                delete = screen.delete,
                                approve = screen.approve,
                                screenURL = screen.screenURL
                            };
                            // Avoid duplicate screen.
                            if (modulesAccess.Screens.Where(scn => scn.screenName == screen.screenName).ToList().Count() == 0)
                            {
                                modulesAccess.Screens.Add(accessScreen);
                            }
                        }
                        // Avoid duplicate module.
                        if (modulesAccessList.Where(m => m.moduleName == modulesAccess.moduleName).ToList().Count() == 0)
                        {
                            modulesAccessList.Add(modulesAccess);
                        }
                    }
                    var index = companyList.FindIndex(com => com.companyId == module.Key);
                    if (index > -1)
                    {
                        companyList[index].AccessControls = modulesAccessList;
                    }
                }

                //}
            }
            accessControl.CompanyDetails.Companies = companyList;

            // Retrive default company value
            var defaultCompany = await _context.Organisations.Where(org => org.companyId == employeeDetail.companyId).FirstOrDefaultAsync();
            accessControl.CompanyDetails.defaultCompanyId = defaultCompany != null ? defaultCompany.companyId : 0;
            accessControl.CompanyDetails.defaultCompanyName = defaultCompany != null ? defaultCompany.companyName : "";
            var defaultClient = await _context.ClientCreation.Where(client => client.clientId == accessControl.ClientDetails.clientId).FirstOrDefaultAsync();
            if (defaultCompany != null && defaultCompany.makerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsCompanyMaker = true;
            }
            if (defaultCompany != null && defaultCompany.checkerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsCompanyChecker = true;
            }
            if (defaultClient != null && defaultClient.makerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsClientMaker = true;
            }
            if (defaultClient != null && defaultClient.checkerId == accessControl.EmployeeDetails.employeeId)
            {
                accessControl.IsClientChecker = true;
            }
            accessControl.ServerName = GetServerName();
            var accessControlJson = JsonConvert.SerializeObject(accessControl);
            if (accessControlJson == null)
            {
                return NotFound();
            }
            //return System.Text.Json.JsonSerializer.Deserialize<object>(accessControlJson);
            return accessControl;
        }

        [HttpGet("GetEncryptValue/{EmployeeObject}")]
        public async Task<ActionResult<string>> GetEncryptValue(string EmployeeObject)
        {
            string encrypt = "";
            try
            {
                encrypt = Encrypt(EmployeeObject.ToString());
                encrypt = encrypt.Replace("+", "plus").Replace("/", "slash");
            }
            catch (Exception ex)
            {
                return Conflict(new { messge = $"Error: {ex.Message}" });
            }
            return encrypt;
        }

        [HttpGet("GetDecryptValue/{Value}")]
        public async Task<ActionResult<object>> GetDecryptValue(string Value)
        {

            dynamic decrypt;
            try
            {
                Value = Value.Replace("plus", "+").Replace("slash", "/");
                Value = Uri.UnescapeDataString(Value);
                decrypt = Decrypt(Value);
            }
            catch (Exception ex)
            {
                return Conflict(new { messge = $"Error: {ex.Message}" });
            }
            return decrypt;
        }

        [HttpPost()]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> SendEmail(string to, string subject, string html, int companyId)
        {
            try
            {
                // create message
                var email = new MimeMessage();

                if (to.Contains(";"))
                {
                    to.Split(';').ToList().ForEach(recepient =>
                    {
                        if (recepient.Trim() != "")
                        {
                            email.To.Add(MailboxAddress.Parse(recepient));
                        }
                    });
                }
                else
                {
                    email.To.Add(MailboxAddress.Parse(to));
                }
                email.Subject = subject;
                email.Body = new TextPart(TextFormat.Html) { Text = html };

                // send email
                var smtp = new SmtpClient();
                //companyId = 1;
                var emailConfig = await _context.EmailConfigurations.Where(ec => ec.companyId == companyId).FirstOrDefaultAsync();

                if (emailConfig != null)
                {
                    email.From.Add(MailboxAddress.Parse(emailConfig.userName));

                   // smtp.Authenticate(emailConfig.userName, emailConfig.password);
                    email.From.Add(MailboxAddress.Parse(emailConfig.userName));
                    smtp.Connect(emailConfig.host, Convert.ToInt32(emailConfig.port), SecureSocketOptions.StartTls);
                   // var FromAddress = MailboxAddress.Parse(emailConfig.userName);
                   // FromAddress.Name = emailConfig.userName;
                   // email.From.Add(FromAddress);
                    if (!string.IsNullOrEmpty(emailConfig.password) )//&& !string.IsNullOrEmpty(emailConfig.userName))
                    {
                        string Password = Helpers.Helpers.EmailDecrypt(emailConfig.password).ToString();
                        smtp.Authenticate(emailConfig.userName, Password);
                    }
                    smtp.Send(email);
                    smtp.Disconnect(true);
                }
                else
                {
                    return Conflict(new { message = $"Error while sending E-mail: " });
                }

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error while sending E-mail: {ex.Message}" });
            }
            return new { message = "E-mail sent successfully !!!" };
        }

        //SMS 
        [HttpPost()]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> SendSMS(string countryCode, string mobileNumber, string body, int companyId)
        {
            var sms = await _context.SmsConfigurations.Where(ec => ec.companyId == companyId).FirstOrDefaultAsync();
            try
            {
                string API_KEY = sms.apiKey;
                string API_SECRET = sms.apiSecretKey;
                string code = "+"+ countryCode;
               // double TO = Convert.ToDouble(mobileNumber);
                bool isValid = Regex.IsMatch(mobileNumber, @"^\d{10}$");
                if (!isValid)
                {
                    return Conflict(new { message = "Invalid MobileNumber." });

                }
                string Number = countryCode + mobileNumber.ToString();
                string Message = body;
                string sURL = "https://www.thetexting.com/rest/sms/json/message/send?api_key=" + API_KEY + "&api_secret=" + API_SECRET + "&to=" + Number + "&text=" + Message;


                using (WebClient client = new WebClient())
                {
                    string s = client.DownloadString(sURL);
                    return (new { message = "Message Send Successfully!" });
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = "Error in sending Message" });
            }

        }

        [HttpPost()]
        public async Task<object> EmailConfiguration(EmailConfiguration emailConfiguration)
        {
            try
            {
                emailConfiguration.password = Helpers.Helpers.EmailEncrypt(emailConfiguration.password);

                _context.EmailConfigurations.Update(emailConfiguration);

                await _context.SaveChangesAsync();
            }

            catch (DbUpdateException)
            {
                throw;
            }

            var emailConfigurationsJson = JsonConvert.SerializeObject(emailConfiguration);
            return System.Text.Json.JsonSerializer.Deserialize<object>(emailConfigurationsJson);
        }


    }
}