﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterChangesTrackersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public MasterChangesTrackersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/MasterChangesTrackers
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetMasterChangesTrackers()
        {
            var masterChanges = await (from master in _context.MasterChangesTrackers
                                       join status in _context.Statuses on master.status equals status.statusId into Statuses
                                       from statusV in Statuses.DefaultIfEmpty()
                                       join company in _context.Organisations on master.companyId equals company.companyId into Companies
                                       from companyV in Companies.DefaultIfEmpty()
                                       select new
                                       {
                                           master.masterChangesTrackerId,
                                           master.status,
                                           statusV.statusName,
                                           master.companyId,
                                           companyV.companyName,
                                           master.updatedDate,
                                           master.updatedBy,
                                           master.createdBy,
                                           master.createdDate
                                       }
                                       ).ToListAsync();
            var masterChangesJson = JsonConvert.SerializeObject(masterChanges);
            if (masterChanges == null)
            {
                return NotFound();
            }
            ArrayList masterChangesJsonList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(masterChangesJson);
            return masterChangesJsonList;

        }

        // GET: api/MasterChangesTrackers/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetMasterChangesTracker(int id)
        {
            var masterChangesTracker = await _context.MasterChangesTrackers.FindAsync(id);

            if (masterChangesTracker == null)
            {
                return NotFound();
            }
            var masterChangesTrackerJson = JsonConvert.SerializeObject(masterChangesTracker);
            object masterChange = System.Text.Json.JsonSerializer.Deserialize<object>(masterChangesTrackerJson);
            return masterChange;

        }

        // GET: api/GetMasterChangesListForUserId/5
        [HttpGet("GetMasterChangesListForUserId/{UserId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetMasterChangesListForUserId(long UserId)
        {
            var companies = await _context.Organisations.Where(company => company.checkerId == UserId).Select(comp => comp.companyId).ToListAsync();

            if (companies.Count() == 0)
            {
                return Conflict(new { message = "The selected user is not a checker for any company !!!" });
            }
            var mastersList = await (from master in _context.MasterChangesTrackers
                                     where master.status == (int)Statuses.Pending
                                     join status in _context.Statuses on master.status equals status.statusId into Statuses
                                     from statusV in Statuses.DefaultIfEmpty()
                                     join company in _context.Organisations on master.companyId equals company.companyId into Companies
                                     from companyV in Companies.DefaultIfEmpty()
                                     select new
                                     {
                                         master.masterChangesTrackerId,
                                         master.companyId,
                                         companyV.companyName,
                                         master.status,
                                         statusV.statusName,
                                         master.updatedBy,
                                         master.createdBy,
                                         master.updatedDate,
                                         master.createdDate
                                     }
                                     ).ToListAsync();
            if (mastersList.Count == 0)
            {
                return new { };
            }
            List<object> newMastersList = new List<object>();
            if (mastersList.Count > 0)
            {
                mastersList.ForEach(master =>
                {
                    if (companies.IndexOf((long)master.companyId) > -1)
                    {
                        newMastersList.Add(master);
                    }
                });
            }


            var masterChangesTrackerJson = JsonConvert.SerializeObject(mastersList);
            object masterChangesList = System.Text.Json.JsonSerializer.Deserialize<object>(masterChangesTrackerJson);
            return masterChangesList;

        }


        // PUT: api/MasterChangesTrackers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutMasterChangesTracker(int id, MasterChangesTracker masterChangesTracker)
        {
            //if (id != masterChangesTracker.Id)
            //{
            //    return BadRequest();
            //}
            masterChangesTracker.masterChangesTrackerId = id;
            masterChangesTracker.updatedDate = DateTime.UtcNow;
            _context.Entry(masterChangesTracker).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MasterChangesTrackerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated sccessfully !!!" };
            //return NoContent();
        }

        // POST: api/MasterChangesTrackers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostMasterChangesTracker(MasterChangesTracker masterChangesTracker)
        {
            try
            {
                var lastMaster = await _context.MasterChangesTrackers.OrderBy(master => master.masterChangesTrackerId).LastOrDefaultAsync();
                masterChangesTracker.masterChangesTrackerId = lastMaster != null ? lastMaster.masterChangesTrackerId + 1 : 1;
                _context.MasterChangesTrackers.Add(masterChangesTracker);
                masterChangesTracker.updatedDate = DateTime.UtcNow;
                masterChangesTracker.createdDate = masterChangesTracker.updatedDate;
                await _context.SaveChangesAsync();

                var masterChangesJson = JsonConvert.SerializeObject(masterChangesTracker);

                object masterChangesJsonValue = System.Text.Json.JsonSerializer.Deserialize<object>(masterChangesJson);
                return masterChangesJsonValue;
            }
            catch (Exception ex)
            {
                return Conflict(new { message = ex.Message });
            }

            return CreatedAtAction("GetMasterChangesTracker", new { id = masterChangesTracker.masterChangesTrackerId }, masterChangesTracker);
        }

        // DELETE: api/MasterChangesTrackers/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteMasterChangesTracker(int id)
        {
            var masterChangesTracker = await _context.MasterChangesTrackers.FindAsync(id);
            if (masterChangesTracker == null)
            {
                return NotFound();
            }

            _context.MasterChangesTrackers.Remove(masterChangesTracker);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool MasterChangesTrackerExists(int id)
        {
            return _context.MasterChangesTrackers.Any(e => e.masterChangesTrackerId == id);
        }
    }
}
