﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;
using OAuthAPI.models.Helpers;
using OAuthAPI.ActionFilters;
using static OAuthAPI.models.Helpers.Helper;
using Nancy.Json;
using OAuthAPI.Models;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRolesController : ControllerBase
    {
        private readonly Common_Schema_Context _context;
        private readonly ILogger<AccountController> _logger;
        private bool isOwnerCompany = Common_Schema_Context.IsOwnerCompany;

        public UserRolesController(Common_Schema_Context context, ILogger<AccountController> logger)
        {
            _context = context;
            this._logger = logger;
        }

        // GET: api/UserRoles
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetUserRoles(bool GetAll = false)
        {
            var userRoles = await (from UR in _context.UserRoles
                                   join org in _context.Organisations on UR.companyId equals org.companyId into company
                                   from comp in company.DefaultIfEmpty()
                                   select new
                                   {
                                       UR.userRoleId,
                                       UR.roleName,
                                       UR.companyId,
                                       Status = UR.actualStatus,
                                   }
                                   ).ToListAsync();
            if (GetAll == false)
            {
                userRoles = userRoles.Where(UR => UR.Status == "active").ToList();
            }

            var userRolesjson = JsonConvert.SerializeObject(userRoles);
            ArrayList userRoleslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(userRolesjson);
            return userRoleslist;
        }

        // GET: api/GetUserRolesForCompany/1
        [HttpGet("GetUserRolesForCompany/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetUserRolesForCompany(long CompanyId)
        {
            var userRoles = await (from UR in _context.UserRoles
                                   where UR.companyId == CompanyId
                                   select new
                                   {
                                       UR.userRoleId,
                                       UR.roleName,
                                       UR.companyId,
                                       Status = UR.actualStatus,
                                   }
                                   ).ToListAsync();
            //if (GetAll == false)
            //{
            //    userRoles = userRoles.Where(UR => UR.Status == "active").ToList();
            //}

            var userRolesjson = JsonConvert.SerializeObject(userRoles);
            ArrayList userRoleslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(userRolesjson);
            return userRoleslist;
        }

        // GET: api/UserRoles/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetUserRole(long id)
        {
            //var userRoles = await _context.UserRoles.FindAsync(id);
            var userRole = await (from UR in _context.UserRoles
                                  where UR.userRoleId == id
                                  join org in _context.Organisations on UR.companyId equals org.companyId into company
                                  from comp in company.DefaultIfEmpty()
                                  select new
                                  {
                                      UR.userRoleId,
                                      UR.roleName,
                                      UR.createdBy,
                                      UR.createdTime,
                                      UR.updatedBy,
                                      UR.updatedDate,
                                      UR.companyId,
                                      UR.isMultiCompany,
                                      Status = UR.actualStatus,
                                      comp.companyName
                                  }
                                       ).FirstOrDefaultAsync();
            if (userRole == null)
            {
                return NotFound();
            }

            if (userRole.isMultiCompany == true)
            {
                var companies = await _context.RoleOrganisationMappers.Where(roleOrg => roleOrg.roleId == id).ToListAsync();
                var userRoleWithCompanies = new
                {
                    userRole.userRoleId,
                    userRole.roleName,
                    userRole.createdBy,
                    userRole.createdTime,
                    userRole.updatedBy,
                    userRole.updatedDate,
                    userRole.companyId,
                    userRole.isMultiCompany,
                    userRole.companyName,
                    userRole.Status,
                    Companies = companies.Select(comp => comp.companyId).ToList()
                };

                var userRoleWithCompaniesJson = JsonConvert.SerializeObject(userRoleWithCompanies);
                var _userRoleWithCompanies = System.Text.Json.JsonSerializer.Deserialize<object>(userRoleWithCompaniesJson);

                return _userRoleWithCompanies;
            }

            var userRolesjson = JsonConvert.SerializeObject(userRole);
            var _userRoles = System.Text.Json.JsonSerializer.Deserialize<object>(userRolesjson);

            return _userRoles;
        }

        // GET: api/UserRoles/5
        [HttpGet("GetUserRolesForCompanyId/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetUserRolesForCompanyId(long CompanyId)
        {
            //var userRoles = await _context.UserRoles.FindAsync(id);

            var userRoles = await (from UR in _context.UserRoles
                                   where UR.companyId == CompanyId && (UR.actualStatus != null)
                                   join org in _context.Organisations on UR.companyId equals org.companyId into company
                                   from comp in company.DefaultIfEmpty()
                                   where UR.userRoleId != (int)UserRoles.SuperAdmin

                                   select new
                                   {
                                       UR.userRoleId,
                                       UR.roleName,
                                       UR.createdBy,
                                       UR.createdTime,
                                       UR.updatedBy,
                                       UR.updatedDate,
                                       UR.companyId,
                                       UR.isMultiCompany,
                                       Status = UR.actualStatus,
                                       comp.companyName,
                                       CompanyIds = new List<long>()
                                   }
                                       ).ToListAsync();



            if (userRoles == null)
            {
                return NotFound();
            }

            var roleOrgMappers = await _context.RoleOrganisationMappers.ToListAsync();
            userRoles.ForEach((userRole) =>
            {
                if (userRole.isMultiCompany == true)
                {
                    var companies = roleOrgMappers.Where(roleOrg => roleOrg.roleId == userRole.userRoleId);
                    if (companies != null)
                    {
                        foreach (var compan in companies)
                            userRole.CompanyIds.Add((long)compan.companyId);
                    }
                    else
                    {
                        userRole.CompanyIds.Add((long)userRole.companyId);
                    }
                }
                else
                {
                    userRole.CompanyIds.Add((long)userRole.companyId);
                }
            });

            var userRolesjson = JsonConvert.SerializeObject(userRoles);
            var _userRoles = System.Text.Json.JsonSerializer.Deserialize<object>(userRolesjson);

            return _userRoles;
        }

        // GET: api/UserRoles/5
        [HttpGet("GetUsersOfUserRole/{RoleId}/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetUsersOfUserRole(long RoleId, long CompanyId)
        {
            // Fetch the TMI users, company Id for TMI is always 1
            var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(emp => emp.companyId == CompanyId && emp.status != (int)Statuses.Deleted).ToListAsync();
            var userRoles = await _context.UserRoles.ToListAsync();
            List<object> employeesWithRoles = new List<object>();
            employeePersonalDetail.ForEach(emp =>
            {
                List<object> roles = new List<object>();
                if (emp.roleIds != null)
                {
                    int[] roleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
                    var hasRole = roleIds.Where(id => id == RoleId).ToList();
                    if (hasRole.Count() > 0)
                    {
                        var UserRole = _context.UserRoles.Where(r => r.userRoleId == RoleId).Select(r => r.roleName).FirstOrDefault(); // line added by shwetha
                        var empObj = new { EmployeeId = emp.employeePersonalDetailId, EmployeeName = $"{emp.firstName} {emp.lastName}", UserRole };
                        employeesWithRoles.Add(empObj);
                    }
                }

            });
            var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeesWithRoles);
            var employeePersonalDetailsObj = System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            //if (employeePersonalDetail == null)
            //{
            //    return NotFound();
            //}

            return employeePersonalDetailsObj;
        }

        // GET: api/ValidateUserForClientOrCompany/5/1/true
        [HttpGet("ValidateUserForClientOrCompany/{Id}/{IsClient}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ValidateUserForClientOrCompany(long Id, bool IsClient = false)
        {
            if (IsClient == true)
            {
                var clientUsers = await _context.ClientUserRoleMappers.Where(clientUser => clientUser.clientId == Id).ToListAsync();
                if (clientUsers.Count() <= 2)
                {
                    return Conflict(new { message = "User tagged to the client which have minimum users. Add adequate users under client before removing user" });
                }
            }
            else
            {
                var companyUsers = await _context.CompanyUserRoleMappers.Where(companyUser => companyUser.companyId == Id).ToListAsync();
                if (companyUsers.Count() <= 2)
                {
                    return Conflict(new { message = "User tagged to the company which have minimum users. Add adequate users under company before removing user" });
                }
            }

            return new { message = "Active Users present in the User group. Do you still want to disable?" };
        }

        // PUT: api/DisableUser/5/1/true
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("DisableUser/{EmployeeId}/{Id}/{IsClient}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> DisableUser(long EmployeeId, long Id, bool IsClient = false)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            if (IsClient == true)
            {
                var clientUsers = await _context.ClientUserRoleMappers.Where(clientUser => clientUser.clientId == Id && clientUser.status == (int)Statuses.Approved).ToListAsync();
                if (clientUsers.Count() <= 2)
                {
                    return Conflict(new { message = "User tagged to the client which have minimum users. Add adequate users under client before removing user" });
                }
                var clientUser = await _context.ClientUserRoleMappers.Where(clientUser => clientUser.clientId == Id && clientUser.employeeId == EmployeeId).FirstOrDefaultAsync();
                if (clientUser == null)
                {
                    return Conflict(new { message = "User does not exist !!!" });
                }
                clientUser.status = (int)Statuses.Deleted;
                clientUser.updatedDate = DateTime.UtcNow;
                clientUser.updatedBy = userEmail;
                _context.Entry(clientUser).State = EntityState.Modified;
            }
            else
            {
                var companyUsers = await _context.CompanyUserRoleMappers.Where(companyUser => companyUser.companyId == Id && companyUser.status == (int)Statuses.Approved).ToListAsync();
                if (companyUsers.Count() <= 2)
                {
                    return Conflict(new { message = "User tagged to the company which have minimum users. Add adequate users under company before removing user" });
                }
                var companyUser = await _context.CompanyUserRoleMappers.Where(companyUser => companyUser.companyId == Id && companyUser.employeeId == EmployeeId).FirstOrDefaultAsync();
                if (companyUser == null)
                {
                    return Conflict(new { message = "User does not exist !!!" });
                }
                companyUser.status = (int)Statuses.Deleted;
                companyUser.updatedDate = DateTime.UtcNow;
                companyUser.updatedBy = userEmail;
                _context.Entry(companyUser).State = EntityState.Modified;
            }
            await _context.SaveChangesAsync();
            return new { message = "User Disabled successfully !!!" };
        }



        // PUT: api/ValidateUserRoles
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ValidateUserRoles/{Status}/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> ValidateUserRoles(List<long> UserRoleIds, string Status, long CompanyId)
        {
            try
            {
                string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
                if (Status.ToLower() == "inactive" || Status.ToLower() == "deleted")
                {
                    // Commented below line by Srinivas for 
                    //var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(emp => emp.CompanyId == CompanyId).ToListAsync();
                    // 
                    var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(c => c.companyId == CompanyId ).ToListAsync();

                    // Select client users for role id
                    var clientUsersForRoleId = _context.ClientUserRoleMappers.ToList();

                    // Select company users for role id
                    //  var companyUsersForRoleId = _context.CompanyUserRoleMappers.Where(c => c.companyId == CompanyId).ToList();
                    var companyUsersForRoleId = _context.CompanyUserRoleMappers.ToList();


                    List<ValidatedUser> validatedUsers = new List<ValidatedUser>();
                    UserRoleIds.ForEach(roleId =>
                    {
                        //var Reqemp = _context.EmployeePersonalDetails.Where(d => d.status != (int)Statuses.Deleted && d.roleId ==roleId).ToList();
                        //var groupWithNoUsers = _context.EmployeePersonalDetails.Where(d => d.roleId == roleId && d.status != (int)Statuses.Deleted).ToList();
                        int groupWithNoUsers = 0;
                        var emp1 =  _context.EmployeePersonalDetails.Where(c => c.companyId == CompanyId && c.status != (int)Statuses.Deleted).ToList();
                        emp1.ForEach(emp =>
                        {
                            var RoleIds1 = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
                            foreach (var x in RoleIds1)
                            {
                                var Reqemp = _context.EmployeePersonalDetails.Where(d => d.status != (int)Statuses.Deleted && x == roleId).ToList();
                                if(Reqemp.Count() > 0)
                                {
                                    groupWithNoUsers++;
                                }
                            }
                        });
                         //var groupWithNoUsers = Reqemp.
                            if (groupWithNoUsers != 0)     //added now
                                {
                                    var userRole = _context.UserRoles.Where(ur => ur.userRoleId == roleId).FirstOrDefault();
                                    var intEmpCount = 0;
                                    var intRoleCount = 0;
                                    //var selectedroles = employeePersonalDetail.Where(ed => ed.RoleIds.Replace("[", "").Replace("]", "").Split(new char[] { ',' }).Any(code => code.Trim() == roleId.ToString()));
                                    employeePersonalDetail.ForEach(emp =>
                                    {
                                        var RoleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
                                        if (RoleIds != null)
                                        {
                                            if (RoleIds.Count() > 1)
                                            {
                                                var validatedValue1 = RoleIds.ToList().Where(rId => rId == roleId).ToList();
                                                if (validatedValue1.Count() > 0)
                                                {
                                                    intRoleCount++;
                                                }
                                            }
                                            var validatedValue = RoleIds.ToList().Where(rId => rId == roleId).ToList();
                                            if (validatedValue.Count() > 0)
                                            {
                                                intEmpCount++;
                                            }
                                        }
                                    });
                                    var s = (from ss in _context.ClientCreation where ss.isOwnerClient != true select new { ss.clientId }).ToList();  //added now

                                    var intClient = (from sss in s
                                                     join f in _context.ClientUserRoleMappers.Where(c => c.roleId == roleId)
                                                     on sss.clientId equals f.clientId
                                                     select new
                                                     {
                                                         f.clientId,
                                                         f.roleId
                                                     }).ToList();    //added now
                                                                     //var intClient = clientUsersForRoleId.Count(ed => ed.roleId == roleId);
                                                                     //var intCompany = companyUsersForRoleId.Count(ed => ed.roleId == roleId);
                                    var t = (from ss in _context.Organisations where ss.isOwnerCompany != true select new { ss.companyId }).ToList(); //added now
                                    var intCompany = (from ttt in t
                                                      join g in _context.CompanyUserRoleMappers.Where(c => c.roleId != roleId)
                                                      on ttt.companyId equals g.companyId
                                                      select new
                                                      {
                                                          g.companyId,
                                                          g.roleId
                                                      }).ToList();   //added now
                                    var comp = _context.CompanyUserRoleMappers.Where(cu => cu.companyId != 1 && cu.roleId == roleId && cu.status != (int)Statuses.Deleted).ToList();
                                    // var s = (from ss in _context.Organisations where ss.companyId == CompanyId select new { ss.clientId }).ToList();

                                    var ncl = _context.ClientUserRoleMappers.Where(_cu => _cu.roleId == roleId && _cu.clientId != 1 && _cu.status != (int)Statuses.Deleted).ToList();

                                    // var clu = (from ss in s join clu1 in _context.ClientUserRoleMappers on ss.clientId  equals clu1.clientId select clu1).ToList();

                                    // var clu2 =
                                    // var comp1 = _context.CompanyUserRoleMappers.Where(a =>a.roleId == roleId && a.companyId != 1)
                                    var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                                    (c.isAllowedToClient == true && isOwnerCompany == false)))
                                                       select screenc;
                                    List<String> singleChecks = new List<String>();
                                    List<String> singleMakes = new List<String>();

                                    var singleOutputM = (from cm in _context.ScreenPermissions
                                                         where cm.roleId == roleId
                                                         join sc in screenCountC on cm.screenId equals sc.screenId
                                                         select new
                                                         {
                                                             sc.screenId,
                                                             createPermission = cm.create,
                                                             approvePermission = cm.approve,
                                                             // createPermission = (cm.create == true ? 1 : 0)
                                                             // approvePermission = (cm.approve == true ? 1 : 0),
                                                         }).ToList();
                                    var singleTestM = from singleMaker in singleOutputM.Where(m => m.createPermission == true) select singleMaker;
                                    //condition for checker
                                    var singleTestC = from singleM in singleOutputM where singleM.approvePermission == true select singleM;

                                    //if  maker
                                    if (singleTestM.Count() != 0)
                                    {
                                        String singleMake = singleTestM.ToString();
                                        singleMakes.Add(singleMake);
                                    }
                                    //if checker
                                    if (singleTestC.Count() != 0)
                                    {
                                        String singleCheck = singleTestC.ToString();
                                        singleChecks.Add(singleCheck);
                                    }

                                    var intClient1 = clientUsersForRoleId.Where(ed => ed.roleId == roleId && ed.clientId != 1).ToList();
                                    var eid = _context.ClientUserRoleMappers.Where(c => c.roleId == roleId && c.clientId != 1).Select(c => c.employeeId).FirstOrDefault();
                                    var intCompany1 = companyUsersForRoleId.Where(ed => ed.roleId == roleId && ed.companyId != 1).ToList();
                                    var cid = _context.CompanyUserRoleMappers.Where(c => c.roleId == roleId && c.companyId != 1).Select(c => c.employeeId).FirstOrDefault();
                                    List<String> less = new List<String>();
                                    List<String> grt = new List<String>();

                                    foreach (var cln in intClient1)
                                    {
                                        var l = _context.ClientUserRoleMappers.Where(ll => ll.clientId == cln.clientId && ll.employeeId != eid && ll.status == (int)Statuses.Approved).ToList();
                                        if (l.Count() < 2)
                                        {
                                            String les = l.ToString();
                                            less.Add(les);
                                        }
                                        if (l.Count() >= 2)
                                        {
                                            List<String> checks = new List<String>();
                                            List<String> makes = new List<String>();
                                            foreach (var lll in l)
                                            {
                                                var outputM = (from cm in _context.ScreenPermissions
                                                               where cm.roleId == lll.roleId
                                                               join sc in screenCountC on cm.screenId equals sc.screenId
                                                               select new
                                                               {
                                                                   sc.screenId,
                                                                   createPermission = cm.create,
                                                                   approvePermission = cm.approve,
                                                                   // createPermission = (cm.create == true ? 1 : 0)
                                                                   // approvePermission = (cm.approve == true ? 1 : 0),
                                                               }).ToList();

                                                // condition for make
                                                var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                                                //condition for checker
                                                var testC = from m in outputM where m.approvePermission == true select m;

                                                //if  maker
                                                if (testM.Count() != 0)
                                                {
                                                    String make = testM.ToString();
                                                    makes.Add(make);
                                                }
                                                //if checker
                                                if (testC.Count() != 0)
                                                {
                                                    String check = testC.ToString();
                                                    checks.Add(check);
                                                }

                                            }
                                            if ((singleChecks.Count() > 0 || singleMakes.Count() > 0))
                                            {
                                                if (singleMakes.Count() > 0 && makes.Count() == 0)
                                                {
                                                    String greater = l.ToString();
                                                    grt.Add(greater);
                                                }

                                                if ((singleChecks.Count() > 0 && checks.Count() == 0))
                                                {
                                                    String greater = l.ToString();
                                                    grt.Add(greater);
                                                }
                                            }

                                        }

                                    }
                                    List<String> lessc = new List<String>();
                                    List<String> grtc = new List<String>();

                                    foreach (var com in intCompany1)
                                    {
                                        var l1 = _context.CompanyUserRoleMappers.Where(ll => ll.companyId == com.companyId && ll.employeeId != cid && ll.status == (int)Statuses.Approved).ToList();
                                        if (l1.Count() < 2)
                                        {
                                            String les = l1.ToString();
                                            lessc.Add(les);
                                        }
                                        if (l1.Count() >= 2)
                                        {
                                            List<String> checks = new List<String>();
                                            List<String> makes = new List<String>();
                                            foreach (var lll in l1)
                                            {
                                                var outputM = (from cm in _context.ScreenPermissions
                                                               where cm.roleId == lll.roleId
                                                               join sc in screenCountC on cm.screenId equals sc.screenId
                                                               select new
                                                               {
                                                                   sc.screenId,
                                                                   createPermission = cm.create,
                                                                   approvePermission = cm.approve,
                                                                   // createPermission = (cm.create == true ? 1 : 0)
                                                                   // approvePermission = (cm.approve == true ? 1 : 0),
                                                               }).ToList();

                                                // condition for make
                                                var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                                                //condition for checker
                                                var testC = from m in outputM where m.approvePermission == true select m;

                                                //if  maker
                                                if (testM.Count() != 0)
                                                {
                                                    String make = testM.ToString();
                                                    makes.Add(make);
                                                }
                                                //if checker
                                                if (testC.Count() != 0)
                                                {
                                                    String check = testC.ToString();
                                                    checks.Add(check);
                                                }

                                            }
                                            if ((singleChecks.Count() > 0 || singleMakes.Count() > 0))
                                            {
                                                if (singleMakes.Count() > 0 && makes.Count() == 0)
                                                {
                                                    String greater = l1.ToString();
                                                    grtc.Add(greater);
                                                }

                                                if ((singleChecks.Count() > 0 && checks.Count() == 0))
                                                {
                                                    String greater = l1.ToString();
                                                    grtc.Add(greater);
                                                }
                                            }

                                        }

                                    }
                                    if (less.Count() > 0)
                                    {
                                        validatedUsers.Add(new
                                                     ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                                        });
                                    }
                                    else if (grt.Count() > 0)
                                    {

                                        validatedUsers.Add(new
                                                       ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                                        });
                                    }
                                    else if (lessc.Count() > 0)
                                    {
                                        validatedUsers.Add(new
                                                     ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                                        });
                                    }
                                    else if (grtc.Count() > 0)
                                    {

                                        validatedUsers.Add(new
                                                       ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                                        });
                                    }
                                    else if (intRoleCount > 0)
                                    {
                                        validatedUsers.Add(new ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Active Users present in the User group. Do you still want to disable?"
                                        });
                                    }
                                    else if (comp.Count() == 0)
                                    {
                                        validatedUsers.Add(new ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Active Users present in the User group. Do you still want to disable?"
                                        });
                                    }
                                    else if (ncl.Count() == 0)
                                    {
                                        validatedUsers.Add(new ValidatedUser
                                        {
                                            roleId = roleId,
                                            roleName = userRole.roleName,
                                            message = "Active Users present in the User group. Do you still want to disable?"
                                        });
                                    }

                                    //else if ((intClient > 0 && intClient <= 2) || (intCompany > 0 && intCompany <= 2))
                                    //{
                                    //    validatedUsers.Add(new
                                    //                  ValidatedUser
                                    //    {
                                    //        roleId = roleId,
                                    //        roleName = userRole.roleName,
                                    //        message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group1."
                                    //    });

                                    //}
                                    //else if (intEmpCount > 0 && intClient == 0 && intCompany == 0)
                                    //{
                                    //    validatedUsers.Add(new ValidatedUser
                                    //    {
                                    //        roleId = roleId,
                                    //        roleName = userRole.roleName,
                                    //        message = "Active Users present in the User group. Do you still want to disable?"
                                    //    });
                                    //}

                                    //else if ((intClient > 2) || (intCompany > 2) || (intEmpCount > 0))
                                    //{
                                    //    var ClientsForRole = clientUsersForRoleId.Where(e => e.roleId == roleId).DistinctBy(e => e.clientId);
                                    //    var CompanyForRole = companyUsersForRoleId.Where(ed => ed.roleId == roleId).DistinctBy(e => e.companyId);

                                    //    var Clients = clientUsersForRoleId.Where(_ => ClientsForRole.Any(a => a.clientId == _.clientId && _.roleId != roleId && _.roleId != null))
                                    //    .Join(_context.ClientCreation, e => e.clientId, c => c.clientId, (e, c) => new { e.clientId, e.roleId, c.clientName })
                                    //    .DistinctBy(e => e.clientId)
                                    //    .Select(g => g.clientName);

                                    //    var Companies = companyUsersForRoleId.Where(_ => CompanyForRole.Any(a => a.companyId == _.companyId && _.roleId != roleId && _.roleId != null))
                                    //     .Join(_context.Organisations, e => e.companyId, c => c.companyId, (e, c) => new { e.companyId, e.roleId, c.companyName })
                                    //     .DistinctBy(e => e.companyId)
                                    //     .Select(g => g.companyName);
                                    //    if (Clients.Count() != ClientsForRole.Count() || Companies.Count() != CompanyForRole.Count())
                                    //    {
                                    //        var ClientNames = string.Join(", ", Clients);
                                    //        ClientNames = ClientNames == null ? string.Empty : "<Clients : " + ClientNames + ">";

                                    //        var CompanyNames = string.Join(", ", Companies);
                                    //        CompanyNames = CompanyNames == null ? string.Empty : "<Companies : " + CompanyNames + ">";
                                    //        validatedUsers.Add(new ValidatedUser
                                    //        {
                                    //            roleId = roleId,
                                    //            roleName = userRole.roleName,
                                    //            message = "Adequate users under client/company exist for the same user group. Add adequate users under company/client to disable this user group." + ClientNames + CompanyNames
                                    //        });

                                    //    }
                                    //    else
                                    //    {
                                    //        validatedUsers.Add(new ValidatedUser
                                    //        {
                                    //            roleId = roleId,
                                    //            roleName = userRole.roleName,
                                    //            message = "Active Users present in the User group. Do you still want to disable?"
                                    //        });
                                    //    }
                                    //}
                                    // Commented these lines by Srinivas and simplified the code

                                    //employeePersonalDetail.ForEach(emp =>
                                    //{
                                    //    var RoleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.RoleIds);
                                    //    if (RoleIds != null)
                                    //    {
                                    //        // Check whether the user role has active users
                                    //        var validatedValue = RoleIds.ToList().Where(rId => rId == roleId  ).ToList();
                                    //        if (validatedValue.Count() > 0)
                                    //        {
                                    //            if (validatedUsers.Where(vUser => vUser.RoleId != emp.RoleId).ToList().Count() == 0)
                                    //            {
                                    //                if (validatedUsers.Where(vUser => vUser.RoleId == roleId).ToList().Count() == 0)
                                    //                {
                                    //                    validatedUsers.Add(new ValidatedUser { RoleId = roleId, RoleName = userRole.RoleName,
                                    //                     Message = "Active Users present in the User group. Do you still want to " + (Status.ToLower() == "inactive" ? "disable" : "delete") + "?" });
                                    //                }
                                    //            }

                                    //            // Select client users for role id
                                    //            var clientUsersForRoleId = _context.ClientUserRoleMappers.Where(clientUser => clientUser.RoleId == roleId).ToList();

                                    //            // Select client users other than role id
                                    //            var clientUsersWithoutRoleId = clientUsersForRoleId.Where(user => user.RoleId != roleId).ToList();

                                    //            // Select company users for role id
                                    //            var companyUsersForRoleId = _context.CompanyUserRoleMappers.Where(companyUser => companyUser.RoleId == roleId).ToList();

                                    //            // Select company users other than role id
                                    //            var companyUsersWithoutRoleId = companyUsersForRoleId.Where(user => user.RoleId != roleId).ToList();

                                    //            if (clientUsersWithoutRoleId.Count() < 2)
                                    //            {
                                    //                if (validatedUsers.Where(vUser => vUser.RoleId == roleId).ToList().Count() == 0)
                                    //                {
                                    //                    validatedUsers.Add(new
                                    //                ValidatedUser
                                    //                    {
                                    //                        RoleId = roleId,
                                    //                        RoleName = userRole.RoleName,
                                    //                        Message = "Users in User groups are tagged to the client which have minimum users." +
                                    //                    " Add adequate users under client before " + (Status.ToLower() == "inactive" ? "disabling" : "deleting") + " the User group."
                                    //                    });
                                    //                }
                                    //            }
                                    //            if (companyUsersWithoutRoleId.Count() < 2)
                                    //            {
                                    //                if (validatedUsers.Where(vUser => vUser.RoleId == roleId).ToList().Count() == 0)
                                    //                {
                                    //                    validatedUsers.Add(new
                                    //             ValidatedUser
                                    //                    {
                                    //                        RoleId = roleId,
                                    //                        RoleName = userRole.RoleName,
                                    //                        Message = "Users in User groups are tagged to the company which have minimum users." +
                                    //                    " Add adequate users under company before " + (Status.ToLower() == "inactive" ? "disabling" : "deleting") + " the User group."
                                    //                    });
                                    //                }
                                    //            }
                                    //        }
                                    //        else
                                    //        {
                                    //            var selectUserRole = _context.UserRoles.Where(ur => ur.Id == roleId).FirstOrDefault();
                                    //            if ((Status.ToLower() == "inactive" || Status.ToLower() == "deleted") && selectUserRole != null)
                                    //            {

                                    //                selectUserRole.ActualStatus = Status.ToLower();
                                    //                selectUserRole.UpdatedDate = DateTime.UtcNow;
                                    //                selectUserRole.UpdatedBy = userEmail;
                                    //                _context.Entry(selectUserRole).State = EntityState.Modified;
                                    //                //_context.SaveChanges();

                                    //            }

                                    //        }
                                    //    }
                                    //});
                                }
                            //}
                        //});

                    });
                        if (validatedUsers.Count() > 0)
                        {
                            return Conflict(new { message = "There are some conflicts", content = validatedUsers });
                        }
                    }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return new { message = "OK" };
        }
        // PUT: api/ValidateUserRoles/1/1/1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ValidateUserToRemove/{EmployeeId}/{RoleId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> ValidateUserToRemove(long EmployeeId, long RoleId)

        {
            try
            {
                string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
                //var er = _context.EmployeePersonalDetails.Where(err => err.employeePersonalDetailId == EmployeeId && err.roleId == RoleId).FirstOrDefault();
                //var RoleIds = new JavaScriptSerializer().Deserialize<int[]>(er.roleIds).ToList();

                var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                          (c.isAllowedToClient == true && isOwnerCompany == false)))
                                   select screenc;

                List<String> singleChecks = new List<String>();
                List<String> singleMakes = new List<String>();

                var singleOutputM = (from cm in _context.ScreenPermissions
                                     where cm.roleId == RoleId
                                     join sc in screenCountC on cm.screenId equals sc.screenId
                                     select new
                                     {
                                         sc.screenId,
                                         createPermission = cm.create,
                                         approvePermission = cm.approve,
                                         // createPermission = (cm.create == true ? 1 : 0)
                                         // approvePermission = (cm.approve == true ? 1 : 0),
                                     }).ToList();
                var singleTestM = from singleMaker in singleOutputM.Where(m => m.createPermission == true) select singleMaker;
                //condition for checker
                var singleTestC = from singleM in singleOutputM where singleM.approvePermission == true select singleM;

                //if  maker
                if (singleTestM.Count() != 0)
                {
                    String singleMake = singleTestM.ToString();
                    singleMakes.Add(singleMake);
                }
                //if checker
                if (singleTestC.Count() != 0)
                {
                    String singleCheck = singleTestC.ToString();
                    singleChecks.Add(singleCheck);
                }
                //var client =  _context.ClientCreation.Where(f => f.isOwnerClient != true).ToList();
                //var client = _context.ClientCreation.Where(r => r.isOwnerClient != true).Select(r => r.clientId).FirstOrDefault();

                //var clientUser = _context.ClientUserRoleMappers.Where(c => c.roleId == RoleId && c.employeeId == EmployeeId).ToList();
                var s = (from ss in _context.ClientCreation where ss.isOwnerClient != true select new { ss.clientId }).ToList();

                var clientUser = (from sss in s
                                  join f in _context.ClientUserRoleMappers.Where(c => c.roleId == RoleId && c.employeeId == EmployeeId)
                                  on sss.clientId equals f.clientId
                                  select new
                                  {
                                      f.clientId
                                  }).ToList();

                List<ValidatedUser> validatedUsers = new List<ValidatedUser>();

                List<String> less = new List<String>();
                List<String> grt = new List<String>();

                if (clientUser.Count() != 0)
                {
                    foreach (var cln in clientUser)
                    {
                        var l = _context.ClientUserRoleMappers.Where(ll => ll.clientId == cln.clientId && ll.employeeId != EmployeeId && ll.status == (int)Statuses.Approved).ToList();
                        if (l.Count() < 2)
                        {
                            String les = l.ToString();
                            less.Add(les);
                        }
                        if (l.Count() >= 2)
                        {
                            List<String> checks = new List<String>();
                            List<String> makes = new List<String>();

                            foreach (var lll in l)
                            {
                                var outputM = (from cm in _context.ScreenPermissions
                                               where cm.roleId == lll.roleId
                                               join sc in screenCountC on cm.screenId equals sc.screenId
                                               select new
                                               {
                                                   sc.screenId,
                                                   createPermission = cm.create,
                                                   approvePermission = cm.approve,
                                                   // createPermission = (cm.create == true ? 1 : 0)
                                                   // approvePermission = (cm.approve == true ? 1 : 0),
                                               }).ToList();

                                // condition for make
                                var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                                //condition for checker
                                var testC = from m in outputM where m.approvePermission == true select m;

                                //if  maker
                                if (testM.Count() != 0)
                                {
                                    String make = testM.ToString();
                                    makes.Add(make);
                                }
                                //if checker
                                if (testC.Count() != 0)
                                {
                                    String check = testC.ToString();
                                    checks.Add(check);
                                }

                            }
                            if ((singleChecks.Count() > 0 || singleMakes.Count() > 0))
                            {
                                if (singleMakes.Count() > 0 && makes.Count() == 0)
                                {
                                    String greater = l.ToString();
                                    grt.Add(greater);
                                }

                                if ((singleChecks.Count() > 0 && checks.Count() == 0))
                                {
                                    String greater = l.ToString();
                                    grt.Add(greater);
                                }
                            }

                        }
                    }
                    //var getClientUsers = await _context.ClientUserRoleMappers.Where(c => c.clientId == clientUser.clientId).ToListAsync();
                    //var roleData = await _context.UserRoles.Where(r => r.userRoleId == clientUser.roleId).FirstOrDefaultAsync();
                    //if (getClientUsers.Count <= 2)
                    //{
                    //    ValidatedUser vUser = new ValidatedUser
                    //    {
                    //        roleName = roleData != null ? roleData.roleName : "",
                    //        roleId = clientUser.roleId,
                    //        message = "Users in User groups are tagged to the company/client which have minimum users." +
                    //                        " Add adequate users under company/client before disabling the User2."
                    //    };
                    //    validatedUsers.Add(vUser);
                    //}

                }
                var t = (from ss in _context.Organisations where ss.isOwnerCompany != true select new { ss.companyId }).ToList();

                var companyUser = (from ttt in t
                                   join g in _context.CompanyUserRoleMappers.Where(c => c.roleId == RoleId && c.employeeId == EmployeeId)
                                   on ttt.companyId equals g.companyId
                                   select new
                                   {
                                       g.companyId
                                   }).ToList();
                //var companyUser = _context.CompanyUserRoleMappers.Where(c => c.roleId == RoleId && c.employeeId == EmployeeId).ToList();
                List<String> lessc = new List<String>();
                List<String> grtc = new List<String>();
                if (companyUser.Count() != 0)
                {


                    foreach (var com in companyUser)
                    {
                        var l1 = _context.CompanyUserRoleMappers.Where(ll => ll.companyId == com.companyId && ll.employeeId != EmployeeId && ll.status == (int)Statuses.Approved).ToList();
                        if (l1.Count() < 2)
                        {
                            String les = l1.ToString();
                            lessc.Add(les);
                        }
                        if (l1.Count() >= 2)
                        {
                            List<String> checks = new List<String>();
                            List<String> makes = new List<String>();

                            foreach (var lll in l1)
                            {
                                var outputM = (from cm in _context.ScreenPermissions
                                               where cm.roleId == lll.roleId
                                               join sc in screenCountC on cm.screenId equals sc.screenId
                                               select new
                                               {
                                                   sc.screenId,
                                                   createPermission = cm.create,
                                                   approvePermission = cm.approve,
                                                   // createPermission = (cm.create == true ? 1 : 0)
                                                   // approvePermission = (cm.approve == true ? 1 : 0),
                                               }).ToList();

                                // condition for make
                                var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                                //condition for checker
                                var testC = from m in outputM where m.approvePermission == true select m;

                                //if  maker
                                if (testM.Count() != 0)
                                {
                                    String make = testM.ToString();
                                    makes.Add(make);
                                }
                                //if checker
                                if (testC.Count() != 0)
                                {
                                    String check = testC.ToString();
                                    checks.Add(check);
                                }

                            }
                            if ((singleChecks.Count() > 0 || singleMakes.Count() > 0))
                            {
                                if (singleMakes.Count() > 0 && makes.Count() == 0)
                                {
                                    String greater = l1.ToString();
                                    grtc.Add(greater);
                                }

                                if ((singleChecks.Count() > 0 && checks.Count() == 0))
                                {
                                    String greater = l1.ToString();
                                    grtc.Add(greater);
                                }
                            }

                        }

                    }
                }

                //var getCompanyUsers = await _context.CompanyUserRoleMappers.Where(c => c.companyId == companyUser.companyId).ToListAsync();
                //var roleData = await _context.UserRoles.Where(r => r.userRoleId == companyUser.roleId).FirstOrDefaultAsync();
                //if (getCompanyUsers.Count <= 2)
                //{
                //    ValidatedUser vUser = new ValidatedUser
                //    {
                //        roleName = roleData != null ? roleData.roleName : "",
                //        roleId = companyUser.roleId,
                //        message = $"Users in User groups are tagged to the company/client which have minimum users." +
                //                        " Add adequate users under company/client before disabling the User3."
                //    };
                //    validatedUsers.Add(vUser);
                //}
                if (less.Count() > 0)
                {
                    var userRole = _context.UserRoles.Where(u => u.userRoleId == RoleId).FirstOrDefault();

                    validatedUsers.Add(new
                                 ValidatedUser
                    {
                        roleId = RoleId,
                        roleName = userRole.roleName,
                        message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                    });
                }
                else if (grt.Count() > 0)
                {

                    var userRole = _context.UserRoles.Where(u => u.userRoleId == RoleId).FirstOrDefault();

                    validatedUsers.Add(new
                                 ValidatedUser
                    {
                        roleId = RoleId,
                        roleName = userRole.roleName,
                        message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                    });
                }
                else if (lessc.Count() > 0)
                {
                    var userRole = _context.UserRoles.Where(u => u.userRoleId == RoleId).FirstOrDefault();

                    validatedUsers.Add(new
                                 ValidatedUser
                    {
                        roleId = RoleId,
                        roleName = userRole.roleName,
                        message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                    });
                }
                else if (grtc.Count() > 0)
                {

                    var userRole = _context.UserRoles.Where(u => u.userRoleId == RoleId).FirstOrDefault();

                    validatedUsers.Add(new
                                 ValidatedUser
                    {
                        roleId = RoleId,
                        roleName = userRole.roleName,
                        message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
                    });
                }



                if (validatedUsers.Count() > 0)
                {
                    return Conflict(new { message = "There are some conflicts", content = validatedUsers });
                }

            }

            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return new { message = "OK" };
        }

        // PUT: api/RemoveUserRoleFromUser/1/1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("RemoveUserRoleFromUser/{EmployeeId}/{RoleId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> RemoveUserRoleFromUser(long EmployeeId, int RoleId)
        {
            try
            {
                string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);

                var employee = await _context.EmployeePersonalDetails.Where(e => e.employeePersonalDetailId == EmployeeId).FirstOrDefaultAsync();
                if (employee == null)
                {
                    return Conflict(new { message = "Employee does not exist !!!" });
                }
                else
                {
                    var clientUser = await _context.ClientUserRoleMappers.Where(c => c.employeeId == EmployeeId && c.roleId == RoleId && c.clientId != 1).FirstOrDefaultAsync();
                    if (clientUser != null)
                    {
                        clientUser.status = (int)Statuses.Deleted;
                        _context.ClientUserRoleMappers.Update(clientUser);
                    }

                    var companyUser = await _context.CompanyUserRoleMappers.Where(c => c.employeeId == EmployeeId && c.roleId == RoleId && c.companyId != 1).FirstOrDefaultAsync();
                    if (companyUser != null)
                    {
                        companyUser.status = (int)Statuses.Deleted;
                        _context.CompanyUserRoleMappers.Update(companyUser);
                    }
                    if (employee.roleIds != null)
                    {
                        int[] RoleIds = new JavaScriptSerializer().Deserialize<int[]>(employee.roleIds);

                        var RoleIds1 = new JavaScriptSerializer().Deserialize<int[]>(employee.roleIds);
                        if (RoleIds1.Count() > 1)
                        {
                            int numIndex = Array.IndexOf(RoleIds1, RoleId);
                            RoleIds = RoleIds.Where((val, idx) => idx != numIndex).ToArray();
                            string roles1 = "[]";
                            if (RoleIds.Length > 0)
                            {
                                roles1 = $"[{string.Join(",", RoleIds)}]";
                            }
                            employee.roleIds = roles1;
                            employee.roleId = RoleIds[0];
                            employee.updatedBy = userEmail;
                            employee.updatedDate = DateTime.UtcNow;
                            // employee.status = (int)Statuses.Deleted;
                            _context.Entry(employee).State = EntityState.Modified;
                        }
                        else
                        {
                            int numIndex = Array.IndexOf(RoleIds, RoleId);
                            RoleIds = RoleIds.Where((val, idx) => idx != numIndex).ToArray();
                            string roles = "[]";

                            if (RoleIds.Length > 0)
                            {
                                roles = $"[{string.Join(",", RoleIds)}]";
                            }
                            employee.roleId = 0;
                            employee.roleIds = roles;
                            employee.updatedBy = userEmail;
                            employee.updatedDate = DateTime.UtcNow;
                            employee.status = (int)Statuses.Deleted;
                            _context.Entry(employee).State = EntityState.Modified;
                        }
                    }


                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }
            return new { message = "User Removed Successfully !!!" };
        }

        // PUT: api/ChangeUserRoleStatus/5/1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeUserRoleStatus/{Status}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> ChangeUserRoleStatus(string Status, List<long> UserRoleIds)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            if (Status.ToLower() == "active" || Status.ToLower() == "inactive" || Status.ToLower() == "deleted")
            {
                //UserRoleIds.ForEach(roleId =>
                //{
                //    var userRole = _context.UserRoles.Where(ur => ur.userRoleId == roleId).FirstOrDefault();
                //    userRole.actualStatus = Status.ToLower();
                //    userRole.updatedDate = DateTime.UtcNow;
                //    userRole.updatedBy = userEmail;
                //    _context.Entry(userRole).State = EntityState.Modified;
                //});

                UserRoleIds.ForEach(roleId =>
                {
                    var employeePersonalDetail = _context.EmployeePersonalDetails.Where(e => e.roleId == roleId).ToList();

                    var clientuserroleid = _context.ClientUserRoleMappers.Where(e => e.roleId == roleId).ToList();

                    var companyuserroleid = _context.CompanyUserRoleMappers.Where(e => e.roleId == roleId).ToList();

                    var userRole = _context.UserRoles.Where(ur => ur.userRoleId == roleId).FirstOrDefault();

                    //var selectedroles = employeePersonalDetail.Where(ed => ed.RoleIds.Replace("[", "").Replace("]", "").Split(new char[] { ',' }).Any(code => code.Trim() == roleId.ToString()));
                    employeePersonalDetail.ForEach(emp =>
                    {
                        var RoleIds1 = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
                        if (RoleIds1.Count() != 0)
                        {
                            int[] RoleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);

                            // var RoleIds1 = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
                            if (RoleIds1.Count() > 1)
                            {
                                int numIndex = Array.IndexOf(RoleIds, roleId);
                                numIndex++;
                                //  RoleIds = RoleIds.Where((val, idx) => idx != numIndex).ToArray();
                                RoleIds = RoleIds.Where(val => val != roleId).ToArray();
                                string roles1 = "[]";
                                if (RoleIds.Length > 0)
                                {
                                    roles1 = $"[{string.Join(",", RoleIds)}]";
                                }
                                emp.roleIds = roles1;
                                emp.roleId = RoleIds[0];
                                emp.updatedBy = userEmail;
                                emp.updatedDate = DateTime.UtcNow;
                                // employee.status = (int)Statuses.Deleted;
                                _context.Entry(emp).State = EntityState.Modified;
                            }
                            else
                            {
                                int numIndex = Array.IndexOf(RoleIds, roleId);
                                RoleIds = RoleIds.Where((val, idx) => idx != numIndex).ToArray();
                                string roles = "[]";
                                if (RoleIds.Length > 0)
                                {
                                    roles = $"[{string.Join(",", RoleIds)}]";
                                }
                                emp.roleIds = roles;
                                emp.updatedBy = userEmail;
                                emp.updatedDate = DateTime.UtcNow;
                                emp.status = (int)Statuses.Deleted;

                                _context.Entry(emp).State = EntityState.Modified;

                            }
                        }

                    });
                    if (Status.ToLower() == "active")
                    {
                        foreach (var id in clientuserroleid)
                        {
                            id.status = (int)Statuses.Approved;
                            _context.ClientUserRoleMappers.Update(id);
                        }
                        foreach (var id in companyuserroleid)
                        {
                            id.status = (int)Statuses.Approved;
                            _context.CompanyUserRoleMappers.Update(id);
                        }
                    }
                    else
                    {
                        foreach (var id in clientuserroleid)
                        {
                            id.status = (int)Statuses.Deleted;
                            _context.ClientUserRoleMappers.Update(id);
                        }
                        foreach (var id in companyuserroleid)
                        {
                            id.status = (int)Statuses.Deleted;
                            _context.CompanyUserRoleMappers.Update(id);
                        }
                    }
                    //UserRoleIds.ForEach(roleId =>
                    //{
                    var userRole1 = _context.UserRoles.Where(ur => ur.userRoleId == roleId).FirstOrDefault();
                    userRole1.actualStatus = Status.ToLower();
                    userRole1.updatedDate = DateTime.UtcNow;
                    userRole1.updatedBy = userEmail;
                    _context.Entry(userRole1).State = EntityState.Modified;
                    //});
                });




            }



            else
            {
                return Conflict(new { message = "Status is invalid." });
            }
            await _context.SaveChangesAsync();
            if (Status.ToLower() == "active")
            {
                return new { message = "User Group Enabled successfully !!!" };
            }
            else if (Status.ToLower() == "inactive")
            {
                return new { message = "User Group Disabled successfully !!!" };
            }
            else
            {
                return new { message = "User Group Deleted Successfully !!!" };
            }

        }



        // POST: api/UserRoles
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("PostUserRole")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<object>> PostUserRole(UserRoleWithCompanies userRole)
        {
            UserRole _userRole = new UserRole();

            if (userRole.screens.Count() > 0)
            {

                var comapanyRoles = _context.RoleOrganisationMappers.Where(c => c.companyId == userRole.companyId).Select(e => new { e.roleId }).Distinct().ToList();

                var existingScreensForRoles = _context.ScreenPermissions.Where(SP => SP.roleId != userRole.id && SP.status == (int)Statuses.Approved).ToList();
                var output = (from esfr in existingScreensForRoles
                              join roles in _context.UserRoles on esfr.roleId equals roles.userRoleId
                              join cr in comapanyRoles on roles.userRoleId equals cr.roleId
                              from cfsr in userRole.screens
                              where (esfr.screenId == cfsr.screenId && esfr.create == cfsr.create && esfr.read == cfsr.read &&
                                      esfr.approve == cfsr.approve && esfr.delete == cfsr.delete && esfr.update == cfsr.update)

                              select new
                              {
                                  RoleId = esfr.roleId,
                                  RoleName = roles.roleName,
                                  ScreenId = cfsr.screenId
                              }).ToList();
                var counts = output.GroupBy(x => x.RoleName).Where(grp => grp.Count() == userRole.screens.Count())
                 .Select(g => new { g.Key, Count = g.Count() }).Select(e => e.Key.ToString());
                if (counts.Count() > 0)
                {

                    var RoleNames = string.Join(", ", counts);

                    return Conflict(new { message = "User Group " + RoleNames + " with similar user rights already exist." });
                }
            }


            try
            {
                _logger.LogTrace("############## PostUserRole Execution started ####################");
                _context.ScreenPermissions.RemoveRange(_context.ScreenPermissions.Where(x => x.roleId == userRole.id));
                _userRole.roleName = userRole.roleName;
                _userRole.createdBy = userRole.createdBy;
                _userRole.updatedBy = userRole.updatedBy;
                _userRole.status = (int)userRole.status;
                _userRole.companyId = userRole.companyId;
                _userRole.createdTime = DateTime.UtcNow;
                _userRole.updatedDate = _userRole.createdTime;
                _userRole.isMultiCompany = userRole.isMultiCompany;
                _userRole.actualStatus = userRole.actualStatus;
                if (userRole.id == null || userRole.id <= 0)
                {
                    var userRoles = await _context.UserRoles.ToListAsync();
                    _userRole.userRoleId = userRoles.Count() + 1;
                    _context.UserRoles.Add(_userRole);
                }
                else
                {
                    _userRole.userRoleId = userRole.id;
                    _context.UserRoles.Update(_userRole);
                }


                var roleOrg = await _context.RoleOrganisationMappers.Where(r => r.roleId == _userRole.userRoleId).ToListAsync();
                if (roleOrg != null && roleOrg.Count > 0)
                {
                    _context.RoleOrganisationMappers.RemoveRange(roleOrg);
                }

                foreach (var companyId in userRole.companyIds)
                {

                    RoleOrganisationMapper roleOrganisationMapper = new RoleOrganisationMapper
                    {
                        roleId = _userRole.userRoleId,
                        companyId = companyId,
                        updatedBy = userRole.updatedBy,
                        createdBy = userRole.createdBy,
                        updatedDate = DateTime.UtcNow,
                        createdTime = DateTime.UtcNow

                    };

                    _context.RoleOrganisationMappers.Add(roleOrganisationMapper);
                }


                List<ScreenPermission> screenPermissions = new List<ScreenPermission>();

                foreach (var screen in userRole.screens)
                {

                    ScreenPermission scp = new ScreenPermission();
                    scp.screenPermissionId = screen.screenPermissionId;
                    scp.roleId = _userRole.userRoleId;
                    scp.screenId = screen.screenId;
                    scp.create = screen.create;
                    scp.update = screen.update;
                    scp.approve = screen.approve;
                    scp.read = screen.read;
                    scp.delete = screen.delete;
                    scp.status = screen.status;
                    scp.createdBy = _userRole.updatedBy;
                    scp.createdTime = _userRole.updatedDate;
                    scp.updatedBy = _userRole.updatedBy;
                    scp.updatedDate = DateTime.UtcNow;
                    screenPermissions.Add(scp);
                    if (scp.screenPermissionId > 0)
                    {
                        scp.screenPermissionId = screen.screenPermissionId;
                    }

                }
                _context.ScreenPermissions.UpdateRange(screenPermissions);
                await _context.SaveChangesAsync();

            }
            catch (DbUpdateException ex)
            {
                if (UserRoleExists(userRole.id))
                {
                    //return Conflict(new { message = $"A userRole with the id '{userRole.id}' was already found." });
                    return Conflict(new { message = $"An userRole  was already found." });
                }
                else if (UserRoleNameExists(userRole.roleName, (long)userRole.companyId))
                {
                    return Conflict(new { message = $"An user role with same name already exists." });
                }
                else
                {
                    _logger.LogTrace($"Error: {ex.Message}");
                    return Conflict(new { message = $"Error: {ex.Message}" });
                    //throw;
                }

            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }

            var userRolejson = JsonConvert.SerializeObject(_userRole);
            var _userRoleJson = System.Text.Json.JsonSerializer.Deserialize<object>(userRolejson);

            return _userRoleJson;
        }


        // Get: api/ValidateUserRole
        [HttpGet("ValidateUserRole/{RoleName}/{RoleId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> ValidateUserRole(long RoleId, string RoleName)
        {
            var userRoles = await (from UR in _context.UserRoles
                                   where (UR.roleName.ToLower() == RoleName.ToLower() && UR.userRoleId != RoleId)
                                   select new
                                   {
                                       UR.userRoleId,
                                       UR.roleName
                                   }
                                   ).ToListAsync();

            if (userRoles.Count > 0)
            {
                return Conflict(new { message = $"An user role with same name already exists for the company." });
            }
            else
            {
                return new { message = "OK" };
            }
            var userRolesjson = JsonConvert.SerializeObject(userRoles);
            ArrayList userRoleslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(userRolesjson);
            return userRoleslist;

        }



        private bool UserRoleExists(long id)
        {
            return _context.UserRoles.Any(e => e.userRoleId == id);
        }

        private bool UserRoleNameExists(string roleName, long companyId)
        {
            return _context.UserRoles.Any(e => e.roleName.ToLower().Trim() == roleName.ToLower().Trim() && e.companyId == companyId);
        }

        private bool RoleOrganisationMapperAlreadyExist(long id, long companyId)
        {
            return _context.RoleOrganisationMappers.Any(e => e.roleId == id && e.companyId == companyId);
        }

        //// PUT: api/ValidateUserRoles
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("ValidateUserRoles/{Status}/{CompanyId}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //[ServiceFilter(typeof(ValidationFilterAttribute))]
        //public async Task<object> ValidateUserRoles(List<long> UserRoleIds, string Status, long CompanyId)
        //{
        //    try
        //    {
        //        string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
        //        if (Status.ToLower() == "inactive" || Status.ToLower() == "deleted")
        //        {
        //            // Commented below line by Srinivas for 
        //            //var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(emp => emp.CompanyId == CompanyId).ToListAsync();
        //            // 
        //            var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(c => c.companyId == CompanyId).ToListAsync();

        //            // Select client users for role id
        //            var clientUsersForRoleId = _context.ClientUserRoleMappers.ToList();

        //            // Select company users for role id
        //            // var companyUsersForRoleId = _context.CompanyUserRoleMappers.Where(c => c.companyId == CompanyId).ToList();
        //            // var companyUsersForRoleId = _context.CompanyUserRoleMappers.ToList();
        //            var s = _context.Organisations.Where(o => o.companyId == CompanyId).ToList();
        //            // var employeePersonalDetail1 =  _context.EmployeePersonalDetails.ToList();

        //            var c1 = (from cc in s
        //                      join cc1 in _context.ClientUserRoleMappers on cc.clientId equals cc1.clientId
        //                      select cc1).ToList();
        //            var employeePersonalDetail2 = (from ep in c1
        //                                           join ep1 in _context.EmployeePersonalDetails on ep.employeeId equals ep1.employeePersonalDetailId
        //                                           select new
        //                                           {
        //                                               ep1.roleIds
        //                                           }).ToList();

        //            var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
        //                    (c.isAllowedToClient == true && isOwnerCompany == false)))
        //                               select screenc;

        //            List<ValidatedUser> validatedUsers = new List<ValidatedUser>();
        //            UserRoleIds.ForEach(async roleId =>
        //            {
        //                var userRole = _context.UserRoles.Where(ur => ur.userRoleId == roleId).FirstOrDefault();
        //                var intEmpCount = 0;
        //                var intRoleCount = 0;

        //                //var selectedroles = employeePersonalDetail.Where(ed => ed.RoleIds.Replace("[", "").Replace("]", "").Split(new char[] { ',' }).Any(code => code.Trim() == roleId.ToString()));
        //                employeePersonalDetail2.ForEach(emp =>
        //                {
        //                    var RoleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
        //                    if (RoleIds != null)
        //                    {
        //                        if (RoleIds.Count() > 1)
        //                        {
        //                            var validatedValue1 = RoleIds.ToList().Where(rId => rId == roleId).ToList();
        //                            if (validatedValue1.Count() > 0)
        //                            {
        //                                intRoleCount++;
        //                            }
        //                        }
        //                        var validatedValue = RoleIds.ToList().Where(rId => rId == roleId).ToList();
        //                        if (validatedValue.Count() > 0)
        //                        {
        //                            intEmpCount++;
        //                        }
        //                    }
        //                });

        //                var companyUsersForRoleId = _context.CompanyUserRoleMappers.Where(c => c.companyId == CompanyId).ToList();
        //                var com = companyUsersForRoleId.Where(cp => cp.roleId == roleId).ToList();
        //                var cln = c1.Where(pc => pc.roleId == roleId).ToList();
        //                var intClient = clientUsersForRoleId.Count(ed => ed.roleId == roleId);
        //                var intCompany = companyUsersForRoleId.Count(ed => ed.roleId == roleId);
        //                //  var c = clientUsersForRoleId.Where(cd => cd.roleId == roleId).ToList();

        //                // var c3 = c1.Where(ss => ss.roleId == roleId).ToList();
        //                List<String> singleChecks = new List<String>();
        //                List<String> singleMakes = new List<String>();
        //                // foreach (var suser in c3)
        //                //{
        //                var singleOutputM = (from cm in _context.ScreenPermissions
        //                                     where cm.roleId == roleId
        //                                     join sc in screenCountC on cm.screenId equals sc.screenId
        //                                     select new
        //                                     {
        //                                         sc.screenId,
        //                                         createPermission = cm.create,
        //                                         approvePermission = cm.approve,
        //                                         // createPermission = (cm.create == true ? 1 : 0)
        //                                         // approvePermission = (cm.approve == true ? 1 : 0),
        //                                     }).ToList();
        //                var singleTestM = from singleMaker in singleOutputM.Where(m => m.createPermission == true) select singleMaker;
        //                //condition for checker
        //                var singleTestC = from singleM in singleOutputM where singleM.approvePermission == true select singleM;

        //                //if  maker
        //                if (singleTestM.Count() != 0)
        //                {
        //                    String singleMake = singleTestM.ToString();
        //                    singleMakes.Add(singleMake);
        //                }
        //                //if checker
        //                if (singleTestC.Count() != 0)
        //                {
        //                    String singleCheck = singleTestC.ToString();
        //                    singleChecks.Add(singleCheck);
        //                }
        //                //}
        //                //var cuser = (from cu in c1
        //                //             join cuu in _context.ClientUserRoleMappers on cu.clientId equals cuu.clientId
        //                //             select new
        //                //             {
        //                //                 cuu.roleId
        //                //             }).ToList();


        //                if (intRoleCount > 0)
        //                {
        //                    validatedUsers.Add(new ValidatedUser
        //                    {
        //                        roleId = roleId,
        //                        roleName = userRole.roleName,
        //                        message = "Active Users present in the User group. Do you still want to disable?"
        //                    });
        //                }
        //                else if (cln.Count() > 0)
        //                {
        //                    if (c1.Count() <= 2)
        //                    {
        //                        validatedUsers.Add(new
        //                                     ValidatedUser
        //                        {
        //                            roleId = roleId,
        //                            roleName = userRole.roleName,
        //                            message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                        });
        //                    }
        //                    else if (c1.Count() > 2)
        //                    {
        //                        List<String> checks = new List<String>();
        //                        List<String> makes = new List<String>();

        //                        foreach (var list in c1)
        //                        {
        //                            var outputM = (from cm in _context.ScreenPermissions
        //                                           where cm.roleId == list.roleId
        //                                           join sc in screenCountC on cm.screenId equals sc.screenId
        //                                           select new
        //                                           {
        //                                               sc.screenId,
        //                                               createPermission = cm.create,
        //                                               approvePermission = cm.approve,
        //                                               // createPermission = (cm.create == true ? 1 : 0)
        //                                               // approvePermission = (cm.approve == true ? 1 : 0),
        //                                           }).ToList();

        //                            // condition for make
        //                            var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
        //                            //condition for checker
        //                            var testC = from m in outputM where m.approvePermission == true select m;

        //                            //if  maker
        //                            if (testM.Count() != 0)
        //                            {
        //                                String make = testM.ToString();
        //                                makes.Add(make);
        //                            }
        //                            //if checker
        //                            if (testC.Count() != 0)
        //                            {
        //                                String check = testM.ToString();
        //                                checks.Add(check);
        //                            }
        //                        }
        //                        if (singleMakes.Count() > 0)
        //                        {
        //                            if (makes.Count() <= 1)
        //                            {
        //                                validatedUsers.Add(new
        //                                        ValidatedUser
        //                                {
        //                                    roleId = roleId,
        //                                    roleName = userRole.roleName,
        //                                    message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                                });
        //                            }
        //                        }
        //                        if (singleChecks.Count() > 0)
        //                        {
        //                            if (checks.Count() <= 1)
        //                            {
        //                                validatedUsers.Add(new
        //                                        ValidatedUser
        //                                {
        //                                    roleId = roleId,
        //                                    roleName = userRole.roleName,
        //                                    message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                                });
        //                            }
        //                        }
        //                        else
        //                        {
        //                            validatedUsers.Add(new ValidatedUser
        //                            {
        //                                roleId = roleId,
        //                                roleName = userRole.roleName,
        //                                message = "Active Users present in the User group. Do you still want to disable?"
        //                            });
        //                        }
        //                    }
        //                }
        //                if (com.Count() > 0)
        //                {
        //                    if (companyUsersForRoleId.Count() <= 2)
        //                    {
        //                        validatedUsers.Add(new
        //                                    ValidatedUser
        //                        {
        //                            roleId = roleId,
        //                            roleName = userRole.roleName,
        //                            message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                        });
        //                    }
        //                    else if (companyUsersForRoleId.Count() > 2)
        //                    {

        //                        List<String> checks = new List<String>();
        //                        List<String> makes = new List<String>();

        //                        foreach (var list in companyUsersForRoleId)
        //                        {
        //                            var outputM = (from cm in _context.ScreenPermissions
        //                                           where cm.roleId == list.roleId
        //                                           join sc in screenCountC on cm.screenId equals sc.screenId
        //                                           select new
        //                                           {
        //                                               sc.screenId,
        //                                               createPermission = cm.create,
        //                                               approvePermission = cm.approve,
        //                                               // createPermission = (cm.create == true ? 1 : 0)
        //                                               // approvePermission = (cm.approve == true ? 1 : 0),
        //                                           }).ToList();

        //                            // condition for make
        //                            var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
        //                            //condition for checker
        //                            var testC = from m in outputM where m.approvePermission == true select m;

        //                            //if  maker
        //                            if (testM.Count() != 0)
        //                            {
        //                                String make = testM.ToString();
        //                                makes.Add(make);
        //                            }
        //                            //if checker
        //                            if (testC.Count() != 0)
        //                            {
        //                                String check = testM.ToString();
        //                                checks.Add(check);
        //                            }
        //                        }
        //                        if (singleMakes.Count() > 0)
        //                        {
        //                            if (makes.Count() <= 1)
        //                            {
        //                                validatedUsers.Add(new
        //                                        ValidatedUser
        //                                {
        //                                    roleId = roleId,
        //                                    roleName = userRole.roleName,
        //                                    message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                                });
        //                            }
        //                        }
        //                        if (singleChecks.Count() > 0)
        //                        {
        //                            if (checks.Count() <= 1)
        //                            {
        //                                validatedUsers.Add(new
        //                                        ValidatedUser
        //                                {
        //                                    roleId = roleId,
        //                                    roleName = userRole.roleName,
        //                                    message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                                });
        //                            }
        //                        }
        //                        else
        //                        {
        //                            validatedUsers.Add(new ValidatedUser
        //                            {
        //                                roleId = roleId,
        //                                roleName = userRole.roleName,
        //                                message = "Active Users present in the User group. Do you still want to disable?"
        //                            });
        //                        }
        //                    }
        //                }

        //                //else if ((intClient > 0 && intClient <= 2) || (intCompany > 0 && intCompany <= 2))
        //                //{
        //                //    validatedUsers.Add(new
        //                //                  ValidatedUser
        //                //    {
        //                //        roleId = roleId,
        //                //        roleName = userRole.roleName,
        //                //        message = "Users in User groups are tagged to the company/client which have minimum users. Add adequate users under company/client before disabling the User group."
        //                //    });

        //                //}

        //                //else if (intEmpCount > 0 && intClient == 0 && intCompany == 0)
        //                //{
        //                //    validatedUsers.Add(new ValidatedUser
        //                //    {
        //                //        roleId = roleId,
        //                //        roleName = userRole.roleName,
        //                //        message = "Active Users present in the User group. Do you still want to disable?"
        //                //    });
        //                //}

        //                //else if ((intClient > 2) || (intCompany > 2) || (intEmpCount > 0))
        //                //{
        //                //    var ClientsForRole = clientUsersForRoleId.Where(e => e.roleId == roleId).DistinctBy(e => e.clientId);
        //                //    var CompanyForRole = companyUsersForRoleId.Where(ed => ed.roleId == roleId).DistinctBy(e => e.companyId);

        //                //    var Clients = clientUsersForRoleId.Where(_ => ClientsForRole.Any(a => a.clientId == _.clientId && _.roleId != roleId && _.roleId != null))
        //                //    .Join(_context.ClientCreation, e => e.clientId, c => c.clientId, (e, c) => new { e.clientId, e.roleId, c.clientName })
        //                //    .DistinctBy(e => e.clientId)
        //                //    .Select(g => g.clientName);

        //                //    var Companies = companyUsersForRoleId.Where(_ => CompanyForRole.Any(a => a.companyId == _.companyId && _.roleId != roleId && _.roleId != null))
        //                //     .Join(_context.Organisations, e => e.companyId, c => c.companyId, (e, c) => new { e.companyId, e.roleId, c.companyName })
        //                //     .DistinctBy(e => e.companyId)
        //                //     .Select(g => g.companyName);
        //                //    if (Clients.Count() != ClientsForRole.Count() || Companies.Count() != CompanyForRole.Count())
        //                //    {
        //                //        var ClientNames = string.Join(", ", Clients);
        //                //        ClientNames = ClientNames == null ? string.Empty : "<Clients : " + ClientNames + ">";

        //                //        var CompanyNames = string.Join(", ", Companies);
        //                //        CompanyNames = CompanyNames == null ? string.Empty : "<Companies : " + CompanyNames + ">";
        //                //        validatedUsers.Add(new ValidatedUser
        //                //        {
        //                //            roleId = roleId,
        //                //            roleName = userRole.roleName,
        //                //            message = "Adequate users under client/company exist for the same user group. Add adequate users under company/client to disable this user group." + ClientNames + CompanyNames
        //                //        });

        //                //    }
        //                //    else
        //                //    {
        //                //        validatedUsers.Add(new ValidatedUser
        //                //        {
        //                //            roleId = roleId,
        //                //            roleName = userRole.roleName,
        //                //            message = "Active Users present in the User group. Do you still want to disable?"
        //                //        });
        //                //    }
        //                // }
        //                // Commented these lines by Srinivas and simplified the code

        //                //employeePersonalDetail.ForEach(emp =>
        //                //{
        //                //    var RoleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.RoleIds);
        //                //    if (RoleIds != null)
        //                //    {
        //                //        // Check whether the user role has active users
        //                //        var validatedValue = RoleIds.ToList().Where(rId => rId == roleId  ).ToList();
        //                //        if (validatedValue.Count() > 0)
        //                //        {
        //                //            if (validatedUsers.Where(vUser => vUser.RoleId != emp.RoleId).ToList().Count() == 0)
        //                //            {
        //                //                if (validatedUsers.Where(vUser => vUser.RoleId == roleId).ToList().Count() == 0)
        //                //                {
        //                //                    validatedUsers.Add(new ValidatedUser { RoleId = roleId, RoleName = userRole.RoleName,
        //                //                     Message = "Active Users present in the User group. Do you still want to " + (Status.ToLower() == "inactive" ? "disable" : "delete") + "?" });
        //                //                }
        //                //            }

        //                //            // Select client users for role id
        //                //            var clientUsersForRoleId = _context.ClientUserRoleMappers.Where(clientUser => clientUser.RoleId == roleId).ToList();

        //                //            // Select client users other than role id
        //                //            var clientUsersWithoutRoleId = clientUsersForRoleId.Where(user => user.RoleId != roleId).ToList();

        //                //            // Select company users for role id
        //                //            var companyUsersForRoleId = _context.CompanyUserRoleMappers.Where(companyUser => companyUser.RoleId == roleId).ToList();

        //                //            // Select company users other than role id
        //                //            var companyUsersWithoutRoleId = companyUsersForRoleId.Where(user => user.RoleId != roleId).ToList();

        //                //            if (clientUsersWithoutRoleId.Count() < 2)
        //                //            {
        //                //                if (validatedUsers.Where(vUser => vUser.RoleId == roleId).ToList().Count() == 0)
        //                //                {
        //                //                    validatedUsers.Add(new
        //                //                ValidatedUser
        //                //                    {
        //                //                        RoleId = roleId,
        //                //                        RoleName = userRole.RoleName,
        //                //                        Message = "Users in User groups are tagged to the client which have minimum users." +
        //                //                    " Add adequate users under client before " + (Status.ToLower() == "inactive" ? "disabling" : "deleting") + " the User group."
        //                //                    });
        //                //                }
        //                //            }
        //                //            if (companyUsersWithoutRoleId.Count() < 2)
        //                //            {
        //                //                if (validatedUsers.Where(vUser => vUser.RoleId == roleId).ToList().Count() == 0)
        //                //                {
        //                //                    validatedUsers.Add(new
        //                //             ValidatedUser
        //                //                    {
        //                //                        RoleId = roleId,
        //                //                        RoleName = userRole.RoleName,
        //                //                        Message = "Users in User groups are tagged to the company which have minimum users." +
        //                //                    " Add adequate users under company before " + (Status.ToLower() == "inactive" ? "disabling" : "deleting") + " the User group."
        //                //                    });
        //                //                }
        //                //            }
        //                //        }
        //                //        else
        //                //        {
        //                //            var selectUserRole = _context.UserRoles.Where(ur => ur.Id == roleId).FirstOrDefault();
        //                //            if ((Status.ToLower() == "inactive" || Status.ToLower() == "deleted") && selectUserRole != null)
        //                //            {

        //                //                selectUserRole.ActualStatus = Status.ToLower();
        //                //                selectUserRole.UpdatedDate = DateTime.UtcNow;
        //                //                selectUserRole.UpdatedBy = userEmail;
        //                //                _context.Entry(selectUserRole).State = EntityState.Modified;
        //                //                //_context.SaveChanges();

        //                //            }

        //                //        }
        //                //    }
        //                //});


        //            });
        //            if (validatedUsers.Count() > 0)
        //            {
        //                return Conflict(new { message = "There are some conflicts", content = validatedUsers });
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return Conflict(new { message = $"Error: {ex.Message}" });
        //    }
        //    return new { message = "OK" };
        //}

    }
}


