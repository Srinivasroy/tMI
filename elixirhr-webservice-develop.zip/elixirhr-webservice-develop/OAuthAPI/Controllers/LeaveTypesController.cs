﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveTypesController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public LeaveTypesController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/LeaveTypes
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ArrayList> GetLeaveTypes()
        {
            var leaveTypes = await _context.LeaveTypes.Where(leaveType => leaveType.status == true).ToListAsync();
            var leaveTypesJson = JsonConvert.SerializeObject(leaveTypes);
            ArrayList leaveTypesList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(leaveTypesJson);
            return leaveTypesList;
        }

        // GET: api/LeaveTypes
        [HttpGet("AllLeaveTypes")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<LeaveType>>> GetAllLeaveTypes()
        {
            return await _context.LeaveTypes.ToListAsync();
        }

        // GET: api/LeaveTypes/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> GetLeaveType(long id)
        {
            var leaveType = await _context.LeaveTypes.FindAsync(id);

            if (leaveType == null)
            {
                return NotFound();
            }
            var leaveTypeJson = JsonConvert.SerializeObject(leaveType);
            var leaveTypeObj = System.Text.Json.JsonSerializer.Deserialize<object>(leaveTypeJson);
            return System.Text.Json.JsonSerializer.Serialize(leaveTypeObj);
        }

        // PUT: api/LeaveTypes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutLeaveType(long id, LeaveType leaveType)
        {
            if (!LeaveTypeExists(id))
            {
                return NotFound();
            }
            if (leaveType.companyId == null)
            {
                return Conflict(new { message = "Company Id is mandatory." });
            }
            if (!Helper.OrganisationIdExists((long)leaveType.companyId))
            {
                return Conflict(new { message = "Company does not exist." });
            }

            leaveType.leaveTypeId = id;
            leaveType.updatedDate = DateTime.UtcNow;
            _context.Entry(leaveType).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LeaveTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/LeaveTypes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<LeaveType>> PostLeaveType(LeaveType leaveType)
        {
            if (leaveType.companyId == null)
            {
                return Conflict(new { message = "Company Id is mandatory." });
            }
            if (!Helper.OrganisationIdExists((long)leaveType.companyId))
            {
                return Conflict(new { message = "Company does not exist." });
            }
            leaveType.createdTime = DateTime.UtcNow;
            leaveType.updatedDate = leaveType.createdTime;
            leaveType.status = true;
            _context.LeaveTypes.Add(leaveType);
            try
            {

                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (LeaveTypeExists(leaveType.leaveTypeId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetLeaveType", new { id = leaveType.leaveTypeId }, leaveType);
        }

        // DELETE: api/LeaveTypes/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteLeaveType(long id)
        {
            var leaveType = await _context.LeaveTypes.FindAsync(id);
            if (leaveType == null)
            {
                return NotFound();
            }
            leaveType.status = false;
            _context.LeaveTypes.Update(leaveType);
            //_context.LeaveTypes.Remove(leaveType);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool LeaveTypeExists(long id)
        {
            return _context.LeaveTypes.Any(e => e.leaveTypeId == id);
        }

    }
}
