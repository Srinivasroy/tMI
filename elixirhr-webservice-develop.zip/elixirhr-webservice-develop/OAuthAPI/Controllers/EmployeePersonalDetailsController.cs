﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.Helpers;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;
using OAuthAPI.Models.Common_Schema;
using static OAuthAPI.models.Helpers.Helper;
using Microsoft.Extensions.Configuration;
using OAuthAPI.ActionFilters;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using Nancy.Json;
using OAuthAPI.Models;
using MySqlX.XDevAPI.Common;
using OAuthAPI.models;
using System.Text.RegularExpressions;
using Org.BouncyCastle.Asn1.X509;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeePersonalDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;
        private IConfiguration configuration;
        private readonly ILogger<AccountController> _logger;
        private static Random random = new Random();
        private bool isOwnerCompany = Common_Schema_Context.IsOwnerCompany;
        public EmployeePersonalDetailsController(Common_Schema_Context context, IConfiguration iconfig, ILogger<AccountController> logger)
        {
            _context = context;
            configuration = iconfig;
            this._logger = logger;
        }

        // GET: api/EmployeePersonalDetails
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetEmployeePersonalDetails(bool? getAll = false)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            if (getAll == true)
            {
                //var employeePersonalDetails = await _context.EmployeePersonalDetails.ToListAsync();
                var employeePersonalDetails = await (from emp in _context.EmployeePersonalDetails.Where(e => e.isClientAdmin != true)
                                                     join status in _context.Statuses on emp.status equals status.statusId into StatusList
                                                     from actualStatus in StatusList
                                                     join userRole in _context.UserRoles on emp.roleId equals userRole.userRoleId into RoleList
                                                     from role in RoleList.DefaultIfEmpty()
                                                     select new
                                                     {
                                                         emp.employeePersonalDetailId,
                                                         emp.firstName,
                                                         emp.middleName,
                                                         emp.lastName,
                                                         emp.clientId,
                                                         emp.dob,
                                                         emp.gender,
                                                         emp.maritalStatus,
                                                         emp.religion,
                                                         emp.mobileNo,
                                                         emp.companyId,
                                                         emp.roleId,
                                                         role.roleName,
                                                         emp.updatedBy,
                                                         emp.updatedDate,
                                                         emp.createdTime,
                                                         emp.createdBy,
                                                         emp.email,
                                                         actualStatus.statusName,
                                                         emp.employeeImageUrl,
                                                         emp.status,
                                                         emp.roleIds
                                                     }
                                                         ).ToListAsync();
                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetails);
                if (employeePersonalDetails == null)
                {
                    return NotFound();
                }
                ArrayList employeePersonalDetailsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(employeePersonalDetailsJson);
                return employeePersonalDetailsList;

            }
            else
            {
                // Show the Employees those who have status other than Deleted
                //var employeePersonalDetails = await _context.EmployeePersonalDetails.Where(emp => emp.Status != (int)Statuses.Deleted).ToListAsync();
                //var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetails);
                //if (employeePersonalDetails == null)
                //{
                //    return NotFound();
                //}


                var employeePersonalDetails = await (from emp in _context.EmployeePersonalDetails
                                                     where emp.status != (int)Statuses.Deleted && emp.isClientAdmin != true
                                                     join status in _context.Statuses on emp.status equals status.statusId into StatusList
                                                     from actualStatus in StatusList
                                                     join userRole in _context.UserRoles on emp.roleId equals userRole.userRoleId into RoleList
                                                     from role in RoleList.DefaultIfEmpty()
                                                     select new
                                                     {
                                                         emp.employeePersonalDetailId,
                                                         emp.firstName,
                                                         emp.middleName,
                                                         emp.lastName,
                                                         emp.dob,
                                                         emp.gender,
                                                         emp.maritalStatus,
                                                         emp.religion,
                                                         emp.mobileNo,
                                                         emp.companyId,
                                                         emp.roleId,
                                                         role.roleName,
                                                         emp.updatedBy,
                                                         emp.updatedDate,
                                                         emp.createdTime,
                                                         emp.createdBy,
                                                         emp.email,
                                                         actualStatus.statusName,
                                                         emp.employeeImageUrl,
                                                         emp.status,
                                                         emp.roleIds
                                                     }
                                                         ).ToListAsync();
                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetails);
                ArrayList employeePersonalDetailsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(employeePersonalDetailsJson);
                return employeePersonalDetailsList;
            }
        }

        // GET: api/GetTMIAdmins
        [HttpGet("GetUsersByRoleId/{roleId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetUsersByRoleId(int roleId)
        {

            var employeePersonalDetails = await (from emp in _context.EmployeePersonalDetails
                                                 where emp.roleId == roleId
                                                 join status in _context.Statuses on emp.status equals status.statusId into StatusList
                                                 from actualStatus in StatusList
                                                 join userRole in _context.UserRoles on emp.roleId equals userRole.userRoleId into RoleList
                                                 from role in RoleList.DefaultIfEmpty()
                                                 select new
                                                 {
                                                     emp.employeePersonalDetailId,
                                                     emp.firstName,
                                                     emp.middleName,
                                                     emp.lastName,
                                                     emp.dob,
                                                     emp.gender,
                                                     emp.maritalStatus,
                                                     emp.religion,
                                                     emp.mobileNo,
                                                     emp.companyId,
                                                     emp.roleId,
                                                     role.roleName,
                                                     emp.updatedBy,
                                                     emp.updatedDate,
                                                     emp.createdTime,
                                                     emp.createdBy,
                                                     emp.email,
                                                     actualStatus.statusName,
                                                     emp.employeeImageUrl,
                                                     emp.status,
                                                     emp.roleIds
                                                 }
                                                     ).ToListAsync();
            var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetails);
            if (employeePersonalDetails == null)
            {
                return NotFound();
            }
            ArrayList employeePersonalDetailsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(employeePersonalDetailsJson);
            return employeePersonalDetailsList;

        }

        //GET: api/EmployeePersonalDetails/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetEmployeePersonalDetail(long id)
        {
            //var employeePersonalDetail = await _context.EmployeePersonalDetails.FindAsync(id);
            var employeePersonalDetail = await (from emp in _context.EmployeePersonalDetails
                                                where emp.employeePersonalDetailId == id
                                                join status in _context.Statuses on emp.status equals status.statusId into StatusList
                                                from actualStatus in StatusList
                                                join userRole in _context.UserRoles on emp.roleId equals userRole.userRoleId into RoleList
                                                from role in RoleList.DefaultIfEmpty()
                                                select new
                                                {
                                                    emp.employeePersonalDetailId,
                                                    emp.firstName,
                                                    emp.middleName,
                                                    emp.lastName,
                                                    emp.fatherName,
                                                    emp.dob,
                                                    emp.gender,
                                                    emp.maritalStatus,
                                                    emp.religion,
                                                    emp.mobileNo,
                                                    emp.companyId,
                                                    emp.groupId,
                                                    emp.roleId,
                                                    role.roleName,
                                                    emp.updatedBy,
                                                    emp.updatedDate,
                                                    emp.createdTime,
                                                    emp.createdBy,
                                                    emp.email,
                                                    emp.status,
                                                    actualStatus.statusName,
                                                    emp.employeeImageUrl,
                                                    emp.roleIds,
                                                    emp.isCompanyAdmin,
                                                    emp.isClientAdmin

                                                }
                                                         ).FirstOrDefaultAsync();
            var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
            if (employeePersonalDetail == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
        }

        //GET: api/GetTMIUsers
        [HttpGet("GetTMIUsers")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetTMIUsers()
        {
            // Fetch the TMI users, company Id for TMI is always 1
            var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(emp => emp.companyId == 1 && emp.status != (int)Statuses.Deleted && emp.employeePersonalDetailId != 1 && emp.isClientAdmin != true).ToListAsync();
            var userRoles = await _context.UserRoles.Where(ur => ur.roleName.ToLower() != "super admin").ToListAsync();
            List<object> employeesWithRoles = new List<object>();
            employeePersonalDetail.ForEach(emp =>
            {
                List<object> roles = new List<object>();
                if (emp.roleIds != null)
                {
                    var roleIds = new JavaScriptSerializer().Deserialize<int[]>(emp.roleIds);
                    roleIds.ToList().ForEach(async (roleId) =>
                    {
                        var role = userRoles.Where(role => role.userRoleId == roleId && role.actualStatus == "active").FirstOrDefault();
                        if (role != null)
                        {
                            var obj = new { roleId = roleId, roleName = role.roleName };
                            roles.Add(obj);
                        }
                    });

                }
                var empObj = new { employeeId = emp.employeePersonalDetailId, roles = roles, employeeName = $"{emp.firstName} {emp.lastName}", email = emp.email };
                employeesWithRoles.Add(empObj);
            });
            var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeesWithRoles);
            var employeePersonalDetailsObj = System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            //if (employeePersonalDetail == null)
            //{
            //    return NotFound();
            //}

            return employeePersonalDetailsObj;
        }

        //GET: api/GetUserManagementUsers
        [HttpGet("GetUsersMappedWithClientOrCompany/{isClient}/{Id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetUsersMappedWithClientOrCompany(long Id, bool? isClient = false)
        {

            if (isClient == true)
            {
                var allUsers = await (from client in _context.ClientUserRoleMappers
                                      where client.clientId == Id
                                      join emp in _context.EmployeePersonalDetails on client.employeeId equals emp.employeePersonalDetailId into Employees
                                      from empV in Employees
                                      select new
                                      {
                                          EmployeeId = empV.employeePersonalDetailId,
                                          EmployeeName = $"{empV.firstName} {empV.lastName}",
                                          Email = empV.email,
                                          client.clientId

                                      }
                                   ).ToListAsync();
                var allUsersJson = JsonConvert.SerializeObject(allUsers);
                var allUsersJsonObj = System.Text.Json.JsonSerializer.Deserialize<object>(allUsersJson);


                return allUsersJsonObj;
            }
            else
            {
                var allUsers = await (from company in _context.CompanyUserRoleMappers
                                      where company.companyId == Id
                                      join emp in _context.EmployeePersonalDetails on company.employeeId equals emp.employeePersonalDetailId into Employees
                                      from empV in Employees
                                      select new
                                      {
                                          EmployeeId = empV.employeePersonalDetailId,
                                          EmployeeName = $"{empV.firstName} {empV.lastName}",
                                          Email = empV.email,
                                          company.companyId

                                      }
                                  ).ToListAsync();
                var allUsersJson = JsonConvert.SerializeObject(allUsers);
                var allUsersJsonObj = System.Text.Json.JsonSerializer.Deserialize<object>(allUsersJson);


                return allUsersJsonObj;
            }

            return new { };
        }



        //GET: api/GetUserManagementUsers
        [HttpGet("GetUserManagementUsers")]
        //   [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetUserManagementUsers()
        {

            var companyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                      join company in _context.Organisations on companyuser.companyId equals company.companyId into Companies
                                      from companyV in Companies
                                      where companyV.isOwnerCompany != true     //added now
                                      join client in _context.ClientCreation on companyV.clientId equals client.clientId into Clients
                                      from clientV in Clients.DefaultIfEmpty()
                                      join employee in _context.EmployeePersonalDetails on companyuser.employeeId equals employee.employeePersonalDetailId into Employees
                                      from employeeV in Employees.DefaultIfEmpty()
                                      where employeeV.status == (int)Statuses.Approved && employeeV.roleId != 1
                                      join userRole in _context.UserRoles on companyuser.roleId equals userRole.userRoleId into UserRoles
                                      //where userRole.userRoleId != (int)UserRoles.SuperAdmin
                                      from userRoleV in UserRoles
                                      select new
                                      {
                                          employeeId = companyuser.employeeId,
                                          name = $"{employeeV.firstName} {employeeV.lastName}",
                                          roleId = companyuser.roleId,
                                          roleName = userRoleV.roleName,
                                          clientId = clientV.clientId,
                                          clientName = clientV.clientName, // Replaced by "";
                                          companyId = companyuser.companyId,
                                          companyName = companyV.companyName,
                                          companyData = true,
                                          id = companyuser.userRoleMapperId
                                      }
                                  ).ToListAsync();

            var clientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                     join client in _context.ClientCreation on clientuser.clientId equals client.clientId into Clients
                                     from clientV in Clients.DefaultIfEmpty()
                                     where clientV.isOwnerClient != true
                                     join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId into Employees
                                     from employeeV in Employees.DefaultIfEmpty()
                                     where employeeV.status == (int)Statuses.Approved && employeeV.roleId != 1
                                     join userRole in _context.UserRoles on clientuser.roleId equals userRole.userRoleId into UserRoles
                                     from userRoleV in UserRoles
                                     join org in _context.Organisations on clientuser.clientId equals org.clientId into Organisations   // ---
                                     from orgs in Organisations.DefaultIfEmpty()                                                       // ---
                                     select new
                                     {
                                         employeeId = clientuser.employeeId,
                                         name = $"{employeeV.firstName} {employeeV.lastName}",
                                         roleId = clientuser.roleId,
                                         roleName = userRoleV.roleName,
                                         clientId = clientV.clientId,
                                         clientName = clientV.clientName,
                                         companyId = 0,
                                         companyName = orgs.companyName,    // --- Replaced By "" 
                                         companyData = false,
                                         id = clientuser.clientUserRoleMapperId
                                     }
                              ).ToListAsync();

            List<object> allUsers = new List<object>();
            companyUsers.ForEach(companyUser =>
            {
                allUsers.Add(companyUser);
            });
            clientUsers.ForEach(clientUser =>
            {
                allUsers.Add(clientUser);
            });

            var allUsersJson = JsonConvert.SerializeObject(allUsers);
            var allUsersJsonObj = System.Text.Json.JsonSerializer.Deserialize<object>(allUsersJson);


            return allUsersJsonObj;
        }

        //Update: api/UpdateUserManagementDetails
        [HttpPut("UpdateUserManagementDetails")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> UpdateUserManagementDetails(UpdateEmployeeDetails updateEmployeeDetails)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            if (updateEmployeeDetails.companyData == false)
            {
                //added now -------------------------------------
                var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                          (c.isAllowedToClient == true && isOwnerCompany == false)))
                                   select screenc;

                List<String> singleChecks = new List<String>();
                List<String> singleMakes = new List<String>();
                var rid = _context.ClientUserRoleMappers.Where(s => s.clientUserRoleMapperId == updateEmployeeDetails.id).Select(a => a.roleId).FirstOrDefault();
                var singleOutputM = (from cm in _context.ScreenPermissions
                                     where cm.roleId == rid  //updateEmployeeDetails.roleId
                                     join sc in screenCountC on cm.screenId equals sc.screenId
                                     select new
                                     {
                                         sc.screenId,
                                         createPermission = cm.create,
                                         approvePermission = cm.approve,

                                     }).ToList();
                var singleTestM = from singleMaker in singleOutputM.Where(m => m.createPermission == true) select singleMaker;
                //condition for checker
                var singleTestC = from singleM in singleOutputM where singleM.approvePermission == true select singleM;

                //if  maker
                if (singleTestM.Count() != 0)
                {
                    String singleMake = singleTestM.ToString();
                    singleMakes.Add(singleMake);
                }
                //if checker
                if (singleTestC.Count() != 0)
                {
                    String singleCheck = singleTestC.ToString();
                    singleChecks.Add(singleCheck);
                }
                // for input role 
                List<String> singleChecks2 = new List<String>();
                List<String> singleMakes2 = new List<String>();
                //var rid = _context.ClientUserRoleMappers.Where(s => s.clientUserRoleMapperId == updateEmployeeDetails.id).Select(a => a.roleId).FirstOrDefault();
                var singleOutputM2 = (from cm in _context.ScreenPermissions
                                      where cm.roleId == updateEmployeeDetails.roleId  //updateEmployeeDetails.roleId
                                      join sc in screenCountC on cm.screenId equals sc.screenId
                                      select new
                                      {
                                          sc.screenId,
                                          createPermission = cm.create,
                                          approvePermission = cm.approve,

                                      }).ToList();
                var singleTestM2 = from singleMaker in singleOutputM2.Where(m => m.createPermission == true) select singleMaker;
                //condition for checker
                var singleTestC2 = from singleM in singleOutputM2 where singleM.approvePermission == true select singleM;

                //if  maker
                if (singleTestM2.Count() != 0)
                {
                    String singleMake = singleTestM2.ToString();
                    singleMakes2.Add(singleMake);
                }
                //if checker
                if (singleTestC2.Count() != 0)
                {
                    String singleCheck = singleTestC2.ToString();
                    singleChecks2.Add(singleCheck);
                }

                // till here


                var cid = _context.ClientUserRoleMappers.Where(s => s.clientUserRoleMapperId == updateEmployeeDetails.id).Select(a => a.clientId).FirstOrDefault();
                //added
                List<String> less = new List<String>();
                List<String> grt = new List<String>();
                var l = _context.ClientUserRoleMappers.Where(ll => ll.clientId == cid).Select(lll => lll.employeeId).ToList();
                //if (l.Count() <= 2)
                //{
                //    String les = l.ToString();
                //    less.Add(les);
                //}
                //if (less.Count() > 0)
                //{
                //    return Conflict(new { message = "Company/Client with minimum users. Add adequate users under !!!" });
                //}
                List<String> checks = new List<String>();
                List<String> makes = new List<String>();
                //var users = _context.ClientUserRoleMappers.Where(d => d.clientId == cid && d.employeeId != updateEmployeeDetails.employeeId).ToList();// && d.employeeId != updateEmployeeDetails.employeeId
                var users = _context.ClientUserRoleMappers.Where(v => v.clientId == cid && v.clientUserRoleMapperId != updateEmployeeDetails.id).ToList();

                if (users.Count() != 0)
                {
                    if (l.Count() > 2)
                    {


                        foreach (var cln in users)
                        {
                            var outputM = (from cm in _context.ScreenPermissions
                                           where cm.roleId == cln.roleId
                                           join sc in screenCountC on cm.screenId equals sc.screenId
                                           select new
                                           {
                                               sc.screenId,
                                               createPermission = cm.create,
                                               approvePermission = cm.approve,

                                           }).ToList();

                            // condition for make
                            var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                            //condition for checker
                            var testC = from m in outputM where m.approvePermission == true select m;

                            //if  maker
                            if (testM.Count() != 0)
                            {
                                String make = testM.ToString();
                                makes.Add(make);
                            }
                            //if checker
                            if (testC.Count() != 0)
                            {
                                String check = testC.ToString();
                                checks.Add(check);
                            }
                        }
                    }

                }
                //-----------------------------------------------


                try
                {
                    var clientUser = await _context.ClientUserRoleMappers.Where(client => client.clientUserRoleMapperId == updateEmployeeDetails.id).FirstOrDefaultAsync();
                    if (clientUser != null && updateEmployeeDetails.clientId != null)
                    {
                        clientUser.employeeId = updateEmployeeDetails.employeeId;
                        clientUser.updatedDate = DateTime.UtcNow;
                        clientUser.clientId = updateEmployeeDetails.clientId;

                        if (singleMakes.Count() != 0 && makes.Count() > 0)
                        {
                            clientUser.roleId = updateEmployeeDetails.roleId;
                        }
                        else if (singleChecks.Count() != 0 && checks.Count() > 0)
                        {
                            clientUser.roleId = updateEmployeeDetails.roleId;
                        }
                        else if (singleMakes.Count() != 0 && makes.Count() == 0)
                        {
                            if (singleMakes2.Count() != 0)
                            {
                                clientUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else
                            {
                                return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                            }
                        }
                        else if (singleChecks.Count() != 0 && checks.Count() == 0)
                        {
                            if (singleChecks2.Count() != 0)
                            {
                                clientUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else
                            {
                                return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                            }
                        }
                        else if (singleMakes.Count() == 0 && singleChecks.Count() == 0)
                        {
                            clientUser.roleId = updateEmployeeDetails.roleId;
                        }
                        else if (singleMakes2.Count() == 0 && singleChecks2.Count == 0)
                        {
                            if (singleMakes.Count() != 0)//&& makes.Count() > 0)
                            {
                                clientUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else if (singleChecks.Count() != 0) //&& checks.Count() > 0)
                            {
                                clientUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else
                            {
                                return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                            }
                        }


                        else
                        {
                            return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                        }
                        clientUser.updatedBy = userEmail;
                        _context.Entry(clientUser).State = EntityState.Modified;
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        return Conflict(new { message = "Client user does not exist !!!" });
                    }
                }
                catch (DbUpdateException ex)
                {
                    if (IsClientAlreadyMapped((long)updateEmployeeDetails.employeeId, (long)updateEmployeeDetails.clientId))
                    {
                        return Conflict(new { message = $"User is already assigned with the client" });
                    }
                    else
                    {
                        return Conflict(new { message = $"Error: {ex.Message}" });
                    }
                }
                catch (Exception ex)
                {
                    return Conflict(new { message = $"Error: {ex.Message}" });
                }
            }



            else if (updateEmployeeDetails.companyData == true)
            {
                //added now -------------------------------------
                var screenCountC1 = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                              (c.isAllowedToClient == true && isOwnerCompany == false)))
                                    select screenc;

                List<String> singleChecks1 = new List<String>();
                List<String> singleMakes1 = new List<String>();
                var rid1 = _context.CompanyUserRoleMappers.Where(s => s.userRoleMapperId == updateEmployeeDetails.id).Select(a => a.roleId).FirstOrDefault();
                var singleOutputM1 = (from cm in _context.ScreenPermissions
                                      where cm.roleId == rid1
                                      join sc in screenCountC1 on cm.screenId equals sc.screenId
                                      select new
                                      {
                                          sc.screenId,
                                          createPermission = cm.create,
                                          approvePermission = cm.approve,

                                      }).ToList();
                var singleTestM1 = from singleMaker in singleOutputM1.Where(m => m.createPermission == true) select singleMaker;
                //condition for checker
                var singleTestC1 = from singleM in singleOutputM1 where singleM.approvePermission == true select singleM;

                //if  maker
                if (singleTestM1.Count() != 0)
                {
                    String singleMake = singleTestM1.ToString();
                    singleMakes1.Add(singleMake);
                }
                //if checker
                if (singleTestC1.Count() != 0)
                {
                    String singleCheck = singleTestC1.ToString();
                    singleChecks1.Add(singleCheck);
                }

                // for input role 
                List<String> singleChecks2 = new List<String>();
                List<String> singleMakes2 = new List<String>();
                //var rid = _context.ClientUserRoleMappers.Where(s => s.clientUserRoleMapperId == updateEmployeeDetails.id).Select(a => a.roleId).FirstOrDefault();
                var singleOutputM2 = (from cm in _context.ScreenPermissions
                                      where cm.roleId == updateEmployeeDetails.roleId  //updateEmployeeDetails.roleId
                                      join sc in screenCountC1 on cm.screenId equals sc.screenId
                                      select new
                                      {
                                          sc.screenId,
                                          createPermission = cm.create,
                                          approvePermission = cm.approve,

                                      }).ToList();
                var singleTestM2 = from singleMaker in singleOutputM2.Where(m => m.createPermission == true) select singleMaker;
                //condition for checker
                var singleTestC2 = from singleM in singleOutputM2 where singleM.approvePermission == true select singleM;

                //if  maker
                if (singleTestM2.Count() != 0)
                {
                    String singleMake = singleTestM2.ToString();
                    singleMakes2.Add(singleMake);
                }
                //if checker
                if (singleTestC2.Count() != 0)
                {
                    String singleCheck = singleTestC2.ToString();
                    singleChecks2.Add(singleCheck);
                }

                // till here


                var cid1 = _context.CompanyUserRoleMappers.Where(s => s.userRoleMapperId == updateEmployeeDetails.id).Select(a => a.companyId).FirstOrDefault();

                //added
                List<String> less = new List<String>();
                List<String> grt = new List<String>();
                var l = _context.CompanyUserRoleMappers.Where(ll => ll.companyId == cid1).Select(lll => lll.employeeId).ToList();
                //if (l.Count() <= 2)
                //{
                //    String les = l.ToString();
                //    less.Add(les);
                //}
                //if (less.Count() > 0)
                //{
                //    return Conflict(new { message = "Company/Client with minimum users. Add adequate users under !!!" });
                //}
                List<String> checks1 = new List<String>();
                List<String> makes1 = new List<String>();
                //var users1 = _context.CompanyUserRoleMappers.Where(d => d.companyId == cid1 && d.employeeId != updateEmployeeDetails.employeeId).ToList();
                var users1 = _context.CompanyUserRoleMappers.Where(v => v.companyId == cid1 && v.userRoleMapperId != updateEmployeeDetails.id).ToList();

                if (users1.Count() != 0)
                {
                    if (l.Count() > 2)
                    {

                        foreach (var cln in users1)
                        {
                            var outputM1 = (from cm in _context.ScreenPermissions
                                            where cm.roleId == cln.roleId
                                            join sc in screenCountC1 on cm.screenId equals sc.screenId
                                            select new
                                            {
                                                sc.screenId,
                                                createPermission = cm.create,
                                                approvePermission = cm.approve,

                                            }).ToList();

                            // condition for make
                            var testM1 = from maker in outputM1.Where(m => m.createPermission == true) select maker;
                            //condition for checker
                            var testC1 = from m in outputM1 where m.approvePermission == true select m;

                            //if  maker
                            if (testM1.Count() != 0)
                            {
                                String make = testM1.ToString();
                                makes1.Add(make);
                            }
                            //if checker
                            if (testC1.Count() != 0)
                            {
                                String check = testC1.ToString();
                                checks1.Add(check);
                            }
                        }
                    }

                }
                //-----------------------------------------------


                try
                {
                    var companyUser = await _context.CompanyUserRoleMappers.Where(company => company.userRoleMapperId == updateEmployeeDetails.id).FirstOrDefaultAsync();
                    if (companyUser != null && updateEmployeeDetails.companyId != null)
                    {
                        companyUser.employeeId = updateEmployeeDetails.employeeId;
                        companyUser.updatedDate = DateTime.UtcNow;
                        companyUser.companyId = updateEmployeeDetails.companyId;
                        if (singleMakes1.Count() != 0 && makes1.Count() > 0)
                        {
                            companyUser.roleId = updateEmployeeDetails.roleId;
                        }
                        else if (singleChecks1.Count() != 0 && checks1.Count() > 0)
                        {
                            companyUser.roleId = updateEmployeeDetails.roleId;
                        }
                        else if (singleMakes1.Count() != 0 && makes1.Count() == 0)
                        {
                            if (singleMakes2.Count() != 0)
                            {
                                companyUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else
                            {
                                return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                            }
                        }
                        else if (singleChecks1.Count() != 0 && checks1.Count() == 0)
                        {
                            if (singleChecks2.Count() != 0)
                            {
                                companyUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else
                            {
                                return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                            }
                        }
                        else if (singleMakes1.Count() == 0 && singleChecks1.Count() == 0)
                        {
                            companyUser.roleId = updateEmployeeDetails.roleId;
                        }
                        else if (singleMakes2.Count() == 0 && singleChecks2.Count == 0)
                        {
                            if (singleMakes1.Count() != 0)//&& makes.Count() > 0)
                            {
                                companyUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else if (singleChecks1.Count() != 0) //&& checks.Count() > 0)
                            {
                                companyUser.roleId = updateEmployeeDetails.roleId;
                            }
                            else
                            {
                                return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                            }
                        }


                        else
                        {
                            return Conflict(new { message = "Client/Company have minimum users. Add adequate users under Client/Company." });
                        }

                        companyUser.updatedBy = userEmail;
                        _context.Entry(companyUser).State = EntityState.Modified;
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        return Conflict(new { message = "Company user does not exist !!!" });
                    }
                }
                catch (DbUpdateException ex)
                {
                    if (IsCompanyAlreadyMapped((long)updateEmployeeDetails.employeeId, (long)updateEmployeeDetails.companyId))
                    {
                        return Conflict(new { message = $"User is already assigned with the company" });
                    }
                    else
                    {
                        return Conflict(new { message = $"Error: {ex.Message}" });
                    }
                }
                catch (Exception ex)
                {
                    return Conflict(new { message = $"Error: {ex.Message}" });
                }
            }
            else
            {
                return Conflict(new { message = "CompanyData property should be available !!!" });
            }
            return new { message = "Record updated successfully !!!" };
        }

        //GET: api/GetDefaultAdmin/5
        [HttpGet("GetDefaultAdmin/{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetDefaultAdmin(long id, bool isClient)
        {
            if (isClient == true)
            {
                var employeePersonalDetail = await (from emp in _context.EmployeePersonalDetails
                                                    where emp.clientId == id && emp.isClientAdmin == true
                                                    join status in _context.Statuses on emp.status equals status.statusId into StatusList
                                                    from actualStatus in StatusList
                                                    join userRole in _context.UserRoles on emp.roleId equals userRole.userRoleId into RoleList
                                                    from role in RoleList.DefaultIfEmpty()
                                                    select new
                                                    {
                                                        id = emp.employeePersonalDetailId,
                                                        firstName = emp.firstName,
                                                        middleName = emp.middleName,
                                                        lastName = emp.lastName,
                                                        fatherName = emp.fatherName,
                                                        dob = emp.dob,
                                                        gender = emp.gender,
                                                        maritalStatus = emp.maritalStatus,
                                                        religion = emp.religion,
                                                        mobileNo = emp.mobileNo,
                                                        companyId = emp.companyId,
                                                        groupId = emp.groupId,
                                                        roleId = emp.roleId,
                                                        roleName = role.roleName,
                                                        updatedBy = emp.updatedBy,
                                                        updatedDate = emp.updatedDate,
                                                        createdTime = emp.createdTime,
                                                        createdBy = emp.createdBy,
                                                        email = emp.email,
                                                        status = emp.status,
                                                        statusName = actualStatus.statusName,
                                                        employeeImageUrl = emp.employeeImageUrl,
                                                        isClientAdmin = emp.isClientAdmin,
                                                        isCompanyAdmin = emp.isCompanyAdmin,
                                                        roleIds = emp.roleIds
                                                    }
                                                         ).OrderBy(c => c.createdTime).ToListAsync();//LastOrDefaultAsync();

                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
                if (employeePersonalDetail == null)
                {
                    return NotFound();
                }

                return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            }
            else
            {
                var employeePersonalDetail = await (from emp in _context.EmployeePersonalDetails
                                                    where emp.companyId == id && emp.isCompanyAdmin == true
                                                    join status in _context.Statuses on emp.status equals status.statusId into StatusList
                                                    from actualStatus in StatusList
                                                    join userRole in _context.UserRoles on emp.roleId equals userRole.userRoleId into RoleList
                                                    from role in RoleList.DefaultIfEmpty()
                                                    select new
                                                    {
                                                        id = emp.employeePersonalDetailId,
                                                        firstName = emp.firstName,
                                                        middleName = emp.middleName,
                                                        lastName = emp.lastName,
                                                        fatherName = emp.fatherName,
                                                        dob = emp.dob,
                                                        gender = emp.gender,
                                                        maritalStatus = emp.maritalStatus,
                                                        religion = emp.religion,
                                                        mobileNo = emp.mobileNo,
                                                        companyId = emp.companyId,
                                                        groupId = emp.groupId,
                                                        roleId = emp.roleId,
                                                        roleName = role.roleName,
                                                        updatedBy = emp.updatedBy,
                                                        updatedDate = emp.updatedDate,
                                                        createdTime = emp.createdTime,
                                                        createdBy = emp.createdBy,
                                                        email = emp.email,
                                                        status = emp.status,
                                                        statusName = actualStatus.statusName,
                                                        employeeImageUrl = emp.employeeImageUrl,
                                                        isClientAdmin = emp.isClientAdmin,
                                                        isCompanyAdmin = emp.isCompanyAdmin,
                                                        roleIds = emp.roleIds
                                                    }
                                                         ).OrderBy(c => c.createdTime).ToListAsync();    //LastOrDefaultAsync();

                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
                if (employeePersonalDetail == null)
                {
                    return NotFound();
                }

                return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            }

            return new { };
        }


        // PUT: api/EmployeePersonalDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutEmployeePersonalDetail(long id, EmployeePersonalDetailWithoutPassword employeePersonalDetailWithoutPassword)
        {
            var actualEmployee = await _context.EmployeePersonalDetails.Where(emp => emp.employeePersonalDetailId == id).FirstOrDefaultAsync();
            _context.Entry(actualEmployee).State = EntityState.Detached;
            if (!EmployeePersonalDetailIdExists(id))
            {
                return NotFound();
            }
            if (!Helper.OrganisationIdExists((long)employeePersonalDetailWithoutPassword.companyId))
            {
                return Conflict(new { message = $"Company Id '{employeePersonalDetailWithoutPassword.companyId}' not found." });
            }
            var actualEmployeePersonaDetail = GetEmployeePersonalDetailById(id);
            if (employeePersonalDetailWithoutPassword.password != null && actualEmployeePersonaDetail.email != employeePersonalDetailWithoutPassword.updatedBy && Helpers.Helpers.SHA256Hash(employeePersonalDetailWithoutPassword.password) != actualEmployeePersonaDetail.password)
            {
                return Conflict(new { message = "You are not the authorised user to update password !!!" });
            }



            var employeePersonalDetail = new EmployeePersonalDetail()
            {
                employeePersonalDetailId = id,
                firstName = employeePersonalDetailWithoutPassword.firstName == null ? actualEmployeePersonaDetail.firstName : employeePersonalDetailWithoutPassword.firstName,
                middleName = employeePersonalDetailWithoutPassword.middleName == null ? actualEmployeePersonaDetail.middleName : employeePersonalDetailWithoutPassword.middleName,
                lastName = employeePersonalDetailWithoutPassword.lastName == null ? actualEmployeePersonaDetail.lastName : employeePersonalDetailWithoutPassword.lastName,
                fatherName = employeePersonalDetailWithoutPassword.fatherName == null ? actualEmployeePersonaDetail.fatherName : employeePersonalDetailWithoutPassword.fatherName,
                dob = employeePersonalDetailWithoutPassword.dob == null ? actualEmployeePersonaDetail.dob : employeePersonalDetailWithoutPassword.dob,
                gender = employeePersonalDetailWithoutPassword.gender == null ? actualEmployeePersonaDetail.gender : employeePersonalDetailWithoutPassword.gender,
                maritalStatus = employeePersonalDetailWithoutPassword.maritalStatus == null ? actualEmployeePersonaDetail.maritalStatus : employeePersonalDetailWithoutPassword.maritalStatus,
                religion = employeePersonalDetailWithoutPassword.religion == null ? actualEmployeePersonaDetail.religion : employeePersonalDetailWithoutPassword.religion,
                countryCode = employeePersonalDetailWithoutPassword.countryCode == null ? actualEmployeePersonaDetail.countryCode : employeePersonalDetailWithoutPassword.countryCode,
                mobileNo = employeePersonalDetailWithoutPassword.mobileNo == null ? actualEmployeePersonaDetail.mobileNo : employeePersonalDetailWithoutPassword.mobileNo,
                companyId = employeePersonalDetailWithoutPassword.companyId == null ? actualEmployeePersonaDetail.companyId : employeePersonalDetailWithoutPassword.companyId,
                groupId = employeePersonalDetailWithoutPassword.groupId == null ? actualEmployeePersonaDetail.groupId : employeePersonalDetailWithoutPassword.groupId,
                roleId = employeePersonalDetailWithoutPassword.roleId == null ? actualEmployeePersonaDetail.roleId : employeePersonalDetailWithoutPassword.roleId,
                updatedBy = employeePersonalDetailWithoutPassword.updatedBy == null ? actualEmployeePersonaDetail.updatedBy : employeePersonalDetailWithoutPassword.updatedBy,
                updatedDate = DateTime.UtcNow,
                email = employeePersonalDetailWithoutPassword.email == null ? actualEmployeePersonaDetail.email : employeePersonalDetailWithoutPassword.email,
                password = employeePersonalDetailWithoutPassword.password != null ? Helpers.Helpers.SHA256Hash(employeePersonalDetailWithoutPassword.password) : actualEmployeePersonaDetail.password,
                status = employeePersonalDetailWithoutPassword.status == null ? actualEmployeePersonaDetail.status : employeePersonalDetailWithoutPassword.status,
                createdBy = actualEmployee != null ? actualEmployee.createdBy : "",
                createdTime = actualEmployee != null ? actualEmployee.createdTime : DateTime.UtcNow,
                isCompanyAdmin = actualEmployee.isCompanyAdmin,
                isClientAdmin = actualEmployee.isClientAdmin,
                employeeImageUrl = employeePersonalDetailWithoutPassword.employeeImageUrl,
                clientId = actualEmployee.clientId,
                roleIds = employeePersonalDetailWithoutPassword.roleIds == null ? actualEmployeePersonaDetail.roleIds : employeePersonalDetailWithoutPassword.roleIds

            };


            _context.Entry(employeePersonalDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeePersonalDetailIdExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                {
                    return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }


        // PUT: api/EmployeePersonalDetails/ValidateToDisableUser/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ValidateToDisableUser/{EmployeeId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<object> ValidateToDisableUser(long EmployeeId)
        {

            if (!EmployeePersonalDetailIdExists(EmployeeId))
            {
                return NotFound();
            }
            var employeePersonalDetail = _context.EmployeePersonalDetails.Where(m => m.employeePersonalDetailId == EmployeeId).FirstOrDefault();
            try
            {
                if (!Helper.OrganisationIdExists((long)employeePersonalDetail.companyId))
                {
                    return Conflict(new { message = $"Company Id '{employeePersonalDetail.companyId}' not found." });
                }
                //var clientUserPresent = _context.ClientUserRoleMappers.Where(up => up.employeeId == EmployeeId).ToList();
                //var ClientUserPresent = _context.CompanyUserRoleMappers.Where(up => up.employeeId == EmployeeId).ToList();

                List<ValidatedEmployee> validatedUsers = new List<ValidatedEmployee>();
                //if (comp.Count() > 0 || ncl.Count() > 0)
                //{
                if (employeePersonalDetail.roleIds != null)
                {
                    var roleIds = new JavaScriptSerializer().Deserialize<int[]>(employeePersonalDetail.roleIds).ToList();
                    roleIds.ForEach(roleId =>
                    {
                        // Validating user under client

                        var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                             (c.isAllowedToClient == true && isOwnerCompany == false)))
                                           select screenc;

                        List<String> singleChecks = new List<String>();
                        List<String> singleMakes = new List<String>();

                        var singleOutputM = (from cm in _context.ScreenPermissions
                                             where cm.roleId == roleId
                                             join sc in screenCountC on cm.screenId equals sc.screenId
                                             select new
                                             {
                                                 sc.screenId,
                                                 createPermission = cm.create,
                                                 approvePermission = cm.approve,
                                                 // createPermission = (cm.create == true ? 1 : 0)
                                                 // approvePermission = (cm.approve == true ? 1 : 0),
                                             }).ToList();
                        var singleTestM = from singleMaker in singleOutputM.Where(m => m.createPermission == true) select singleMaker;
                        //condition for checker
                        var singleTestC = from singleM in singleOutputM where singleM.approvePermission == true select singleM;

                        //if  maker
                        if (singleTestM.Count() != 0)
                        {
                            String singleMake = singleTestM.ToString();
                            singleMakes.Add(singleMake);
                        }
                        //if checker
                        if (singleTestC.Count() != 0)
                        {
                            String singleCheck = singleTestC.ToString();
                            singleChecks.Add(singleCheck);
                        }
                        var clientUser = _context.ClientUserRoleMappers.Where(c => c.employeeId == EmployeeId && c.clientId != 1).ToList();

                        List<String> less = new List<String>();
                        List<String> grt = new List<String>();
                        foreach (var c in clientUser)
                        {
                            var clientUsers = _context.ClientUserRoleMappers.Where(v => v.clientId == c.clientId && v.employeeId != EmployeeId && v.status != (int)Statuses.Deleted).ToList();
                            if (clientUsers.Count() < 2)
                            {
                                String les = clientUsers.ToString();
                                less.Add(les);
                            }
                            if (clientUsers.Count() >= 2)
                            {
                                List<String> checks = new List<String>();
                                List<String> makes = new List<String>();

                                foreach (var lll in clientUsers)
                                {
                                    var outputM = (from cm in _context.ScreenPermissions
                                                   where cm.roleId == lll.roleId
                                                   join sc in screenCountC on cm.screenId equals sc.screenId
                                                   select new
                                                   {
                                                       sc.screenId,
                                                       createPermission = cm.create,
                                                       approvePermission = cm.approve,
                                                       // createPermission = (cm.create == true ? 1 : 0)
                                                       // approvePermission = (cm.approve == true ? 1 : 0),
                                                   }).ToList();

                                    // condition for make
                                    var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                                    //condition for checker
                                    var testC = from m in outputM where m.approvePermission == true select m;

                                    //if  maker
                                    if (testM.Count() != 0)
                                    {
                                        String make = testM.ToString();
                                        makes.Add(make);
                                    }
                                    //if checker
                                    if (testC.Count() != 0)
                                    {
                                        String check = testC.ToString();
                                        checks.Add(check);
                                    }

                                }
                                if ((singleChecks.Count() > 0 || singleMakes.Count() > 0))
                                {
                                    if (singleMakes.Count() > 0 && makes.Count() == 0)
                                    {
                                        String greater = clientUsers.ToString();
                                        grt.Add(greater);
                                    }

                                    if ((singleChecks.Count() > 0 && checks.Count() == 0))
                                    {
                                        String greater = clientUsers.ToString();
                                        grt.Add(greater);
                                    }
                                }
                            }
                        }

                        // If the users mapped to the client is less than or equal to 2, exist without disabling the user
                        var comUser = _context.CompanyUserRoleMappers.Where(c => c.employeeId == EmployeeId && c.companyId != 1).ToList();

                        List<String> lessc = new List<String>();
                        List<String> grtc = new List<String>();
                        foreach (var co in comUser)
                        {
                            var comUsers1 = _context.CompanyUserRoleMappers.Where(cm => cm.companyId == co.companyId && cm.employeeId != EmployeeId && cm.status != (int)Statuses.Deleted).ToList();
                            if (comUsers1.Count() < 2)
                            {
                                String les = comUsers1.ToString();
                                lessc.Add(les);
                            }
                            if (comUsers1.Count() >= 2)
                            {
                                List<String> checks = new List<String>();
                                List<String> makes = new List<String>();

                                foreach (var lll in comUsers1)
                                {
                                    var outputM = (from cm in _context.ScreenPermissions
                                                   where cm.roleId == lll.roleId
                                                   join sc in screenCountC on cm.screenId equals sc.screenId
                                                   select new
                                                   {
                                                       sc.screenId,
                                                       createPermission = cm.create,
                                                       approvePermission = cm.approve,
                                                       // createPermission = (cm.create == true ? 1 : 0)
                                                       // approvePermission = (cm.approve == true ? 1 : 0),
                                                   }).ToList();

                                    // condition for make
                                    var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                                    //condition for checker
                                    var testC = from m in outputM where m.approvePermission == true select m;

                                    //if  maker
                                    if (testM.Count() != 0)
                                    {
                                        String make = testM.ToString();
                                        makes.Add(make);
                                    }
                                    //if checker
                                    if (testC.Count() != 0)
                                    {
                                        String check = testC.ToString();
                                        checks.Add(check);
                                    }

                                }
                                if ((singleChecks.Count() > 0 || singleMakes.Count() > 0))
                                {
                                    if (singleMakes.Count() > 0 && makes.Count() == 0)
                                    {
                                        String greater = comUsers1.ToString();
                                        grt.Add(greater);
                                    }

                                    if ((singleChecks.Count() > 0 && checks.Count() == 0))
                                    {
                                        String greater = comUsers1.ToString();
                                        grt.Add(greater);
                                    }
                                }
                            }
                        }

                        if (less.Count() > 0)
                        {
                            var userRole = _context.UserRoles.Where(u => u.userRoleId == roleId).FirstOrDefault();

                            validatedUsers.Add(new
                                                    ValidatedEmployee
                            {
                                roleId = roleId,
                                roleName = userRole.roleName,
                                message = "Users in User groups are tagged to the client which have minimum users." +
                                                        " Add adequate users under client before disabling the User."
                            });
                        }
                        else if (grt.Count() > 0)
                        {
                            var userRole = _context.UserRoles.Where(u => u.userRoleId == roleId).FirstOrDefault();

                            validatedUsers.Add(new
                                                                               ValidatedEmployee
                            {
                                roleId = roleId,
                                roleName = userRole.roleName,
                                message = "Users in User groups are tagged to the client which have minimum users." +
                                                                                   " Add adequate users under client before disabling the User."
                            });
                        }
                        else if (lessc.Count() > 0)
                        {
                            var userRole = _context.UserRoles.Where(u => u.userRoleId == roleId).FirstOrDefault();

                            validatedUsers.Add(new
                                                    ValidatedEmployee
                            {
                                roleId = roleId,
                                roleName = userRole.roleName,
                                message = "Users in User groups are tagged to the client which have minimum users." +
                                                        " Add adequate users under client before disabling the User."
                            });
                        }
                        else if (grtc.Count() > 0)
                        {
                            var userRole = _context.UserRoles.Where(u => u.userRoleId == roleId).FirstOrDefault();

                            validatedUsers.Add(new
                                                                               ValidatedEmployee
                            {
                                roleId = roleId,
                                roleName = userRole.roleName,
                                message = "Users in User groups are tagged to the client which have minimum users." +
                                                                                   " Add adequate users under client before disabling the User."
                            });
                        }


                    });

                }
                //}


                if (validatedUsers.Count() > 0)
                {
                    return Conflict(new { message = "There are some conflicts", content = validatedUsers });
                }
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeePersonalDetailIdExists(EmployeeId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                {
                    return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "OK" };
        }        // PUT: api/EmployeePersonalDetails/DisableUser/5
                 // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("DisableUser/{EmployeeId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> DisableUser(long EmployeeId)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(e => e.employeePersonalDetailId == EmployeeId).FirstOrDefaultAsync();
            if (employeePersonalDetail != null)
            {
                // Update employee status
                employeePersonalDetail.password = Helpers.Helpers.SHA256Hash(employeePersonalDetail.password);
                employeePersonalDetail.status = (int)Statuses.Deleted;
                employeePersonalDetail.updatedDate = DateTime.UtcNow;
                employeePersonalDetail.updatedBy = userEmail;
                //employeePersonalDetail.RoleIds = "[]";
                _context.Entry(employeePersonalDetail).State = EntityState.Modified;

                var clientUsers = await _context.ClientUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();
                if (clientUsers.Count() > 0)
                {
                    clientUsers.ForEach(user =>
                    {
                        user.status = employeePersonalDetail.status;
                        _context.ClientUserRoleMappers.Update(user);
                    });
                }
                var companyUsers = await _context.CompanyUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();
                if (companyUsers.Count() > 0)
                {
                    companyUsers.ForEach(user =>
                    {
                        user.status = employeePersonalDetail.status;
                        _context.CompanyUserRoleMappers.Update(user);
                    });
                }

                await _context.SaveChangesAsync();
            }
            else
            {
                return Conflict(new { message = "Employee does not exists !!!" });
            }

            return new { message = "Record updated successfully !!!" };
        }


        // PUT: api/EmployeePersonalDetails/ChangeEmployeeStatus/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeEmployeeStatus/{EmployeeId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> ChangeEmployeeStatus(long EmployeeId)
        {
            if (!EmployeePersonalDetailIdExists(EmployeeId))
            {
                return NotFound();
            }
            var employeePersonalDetail = _context.EmployeePersonalDetails.Where(m => m.employeePersonalDetailId == EmployeeId).FirstOrDefault();
            if (!Helper.OrganisationIdExists((long)employeePersonalDetail.companyId))
            {
                return Conflict(new { message = $"Company Id '{employeePersonalDetail.companyId}' not found." });
            }

            employeePersonalDetail.password = Helpers.Helpers.SHA256Hash(employeePersonalDetail.password);
            employeePersonalDetail.status = (int)Statuses.Approved;
            employeePersonalDetail.updatedDate = DateTime.UtcNow;
            _context.Entry(employeePersonalDetail).State = EntityState.Modified;

            var clientUsers = await _context.ClientUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();
            if (clientUsers.Count() > 0)
            {
                clientUsers.ForEach(user =>
                {
                    user.status = employeePersonalDetail.status;
                    _context.ClientUserRoleMappers.Update(user);
                });
            }
            var companyUsers = await _context.CompanyUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();
            if (companyUsers.Count() > 0)
            {
                companyUsers.ForEach(user =>
                {
                    user.status = employeePersonalDetail.status;
                    _context.CompanyUserRoleMappers.Update(user);
                });
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeePersonalDetailIdExists(EmployeeId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                {
                    return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }



        private async Task<string> FileUploadAsync(IFormFile formFile, long employeeId)
        {
            //long size = files.Sum(f => f.Length);


            //foreach (var formFile in files)
            //{
            //    if (formFile.Length > 0)
            //    {
            var filePath = Path.GetTempFileName();
            //string myBucketName = "tmi-elixirhr"; //your s3 bucket name goes here  
            string myBucketName = configuration.GetValue<string>("AwsBucket:BucketName");
            string s3DirectoryName = configuration.GetValue<string>("AwsBucket:DirectoryName");
            string s3URL = configuration.GetValue<string>("AwsBucket:URL");
            string s3FileName = filePath;
            string fileName = $"employee_{employeeId}.{formFile.FileName.Split(".").Last()}";
            using (var stream = System.IO.File.Create(filePath))
            {

                await formFile.CopyToAsync(stream);
                bool a;
                AmazonUploader myUploader = new AmazonUploader();
                a = myUploader.sendMyFileToS3(stream, myBucketName, s3DirectoryName, fileName);
                if (a == true)
                {
                    return $"{s3URL}/{s3DirectoryName}/{fileName}";

                }
                else
                    return "File not uploaded";
            }

            //    }
            //}

            // Process uploaded files
            // Don't rely on or trust the FileName property without validation.

            return "";
        }

        // POST: api/EmployeePersonalDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("UploadEmployeeDataWithImage")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<object>> UploadEmployeeDataWithImage([FromForm] EmployeePersonalDetailWithImage employeePersonalDetailWithImage)
        {
            try
            {
                _logger.LogInformation($"############## Reached Employee_Personal_Details ####################");
                EmployeePersonalDetail employeePersonalDetail = new EmployeePersonalDetail
                {
                    firstName = employeePersonalDetailWithImage.firstName,
                    middleName = employeePersonalDetailWithImage.middleName,
                    lastName = employeePersonalDetailWithImage.lastName,
                    fatherName = employeePersonalDetailWithImage.fatherName,
                    dob = employeePersonalDetailWithImage.dob,
                    gender = employeePersonalDetailWithImage.gender,
                    maritalStatus = employeePersonalDetailWithImage.maritalStatus,
                    religion = employeePersonalDetailWithImage.religion,
                    countryCode = employeePersonalDetailWithImage.countryCode,
                    mobileNo = employeePersonalDetailWithImage.mobileNo,
                    companyId = employeePersonalDetailWithImage.companyId,
                    groupId = employeePersonalDetailWithImage.groupId,
                    roleId = employeePersonalDetailWithImage.roleId,
                    email = employeePersonalDetailWithImage.email,
                    password = employeePersonalDetailWithImage.password,
                    status = employeePersonalDetailWithImage.status,
                    updatedBy = employeePersonalDetailWithImage.updatedBy,
                    createdBy = employeePersonalDetailWithImage.createdBy
                };

                _context.EmployeePersonalDetails.Add(employeePersonalDetail);
                try
                {
                    if (!Helper.OrganisationIdExists((long)employeePersonalDetail.companyId))
                    {
                        return Conflict(new { message = $"Company Id '{employeePersonalDetail.companyId}' not found." });
                    }
                    var _count = await _context.EmployeePersonalDetails.CountAsync();
                    employeePersonalDetail.employeePersonalDetailId = _count + 1;
                    if (employeePersonalDetailWithImage.formFile != null)
                    {
                        string[] extensions = { ".jpg", ".jpeg", ".gif", ".bmp", ".png" };
                        if (extensions.Any(x => x.Equals(Path.GetExtension(employeePersonalDetailWithImage.formFile.FileName.ToLower()), StringComparison.OrdinalIgnoreCase)))
                        {
                            var imageUrl = await FileUploadAsync(employeePersonalDetailWithImage.formFile, employeePersonalDetail.employeePersonalDetailId);
                            employeePersonalDetail.employeeImageUrl = imageUrl;
                        }
                        else
                        {
                            return Conflict(new { message = $"Only .png/.jpg/.jpeg /.gif/.bmp are allowed to upload !!!" });
                        }
                    }
                    employeePersonalDetail.password = Helpers.Helpers.SHA256Hash(employeePersonalDetail.password);
                    employeePersonalDetail.createdTime = DateTime.UtcNow;
                    employeePersonalDetail.updatedDate = employeePersonalDetail.createdTime;

                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (EmployeePersonalDetailIdExists(employeePersonalDetail.employeePersonalDetailId))
                    {
                        return Conflict();
                    }
                    else if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                    {
                        return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                    }
                    else
                    {
                        throw;
                    }
                }
                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
                return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"############## Error in post Employee_Personal_Details #################### \n {ex.Message}");
            }
            return new { };
        }

        [HttpPost()]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<object>> PostEmployeePersonalDetail(EmployeePersonalDetail employeePersonalDetailWithImage)
        {
            try
            {
                _logger.LogInformation($"############## Reached Employee_Personal_Details ####################");


                EmployeePersonalDetail employeePersonalDetail = new EmployeePersonalDetail
                {
                    firstName = employeePersonalDetailWithImage.firstName,
                    middleName = employeePersonalDetailWithImage.middleName,
                    lastName = employeePersonalDetailWithImage.lastName,
                    fatherName = employeePersonalDetailWithImage.fatherName,
                    dob = employeePersonalDetailWithImage.dob,
                    gender = employeePersonalDetailWithImage.gender,
                    maritalStatus = employeePersonalDetailWithImage.maritalStatus,
                    religion = employeePersonalDetailWithImage.religion,
                    countryCode = employeePersonalDetailWithImage.countryCode, // CountryCode
                    mobileNo = employeePersonalDetailWithImage.mobileNo,
                    companyId = employeePersonalDetailWithImage.companyId,
                    groupId = employeePersonalDetailWithImage.groupId,
                    clientId = employeePersonalDetailWithImage.clientId,
                    roleId = employeePersonalDetailWithImage.companyId == 1 && employeePersonalDetailWithImage.roleId == null ? 2 : employeePersonalDetailWithImage.roleId, // For TMI user role is set as "2"
                    email = employeePersonalDetailWithImage.email,
                    //Password = "Tmi@12345",
                    password = RandomString(9),
                    status = employeePersonalDetailWithImage.status,
                    updatedBy = employeePersonalDetailWithImage.updatedBy,
                    createdBy = employeePersonalDetailWithImage.createdBy,
                    employeeImageUrl = employeePersonalDetailWithImage.employeeImageUrl,
                    isClientAdmin = employeePersonalDetailWithImage.isClientAdmin,
                    isCompanyAdmin = employeePersonalDetailWithImage.isCompanyAdmin,
                    roleIds = employeePersonalDetailWithImage.roleIds
                };



                _context.EmployeePersonalDetails.Add(employeePersonalDetail);
                try
                {
                    if (!Helper.OrganisationIdExists((long)employeePersonalDetail.companyId))
                    {
                        return Conflict(new { message = $"Company Id '{employeePersonalDetail.companyId}' not found." });
                    }
                    var lastEmployee = await _context.EmployeePersonalDetails.OrderBy(emp => emp.employeePersonalDetailId).LastOrDefaultAsync();
                    employeePersonalDetail.employeePersonalDetailId = lastEmployee != null ? lastEmployee.employeePersonalDetailId + 1 : 1;
                    employeePersonalDetail.password = Helpers.Helpers.SHA256Hash(employeePersonalDetail.password);
                    employeePersonalDetail.createdTime = DateTime.UtcNow;
                    employeePersonalDetail.updatedDate = employeePersonalDetail.createdTime;
                    //TrackPassword trackPassword = new TrackPassword
                    //{
                    //    EmployeeId = employeePersonalDetail.Id,
                    //    LastChanged = DateTime.UtcNow,
                    //    Password = employeePersonalDetail.Password
                    //};
                    //_context.TrackPasswords.Add(trackPassword);

                    CompanyUserRoleMapper companyUserRoleMapper = new CompanyUserRoleMapper
                    {
                        companyId = employeePersonalDetail.companyId,
                        employeeId = employeePersonalDetail.employeePersonalDetailId,
                        roleId = employeePersonalDetail.roleId,
                        updatedDate = DateTime.UtcNow,
                        createdDate = DateTime.UtcNow,
                        status = (int)Statuses.Approved

                    };
                    ClientUserRoleMapper clientUserRoleMapper = new ClientUserRoleMapper
                    {
                        clientId = employeePersonalDetail.clientId,
                        employeeId = employeePersonalDetail.employeePersonalDetailId,
                        roleId = employeePersonalDetail.roleId,
                        updatedDate = DateTime.UtcNow,
                        createdDate = DateTime.UtcNow,
                        status = (int)Statuses.Approved
                    };

                    await _context.SaveChangesAsync();
                    _context.ClientUserRoleMappers.Add(clientUserRoleMapper);
                    _context.Add(companyUserRoleMapper);

                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (EmployeePersonalDetailIdExists(employeePersonalDetail.employeePersonalDetailId))
                    {
                        return Conflict();
                    }
                    else if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                    {
                        return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                    }
                    else
                    {
                        throw;
                    }
                }
                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
                return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"############## Error in post Employee_Personal_Details #################### \n {ex.Message}");
            }
            return new { };
        }

        [HttpPost("CreateCompanyAdmin/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<object>> CreateCompanyAdmin(EmployeePersonalDetail employeePersonalDetailWithImage, long CompanyId)
        {
            try
            {
                _logger.LogInformation($"############## Reached Employee_Personal_Details ####################");
                if (employeePersonalDetailWithImage.companyId == null)
                {
                    return Conflict(new { message = "Company Id is mandatory !!!" });

                }
                var Num = _context.EmployeePersonalDetails.Where(n => n.mobileNo == employeePersonalDetailWithImage.mobileNo && n.employeePersonalDetailId != employeePersonalDetailWithImage.employeePersonalDetailId).FirstOrDefault();
                if (Num != null)
                {
                    return Conflict(new { message = "MobileNumber already found." });
                }
                bool isValid = Regex.IsMatch(employeePersonalDetailWithImage.mobileNo, @"^\d{10}$");

                if (!isValid)
                {
                    return Conflict(new { message = "Invalid MobileNumber." });

                }

                // If the email Id and company id matches the data, then the value should be updated.
                if (EmployeePersonalDetailEmailExists(employeePersonalDetailWithImage.email))
                {
                    var employeePersonalDetails = await _context.EmployeePersonalDetails.Where(emp => emp.email == employeePersonalDetailWithImage.email &&
                    emp.companyId == employeePersonalDetailWithImage.companyId).FirstOrDefaultAsync();

                    if (employeePersonalDetails != null)
                    {
                        employeePersonalDetails.firstName = employeePersonalDetailWithImage.firstName;
                        employeePersonalDetails.middleName = employeePersonalDetailWithImage.middleName;
                        employeePersonalDetails.lastName = employeePersonalDetailWithImage.lastName;
                        employeePersonalDetails.fatherName = employeePersonalDetailWithImage.fatherName;
                        employeePersonalDetails.dob = employeePersonalDetailWithImage.dob;
                        employeePersonalDetails.gender = employeePersonalDetailWithImage.gender;
                        employeePersonalDetails.maritalStatus = employeePersonalDetailWithImage.maritalStatus;
                        employeePersonalDetails.religion = employeePersonalDetailWithImage.religion;
                        employeePersonalDetails.countryCode = employeePersonalDetailWithImage.countryCode;
                        employeePersonalDetails.mobileNo = employeePersonalDetailWithImage.mobileNo;
                        employeePersonalDetails.companyId = employeePersonalDetailWithImage.companyId;
                        employeePersonalDetails.groupId = employeePersonalDetailWithImage.groupId;
                        employeePersonalDetails.email = employeePersonalDetailWithImage.email;
                        //employeePersonalDetails.Password = Helpers.Helpers.SHA256Hash("Tmi@12345");
                        employeePersonalDetails.password = Helpers.Helpers.SHA256Hash(RandomString(9));
                        employeePersonalDetails.status = employeePersonalDetailWithImage.status;
                        employeePersonalDetails.updatedBy = employeePersonalDetailWithImage.updatedBy;
                        employeePersonalDetails.createdBy = employeePersonalDetailWithImage.createdBy;
                        employeePersonalDetails.employeeImageUrl = employeePersonalDetailWithImage.employeeImageUrl;
                        employeePersonalDetails.isClientAdmin = employeePersonalDetailWithImage.isClientAdmin;
                        employeePersonalDetails.isCompanyAdmin = employeePersonalDetailWithImage.isCompanyAdmin;
                        employeePersonalDetails.clientId = employeePersonalDetailWithImage.clientId;
                        _context.Entry(employeePersonalDetails).State = EntityState.Modified;
                        // await _context.SaveChangesAsync();
                        return new { message = "Record updated successfully !!!" };
                    }
                    else
                    {
                        return Conflict(new { message = "An user with same Email Id already existing, in different company !!!" });
                    }

                }

                // Validate Client Id, when company Id is '0'

                if (employeePersonalDetailWithImage.companyId == 0 && employeePersonalDetailWithImage.clientId != 0)
                {
                    var company = await _context.Organisations.Where(org => org.clientId == employeePersonalDetailWithImage.clientId).FirstOrDefaultAsync();
                    if (company == null)
                    {
                        return Conflict(new { message = "There is no company for the client Id." });
                    }
                    else
                    {
                        employeePersonalDetailWithImage.companyId = company.companyId;
                    }
                }

                // Validate role name, insert only if the name did not exist.

                var roleName = employeePersonalDetailWithImage.isClientAdmin == true ? "Client Admin" : "Company Admin";

                var isExistsRoleName = await _context.UserRoles.Where(userRole => userRole.roleName == roleName && userRole.companyId == employeePersonalDetailWithImage.companyId).FirstOrDefaultAsync();
                UserRole userRole = new UserRole();
                if (isExistsRoleName == null)
                {


                    var lastUserRole = await _context.UserRoles.OrderBy(role => role.userRoleId).LastOrDefaultAsync();
                    userRole = new UserRole
                    {
                        userRoleId = lastUserRole != null ? lastUserRole.userRoleId + 1 : 1,
                        companyId = employeePersonalDetailWithImage.companyId,
                        createdBy = employeePersonalDetailWithImage.createdBy,
                        updatedBy = employeePersonalDetailWithImage.updatedBy,
                        roleName = employeePersonalDetailWithImage.isClientAdmin == true ? "Client Admin" : "Company Admin",
                        createdTime = DateTime.UtcNow,
                        updatedDate = DateTime.UtcNow,
                        isMultiCompany = false,
                        status = 1
                    };
                    _context.UserRoles.Add(userRole);
                }
                else
                {
                    userRole = isExistsRoleName;
                }



                await _context.SaveChangesAsync();
                if (employeePersonalDetailWithImage.isClientAdmin == true)
                {
                    if (!ModuleOrganisationMapperExists(7, (int)employeePersonalDetailWithImage.companyId))
                    {
                        ModuleOrganisationMapper moduleOrganisationMapper = new ModuleOrganisationMapper
                        {
                            companyId = employeePersonalDetailWithImage.companyId,
                            createdBy = employeePersonalDetailWithImage.createdBy,
                            updatedBy = employeePersonalDetailWithImage.updatedBy,
                            createdTime = DateTime.UtcNow,
                            moduleId = 7,// AccessControl module Id
                            status = 1,
                            updatedDate = DateTime.UtcNow
                        };
                        _context.ModuleOrganisationMappers.Add(moduleOrganisationMapper);
                    }
                    // Select all screens which are mapped with access control logic
                    var screensForAccessControl = await _context.Screens.Where(screen => screen.moduleId == 7).ToListAsync();
                    foreach (var screen in screensForAccessControl)
                    {
                        ScreenPermission screenPermission = new ScreenPermission
                        {
                            approve = true,
                            create = true,
                            createdBy = employeePersonalDetailWithImage.createdBy,
                            createdTime = DateTime.UtcNow,
                            update = true,
                            delete = true,
                            read = true,
                            roleId = userRole.userRoleId,
                            screenId = screen.screenId,
                            status = 1,
                            updatedBy = employeePersonalDetailWithImage.updatedBy,
                            updatedDate = DateTime.Now
                        };
                        if (!ScreenPermissionExists(userRole.userRoleId, screen.screenId))
                        {
                            _context.ScreenPermissions.Add(screenPermission);
                            // await _context.SaveChangesAsync();
                            _context.Entry(screenPermission).State = EntityState.Detached;
                        }
                    }

                    RoleOrganisationMapper roleOrganisationMapper = new RoleOrganisationMapper
                    {
                        companyId = employeePersonalDetailWithImage.companyId,
                        roleId = userRole.userRoleId,
                        createdBy = employeePersonalDetailWithImage.createdBy,
                        createdTime = DateTime.UtcNow,
                        updatedBy = employeePersonalDetailWithImage.updatedBy,
                        updatedDate = DateTime.UtcNow
                    };

                    if (!IsRoleOrganisationAlreadyMapped((long)roleOrganisationMapper.roleId, (long)roleOrganisationMapper.companyId))
                    {
                        _context.RoleOrganisationMappers.Add(roleOrganisationMapper);
                    }


                }


                //_context.UserRoles.Add(userRole);
                // await _context.SaveChangesAsync();

                EmployeePersonalDetail employeePersonalDetail = new EmployeePersonalDetail
                {
                    firstName = employeePersonalDetailWithImage.firstName,
                    middleName = employeePersonalDetailWithImage.middleName,
                    lastName = employeePersonalDetailWithImage.lastName,
                    fatherName = employeePersonalDetailWithImage.fatherName,
                    dob = employeePersonalDetailWithImage.dob,
                    gender = employeePersonalDetailWithImage.gender,
                    maritalStatus = employeePersonalDetailWithImage.maritalStatus,
                    religion = employeePersonalDetailWithImage.religion,
                    mobileNo = employeePersonalDetailWithImage.mobileNo,
                    companyId = employeePersonalDetailWithImage.companyId,
                    groupId = employeePersonalDetailWithImage.groupId,
                    //RoleId = employeePersonalDetailWithImage.IsClientAdmin == true ? (int)UserRoles.ClientAdmin : (int)UserRoles.CompanyAdmin,
                    roleId = userRole.userRoleId,
                    email = employeePersonalDetailWithImage.email,
                    //Password = Helpers.Helpers.SHA256Hash("Tmi@12345"),
                    password = Helpers.Helpers.SHA256Hash(RandomString(9)),
                    status = employeePersonalDetailWithImage.status,
                    updatedBy = employeePersonalDetailWithImage.updatedBy,
                    createdBy = employeePersonalDetailWithImage.createdBy,
                    employeeImageUrl = employeePersonalDetailWithImage.employeeImageUrl,
                    isClientAdmin = employeePersonalDetailWithImage.isClientAdmin,
                    isCompanyAdmin = employeePersonalDetailWithImage.isCompanyAdmin,
                    clientId = employeePersonalDetailWithImage.clientId,
                    roleIds = $"[{userRole.userRoleId}]",
                };

                _context.EmployeePersonalDetails.Update(employeePersonalDetail);
                try
                {
                    if (!Helper.OrganisationIdExists((long)employeePersonalDetail.companyId))
                    {
                        return Conflict(new { message = $"Company Id '{employeePersonalDetail.companyId}' not found." });
                    }
                    var lastEmployee = await _context.EmployeePersonalDetails.OrderBy(emp => emp.employeePersonalDetailId).LastOrDefaultAsync();
                    employeePersonalDetail.employeePersonalDetailId = lastEmployee != null ? lastEmployee.employeePersonalDetailId + 1 : 1;
                    //employeePersonalDetail.Password = Helpers.Helpers.SHA256Hash(employeePersonalDetail.Password);
                    employeePersonalDetail.createdTime = DateTime.UtcNow;
                    employeePersonalDetail.updatedDate = employeePersonalDetail.createdTime;
                    if (employeePersonalDetailWithImage.isCompanyAdmin == true)
                    {
                        var client = await _context.Organisations.Where(org => org.companyId == employeePersonalDetail.companyId).FirstOrDefaultAsync();
                        if (client != null)
                        {
                            employeePersonalDetail.clientId = client.clientId;
                        }
                    }

                    //TrackPassword trackPassword = new TrackPassword
                    //{
                    //    EmployeeId = employeePersonalDetail.Id,
                    //    LastChanged = DateTime.UtcNow,
                    //    Password = employeePersonalDetail.Password
                    //};
                    //_context.TrackPasswords.Add(trackPassword);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (EmployeePersonalDetailIdExists(employeePersonalDetail.employeePersonalDetailId))
                    {
                        return Conflict();
                    }
                    else if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                    {
                        return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                    }
                    else
                    {
                        throw;
                    }
                }
                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
                return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"############## Error in post Employee_Personal_Details #################### \n {ex.Message}");
                return Conflict(new { message = ex.Message });
            }

            return new { };
        }


        [HttpPost("CreateClientAdmin/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<object>> CreateClientAdmin(ClientSetup employeePersonalDetailWithImage, long CompanyId)
        {
            try
            {
                _logger.LogInformation($"############## Reached Employee_Personal_Details ####################");
                string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
                if (employeePersonalDetailWithImage.companyId == null)
                {
                    return Conflict(new { message = "Company Id is mandatory !!!" });

                }
                var Num = _context.EmployeePersonalDetails.Where(n => n.mobileNo == employeePersonalDetailWithImage.mobileNo1 && n.employeePersonalDetailId != employeePersonalDetailWithImage.employeePersonalDetailId).FirstOrDefault();
                if (Num != null)
                {
                    return Conflict(new { message = "MobileNumber already found." });
                }
                bool isValid = Regex.IsMatch(employeePersonalDetailWithImage.mobileNo1, @"^\d{10}$");

                var ClientNum = _context.ClientCreation.Where(n => n.mobileNo == employeePersonalDetailWithImage.mobileNo && n.clientId != employeePersonalDetailWithImage.clientId).FirstOrDefault();
                if (ClientNum != null)
                {
                    return Conflict(new { message = "MobileNumber already found." });
                }
                bool isValid1 = Regex.IsMatch(employeePersonalDetailWithImage.mobileNo, @"^\d{10}$");

                if (!isValid || !isValid1)
                {
                    return Conflict(new { message = "Invalid MobileNumber." });

                }

                if (employeePersonalDetailWithImage.clientName == null)
                {
                    return Conflict(new { message = "Client name is mandatory" });
                }
                //if (employeePersonalDetailWithImage.status == (int)Statuses.Deleted)
                //{
                //    var companies = _context.Organisations.Where(org => org.clientId == employeePersonalDetailWithImage.clientId).ToList();
                //    companies.ForEach(comp =>
                //    {
                //        comp.status = (int)Statuses.Deleted;
                //        comp.updatedDate = DateTime.UtcNow;
                //        _context.Entry(comp).State = EntityState.Modified;
                //    });
                //}

                var clientdata = await _context.ClientCreation.Where(a => a.clientId == employeePersonalDetailWithImage.clientId).FirstOrDefaultAsync();

                if (clientdata != null)
                {
                    clientdata.clientName = employeePersonalDetailWithImage.clientName;
                    clientdata.mobileNo = employeePersonalDetailWithImage.mobileNo;
                    clientdata.status = employeePersonalDetailWithImage.status;
                    clientdata.address1 = employeePersonalDetailWithImage.address1;
                    clientdata.address2 = employeePersonalDetailWithImage.address2;
                    clientdata.address3 = employeePersonalDetailWithImage.address3;
                    clientdata.pincode = employeePersonalDetailWithImage.pincode;
                    clientdata.pan = employeePersonalDetailWithImage.pan;
                    clientdata.tan = employeePersonalDetailWithImage.tan;
                    clientdata.stateId = employeePersonalDetailWithImage.stateId;
                    clientdata.countryId = employeePersonalDetailWithImage.countryId;
                    clientdata.twoWayAuthentication = employeePersonalDetailWithImage.twoWayAuthentication;
                    clientdata.isEmail = employeePersonalDetailWithImage.isEmail;
                    clientdata.isSms = employeePersonalDetailWithImage.isSms;
                    clientdata.rejectionReason = employeePersonalDetailWithImage.rejectionReason;

                }


                clientdata.clientId = employeePersonalDetailWithImage.clientId;
                clientdata.updatedBy = userEmail;
                clientdata.updatedDate = DateTime.UtcNow;
                if (employeePersonalDetailWithImage.isSms == true || employeePersonalDetailWithImage.isEmail == true)
                {
                    _context.ClientCreation.Update(clientdata);
                    // _context.Entry(employeePersonalDetailWithImage).State = EntityState.Modified;
                }
                else
                {
                    return Conflict(new { message = "Either Mail or SMS is Required!!!" });
                }




                // If the email Id and company id matches the data, then the value should be updated.
                if (EmployeePersonalDetailEmailExists(employeePersonalDetailWithImage.email))
                {
                    var employeePersonalDetails = await _context.EmployeePersonalDetails.Where(emp => emp.email == employeePersonalDetailWithImage.email &&
                    emp.companyId == employeePersonalDetailWithImage.companyId).FirstOrDefaultAsync();

                    if (employeePersonalDetails != null)
                    {
                        employeePersonalDetails.firstName = employeePersonalDetailWithImage.firstName;
                        employeePersonalDetails.middleName = employeePersonalDetailWithImage.middleName;
                        employeePersonalDetails.lastName = employeePersonalDetailWithImage.lastName;
                        employeePersonalDetails.fatherName = employeePersonalDetailWithImage.fatherName;
                        employeePersonalDetails.dob = employeePersonalDetailWithImage.dob;
                        employeePersonalDetails.gender = employeePersonalDetailWithImage.gender;
                        employeePersonalDetails.maritalStatus = employeePersonalDetailWithImage.maritalStatus;
                        employeePersonalDetails.religion = employeePersonalDetailWithImage.religion;
                        employeePersonalDetails.countryCode = employeePersonalDetailWithImage.countryCode;
                        employeePersonalDetails.mobileNo = employeePersonalDetailWithImage.mobileNo1;
                        employeePersonalDetails.companyId = employeePersonalDetailWithImage.companyId;
                        employeePersonalDetails.groupId = employeePersonalDetailWithImage.groupId;
                        employeePersonalDetails.email = employeePersonalDetailWithImage.email;
                        //employeePersonalDetails.Password = Helpers.Helpers.SHA256Hash("Tmi@12345");
                        employeePersonalDetails.password = Helpers.Helpers.SHA256Hash(RandomString(9));
                        employeePersonalDetails.status = employeePersonalDetailWithImage.status;
                        employeePersonalDetails.updatedBy = employeePersonalDetailWithImage.updatedBy;
                        employeePersonalDetails.createdBy = employeePersonalDetailWithImage.createdBy;
                        employeePersonalDetails.employeeImageUrl = employeePersonalDetailWithImage.employeeImageUrl;
                        employeePersonalDetails.isClientAdmin = employeePersonalDetailWithImage.isClientAdmin;
                        employeePersonalDetails.isCompanyAdmin = employeePersonalDetailWithImage.isCompanyAdmin;
                        employeePersonalDetails.clientId = employeePersonalDetailWithImage.clientId;
                        _context.Entry(employeePersonalDetails).State = EntityState.Modified;
                        await _context.SaveChangesAsync();
                        return new { message = "Record updated successfully !!!" };
                    }
                    else
                    {
                        return Conflict(new { message = "An user with same Email Id already existing, in different company !!!" });
                    }

                }

                // Validate Client Id, when company Id is '0'

                if (employeePersonalDetailWithImage.companyId == 0 && employeePersonalDetailWithImage.clientId != 0)
                {
                    var company = await _context.Organisations.Where(org => org.clientId == employeePersonalDetailWithImage.clientId).FirstOrDefaultAsync();
                    if (company == null)
                    {
                        return Conflict(new { message = "There is no company for the client Id." });
                    }
                    else
                    {
                        employeePersonalDetailWithImage.companyId = company.companyId;
                    }
                }

                // Validate role name, insert only if the name did not exist.

                var roleName = employeePersonalDetailWithImage.isClientAdmin == true ? "Client Admin" : "Company Admin";

                var isExistsRoleName = await _context.UserRoles.Where(userRole => userRole.roleName == roleName && userRole.companyId == employeePersonalDetailWithImage.companyId).FirstOrDefaultAsync();
                UserRole userRole = new UserRole();
                if (isExistsRoleName == null)
                {


                    var lastUserRole = await _context.UserRoles.OrderBy(role => role.userRoleId).LastOrDefaultAsync();
                    userRole = new UserRole
                    {
                        userRoleId = lastUserRole != null ? lastUserRole.userRoleId + 1 : 1,
                        companyId = employeePersonalDetailWithImage.companyId,
                        createdBy = employeePersonalDetailWithImage.createdBy,
                        updatedBy = employeePersonalDetailWithImage.updatedBy,
                        roleName = employeePersonalDetailWithImage.isClientAdmin == true ? "Client Admin" : "Company Admin",
                        createdTime = DateTime.UtcNow,
                        updatedDate = DateTime.UtcNow,
                        isMultiCompany = false,
                        status = 1
                    };
                    _context.UserRoles.Add(userRole);
                }
                else
                {
                    userRole = isExistsRoleName;
                }



                // await _context.SaveChangesAsync();
                if (employeePersonalDetailWithImage.isClientAdmin == true)
                {
                    if (!ModuleOrganisationMapperExists(7, (int)employeePersonalDetailWithImage.companyId))
                    {
                        ModuleOrganisationMapper moduleOrganisationMapper = new ModuleOrganisationMapper
                        {
                            companyId = employeePersonalDetailWithImage.companyId,
                            createdBy = employeePersonalDetailWithImage.createdBy,
                            updatedBy = employeePersonalDetailWithImage.updatedBy,
                            createdTime = DateTime.UtcNow,
                            moduleId = 7,// AccessControl module Id
                            status = 1,
                            updatedDate = DateTime.UtcNow
                        };
                        _context.ModuleOrganisationMappers.Add(moduleOrganisationMapper);
                    }
                    // Select all screens which are mapped with access control logic
                    var screensForAccessControl = await _context.Screens.Where(screen => screen.moduleId == 7).ToListAsync();
                    foreach (var screen in screensForAccessControl)
                    {
                        ScreenPermission screenPermission = new ScreenPermission
                        {
                            approve = true,
                            create = true,
                            createdBy = employeePersonalDetailWithImage.createdBy,
                            createdTime = DateTime.UtcNow,
                            update = true,
                            delete = true,
                            read = true,
                            roleId = userRole.userRoleId,
                            screenId = screen.screenId,
                            status = 1,
                            updatedBy = employeePersonalDetailWithImage.updatedBy,
                            updatedDate = DateTime.Now
                        };
                        if (!ScreenPermissionExists(userRole.userRoleId, screen.screenId))
                        {
                            _context.ScreenPermissions.Add(screenPermission);
                            // await _context.SaveChangesAsync();
                            _context.Entry(screenPermission).State = EntityState.Detached;
                        }
                    }

                    RoleOrganisationMapper roleOrganisationMapper = new RoleOrganisationMapper
                    {
                        companyId = employeePersonalDetailWithImage.companyId,
                        roleId = userRole.userRoleId,
                        createdBy = employeePersonalDetailWithImage.createdBy,
                        createdTime = DateTime.UtcNow,
                        updatedBy = employeePersonalDetailWithImage.updatedBy,
                        updatedDate = DateTime.UtcNow
                    };

                    if (!IsRoleOrganisationAlreadyMapped((long)roleOrganisationMapper.roleId, (long)roleOrganisationMapper.companyId))
                    {
                        _context.RoleOrganisationMappers.Add(roleOrganisationMapper);
                    }


                }


                //_context.UserRoles.Add(userRole);
                // await _context.SaveChangesAsync();

                EmployeePersonalDetail employeePersonalDetail = new EmployeePersonalDetail
                {
                    firstName = employeePersonalDetailWithImage.firstName,
                    middleName = employeePersonalDetailWithImage.middleName,
                    lastName = employeePersonalDetailWithImage.lastName,
                    fatherName = employeePersonalDetailWithImage.fatherName,
                    dob = employeePersonalDetailWithImage.dob,
                    gender = employeePersonalDetailWithImage.gender,
                    maritalStatus = employeePersonalDetailWithImage.maritalStatus,
                    religion = employeePersonalDetailWithImage.religion,
                    mobileNo = employeePersonalDetailWithImage.mobileNo,
                    companyId = employeePersonalDetailWithImage.companyId,
                    groupId = employeePersonalDetailWithImage.groupId,
                    //RoleId = employeePersonalDetailWithImage.IsClientAdmin == true ? (int)UserRoles.ClientAdmin : (int)UserRoles.CompanyAdmin,
                    roleId = userRole.userRoleId,
                    email = employeePersonalDetailWithImage.email,
                    //Password = Helpers.Helpers.SHA256Hash("Tmi@12345"),
                    password = Helpers.Helpers.SHA256Hash(RandomString(9)),
                    status = employeePersonalDetailWithImage.status,
                    updatedBy = employeePersonalDetailWithImage.updatedBy,
                    createdBy = employeePersonalDetailWithImage.createdBy,
                    employeeImageUrl = employeePersonalDetailWithImage.employeeImageUrl,
                    isClientAdmin = employeePersonalDetailWithImage.isClientAdmin,
                    isCompanyAdmin = employeePersonalDetailWithImage.isCompanyAdmin,
                    clientId = employeePersonalDetailWithImage.clientId,
                    roleIds = $"[{userRole.userRoleId}]",
                };

                _context.EmployeePersonalDetails.Update(employeePersonalDetail);
                try
                {
                    if (!Helper.OrganisationIdExists((long)employeePersonalDetail.companyId))
                    {
                        return Conflict(new { message = $"Company Id '{employeePersonalDetail.companyId}' not found." });
                    }
                    var lastEmployee = await _context.EmployeePersonalDetails.OrderBy(emp => emp.employeePersonalDetailId).LastOrDefaultAsync();
                    employeePersonalDetail.employeePersonalDetailId = lastEmployee != null ? lastEmployee.employeePersonalDetailId + 1 : 1;
                    //employeePersonalDetail.Password = Helpers.Helpers.SHA256Hash(employeePersonalDetail.Password);
                    employeePersonalDetail.createdTime = DateTime.UtcNow;
                    employeePersonalDetail.updatedDate = employeePersonalDetail.createdTime;
                    if (employeePersonalDetailWithImage.isCompanyAdmin == true)
                    {
                        var client = await _context.Organisations.Where(org => org.companyId == employeePersonalDetail.companyId).FirstOrDefaultAsync();
                        if (client != null)
                        {
                            employeePersonalDetail.clientId = client.clientId;
                        }
                    }

                    //TrackPassword trackPassword = new TrackPassword
                    //{
                    //    EmployeeId = employeePersonalDetail.Id,
                    //    LastChanged = DateTime.UtcNow,
                    //    Password = employeePersonalDetail.Password
                    //};
                    //_context.TrackPasswords.Add(trackPassword);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (EmployeePersonalDetailIdExists(employeePersonalDetail.employeePersonalDetailId))
                    {
                        return Conflict();
                    }
                    else if (EmployeePersonalDetailEmailExists(employeePersonalDetail.email))
                    {
                        return Conflict(new { message = $"An email Id '{employeePersonalDetail.email}' was already found." });
                    }
                    else
                    {
                        throw;
                    }
                }
                var employeePersonalDetailsJson = JsonConvert.SerializeObject(employeePersonalDetail);
                return System.Text.Json.JsonSerializer.Deserialize<object>(employeePersonalDetailsJson);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"############## Error in post Employee_Personal_Details #################### \n {ex.Message}");
                return Conflict(new { message = ex.Message });
            }

            return new { };
        }



        [HttpGet("GetClientAdmin/{ClientId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetClientAdmin(long ClientId)
        {
            var employeePersonalDetail = await _context.EmployeePersonalDetails.Where(x => x.clientId == ClientId).FirstOrDefaultAsync();



            var clientCreation = await (from client in _context.ClientCreation.Where(m => m.clientId == ClientId)
                                        join emp in _context.EmployeePersonalDetails on client.clientId equals emp.clientId into Empdata
                                        from emp1 in Empdata.DefaultIfEmpty()
                                        join status in _context.Statuses on client.status equals status.statusId into Statuses
                                        from statusV in Statuses.DefaultIfEmpty()
                                        select new ClientSetup
                                        {
                                            employeePersonalDetailId = emp1.employeePersonalDetailId,
                                            firstName = emp1.firstName,
                                            middleName = emp1.middleName,
                                            lastName= emp1.lastName,
                                            fatherName = emp1.fatherName,
                                            dob = emp1.dob,
                                            companyId = emp1.companyId,
                                            email = emp1.email,
                                            gender = emp1.gender,
                                            countryCode = emp1.countryCode,
                                            employeeImageUrl = emp1.employeeImageUrl,
                                            groupId = emp1.groupId,
                                            isClientAdmin = emp1.isClientAdmin,
                                            isCompanyAdmin = emp1.isCompanyAdmin,
                                            mobileNo1 = emp1.mobileNo,
                                            roleId = emp1.roleId,
                                            roleIds = emp1.roleIds,
                                            password = emp1.password,
                                            clientId = client.clientId,
                                            clientName = client.clientName,
                                            mobileNo = client.mobileNo,
                                            status = client.status,
                                            address1 = client.address1,
                                            address2 = client.address2,
                                            address3 = client.address3,
                                            stateId = client.stateId,
                                            pincode = client.pincode,
                                            pan = client.pan,
                                            tan = client.tan,
                                            createdBy = client.createdBy,
                                            createdTime = client.createdTime,
                                            updatedBy = client.updatedBy,
                                            updatedDate = client.updatedDate,
                                            twoWayAuthentication = client.twoWayAuthentication,
                                            isSms = client.isSms,
                                            isEmail = client.isEmail,
                                            rejectionReason = client.rejectionReason,
                                            countryId = client.countryId,
                                        }).FirstOrDefaultAsync();



          






           

           // clientCreation.EmployeePersonalDetails = employeePersonalDetail;

            var clientCreationsJson = JsonConvert.SerializeObject(clientCreation);
            if (clientCreation == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationsJson);
        }


        //DELETE: api/EmployeePersonalDetails/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        // There is no hard delete, only the status will be set to false
        public async Task<IActionResult> DeleteEmployeePersonalDetail(long id)
        {
            var employeePersonalDetail = await _context.EmployeePersonalDetails.FindAsync(id);
            if (employeePersonalDetail == null)
            {
                return NotFound();
            }
            employeePersonalDetail.status = (int)Statuses.Deleted;
            _context.EmployeePersonalDetails.Update(employeePersonalDetail);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Get: api/EmployeePersonalDetails/AllDetails/1
        [HttpGet("AllDetails/{EmployeeId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<EmployeeDetails>> GetEmployeeAllDetails(long EmployeeId)
        {
            EmployeePersonalDetail Personal = await _context.EmployeePersonalDetails.FindAsync(EmployeeId);
            var Address = await _context.EmployeeAddressDetails.Where(add => add.employeeId == EmployeeId).FirstOrDefaultAsync();
            var Nominee = await _context.EmployeeNomineeDetails.Where(nom => nom.companyId == Personal.companyId).FirstOrDefaultAsync();
            var Professional = await _context.EmployeeProfessionalDetails.Where(prof => prof.addressId == Address.employeeAddressDetailId).FirstOrDefaultAsync();
            var PersonalObj = new
            {
                firstName = Personal.firstName,
                middleName = Personal.middleName,
                lastName = Personal.lastName,
                fatherName = Personal.fatherName,
                dob = Personal.dob,
                gender = Personal.gender,
                maritalStatus = Personal.maritalStatus,
                religion = Personal.religion,
                mobileNo = Personal.mobileNo,
                companyId = Personal.companyId,
                updatedBy = Personal.updatedBy,
                createdBy = Personal.createdBy,
                email = Personal.email,
                createdTime = Personal.createdTime,
                updatedDate = Personal.updatedDate
            };
            EmployeeDetails employeeDetails = new EmployeeDetails { address = JsonConvert.SerializeObject(Address), personalDetail = JsonConvert.SerializeObject(PersonalObj), nominee = JsonConvert.SerializeObject(Nominee), professionalDetail = JsonConvert.SerializeObject(Professional) };

            return employeeDetails;
        }

        // Get: api/EmployeePersonalDetails/AllDetails/1
        [HttpGet("IsEmailIdValid/{EmailId}/{Organization}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> IsEmailIdValid(string EmailId, string Organization)
        {
            EmployeePersonalDetail employee = await _context.EmployeePersonalDetails.Where(emp => emp.email == EmailId).FirstOrDefaultAsync();
            if (employee == null)
            {
                return Conflict(new { message = "Employee does not exist." });
            }
            var organisation = await _context.Organisations.Where(org => Organization == org.organization && employee.companyId == org.companyId).FirstOrDefaultAsync();


            if (organisation == null)
            {
                return Conflict(new { message = "Incorrect Credentials." });
            }

            return new { EmployeeId = employee.employeePersonalDetailId, PassKey = employee.password, Email = employee.email };
        }

        //Api to Upload Employee Image 
        [HttpPost("UploadProfile")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> UploadProfile([FromForm] EmployeeDetailsWithImage employee)
        {
            try
            {
                EmployeePersonalDetail emp = _context.EmployeePersonalDetails.Where(e => e.employeePersonalDetailId == employee.employeePersonalDetailId).FirstOrDefault();

                if (employee.formFile != null)
                {
                    if (employee.formFile.Length < 50 * 1024)
                    {
                        string[] extensions = { ".jpg", ".png" };
                        if (extensions.Any(x => x.Equals(Path.GetExtension(employee.formFile.FileName.ToLower()), StringComparison.OrdinalIgnoreCase)))
                        {
                            var Url = await FileUploadAsync(employee.formFile, $"{emp.firstName}_{emp.lastName}".ToString());
                            employee.employeeImageUrl = Url;
                            emp.employeeImageUrl = employee.employeeImageUrl;

                        }
                        else
                        {
                            return Conflict(new { message = $"Only .png/.jpg are allowed to upload !!!" });
                        }
                    }
                    else
                    {
                        return Conflict(new { message = $"The file size exceeds the maximum allowed size of 50KB. !!!" });
                    }
                }
                else
                {
                    return Conflict(new { message = $"File not choosen !!!" });
                }
                _context.EmployeePersonalDetails.Update(emp);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new { message = $"Error while uploading Logo!!!" });
            }
            return new { message = "Details Updated Successfully !!!" };
        }
        private async Task<string> FileUploadAsync(IFormFile file, string FirstName)
        {
            try
            {
                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "Images", FirstName);

                // Check if the folder already exists
                if (Directory.Exists(folderPath))
                {
                    // Delete existing files inside the folder
                    DirectoryInfo directoryInfo = new DirectoryInfo(folderPath);
                    foreach (FileInfo fileInfo in directoryInfo.GetFiles())
                    {
                        fileInfo.Delete();
                    }
                }
                else
                {
                    Directory.CreateDirectory(folderPath);
                }



                var fileName = Path.GetFileName(file.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Images", FirstName, fileName);
                bool exists = System.IO.Directory.Exists(Path.GetDirectoryName(filePath));
                if (!exists)
                    System.IO.Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
                return filePath;
            }
            catch (DbUpdateException)
            {
                throw;
            }
        }

        //Api to get All the Employee Images
        [HttpGet("GetAll")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetAll()
        {
            var List = await (from emp in _context.EmployeePersonalDetails
                                  // where emp.Id == Id
                              select new
                              {
                                  emp.employeePersonalDetailId,
                                  emp.firstName,
                                  emp.middleName,
                                  emp.lastName,
                                  emp.fatherName,
                                  emp.dob,
                                  emp.gender,
                                  emp.maritalStatus,
                                  emp.religion,
                                  emp.mobileNo,
                                  emp.companyId,
                                  emp.groupId,
                                  emp.roleId,
                                  emp.updatedBy,
                                  emp.updatedDate,
                                  emp.createdTime,
                                  emp.createdBy,
                                  emp.email,
                                  emp.status,
                                  emp.employeeImageUrl,
                                  emp.roleIds,
                                  emp.isCompanyAdmin,
                                  emp.isClientAdmin,
                                  img = string.IsNullOrEmpty(emp.employeeImageUrl) ? null : Convert.ToBase64String(System.IO.File.ReadAllBytes(emp.employeeImageUrl)),
                              }).ToListAsync();
            if (List.Count > 0)
            {
                return List;
            }
            return Conflict("Employee Not Found");
        }

        [HttpGet("GetEmpDetails/{Id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetEmpDetails(long Id)
        {
            var List = await (from emp in _context.EmployeePersonalDetails
                              where emp.employeePersonalDetailId == Id
                              select new
                              {
                                  emp.employeePersonalDetailId,
                                  emp.employeeImageUrl,
                                  img = string.Empty
                              }).ToListAsync();
            if (List.Count > 0)
            {
                if (!string.IsNullOrEmpty(List[0].employeeImageUrl))
                {
                    byte[] bytes = System.IO.File.ReadAllBytes(List[0].employeeImageUrl);
                    var retuList = (from emp in List
                                    where emp.employeePersonalDetailId == Id
                                    select new
                                    {
                                        emp.employeePersonalDetailId,
                                        emp.employeeImageUrl,
                                        img = bytes,
                                    }).ToList();
                    return retuList;
                }
                return List[0];
            }
            return Conflict("Employee Not Found");
        }

        [HttpDelete("RemoveProfile/{Id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> RemoveProfile(long Id)
        {
            EmployeePersonalDetail emp = _context.EmployeePersonalDetails.Where(e => e.employeePersonalDetailId == Id).FirstOrDefault();
            if (emp == null)
            {
                return NotFound();
            }
            emp.employeeImageUrl = null;
            _context.EmployeePersonalDetails.Update(emp);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool EmployeePersonalDetailIdExists(long id)
        {
            return _context.EmployeePersonalDetails.Any(e => e.employeePersonalDetailId == id);
        }

        private bool ModuleOrganisationMapperExists(int moduleId, int companyId)
        {
            return _context.ModuleOrganisationMappers.Any(e => e.moduleId == moduleId && e.companyId == companyId);
        }

        private bool ScreenPermissionExists(long roleId, long screenId)
        {
            return _context.ScreenPermissions.Any(e => e.roleId == roleId && e.screenId == screenId);
        }

        private bool IsCompanyAlreadyMapped(long EmployeeId, long CompanyId)
        {
            return _context.CompanyUserRoleMappers.Any(c => c.employeeId == EmployeeId && c.companyId == CompanyId);
        }

        private bool IsClientAlreadyMapped(long EmployeeId, long ClientId)
        {
            return _context.ClientUserRoleMappers.Any(c => c.employeeId == EmployeeId && c.clientId == ClientId);
        }

        private bool IsRoleOrganisationAlreadyMapped(long RoleId, long CompanyId)
        {
            return _context.RoleOrganisationMappers.Any(c => c.roleId == RoleId && c.companyId == CompanyId);
        }

        private EmployeePersonalDetail GetEmployeePersonalDetailById(long id)
        {
            var empPersonalDetail = _context.EmployeePersonalDetails.Where(e => e.employeePersonalDetailId == id).FirstOrDefault();
            _context.Entry<EmployeePersonalDetail>(empPersonalDetail).State = EntityState.Detached;
            return empPersonalDetail;
        }

        private bool EmployeePersonalDetailEmailExists(string email)
        {
            return _context.EmployeePersonalDetails.Any(e => e.email == email);
        }


        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

    }
}
