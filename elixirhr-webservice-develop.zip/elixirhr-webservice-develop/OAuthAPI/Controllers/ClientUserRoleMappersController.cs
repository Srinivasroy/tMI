﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.Models.Common_Schema;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientUserRoleMappersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public ClientUserRoleMappersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/ClientUserRoleMappers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClientUserRoleMapper>>> GetClientUserRoleMappers()
        {
            return await _context.ClientUserRoleMappers.ToListAsync();
        }

        // GET: api/ClientUserRoleMappers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ClientUserRoleMapper>> GetClientUserRoleMapper(int id)
        {
            var clientUserRoleMapper = await _context.ClientUserRoleMappers.FindAsync(id);

            if (clientUserRoleMapper == null)
            {
                return NotFound();
            }

            return clientUserRoleMapper;
        }

        // PUT: api/ClientUserRoleMappers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutClientUserRoleMapper(int id, ClientUserRoleMapper clientUserRoleMapper)
        {
            if (id != clientUserRoleMapper.clientUserRoleMapperId)
            {
                return BadRequest();
            }

            _context.Entry(clientUserRoleMapper).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ClientUserRoleMapperExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ClientUserRoleMappers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ClientUserRoleMapper>> PostClientUserRoleMapper(ClientUserRoleMapper clientUserRoleMapper)
        {
            try
            {
                _context.ClientUserRoleMappers.Add(clientUserRoleMapper);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (ClientEmployeeAlreadyExists((long)clientUserRoleMapper.clientId,(long)clientUserRoleMapper.employeeId))
                {
                    return Conflict(new { message = $"User already mapped with the client." });
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetClientUserRoleMapper", new { id = clientUserRoleMapper.clientUserRoleMapperId }, clientUserRoleMapper);
        }

        // DELETE: api/DisableClientUser/5/1
        [HttpDelete("DisableClientUser/{ClientId}/{EmployeeId}")]
        public async Task<IActionResult> DisableClientUser(long ClientId, long EmployeeId)
        {
            var clientUserRoleMapper = await _context.ClientUserRoleMappers.FindAsync(EmployeeId);
            if (clientUserRoleMapper == null)
            {
                return NotFound();
            }

            _context.ClientUserRoleMappers.Remove(clientUserRoleMapper);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/ClientUserRoleMappers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteClientUserRoleMapper(int id)
        {
            var clientUserRoleMapper = await _context.ClientUserRoleMappers.FindAsync(id);
            if (clientUserRoleMapper == null)
            {
                return NotFound();
            }

            _context.ClientUserRoleMappers.Remove(clientUserRoleMapper);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ClientUserRoleMapperExists(int id)
        {
            return _context.ClientUserRoleMappers.Any(e => e.clientUserRoleMapperId == id);
        }

        private bool ClientEmployeeAlreadyExists(long ClientId, long EmployeeId)
        {
            return _context.ClientUserRoleMappers.Any(e=> e.employeeId == EmployeeId && e.clientId == ClientId);
        }
    }
}
