﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.Models.Common_Schema;
using OAuthAPI.models.common_schema;
using System.Collections;
using static OAuthAPI.models.Helpers.Helper;
using Newtonsoft.Json;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterOrgMappersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public MasterOrgMappersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/MasterOrgMappers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<MasterOrgMapper>>> GetMasterOrgMappers()
        {
            return await _context.MasterOrgMappers.ToListAsync();
        }

        // GET: api/MasterOrgMappers/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<MasterOrgMapper>> GetMasterOrgMapper(long id)
        {
            var masterOrgMapper = await _context.MasterOrgMappers.FindAsync(id);

            if (masterOrgMapper == null)
            {
                return NotFound();
            }

            return masterOrgMapper;
        }

        // PUT: api/MasterOrgMappers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<IActionResult> PutMasterOrgMapper(long id, MasterOrgMapper masterOrgMapper)
        {
            if (id != masterOrgMapper.masterOrgId)
            {
                return BadRequest();
            }

            _context.Entry(masterOrgMapper).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MasterOrgMapperExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MasterOrgMappers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<MasterOrgMapper>> PostMasterOrgMapper(MasterOrgMapper masterOrgMapper)
        {
            _context.MasterOrgMappers.Add(masterOrgMapper);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetMasterOrgMapper", new { id = masterOrgMapper.masterOrgId }, masterOrgMapper);
        }

        // DELETE: api/MasterOrgMappers/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteMasterOrgMapper(long id)
        //{
        //    var masterOrgMapper = await _context.MasterOrgMappers.FindAsync(id);
        //    if (masterOrgMapper == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.MasterOrgMappers.Remove(masterOrgMapper);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}
        [HttpGet("GetMasterr/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetMasterr(long companyId)
        {
            try
            {
                //var notexistingcomapnyid = _context.MasterOrgMappers.Where(m => m.CompanyId == companyId);

                var masters = (from mom in _context.MasterOrgMappers.
                               Where(e => e.companyId == companyId && e.status != (int)Statuses.Deleted)
                               select new
                               {
                                   MasterOrgId = ((int)mom.masterOrgId > 0 ? (int)mom.masterOrgId : 0),
                                   mom.name,
                                   mom.displayName,
                                   MasterId = ((int)mom.masterId > 0 ? (int)mom.masterId : 0),
                                   mom.companyId,
                                   mom.approvedOrderNo,
                                   mom.orderNo,
                                   mom.notificationId,
                                   mom.status,

                               }).OrderBy(m => m.orderNo).ToList();
                if(masters==null || masters.Count() <=0)

                {
                    var norecord = (from master in _context.Masters
                                          join masterorgmapper in _context.MasterOrgMappers
                                            on master.masterId equals masterorgmapper.masterId
                                          orderby master.defaultOrder
                                          select new
                                          {
                                              master.masterId,
                                              master.name,
                                              master.displayName,
                                              master.defaultOrder,
                                              master.status,
                                             // masterorgmapper.CompanyId,
                                              //masterorgmapper.ApprovedOrderNo,
                                              //masterorgmapper.OrderNo,
                                              //masterorgmapper.NotificationId



                                          }).ToList();

                    var norecords = JsonConvert.SerializeObject(norecord);

                    ArrayList masterLists = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(norecords);
                    return masterLists;
                }

                var mastersJson = JsonConvert.SerializeObject(masters);



                ArrayList masterList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(mastersJson);
                return masterList;




            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }

        }

        [HttpPost("PostMasterOrgMapper/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<List<MasterOrgMapper>>> PostMasterOrgMapper(long companyId, List<MasterOrgMapper> masterOrgMapper)
        {
            try
            {
                if (_context.MasterOrgMappers == null)
                {
                    return Problem("Entity set 'MasterContext.MasterOrgMappers'  is null.");
                }

                _context.MasterOrgMappers.UpdateRange(masterOrgMapper);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }

            return Ok(masterOrgMapper);



            //return CreatedAtAction("GetMasterOrgMapper", new { id = masterOrgMapper.MasterOrgId }, masterOrgMapper);
        }

        [HttpPut("PutMasterOrgMapper")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> PutMasterOrgMapper( List<MasterOrgMapper> masterOrgMapper)
        {
            //if (id != masterOrgMapper.MasterOrgId)
            //{
            //    return BadRequest();
            //}

            try
            {
                if (_context.MasterOrgMappers == null)
                {
                    return Problem("Entity set 'MasterContext.MasterOrgMappers'  is null.");
                }

                _context.MasterOrgMappers.UpdateRange(masterOrgMapper);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }

            return Ok(masterOrgMapper);

        }

        private bool MasterOrgMapperExists(long id)
        {
            return _context.MasterOrgMappers.Any(e => e.masterOrgId == id);
        }
    }
}
