﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;
using OAuthAPI.ActionFilters;
using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScreensController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public ScreensController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Screens
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetScreens(bool getALL = false)
        {

            var screens = await (from screen in _context.Screens
                                 join module in _context.Modules on screen.moduleId equals module.moduleId into Modules
                                 from moduleV in Modules.DefaultIfEmpty()
                                 join status in _context.Statuses on screen.status equals status.statusId into Statuses
                                 from statusV in Statuses.DefaultIfEmpty()
                                 select new
                                 {
                                     screen.screenId,
                                     screen.screenName,
                                     moduleV.moduleName,
                                     screen.moduleId,
                                     statusV.statusName,
                                     screen.status,
                                     screen.updatedBy,
                                     screen.updatedDate,
                                     screen.createdBy,
                                     screen.createdTime,
                                     screen.screenURL,
                                     screen.isApproveAllowed
                                 }
                             ).ToListAsync();
            if (getALL == false)
            {
                screens = screens.Where(scn => scn.status == (int)Statuses.Approved).ToList();
            }
            var screensjson = JsonConvert.SerializeObject(screens);
            ArrayList screenslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(screensjson);
            return screenslist;

        }

        // GET: api/Screens/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetScreen(long id)
        {
            //var screen = await _context.Screens.FindAsync(id);
            var screens = await (from screen in _context.Screens
                                 where screen.screenId == id
                                 join module in _context.Modules on screen.moduleId equals module.moduleId into Modules
                                 from moduleV in Modules.DefaultIfEmpty()
                                 select new
                                 {
                                     screen.screenId,
                                     screen.screenName,
                                     moduleV.moduleName,
                                     screen.moduleId,
                                     screen.updatedBy,
                                     screen.updatedDate,
                                     screen.createdBy,
                                     screen.createdTime,
                                     screen.screenURL,
                                     screen.isApproveAllowed
                                 }
                                ).ToListAsync();
            if (screens == null)
            {
                return NotFound();
            }



            var screenjson = JsonConvert.SerializeObject(screens);
            var _screen = System.Text.Json.JsonSerializer.Deserialize<object>(screenjson);

            return _screen;
        }

        // GET: api/Screens/GroupByModule
        [HttpGet("GroupByModule")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GroupByModule()
        {

            var screens = await (from screen in _context.Screens
                                 join module in _context.Modules on screen.moduleId equals module.moduleId into Modules
                                 from moduleV in Modules.DefaultIfEmpty()
                                 select new
                                 {
                                     screen.screenId,
                                     screen.screenName,
                                     moduleV.moduleName,
                                     screen.moduleId,
                                     screen.updatedBy,
                                     screen.updatedDate,
                                     screen.createdBy,
                                     screen.createdTime,
                                     screen.screenURL,
                                     screen.isApproveAllowed,
                                 }
                             ).ToListAsync();
            var groupByModuleName = screens.GroupBy(screen => screen.moduleName).ToList();
            List<ScreenWithModule> screenWithModule = new List<ScreenWithModule>();
            foreach (var module in groupByModuleName)
            {
                ScreenWithModule withModule = new ScreenWithModule();
                withModule.moduleName = module.Key;
                var screensValue = module.ToList();
                List<ScreenValues> screenValues = new List<ScreenValues>();
                foreach (var screen in screensValue)
                {
                    withModule.id = screen.moduleId.ToString();
                    ScreenValues Screen = new ScreenValues()
                    {
                        screenId = screen.screenId,
                        screenName = screen.screenName,
                        moduleName = screen.moduleName,
                        moduleId = screen.moduleId,
                        updatedBy = screen.updatedBy,
                        updatedDate = screen.updatedDate,
                        createdBy = screen.createdBy,
                        createdTime = screen.createdTime,
                        screenURL = screen.screenURL,
                        isApproveAllowed = screen.isApproveAllowed
                    };
                    screenValues.Add(Screen);
                }
                withModule.Screens = screenValues;

                screenWithModule.Add(withModule);
            }
            var groupByModuleNameJson = JsonConvert.SerializeObject(screenWithModule);
            ArrayList screenslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(groupByModuleNameJson);
            return screenslist;

        }

        // GET: api/Screens/GroupByModule/CompanyId
        [HttpGet("GroupByModule/CompanyId")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GroupByModule(long CompanyId)
        {

            var screens = await (from moduleOrg in _context.ModuleOrganisationMappers
                                 where moduleOrg.companyId == CompanyId
                                 join module in _context.Modules on moduleOrg.moduleId equals module.moduleId into Modules
                                 from moduleV in Modules.DefaultIfEmpty()
                                 join screen in _context.Screens on moduleV.moduleId equals screen.moduleId into ScreensValue
                                 from screenV in ScreensValue.DefaultIfEmpty()
                                 where screenV.status == (int)Statuses.Approved
                                 select new
                                 {
                                     Id = (int?)screenV.screenId,
                                     ScreenName = screenV.screenName,
                                     moduleV.moduleName,
                                     screenV.moduleId,
                                     screenV.updatedBy,
                                     screenV.updatedDate,
                                     screenV.createdBy,
                                     screenV.createdTime,
                                     screenV.screenURL,
                                     screenV.isApproveAllowed,
                                     moduleOrg.companyId
                                 }
                             ).ToListAsync();
            var groupByModuleName = screens.GroupBy(screen => screen.moduleName).ToList();
            List<ScreenWithModule> screenWithModule = new List<ScreenWithModule>();
            foreach (var module in groupByModuleName)
            {
                ScreenWithModule withModule = new ScreenWithModule();
                withModule.moduleName = module.Key;
                var screensValue = module.ToList();
                List<ScreenValues> screenValues = new List<ScreenValues>();
                foreach (var screen in screensValue)
                {
                    withModule.id = screen.moduleId.ToString();
                    ScreenValues Screen = new ScreenValues()
                    {
                        screenId = screen.Id != null ? (long)screen.Id : 0,
                        screenName = screen.ScreenName,
                        moduleName = screen.moduleName,
                        moduleId = screen.moduleId,
                        updatedBy = screen.updatedBy,
                        updatedDate = screen.updatedDate,
                        createdBy = screen.createdBy,
                        createdTime = screen.createdTime,
                        screenURL = screen.screenURL,
                        isApproveAllowed = screen.isApproveAllowed
                    };
                    if (Screen.screenId != 0)
                        screenValues.Add(Screen);
                }
                withModule.Screens = screenValues;

                screenWithModule.Add(withModule);
            }
            var groupByModuleNameJson = JsonConvert.SerializeObject(screenWithModule);
            ArrayList screenslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(groupByModuleNameJson);
            return screenslist;

        }

        // PUT: api/Screens/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutScreen(long id, Screen screen)
        {
            if (!ScreenExists(id))
            {
                return Conflict(new { message = $"Screen Id '{screen.screenId}' not found." });
            }
            if (!ModuleExists((long)screen.moduleId))
            {
                return Conflict(new { message = $"Module Id '{screen.moduleId}' not found." });
            }

            screen.screenId = id;
            screen.updatedDate = DateTime.UtcNow;
            _context.Entry(screen).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScreenExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Screens updated successfully !!!" };
        }

        // POST: api/Screens
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<object>> PostScreen(Screen screen)
        {
            _context.Screens.Add(screen);
            try
            {

                if (!ModuleExists((long)screen.moduleId))
                {
                    return Conflict(new { message = $"Module Id '{screen.moduleId}' not found." });
                }
                var lastScreen = await _context.Screens.OrderBy(screen => screen.screenId).LastOrDefaultAsync();
                screen.screenId = lastScreen != null ? lastScreen.screenId + 1 : 1;

                screen.createdTime = DateTime.UtcNow;
                screen.updatedDate = screen.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                if (ScreenNameExists(screen.screenName) && ModuleExists((long)screen.screenId))
                {
                    return Conflict(new { message = $"A screen name already exists in the selected module." });
                }
                else if (ScreenExists(screen.screenId))
                {
                    return Conflict(new { message = $"A screen with the id '{screen.screenId}' was already found." });
                }
                else
                {
                    //throw;
                    return Conflict(new { message = ex.Message });
                }

            }
            catch (Exception ex)
            {
                return Conflict(new { message = ex.Message });
            }

            var screenjson = JsonConvert.SerializeObject(screen);
            var _screen = System.Text.Json.JsonSerializer.Deserialize<object>(screenjson);

            return _screen;
        }


        private bool ScreenExists(long id)
        {
            return _context.Screens.Any(e => e.screenId == id);
        }

        private bool ScreenNameExists(string screenName)
        {
            return _context.Screens.Any(e => e.screenName == screenName);
        }

        private bool ModuleExists(long id)
        {
            return _context.Modules.Any(e => e.moduleId == id);
        }
    }
}
