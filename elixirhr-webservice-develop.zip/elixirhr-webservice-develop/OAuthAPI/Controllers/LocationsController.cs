﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
//using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.Models.Common_Schema;
using Newtonsoft.Json;
using OAuthAPI.models.Helpers;


namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public LocationsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Locations
        [HttpGet]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetLocations(bool? GetAll = false)
        {
            if (GetAll == true)
            {
                var locations = await _context.Locations.ToListAsync();
                var locationsjson = JsonConvert.SerializeObject(locations);
                ArrayList locationslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(locationsjson);

                return locationslist;
            }

            var _locations = await _context.Locations.ToListAsync();
            var _locationsjson = JsonConvert.SerializeObject(_locations);
            ArrayList _locationslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_locationsjson);
            return _locationslist;
        }

        // GET: api/Locations/5
        [HttpGet("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetLocation(long id)
        {
            var location = await _context.Locations.FindAsync(id);

            if (location == null)
            {
                return NotFound();
            }

            var locationjson = JsonConvert.SerializeObject(location);
            var _location = System.Text.Json.JsonSerializer.Deserialize<object>(locationjson);

            return _location;
        }


        // PUT: api/Locations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutLocation(long id, Location location)
        {
            if (!LocationExists(id))
            {
                return Conflict(new { message = $"Location Id '{location.locationId}' not found." });
            }
            if (!Helper.OrganisationIdExists((long)location.companyId))
            {
                return Conflict(new { message = $"Company Id '{location.companyId}' not found." });
            }

            location.locationId = id;
            location.updatedDate = DateTime.UtcNow;
            _context.Entry(location).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LocationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/Locations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostLocation(Location location)
        {
            _context.Locations.Add(location);
            try
            {

                if (!Helper.OrganisationIdExists((long)location.companyId))
                {
                    return Conflict(new { message = $"Company Id '{location.companyId}' not found." });
                }
                location.locationId = _context.Locations.Count() + 1;

                location.createdTime = DateTime.UtcNow;
                location.updatedDate = location.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (LocationExists(location.locationId))
                {
                    return Conflict(new { message = $"Location Id '{location.locationId}' already exists." });
                }
                else
                {
                    throw;
                }
            }

            var locationjson = JsonConvert.SerializeObject(location);
            var _location = System.Text.Json.JsonSerializer.Deserialize<object>(locationjson);

            return _location;
        }

        private bool LocationExists(long id)
        {
            return _context.Locations.Any(e => e.locationId == id);
        }
    }
}
