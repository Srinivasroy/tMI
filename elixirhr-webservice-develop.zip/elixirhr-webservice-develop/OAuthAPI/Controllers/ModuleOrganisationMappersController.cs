﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;
using OAuthAPI.Models.Common_Schema;
using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModuleOrganisationMappersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public ModuleOrganisationMappersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/ModuleOrganisationMappers
        [HttpGet("GetModuleOrganisationMappers/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ArrayList> GetModuleOrganisationMappers(long companyId)
        {
            var moduleOrganisationMappers = await (from module in _context.Modules//.Where(c=> c.isEnabled == true && c.status == 1)
                                                   join parent in _context.Modules.Where(c=>c.isEnabled == true && c.status == 1)
                                                   on module.moduleId equals parent.parentID into parent1
                                                   from parent2 in parent1.DefaultIfEmpty()
                                                   join moduleOrgMapper in _context.ModuleOrganisationMappers.Where(m=>m.companyId == companyId)
                                                   on module.moduleId equals moduleOrgMapper.moduleId into mm
                                                   from mom in mm.DefaultIfEmpty()
                                                   select new
                                                   {
                                                       module.moduleId,
                                                       mom.moduleOrgMapperId,
                                                       module.moduleName,
                                                       companyId=companyId,
                                                       module.parentID,
                                                       parentName = parent2.parentID == null ? module.moduleName : parent2.moduleName,
                                                       module.versionNo,
                                                       isSelected=(mom.moduleId != null && mom.status == 1 ? true : false)
                                                      
                                                   }
                                                   ).ToListAsync();
            var moduleOrganisationMappersJson = JsonConvert.SerializeObject(moduleOrganisationMappers);
            ArrayList moduleOrganisationMappersList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(moduleOrganisationMappersJson);
            return moduleOrganisationMappersList;
        }

        // GET: api/ModuleOrganisationMappers/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> GetModuleOrganisationMapper(int id)
        {
            var moduleOrganisationMapper = await _context.ModuleOrganisationMappers.FindAsync(id);

            if (moduleOrganisationMapper == null)
            {
                return NotFound();
            }
            var moduleOrganisationMapperJson = JsonConvert.SerializeObject(moduleOrganisationMapper);
            return System.Text.Json.JsonSerializer.Deserialize<object>(moduleOrganisationMapperJson);
        }

        // PUT: api/ModuleOrganisationMappers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutModuleOrganisationMapper(int id, ModuleOrganisationMapper moduleOrganisationMapper)
        {

            moduleOrganisationMapper.moduleOrgMapperId = id;
            moduleOrganisationMapper.updatedDate = DateTime.UtcNow;
            _context.Entry(moduleOrganisationMapper).State = EntityState.Modified;

            try
            {

                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ModuleOrganisationMapperExists(id))
                {
                    return NotFound();
                }
                else if (!Helper.ModuleIdExists((long)moduleOrganisationMapper.moduleOrgMapperId))
                {
                    return Conflict("Module Id does not exist !!!");
                }
                else if (!Helper.OrganisationIdExists((long)moduleOrganisationMapper.companyId))
                {
                    return Conflict("Company Id does not exist !!!");
                }
                else if (ModuleOrganisationMapperExists((long)moduleOrganisationMapper.moduleId, (long)moduleOrganisationMapper.companyId))
                {
                    return Conflict("Already module assigned to the company !!!");
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (ModuleOrganisationMapperExists(moduleOrganisationMapper.moduleOrgMapperId))
                {
                    return Conflict();
                }
                else if (!Helper.ModuleIdExists((long)moduleOrganisationMapper.moduleId))
                {
                    return Conflict("Module Id does not exist !!!");
                }
                else if (!Helper.OrganisationIdExists((long)moduleOrganisationMapper.companyId))
                {
                    return Conflict("Company Id does not exist !!!");
                }
                else if (ModuleOrganisationMapperExists((long)moduleOrganisationMapper.moduleId, (long)moduleOrganisationMapper.companyId))
                {
                    return Conflict("Already module assigned to the company !!!");
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/ModuleOrganisationMappers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PostModuleOrganisationMapper(ModulesOrganisationMapper modulesOrganisationMapper)
        {
            // Multiple module ids are pushed to DB
            if (modulesOrganisationMapper.moduleIds.Count() > 0)
            {
                // Adding Access control logic module by default.
                modulesOrganisationMapper.moduleIds.Add(7);
                foreach (long moduleId in modulesOrganisationMapper.moduleIds)
                {
                    ModuleOrganisationMapper moduleOrganisationMapper = new ModuleOrganisationMapper
                    {
                        companyId = modulesOrganisationMapper.companyId,
                        moduleId = moduleId,
                        createdBy = modulesOrganisationMapper.createdBy,
                        updatedBy = modulesOrganisationMapper.updatedBy
                    };
                    try
                    {
                        //Insert module, when it does not exist
                        if (!ModuleOrganisationMapperExists((long)moduleOrganisationMapper.moduleId, (long)moduleOrganisationMapper.companyId))
                        {

                            _context.ModuleOrganisationMappers.Add(moduleOrganisationMapper);

                            moduleOrganisationMapper.createdTime = DateTime.UtcNow;
                            moduleOrganisationMapper.updatedDate = moduleOrganisationMapper.createdTime;
                            moduleOrganisationMapper.status = (int)Statuses.Pending;
                            await _context.SaveChangesAsync();
                            //Detach first instance from change tracker
                            _context.Entry<ModuleOrganisationMapper>(moduleOrganisationMapper).State = EntityState.Detached;
                        }
                        // If the status is deleted for the existing module, then it will be changed to pending
                        else
                        {
                            var status = ModuleOrganisationMapperGetStatus((long)moduleOrganisationMapper.moduleId, (long)moduleOrganisationMapper.companyId);
                            if (status.status == (int)Statuses.Deleted)
                            {
                                status.updatedDate = moduleOrganisationMapper.createdTime;
                                status.status = (int)Statuses.Pending;
                                _context.Entry(status).State = EntityState.Modified;
                                await _context.SaveChangesAsync();
                                //Detach first instance from change tracker
                                _context.Entry<ModuleOrganisationMapper>(status).State = EntityState.Detached;
                            }
                        }

                    }
                    catch (DbUpdateException)
                    {
                        if (ModuleOrganisationMapperExists(moduleOrganisationMapper.moduleOrgMapperId))
                        {
                            return Conflict();
                        }
                        else if (!Helper.ModuleIdExists((long)moduleOrganisationMapper.moduleId))
                        {
                            return Conflict("Module Id does not exist !!!");
                        }
                        else if (!Helper.OrganisationIdExists((long)moduleOrganisationMapper.companyId))
                        {
                            return Conflict("Company Id does not exist !!!");
                        }
                        else if (ModuleOrganisationMapperExists((long)moduleOrganisationMapper.moduleId, (long)moduleOrganisationMapper.companyId))
                        {
                            return Conflict("Already module assigned to the company !!!");
                        }
                        else
                        {
                            throw;
                        }
                    }
                }

                // Adding screen for Access-control-logic for the company Id
                int[] screens = { 3, 4, 6, 7, 8 };
                screens.ToList().ForEach(async (screenId) =>
                {
                    // Data inserting for Super-Admin
                    if (!ScreenPermissionExists(screenId, 1))
                    {
                        ScreenPermission sp = new ScreenPermission
                        {
                            screenId = screenId,
                            roleId = 1,
                            approve = true,
                            create = true,
                            createdBy = "superadmin@tmi.com",
                            createdTime = DateTime.UtcNow,
                            delete = true,
                            read = true,
                            status = 1,
                            update = true,
                            updatedBy = "superadmin@tmi.com",
                            updatedDate = DateTime.UtcNow
                        };
                        _context.ScreenPermissions.Add(sp);
                        await _context.SaveChangesAsync();
                        _context.Entry(sp).State = EntityState.Detached;
                    }
                    // Data inserting for TMI-Admin
                    if (!ScreenPermissionExists(screenId, 2))
                    {
                        ScreenPermission sp = new ScreenPermission
                        {
                            screenId = screenId,
                            roleId = 2,
                            approve = true,
                            create = true,
                            createdBy = "superadmin@tmi.com",
                            createdTime = DateTime.UtcNow,
                            delete = true,
                            read = true,
                            status = 1,
                            update = true,
                            updatedBy = "superadmin@tmi.com",
                            updatedDate = DateTime.UtcNow
                        };
                        _context.ScreenPermissions.Add(sp);
                        await _context.SaveChangesAsync();
                        _context.Entry(sp).State = EntityState.Detached;
                    }
                });

                // Remove the modules, which are not in the requested list
                var availableModules = await _context.ModuleOrganisationMappers.Where(m => m.companyId == modulesOrganisationMapper.companyId).ToListAsync();
                foreach (var available in availableModules)
                {
                    if (modulesOrganisationMapper.moduleIds.IndexOf((long)available.moduleId) == -1)
                    {
                        var moduleToRemove = await _context.ModuleOrganisationMappers.Where(m => m.moduleId == available.moduleId && m.companyId == modulesOrganisationMapper.companyId).FirstOrDefaultAsync();
                        if (moduleToRemove != null)
                        {
                            moduleToRemove.status = (int)Statuses.Deleted;
                            moduleToRemove.updatedDate = DateTime.UtcNow;
                            _context.Entry(moduleToRemove).State = EntityState.Modified;
                            //_context.ModuleOrganisationMappers.Remove(moduleToRemove);
                            await _context.SaveChangesAsync();
                        }
                    }
                }
            }
            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        [HttpPost("PostModuleOrgMapper")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<List<ModuleOrganisationMapper>>> PostModulesOrgMapper(List<ModuleOrganisationMapper> moduleOrganisationMapper)
        {

            ModuleOrganisationMapper mom = new ModuleOrganisationMapper();
            try
            {
                foreach (var modules in moduleOrganisationMapper)
                {
                    var records = await (from c in _context.ModuleOrganisationMappers
                                         where c.companyId == modules.companyId
                                         select c).ToListAsync();
                    if (records != null)
                    {
                        foreach (var record in records)
                        {
                            _context.ModuleOrganisationMappers.Remove(record);
                        }
                    }
                    string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);

                    mom.moduleOrgMapperId = modules.moduleOrgMapperId;
                    mom.moduleId = modules.moduleId;
                    mom.companyId = modules.companyId;
                    mom.updatedDate = DateTime.UtcNow;
                    mom.updatedBy = userEmail;
                    mom.createdBy = userEmail;
                    mom.createdTime = DateTime.UtcNow;
                    mom.status = modules.status;
                    _context.ModuleOrganisationMappers.Add(mom);
                    await _context.SaveChangesAsync();

                }
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }
            return Ok();
        }

        [HttpGet("ModuleOrgMapper")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetModuleOrgMapper(bool? getAll = false)
        {
            if (getAll == true)
            {
                var getdata = await (from mom in _context.ModuleOrganisationMappers
                                     join m in _context.Modules on mom.moduleId equals m.moduleId into list
                                     from l in list.Where(l => l.isEnabled == true)
                                     select new
                                     {
                                         mom.moduleOrgMapperId,
                                         mom.companyId,
                                         mom.moduleId,
                                         l.moduleName,
                                         l.versionNo,
                                         l.isEnabled
                                     }).ToListAsync();
                var getdatajson = JsonConvert.SerializeObject(getdata);
                ArrayList getdatalist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(getdatajson);
                return getdatalist;
            }
            else
            {
                var getdata = await (from mom in _context.ModuleOrganisationMappers
                                     join m in _context.Modules on mom.moduleId equals m.moduleId into list
                                     from l in list
                                     select new
                                     {
                                         mom.moduleOrgMapperId,
                                         mom.companyId,
                                         mom.moduleId,
                                         l.moduleName,
                                         l.versionNo,
                                         l.isEnabled
                                     }).ToListAsync();
                var getdatajson = JsonConvert.SerializeObject(getdata);
                ArrayList getdatalist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(getdatajson);
                return getdatalist;
            }
            //var getdata = await (from mom in _context.ModuleOrganisationMappers
            //                     join m in _context.Modules.Where(m => m.isEnabled == true) on mom.moduleId equals m.moduleId into list
            //                     from l in list.DefaultIfEmpty()
            //                     select new
            //                     {
            //                         mom.moduleOrgMapperId,
            //                         mom.moduleId,
            //                         l.moduleName,
            //                         l.versionNo

            //                     }).ToListAsync();
        }


        // DELETE: api/ModuleOrganisationMappers/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteModuleOrganisationMapper(int id)
        {
            var moduleOrganisationMapper = await _context.ModuleOrganisationMappers.FindAsync(id);
            if (moduleOrganisationMapper == null)
            {
                return NotFound();
            }

            _context.ModuleOrganisationMappers.Remove(moduleOrganisationMapper);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ModuleOrganisationMapperExists(int id)
        {
            return _context.ModuleOrganisationMappers.Any(e => e.moduleOrgMapperId == id);
        }

        private bool ModuleOrganisationMapperExists(long moduleId, long companyId)
        {
            var validate = _context.ModuleOrganisationMappers.Where(e => e.moduleId == moduleId && e.companyId == companyId).FirstOrDefault();
            return validate != null ? true : false;
        }

        private bool ScreenPermissionExists(long screenId, long roleId)
        {
            var validate = _context.ScreenPermissions.Where(e => e.screenId == screenId && e.roleId == roleId).FirstOrDefault();
            return validate != null ? true : false;
        }

        private ModuleOrganisationMapper ModuleOrganisationMapperGetStatus(long moduleId, long companyId)
        {
            var moduleOrgMappper = _context.ModuleOrganisationMappers.Where(e => e.moduleId == moduleId && e.companyId == companyId).FirstOrDefault();
            return moduleOrgMappper;
        }
    }
}
