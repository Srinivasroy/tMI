﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OAuthAPI.ActionFilters;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;
using OAuthAPI.Models.Common_Schema;

using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientCreationsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;
        // private int currentCompanyId = Common_Schema_Context.CurrentCompanyId;
        private bool isOwnerCompany = Common_Schema_Context.IsOwnerCompany;
        public ClientCreationsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/ClientCreations
        [HttpGet("ClientCreations/{EmployeeId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetClientCreation(long EmployeeId, bool? getALL = false)
        {

            if (getALL == true)
            {
                //var clientCreations = await _context.ClientCreation.ToListAsync();
                var clientCreations = await (from client in _context.ClientCreation
                                         join State in _context.States on client.stateId equals State.stateId into States
                                         from stateV in States.DefaultIfEmpty()
                                         //join emp in _context.EmployeePersonalDetails on client.clientId equals emp.clientId   //added now
                                         where client.isOwnerClient != true //&& client.clientId == emp.clientId
                                         join userclient in _context.ClientUserRoleMappers on client.clientId equals userclient.clientId
                                         //where (userclient.employeeId == EmployeeId)  //added after &&  getALL == false ||
                                         join status in _context.Statuses on client.status equals status.statusId into Statuses
                                         from statusV in Statuses.DefaultIfEmpty()
                                         select new
                                         {
                                             client.clientId,
                                             client.clientName,
                                             client.mobileNo,
                                             client.companyCount,
                                             client.status,
                                             statusV.statusName,
                                             client.address1,
                                             client.address2,
                                             client.address3,
                                             client.stateId,
                                             stateV.stateName,
                                             client.pincode,
                                             client.pan,
                                             client.tan,
                                             client.createdBy,
                                             client.createdTime,
                                             client.updatedBy,
                                             client.updatedDate,
                                             client.clientCode,
                                             client.makerId,
                                             client.checkerId,
                                             client.twoWayAuthentication,
                                             client.isSms,
                                             client.isEmail,
                                             client.countryId,
                                         }
                                         ).Distinct().OrderByDescending(client => client.updatedDate).ToListAsync();

            var userMappedClients = await _context.ClientUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();

            List<object> clientWithPermissions = new List<object>();

            clientCreations.ForEach((clientCreation) =>
            {

                var isMapped = userMappedClients.Where(c => c.clientId == clientCreation.clientId).FirstOrDefault();

                if (isMapped != null)
                {
                    var screenPermissions = (from sp in _context.ScreenPermissions
                                             where sp.roleId == isMapped.roleId && sp.status == (int)Statuses.Approved
                                             join screen in _context.Screens on sp.screenId equals screen.screenId into Screens
                                             from screenV in Screens.DefaultIfEmpty()
                                             select new
                                             {
                                                 sp.roleId,
                                                 sp.read,
                                                 sp.approve,
                                                 sp.create,
                                                 sp.update,
                                                 sp.delete,
                                                 screenV.screenName,
                                                 sp.screenId
                                             }
                                                   ).ToList();

                    var cInfo = screenPermissions.Where(s => s.screenName.ToLower().Trim() == "client information").FirstOrDefault();
                    object permissionObj = new { };
                    if (cInfo != null)
                    {
                        permissionObj = new { cInfo.create, cInfo.read, cInfo.update, cInfo.delete, cInfo.approve };

                    }
                    else { permissionObj = new { create = false, read = false, update = false, delete = false, approve = false }; }
                    var obj = new
                    {
                        clientCreation.clientId,
                        clientCreation.clientName,
                        clientCreation.mobileNo,
                        clientCreation.companyCount,
                        clientCreation.status,
                        clientCreation.statusName,
                        clientCreation.address1,
                        clientCreation.address2,
                        clientCreation.address3,
                        clientCreation.stateId,
                        clientCreation.stateName,
                        clientCreation.pincode,
                        clientCreation.pan,
                        clientCreation.tan,
                        clientCreation.createdBy,
                        clientCreation.createdTime,
                        clientCreation.updatedBy,
                        clientCreation.updatedDate,
                        clientCreation.clientCode,
                        clientCreation.makerId,
                        clientCreation.checkerId,
                        clientCreation.twoWayAuthentication,
                        clientCreation.isSms,
                        clientCreation.isEmail,
                        clientCreation.countryId,
                        employeePermission = permissionObj
                    };
                    clientWithPermissions.Add(obj);
                }
                else
                {
                    var obj = new
                    {
                        clientCreation.clientId,
                        clientCreation.clientName,
                        clientCreation.mobileNo,
                        clientCreation.companyCount,
                        clientCreation.status,
                        clientCreation.statusName,
                        clientCreation.address1,
                        clientCreation.address2,
                        clientCreation.address3,
                        clientCreation.stateId,
                        clientCreation.stateName,
                        clientCreation.pincode,
                        clientCreation.pan,
                        clientCreation.tan,
                        clientCreation.createdBy,
                        clientCreation.createdTime,
                        clientCreation.updatedBy,
                        clientCreation.updatedDate,
                        clientCreation.clientCode,
                        clientCreation.makerId,
                        clientCreation.checkerId,
                        clientCreation.twoWayAuthentication,
                        clientCreation.isSms,
                        clientCreation.isEmail,
                        clientCreation.countryId,
                        //clientCreation.countryName,
                        employeePermission = new { create = false, read = false, update = false, delete = false, approve = false }
                    };
                    clientWithPermissions.Add(obj);
                }
            });

            var clientCreationsJson = JsonConvert.SerializeObject(clientWithPermissions);
            if (clientCreations == null)
            {
                return NotFound();
            }
            ArrayList clientCreationsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(clientCreationsJson);
            return clientCreationsList;
             }
            else
            {
                //var clientCreations = await _context.ClientCreation.Where(m => m.Status == true).ToArrayAsync();
                var clientCreations = await (from client in _context.ClientCreation //.Where(m => m.status == (int)Statuses.Approved)
                                             join state in _context.States on client.stateId equals state.stateId into States
                                             from stateV in States.DefaultIfEmpty()
                                             where client.isOwnerClient != true //&& client.clientId == emp.clientId
                                             join userclient in _context.ClientUserRoleMappers on client.clientId equals userclient.clientId
                                             where (userclient.employeeId == EmployeeId) 
                                             join status in _context.Statuses on client.status equals status.statusId into Statuses
                                             from statusV in Statuses.DefaultIfEmpty()
                                             select new
                                             {
                                                 client.clientId,
                                                 client.clientName,
                                                 client.mobileNo,
                                                 client.companyCount,
                                                 client.status,
                                                 statusV.statusName,
                                                 client.address1,
                                                 client.address2,
                                                 client.address3,
                                                 client.stateId,
                                                 stateV.stateName,
                                                 client.pincode,
                                                 client.pan,
                                                 client.tan,
                                                 client.createdBy,
                                                 client.createdTime,
                                                 client.updatedBy,
                                                 client.updatedDate,
                                                 client.clientCode,
                                                 client.makerId,
                                                 client.checkerId,
                                                 client.twoWayAuthentication,
                                                 client.isSms,
                                                 client.isEmail,
                                                 client.countryId,
                                             }
                                           ).OrderByDescending(client => client.updatedDate).ToListAsync();
                //added now
                var userMappedClients = await _context.ClientUserRoleMappers.Where(c => c.employeeId == EmployeeId).ToListAsync();

                List<object> clientWithPermissions = new List<object>();

                clientCreations.ForEach((clientCreation) =>
                {

                    var isMapped = userMappedClients.Where(c => c.clientId == clientCreation.clientId).FirstOrDefault();

                    if (isMapped != null)
                    {
                        var screenPermissions = (from sp in _context.ScreenPermissions
                                                 where sp.roleId == isMapped.roleId && sp.status == (int)Statuses.Approved
                                                 join screen in _context.Screens on sp.screenId equals screen.screenId into Screens
                                                 from screenV in Screens.DefaultIfEmpty()
                                                 select new
                                                 {
                                                     sp.roleId,
                                                     sp.read,
                                                     sp.approve,
                                                     sp.create,
                                                     sp.update,
                                                     sp.delete,
                                                     screenV.screenName,
                                                     sp.screenId
                                                 }
                                                       ).ToList();

                        var cInfo = screenPermissions.Where(s => s.screenName.ToLower().Trim() == "client information").FirstOrDefault();
                        object permissionObj = new { };
                        if (cInfo != null)
                        {
                            permissionObj = new { cInfo.create, cInfo.read, cInfo.update, cInfo.delete, cInfo.approve };

                        }
                        else { permissionObj = new { create = false, read = false, update = false, delete = false, approve = false }; }
                        var obj = new
                        {
                            clientCreation.clientId,
                            clientCreation.clientName,
                            clientCreation.mobileNo,
                            clientCreation.companyCount,
                            clientCreation.status,
                            clientCreation.statusName,
                            clientCreation.address1,
                            clientCreation.address2,
                            clientCreation.address3,
                            clientCreation.stateId,
                            clientCreation.stateName,
                            clientCreation.pincode,
                            clientCreation.pan,
                            clientCreation.tan,
                            clientCreation.createdBy,
                            clientCreation.createdTime,
                            clientCreation.updatedBy,
                            clientCreation.updatedDate,
                            clientCreation.clientCode,
                            clientCreation.makerId,
                            clientCreation.checkerId,
                            clientCreation.twoWayAuthentication,
                            clientCreation.isSms,
                            clientCreation.isEmail,
                            clientCreation.countryId,
                            employeePermission = permissionObj
                        };
                        clientWithPermissions.Add(obj);
                    }
                    else
                    {
                        var obj = new
                        {
                            clientCreation.clientId,
                            clientCreation.clientName,
                            clientCreation.mobileNo,
                            clientCreation.companyCount,
                            clientCreation.status,
                            clientCreation.statusName,
                            clientCreation.address1,
                            clientCreation.address2,
                            clientCreation.address3,
                            clientCreation.stateId,
                            clientCreation.stateName,
                            clientCreation.pincode,
                            clientCreation.pan,
                            clientCreation.tan,
                            clientCreation.createdBy,
                            clientCreation.createdTime,
                            clientCreation.updatedBy,
                            clientCreation.updatedDate,
                            clientCreation.clientCode,
                            clientCreation.makerId,
                            clientCreation.checkerId,
                            clientCreation.twoWayAuthentication,
                            clientCreation.isSms,
                            clientCreation.isEmail,
                            clientCreation.countryId,
                            //clientCreation.countryName,
                            employeePermission = new { create = false, read = false, update = false, delete = false, approve = false }
                        };
                        clientWithPermissions.Add(obj);
                    }
                });
                //till here 

                var clientCreationsJson = JsonConvert.SerializeObject(clientWithPermissions);
                if (clientCreations == null)
                {
                    return NotFound();
                }
                ArrayList clientCreationsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(clientCreationsJson);
                return clientCreationsList;
            }

        }


        [HttpGet("GetClientCompanyList")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetClientCompanyList()
        {
            try
            {
                var employees = await _context.EmployeePersonalDetails.ToListAsync();
                var clientCompanyList = await (from org in _context.Organisations
                                               where org.status != (int)Statuses.Deleted
                                               join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                               from clientsV in Clients.DefaultIfEmpty()
                                                   //where org.isOwnerCompany != true || clientsV.isOwnerClient != true
                                               select new
                                               {
                                                   org.companyId,
                                                   org.clientId,
                                                   org.companyName,
                                                   clientsV.clientName,
                                                   companyStatus = org.status,
                                                   clientStatus = clientsV.status,
                                                   companyMaker = org.makerId,
                                                   companyChecker = org.checkerId,
                                                   clientMaker = clientsV.makerId,
                                                   clientChecker = clientsV.checkerId,
                                               }
                                             ).ToListAsync();
                var newList = new ArrayList();
                var statuses = await _context.Statuses.ToListAsync();
                clientCompanyList.ForEach(clientComp =>
                {
                    var compMaker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.companyMaker).FirstOrDefault();
                    var compChecker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.companyChecker).FirstOrDefault();
                    var clientMaker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.clientMaker).FirstOrDefault();
                    var clientChecker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.clientChecker).FirstOrDefault();
                    var compayStatus = statuses.Where(status => status.statusId == clientComp.companyStatus).FirstOrDefault();
                    var clientStatus = statuses.Where(status => status.statusId == clientComp.clientStatus).FirstOrDefault();
                    var newClientComp = new
                    {
                        companyName = clientComp.companyName,
                        companyId = clientComp.companyId,
                        clientName = clientComp.clientName,
                        clientId = clientComp.clientId,
                        companyMaker = compMaker != null ? $"{compMaker.firstName} {compMaker.lastName}" : "",
                        companyMakerId = clientComp.companyMaker,
                        companyChecker = compChecker != null ? $"{compChecker.firstName} {compChecker.lastName}" : "",
                        companyCheckerId = clientComp.companyChecker,
                        clientMaker = clientMaker != null ? $"{clientMaker.firstName} {clientMaker.lastName}" : "",
                        clientMakerId = clientComp.clientMaker,
                        clientChecker = clientChecker != null ? $"{clientChecker.firstName} {clientChecker.lastName}" : "",
                        clientCheckerId = clientComp.clientChecker,
                        companyStatus = compayStatus != null ? compayStatus.statusName : "",
                        clientStatus = clientStatus != null ? clientStatus.statusName : ""
                    };
                    newList.Add(newClientComp);
                });

                var clientCreationsJson = JsonConvert.SerializeObject(newList);
                if (clientCompanyList == null)
                {
                    return NotFound();
                }
                ArrayList clientCreationsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(clientCreationsJson);
                return clientCreationsList;
            }
            catch (Exception ex)
            {
                Conflict(new { message = $"Error: {ex.Message}" });
            }
            ArrayList list = new ArrayList();
            return list;
        }

        [HttpGet("GetFilteredClientCompanyList/{UserName}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetFilteredClientCompanyList(string UserName)
        {
            try
            {
                var employees = await _context.EmployeePersonalDetails.ToListAsync();
                var clientCompanyList = await (from org in _context.Organisations
                                               where org.status != (int)Statuses.Deleted
                                               join client in _context.ClientCreation on org.clientId equals client.clientId into Clients
                                               from clientsV in Clients.DefaultIfEmpty()
                                               select new
                                               {
                                                   org.companyId,
                                                   org.clientId,
                                                   org.companyName,
                                                   clientsV.clientName,
                                                   companyMaker = org.makerId,
                                                   companyChecker = org.checkerId,
                                                   clientMaker = clientsV.makerId,
                                                   clientChecker = clientsV.checkerId,
                                               }
                                             ).ToListAsync();
                var newList = new ArrayList();
                clientCompanyList.ForEach(clientComp =>
                {

                    var compMaker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.companyMaker).FirstOrDefault();
                    var compChecker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.companyChecker).FirstOrDefault();
                    var clientMaker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.clientMaker).FirstOrDefault();
                    var clientChecker = employees.Where(emp => emp.employeePersonalDetailId == clientComp.clientChecker).FirstOrDefault();
                    var newClientComp = new
                    {
                        companyName = clientComp.companyName,
                        companyId = clientComp.companyId,
                        clientName = clientComp.clientName,
                        clientId = clientComp.clientId,
                        companyMaker = compMaker != null ? $"{compMaker.firstName} {compMaker.lastName}" : "",
                        companyMakerId = clientComp.companyMaker,
                        companyChecker = compChecker != null ? $"{compChecker.firstName} {compChecker.lastName}" : "",
                        companyCheckerId = clientComp.companyChecker,
                        clientMaker = clientMaker != null ? $"{clientMaker.firstName} {clientMaker.lastName}" : "",
                        clientMakerId = clientComp.clientMaker,
                        clientChecker = clientChecker != null ? $"{clientChecker.firstName} {clientChecker.lastName}" : "",
                        clientCheckerId = clientComp.clientChecker
                    };
                    if (newClientComp.companyMaker.ToLower().Contains(UserName.ToLower()) || newClientComp.companyChecker.ToLower().Contains(UserName.ToLower())
                    || newClientComp.clientMaker.ToLower().Contains(UserName) || newClientComp.clientChecker.ToLower().Contains(UserName)
                    )
                    {
                        newList.Add(newClientComp);
                    }
                });



                var clientCreationsJson = JsonConvert.SerializeObject(newList);
                if (clientCompanyList == null)
                {
                    return NotFound();
                }
                ArrayList clientCreationsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(clientCreationsJson);
                return clientCreationsList;
            }
            catch (Exception ex)
            {
                Conflict(new { message = $"Error: {ex.Message}" });
            }
            ArrayList list = new ArrayList();
            return list;
        }

        // GET: api/ClientCreations/5
        [HttpGet("{id}")]
        //  [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetClientCreation(long id)
        {
            //var clientCreation = await _context.ClientCreation.FindAsync(id);
            var clientCreation = await (from client in _context.ClientCreation.Where(m => m.clientId == id)
                                        join state in _context.States on client.stateId equals state.stateId into StateMasters
                                        from stateV in StateMasters.DefaultIfEmpty()
                                        join status in _context.Statuses on client.status equals status.statusId into Statuses
                                        from statusV in Statuses.DefaultIfEmpty()
                                        select new
                                        {
                                            client.clientId,
                                            client.clientName,
                                            client.clientCode,
                                            client.mobileNo,
                                            client.companyCount,
                                            client.status,
                                            statusV.statusName,
                                            client.address1,
                                            client.address2,
                                            client.address3,
                                            stateId = client.stateId == 1 ? null : client.stateId,
                                            stateV.stateName,
                                            client.pincode,
                                            client.pan,
                                            client.tan,
                                            client.createdBy,
                                            client.createdTime,
                                            client.updatedBy,
                                            client.updatedDate,
                                            client.makerId,
                                            client.checkerId,
                                            client.twoWayAuthentication,
                                            client.isSms,
                                            client.isEmail,
                                            countryId = client.countryId == 1 ? null : client.countryId

                                        }
                                           ).FirstOrDefaultAsync();


            var clientCreationsJson = JsonConvert.SerializeObject(clientCreation);
            if (clientCreation == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationsJson);
        }

        // PUT: api/ClientCreations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PutClientCreation(long id, ClientCreation clientCreation)
        {
            //if (clientCreation.ClientCode == null)
            //{
            //    return Conflict(new { message = "Client code is mandatory" });
            //}
            if (clientCreation.clientName == null)
            {
                return Conflict(new { message = "Client name is mandatory" });
            }
            if (clientCreation.status == (int)Statuses.Deleted)
            {
                var companies = _context.Organisations.Where(org => org.clientId == id).ToList();
                companies.ForEach(comp =>
                {
                    comp.status = (int)Statuses.Deleted;
                    comp.updatedDate = DateTime.UtcNow;
                    _context.Entry(comp).State = EntityState.Modified;
                });
            }

            clientCreation.clientId = id;
            clientCreation.updatedDate = DateTime.UtcNow;
            if (clientCreation.isSms == true || clientCreation.isEmail == true)
            {
                _context.Entry(clientCreation).State = EntityState.Modified;
            }
            else
            {
                return Conflict(new { message = "Either Mail or SMS is Required!!!" });
            }
            if (!string.IsNullOrEmpty(clientCreation.mobileNo))
            {
                var Num = _context.ClientCreation.Where(n => n.mobileNo == clientCreation.mobileNo && n.clientId != id).FirstOrDefault();
                if (Num != null)
                {
                    return Conflict(new { message = "MobileNumber already found." });
                }
                bool isValid = Regex.IsMatch(clientCreation.mobileNo, @"^\d{10}$");

                if (!isValid)
                {
                    return Conflict(new { message = "Invalid MobileNumber." });

                }
            }
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ClientCreationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }

            //return NoContent();
            return new { message = "Client details updated successfully !!!" };
        }

        // PUT: api/ChangeClientStatus/{ClientId}/{Status}
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeClientStatus/{ClientId}/{Status}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ChangeClientStatus(long ClientId, int Status, string RejectionReason)
        {
            if (Status == (int)Statuses.Rejected && (RejectionReason == null || RejectionReason == ""))
            {
                return Conflict(new { message = "Reason for rejection is mandatory." });
            }
            // Get Client for the given ClientId
            var clientCreation = await _context.ClientCreation.Where(client => client.clientId == ClientId).FirstOrDefaultAsync();
            if (clientCreation == null)
            {
                return Conflict(new { message = "Client not found." });
            }
            if (clientCreation.clientName == null)
            {
                return Conflict(new { message = "Client name is mandatory" });
            }
            clientCreation.status = Status;
            if (Status == (int)Statuses.Rejected)
            {
                clientCreation.rejectionReason = RejectionReason;
                // Reject all the companies under the client
                var companies = _context.Organisations.Where(org => org.clientId == ClientId).ToList();
                companies.ForEach(comp =>
                {
                    comp.status = (int)Statuses.Rejected;
                    comp.updatedDate = DateTime.UtcNow;
                    _context.Entry(comp).State = EntityState.Modified;
                });

            }
            clientCreation.updatedDate = DateTime.UtcNow;
            _context.Entry(clientCreation).State = EntityState.Modified;

            var clientAdmin = await _context.EmployeePersonalDetails.Where(emp => emp.clientId == ClientId && emp.isClientAdmin == true).FirstOrDefaultAsync();

            if (clientAdmin == null)
            {
                return Conflict(new { message = "Client Admin not found" });
            }

            clientAdmin.status = Status;
            clientAdmin.updatedDate = DateTime.UtcNow;
            _context.Entry(clientAdmin).State = EntityState.Modified;
            try
            {
                // If the client is approved, create DB with client name
                if (Status == (int)Statuses.Approved)
                {
                    var schemaName = clientCreation.clientName;
                    //if (schemaName == null)
                    //{
                    schemaName = $"{Regex.Replace(schemaName.ToLower(), @"\s+", "_")}";
                    //}
                    var companiesUnderClient = await _context.Organisations.Where(org => org.clientId == clientCreation.clientId).ToListAsync();
                    if (companiesUnderClient.Count() > 0)
                    {
                        companiesUnderClient.ForEach(company =>
                        {
                            company.schemaName = schemaName;
                            _context.Entry(company).State = EntityState.Modified;
                        });
                        await _context.SaveChangesAsync();
                    }
                    // Once client is approved and user created DB schema to be created
                    string envName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                    IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json")
                .AddJsonFile($"appsettings.{envName}.json")
                .Build();

                    string connStr = configuration.GetConnectionString("CompayCreationConnnection");

                    MySqlConnection conn = new MySqlConnection(connStr);
                    conn.Open();
                    string sql = $"create database if not exists `{schemaName}`;";
                    MySqlScript script = new MySqlScript(conn);
                    script.Query = sql;
                    int count = script.Execute();

                    // Once company DB is created, dependency table to be created in the same schema. The module name is constant in DB with the name "Compaly Module"
                    var companyModule = await _context.DefaultCompanyScripts.FirstOrDefaultAsync();

                    if (companyModule == null)
                    {
                        return Conflict(new { message = "Default company script does not exist !!!" });
                    }
                    else
                    {

                        sql = $"create database if not exists `{schemaName}`;\n";
                        sql += $"use `{schemaName}`; SET FOREIGN_KEY_CHECKS=0;";
                        script.Query = sql;
                        script.Execute();
                        var scripts = companyModule.Script.Split(';');
                        scripts.ToList().ForEach(line =>
                        {
                            if (line != "")
                            {
                                sql = $"{line};\n";
                                script.Query = sql;
                                script.Execute();
                            }
                        });

                        sql = $"SET FOREIGN_KEY_CHECKS=1;";
                        script.Query = sql;
                        script.Execute();
                        script.Delimiter = ";";
                        // Handled exception, if the value is already exists.
                        try
                        {
                            sql = $"INSERT INTO `client_master` (`ClientId`) VALUES('{clientCreation.clientId}');";
                            script.Query = sql;
                            script.Execute();
                            script.Delimiter = ";";
                        }
                        catch (Exception ex)
                        {
                            return Conflict(new { message = $"Error: {ex.Message}" });
                        }
                    }
                    conn.Close();
                    script.Delimiter = ";";

                    Console.WriteLine("Delimiter: " + script.Delimiter);
                    Console.WriteLine("Query: " + script.Query);
                }
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });
            }

            //return NoContent();
            return new { message = "Client status updated successfully !!!" };
        }


        // POST: api/ClientCreations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostClientCreation(ClientCreation clientCreation)
        {
            //if (clientCreation.ClientCode == null)
            //{
            //  return  Conflict(new { message = "Client code is mandatory" });
            //}
            if (clientCreation.clientName == null)
            {
                return Conflict(new { message = "Client name is mandatory" });
            }
            var clientCreationCount = await _context.ClientCreation.OrderBy(client => client.clientId).LastOrDefaultAsync();
            if (clientCreation.isSms == true || clientCreation.isEmail == true)
            {
                _context.ClientCreation.Add(clientCreation);
            }
            else
            {
                return Conflict(new { message = "Either Mail or SMS is Required!!!" });
            }

            try
            {
                if (clientCreationCount == null)
                {
                    clientCreation.clientId = 1;
                }
                else
                {
                    clientCreation.clientId = clientCreationCount.clientId + 1;
                }
                clientCreation.createdTime = DateTime.UtcNow;
                clientCreation.updatedDate = clientCreation.createdTime;

                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {

                if (ClientNameExists(clientCreation.clientName))
                {
                    return Conflict(new { message = "Client name already exists !!!" });
                }
                else if (ClientCreationExists(clientCreation.clientId))
                {
                    return Conflict(new { message = "Client Id already exists !!!" });
                }
                else if (!Helper.StateExists((int)clientCreation.stateId))
                {
                    return Conflict(new { message = "State does not exist !!!" });
                }
                else
                {
                    throw;
                }
            }

            var clientCreationJson = JsonConvert.SerializeObject(clientCreation);
            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationJson);
        }

        // POST: api/ClientCompanyOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("ClientCompanyOnboarding")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ClientCompanyOnboarding(ClientCompanyCreation clientCompanyCreation)
        {
            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            long companyId = 0;


            if (clientCompanyCreation.clientUsers.Count() < 2 && clientCompanyCreation.companyUsers.Count() < 2)
            {
                return Conflict(new { message = "Please select alteast two client/company users" });
            }
            if (clientCompanyCreation.clientUsers.Count() < 2)
            {
                return Conflict(new { message = "Please select alteast two client users" });
            }
            if (clientCompanyCreation.companyUsers.Count() < 2)
            {
                return Conflict(new { message = "Please select atleast two company users" });
            }

            var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                              (c.isAllowedToClient == true && isOwnerCompany == false)))
                               select screenc;

            // initialing emptylist
            List<String> checks = new List<String>();
            List<String> makes = new List<String>();

            foreach (var user in clientCompanyCreation.clientUsers)
            {
                var outputM = (from cm in _context.ScreenPermissions
                               where cm.roleId == user.roleId
                               join sc in screenCountC on cm.screenId equals sc.screenId
                               select new
                               {
                                   sc.screenId,
                                   createPermission = cm.create,
                                   approvePermission = cm.approve,
                                   // createPermission = (cm.create == true ? 1 : 0)
                                   // approvePermission = (cm.approve == true ? 1 : 0),
                               }).ToList();

                //condition for make
                var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                //condition for checker
                var testC = from m in outputM where m.approvePermission == true select m;

                //if  maker
                if (testM.Count() != 0)
                {
                    String make = testM.ToString();
                    makes.Add(make);
                }
                //if checker
                if (testC.Count() != 0)
                {
                    String check = testC.ToString();
                    checks.Add(check);
                }

            }
            if (checks.Count() == 0 && makes.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker and one Checker" });

            }
            //if both are checker
            if (checks.Count() > 0 && makes.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker" });
            }
            //if both are maker
            if (makes.Count() > 0 && checks.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Checker" });
            }

            List<String> checks1 = new List<String>();
            List<String> makes1 = new List<String>();


            foreach (var user in clientCompanyCreation.companyUsers)
            {
                var outputM = (from cm in _context.ScreenPermissions
                               where cm.roleId == user.roleId
                               join sc in screenCountC on cm.screenId equals sc.screenId
                               select new
                               {
                                   sc.screenId,
                                   createPermission = cm.create,
                                   approvePermission = cm.approve,
                                   // createPermission = (cm.create == true ? 1 : 0)
                                   // approvePermission = (cm.approve == true ? 1 : 0),
                               }).ToList();


                var testM = from m in outputM where m.createPermission == true select m;
                var testC = from m in outputM where m.approvePermission == true select m;


                if (testM.Count() != 0)
                {
                    String makes2 = testM.ToString();
                    makes1.Add(makes2);
                }
                if (testC.Count() != 0)
                {
                    String checks2 = testC.ToString();
                    checks1.Add(checks2);
                }

            }
            if (checks1.Count() == 0 && makes1.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker and one Checker" });

            }
            if (checks1.Count() > 0 && makes1.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker" });
            }
            if (makes1.Count() > 0 && checks1.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Checker" });
            }

            ClientCreation clientCreation = new ClientCreation
            {
                clientName = clientCompanyCreation.clientName,
                makerId = clientCompanyCreation.clientMakerId,
                checkerId = clientCompanyCreation.clientCheckerId,
                status = (int)Statuses.Draft,
                stateId = 1,
                countryId = 1,
                address1 = "",
                address2 = "",
                address3 = "",
                clientCode = "",
                companyCount = 1,
                createdBy = userEmail,
                updatedBy = userEmail,
                pan = "",
                mobileNo = "",
                pincode = "",
                tan = "",
                isEmail = false,
                isSms = false,
                twoWayAuthentication = false,
                isOwnerClient = false,



            };
            try
            {
                //if (clientCreation.ClientName == null)
                //{
                //    return Conflict(new { message = "Client name is mandatory" });
                //}

                // When new client is added ClientId will be sent as 0, from the request.

                if (clientCompanyCreation.clientId == 0)
                {
                    var clientCreationCount = await _context.ClientCreation.OrderBy(client => client.clientId).LastOrDefaultAsync();

                    if (clientCreationCount == null)
                    {
                        clientCreation.clientId = 1;
                    }
                    else
                    {
                        clientCreation.clientId = clientCreationCount.clientId + 1;
                    }
                    clientCreation.createdTime = DateTime.UtcNow;
                    clientCreation.updatedDate = clientCreation.createdTime;
                    _context.ClientCreation.Add(clientCreation);
                }
                else
                {
                    var client = await _context.ClientCreation.Where(client => client.clientId == clientCompanyCreation.clientId).FirstOrDefaultAsync();
                    if (client == null)
                    {
                        return Conflict(new { message = "Client does not exist !!!" });
                    }
                    else
                    {
                        clientCreation = client;
                        clientCreation.makerId = clientCompanyCreation.clientMakerId;
                        clientCreation.checkerId = clientCompanyCreation.clientCheckerId;
                        clientCreation.updatedBy = userEmail;
                        clientCreation.createdTime = DateTime.UtcNow;
                        clientCreation.updatedDate = clientCreation.createdTime;
                        _context.Entry(clientCreation).State = EntityState.Modified;

                    }

                }

                var schemaName = clientCompanyCreation.clientName;
                //if (schemaName == null)
                //{
                schemaName = $"{Regex.Replace(schemaName.ToLower(), @"\s+", "_")}";

                // var lastOrganisation = await _context.Organisations.OrderBy(org => org.companyId).LastOrDefaultAsync();

                Organisation organisation = new Organisation
                {
                    //companyId = lastOrganisation != null ? lastOrganisation.companyId + 1 : 1,
                    clientId = clientCompanyCreation.clientId > 0 ? clientCompanyCreation.clientId : clientCreation.clientId,
                    companyName = clientCompanyCreation.companyName,
                    makerId = 0,
                    checkerId = 0,
                    status = (int)Statuses.Draft,
                    createdBy = userEmail,
                    updatedBy = userEmail,
                    createdTime = clientCreation.createdTime,
                    updatedDate = clientCreation.updatedDate,
                    schemaName = $"{schemaName}_{DateTime.UtcNow}",
                    approved = 0,
                    companyLogo = "",
                    created = 0,
                    esiReg = "",
                    panNo = "",
                    pfReg = "",
                    tanNo = "",
                    companyAddress1 = "",
                    companyAddress2 = "",
                    companyAddress3 = "",
                    stateId = 1,
                    countryId = 1,
                    isEmail = false,
                    isSms = false,
                    twoWayAuthentication = false,
                    isOwnerCompany = false,
                    organization = clientCompanyCreation.organization,
                    companyId = clientCompanyCreation.companyId,
                    //companyId = clientCompanyCreation. > 0 ? clientCompanyCreation.clientId : clientCreation.clientId,

                };
                if (organisation.clientId == null)
                {
                    return Conflict(new { message = "Client is required." });
                }
                _context.Organisations.Add(organisation);
                await _context.SaveChangesAsync();
                companyId = organisation.companyId;


                var OrganisationCommonMasterMappers = await (from cm in _context.CommonMaster.Where(c => c.status == (int)Statuses.Approved && c.isCompulsory == true)

                                                             select new MastersHierarchy
                                                             {
                                                                 hierarchyID = 0,
                                                                 parentID = cm.defaultparentID,
                                                                 parentType = cm.defaultparentType,
                                                                 childID = cm.commonMasterId,
                                                                 childType = models.Helpers.Helper.CommonMasterType,
                                                                 status = (int)Statuses.Approved,
                                                                 updatedBy = userEmail,
                                                                 updatedDate = DateTime.UtcNow,
                                                                 createdBy = userEmail,
                                                                 createdTime = DateTime.UtcNow,
                                                                 companyId = companyId

                                                             }).ToListAsync();
                var existingClientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                                 where (clientuser.clientId == clientCreation.clientId)
                                                 join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId
                                                 select new
                                                 {
                                                     clientuser.employeeId,
                                                     clientuser.clientId,
                                                     clientuser.roleId,
                                                     employee.email,
                                                     name = $"{employee.firstName} {employee.lastName}"
                                                 }
                               ).ToListAsync();
                var existingCompanyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                                  where (companyuser.companyId == organisation.companyId)
                                                  join employee in _context.EmployeePersonalDetails on companyuser.employeeId equals employee.employeePersonalDetailId
                                                  select new
                                                  {
                                                      companyuser.employeeId,
                                                      companyuser.companyId,
                                                      companyuser.roleId,
                                                      employee.email,
                                                      name = $"{employee.firstName} {employee.lastName}"
                                                  }
                                   ).ToListAsync();

                // Add client users
                clientCompanyCreation.clientUsers.ForEach(async (clientUser) =>
                {
                    var result = existingClientUsers.Where(employee => employee.employeeId == clientUser.employeeId && employee.clientId == clientCreation.clientId).FirstOrDefault();
                    if (result == null)
                    {
                        ClientUserRoleMapper clientUserRoleMapper = new ClientUserRoleMapper
                        {
                            clientId = clientCreation.clientId,
                            employeeId = clientUser.employeeId,
                            roleId = clientUser.roleId,
                            updatedBy = userEmail,
                            createdBy = userEmail,
                            updatedDate = DateTime.UtcNow,
                            createdDate = DateTime.UtcNow,
                            status = (int)Statuses.Approved
                        };
                        _context.ClientUserRoleMappers.Add(clientUserRoleMapper);
                    }
                });
                // Add company users
                clientCompanyCreation.companyUsers.ForEach(async (companyUser) =>
                {
                    var result = existingCompanyUsers.Where(employee => employee.employeeId == companyUser.employeeId && employee.companyId == organisation.companyId).FirstOrDefault();
                    if (result == null)
                    {
                        CompanyUserRoleMapper companyUserRoleMapper = new CompanyUserRoleMapper
                        {
                            companyId = organisation.companyId,
                            employeeId = companyUser.employeeId,
                            roleId = companyUser.roleId,
                            createdBy = userEmail,
                            updatedBy = userEmail,
                            updatedDate = DateTime.UtcNow,
                            createdDate = DateTime.UtcNow,
                            status = (int)Statuses.Approved
                        };
                        _context.Add(companyUserRoleMapper);
                    }
                });
                _context.MastersHierarchy.AddRange(OrganisationCommonMasterMappers);
                var saveResult = await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {

                if (ClientNameExists(clientCreation.clientName))
                {

                    return Conflict(new { message = "Company name already exists !!!" });
                }
                else if (CompanyNameExists(clientCompanyCreation.companyName))
                {
                    return Conflict(new { message = "Company name already exists !!!" });
                }
                else if (!Helper.StateExists((int)clientCreation.stateId))
                {
                    return Conflict(new { message = "State does not exist !!!" });
                }
                else if (ClientCreationExists(clientCreation.clientId))
                {
                    return Conflict(new { message = "Client Id already exists !!!" });
                }
                else
                {
                    //throw;
                    return Conflict(new { message = $"{ex.Message}" });
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"{ex.Message}" });
            }
            var clientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                     where (clientuser.clientId == clientCreation.clientId)
                                     join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId
                                     join UR in _context.UserRoles on clientuser.clientUserRoleMapperId equals UR.userRoleId
                                     select new
                                     {
                                         clientuser.employeeId,
                                         clientuser.clientId,
                                         clientuser.roleId,
                                         employee.email,
                                         name = $"{employee.firstName} {employee.lastName}",
                                         UR.roleName
                                     }
                               ).ToListAsync();
            var companyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                      where (companyuser.companyId == companyId)
                                      join employee in _context.EmployeePersonalDetails on companyuser.employeeId equals employee.employeePersonalDetailId
                                      join UR in _context.UserRoles on companyuser.userRoleMapperId equals UR.userRoleId
                                      select new
                                      {
                                          companyuser.employeeId,
                                          companyuser.companyId,
                                          companyuser.roleId,
                                          employee.email,
                                          name = $"{employee.firstName} {employee.lastName}",
                                          UR.userRoleId
                                      }
                               ).ToListAsync();

            var clientCompanyWithEmail = new
            {
                clientName = clientCompanyCreation.clientName,
                companyName = clientCompanyCreation.companyName,
                clientId = clientCreation.clientId,
                companyUsers = companyUsers,
                clientUsers = clientUsers
            };

            var clientCreationJson = JsonConvert.SerializeObject(clientCompanyWithEmail);
            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationJson);
        }


        // PUT: api/UpdateClientCompanyOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("UpdateClientCompanyOnboarding")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> UpdateClientCompanyOnboarding(UpdateClientCompanyCreation clientCompanyCreation)
        {

            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            if (clientCompanyCreation.clientUsers.Count() < 2 && clientCompanyCreation.companyUsers.Count() < 2)
            {
                return Conflict(new { message = "Please select alteast two client/company users" });
            }
            if (clientCompanyCreation.clientUsers.Count() < 2)
            {
                return Conflict(new { message = "Please select alteast two client users" });
            }
            if (clientCompanyCreation.companyUsers.Count() < 2)
            {
                return Conflict(new { message = "Please select atleast two company users" });
            }

            var screenCountC = from screenc in _context.Screens.Where(c => c.isApproveAllowed == true && ((c.isAllowedToOwner == true && isOwnerCompany) ||
                            (c.isAllowedToClient == true && isOwnerCompany == false)))
                               select screenc;

            // initialing emptylist
            List<String> checks = new List<String>();
            List<String> makes = new List<String>();

            foreach (var user in clientCompanyCreation.clientUsers)
            {
                var outputM = (from cm in _context.ScreenPermissions
                               where cm.roleId == user.roleId
                               join sc in screenCountC on cm.screenId equals sc.screenId
                               select new
                               {
                                   sc.screenId,
                                   createPermission = cm.create,
                                   approvePermission = cm.approve,
                                   // createPermission = (cm.create == true ? 1 : 0)
                                   // approvePermission = (cm.approve == true ? 1 : 0),
                               }).ToList();

                //condition for make
                var testM = from maker in outputM.Where(m => m.createPermission == true) select maker;
                //condition for checker
                var testC = from m in outputM where m.approvePermission == true select m;

                //if  maker
                if (testM.Count() != 0)
                {
                    String make = testM.ToString();
                    makes.Add(make);
                }
                //if checker
                if (testC.Count() != 0)
                {
                    String check = testC.ToString();
                    checks.Add(check);
                }

            }
            if (checks.Count() == 0 && makes.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker and one Checker" });

            }
            //if both are checker
            if (checks.Count() > 0 && makes.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker" });
            }
            //if both are maker
            if (makes.Count() > 0 && checks.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Checker" });
            }

            List<String> checks1 = new List<String>();
            List<String> makes1 = new List<String>();


            foreach (var user in clientCompanyCreation.companyUsers)
            {
                var outputM = (from cm in _context.ScreenPermissions
                               where cm.roleId == user.roleId
                               join sc in screenCountC on cm.screenId equals sc.screenId
                               select new
                               {
                                   sc.screenId,
                                   createPermission = cm.create,
                                   approvePermission = cm.approve,
                                   // createPermission = (cm.create == true ? 1 : 0)
                                   // approvePermission = (cm.approve == true ? 1 : 0),
                               }).ToList();


                var testM = from m in outputM where m.createPermission == true select m;
                var testC = from m in outputM where m.approvePermission == true select m;


                if (testM.Count() != 0)
                {
                    String makes2 = testM.ToString();
                    makes1.Add(makes2);
                }
                if (testC.Count() != 0)
                {
                    String checks2 = testC.ToString();
                    checks1.Add(checks2);
                }

            }
            if (checks1.Count() == 0 && makes1.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker and one Checker" });

            }
            if (checks1.Count() > 0 && makes1.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Maker" });
            }
            if (makes1.Count() > 0 && checks1.Count() == 0)
            {
                return Conflict(new { message = "Please select atleast one Checker" });
            }


            try
            {
                if (clientCompanyCreation.clientId == null)
                {
                    return Conflict(new { message = "Client is required." });
                }

                var client = await _context.ClientCreation.Where(client => client.clientId == clientCompanyCreation.clientId).FirstOrDefaultAsync();
                client.clientName = clientCompanyCreation.clientName;
                client.updatedDate = DateTime.UtcNow;
                client.updatedBy = userEmail;
                _context.Entry(client).State = EntityState.Modified;


                var organisation = await _context.Organisations.Where(org => org.companyId == clientCompanyCreation.companyId).FirstOrDefaultAsync();
                organisation.clientId = clientCompanyCreation.clientId;     // This line was added by Srinivas for the issue client is not change for the company.
                organisation.companyName = clientCompanyCreation.companyName;
                _context.Entry(organisation).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                var existingClientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                                 where (clientuser.clientId == clientCompanyCreation.clientId)
                                                 join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId
                                                 select new
                                                 {
                                                     clientuser.clientUserRoleMapperId,
                                                     clientuser.employeeId,
                                                     clientuser.clientId,
                                                     clientuser.roleId,
                                                     employee.email,
                                                     name = $"{employee.firstName} {employee.lastName}"
                                                 }
                               ).ToListAsync();
                var existingCompanyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                                  where (companyuser.companyId == organisation.companyId)
                                                  join employee in _context.EmployeePersonalDetails on companyuser.employeeId equals employee.employeePersonalDetailId
                                                  select new
                                                  {
                                                      companyuser.userRoleMapperId,
                                                      companyuser.employeeId,
                                                      companyuser.companyId,
                                                      companyuser.roleId,
                                                      employee.email,
                                                      name = $"{employee.firstName} {employee.lastName}"
                                                  }
                                   ).ToListAsync();

                // Add client users
                clientCompanyCreation.clientUsers.ForEach(async (clientUser) =>
                {
                    var result = existingClientUsers.Where(employee => employee.employeeId == clientUser.employeeId && employee.clientId == clientCompanyCreation.clientId).FirstOrDefault();
                    if (result == null)
                    {
                        ClientUserRoleMapper clientUserRoleMapper = new ClientUserRoleMapper
                        {
                            clientId = clientCompanyCreation.clientId,
                            employeeId = clientUser.employeeId,
                            roleId = clientUser.roleId,
                            updatedDate = DateTime.UtcNow,
                            createdDate = DateTime.UtcNow,
                            status = (int)Statuses.Approved
                        };
                        _context.ClientUserRoleMappers.Add(clientUserRoleMapper);
                    }
                    else if (result.roleId != clientUser.roleId)
                    {
                        var existingClientUser = _context.ClientUserRoleMappers.Where(employee => employee.employeeId == clientUser.employeeId && employee.clientId == clientCompanyCreation.clientId).FirstOrDefault();
                        existingClientUser.roleId = (long)clientUser.roleId;
                        _context.Entry(existingClientUser).State = EntityState.Modified;
                        _context.SaveChanges();
                    }
                });

                // Remove ClientUsers
                existingClientUsers.ForEach(clientUser =>
                {
                    var result = clientCompanyCreation.clientUsers.Where(u => u.employeeId == clientUser.employeeId).FirstOrDefault();
                    if (result == null)
                    {
                        var getClientUser = _context.ClientUserRoleMappers.Where(c => c.clientUserRoleMapperId == clientUser.clientUserRoleMapperId).FirstOrDefault();
                        if (getClientUser != null)
                        {
                            _context.ClientUserRoleMappers.Remove(getClientUser);
                        }
                    }
                });

                await _context.SaveChangesAsync();
                // Add company users
                clientCompanyCreation.companyUsers.ForEach(async (companyUser) =>
                {
                    var result = existingCompanyUsers.Where(employee => employee.employeeId == companyUser.employeeId && employee.companyId == organisation.companyId).FirstOrDefault();
                    if (result == null)
                    {
                        CompanyUserRoleMapper companyUserRoleMapper = new CompanyUserRoleMapper
                        {
                            companyId = organisation.companyId,
                            employeeId = companyUser.employeeId,
                            roleId = companyUser.roleId,
                            updatedDate = DateTime.UtcNow,
                            createdDate = DateTime.UtcNow,
                            status = (int)Statuses.Approved
                        };
                        _context.Add(companyUserRoleMapper);
                    }
                    else if (result.roleId != companyUser.roleId)
                    {
                        var existingCompanyUser = _context.CompanyUserRoleMappers.Where(employee => employee.employeeId == companyUser.employeeId && employee.companyId == clientCompanyCreation.companyId).FirstOrDefault();
                        existingCompanyUser.roleId = (long)companyUser.roleId;
                        _context.Entry(existingCompanyUser).State = EntityState.Modified;
                        _context.SaveChanges();
                    }
                });

                // Remove CompanyUsers
                existingCompanyUsers.ForEach(companyUser =>
                {
                    var result = clientCompanyCreation.companyUsers.Where(u => u.employeeId == companyUser.employeeId).FirstOrDefault();
                    if (result == null)
                    {
                        var getCompanyUser = _context.CompanyUserRoleMappers.Where(c => c.userRoleMapperId == companyUser.userRoleMapperId).FirstOrDefault();
                        if (getCompanyUser != null)
                        {
                            _context.CompanyUserRoleMappers.Remove(getCompanyUser);

                        }
                    }
                });
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                //throw;
                return Conflict(new { message = $"{ex.Message}" });
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"{ex.Message}" });
            }
            var clientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                     where (clientuser.clientId == clientCompanyCreation.clientId)
                                     join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId
                                     join UR in _context.UserRoles on clientuser.roleId equals UR.userRoleId
                                     select new
                                     {
                                         clientuser.employeeId,
                                         clientuser.clientId,
                                         clientuser.roleId,
                                         employee.email,
                                         name = $"{employee.firstName} {employee.lastName}",
                                         UR.roleName
                                     }
                               ).ToListAsync();
            var companyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                      where (companyuser.companyId == clientCompanyCreation.companyId)
                                      join employee in _context.EmployeePersonalDetails on companyuser.employeeId equals employee.employeePersonalDetailId
                                      join UR in _context.UserRoles on companyuser.roleId equals UR.userRoleId
                                      select new
                                      {
                                          companyuser.employeeId,
                                          companyuser.companyId,
                                          companyuser.roleId,
                                          employee.email,
                                          name = $"{employee.firstName} {employee.lastName}",
                                          UR.roleName
                                      }
                               ).ToListAsync();

            var clientCompanyWithEmail = new
            {
                clientName = clientCompanyCreation.clientName,
                companyName = clientCompanyCreation.companyName,
                clientId = clientCompanyCreation.clientId,
                companyId = clientCompanyCreation.companyId,
                companyUsers = companyUsers,
                clientUsers = clientUsers
            };

            var clientCreationJson = JsonConvert.SerializeObject(clientCompanyWithEmail);
            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationJson);
        }

        // PUT: api/DisableCompanyOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("DisableCompanyOnboarding/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> DisableCompanyOnboarding(long CompanyId)
        {

            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            try
            {
                var organisation = await _context.Organisations.Where(org => org.companyId == CompanyId).FirstOrDefaultAsync();
                organisation.status = (int)Statuses.Deleted;
                organisation.updatedBy = userEmail;
                organisation.updatedDate = DateTime.UtcNow;
                _context.Entry(organisation).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"{ex.Message}" });
            }

            return new { message = "Company disabled successfully !!!" };
        }

        // PUT: api/EnableCompanyOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("EnableCompanyOnboarding/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> EnableCompanyOnboarding(long CompanyId)
        {

            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            try
            {
                var organisation = await _context.Organisations.Where(org => org.companyId == CompanyId).FirstOrDefaultAsync();
                if (organisation != null)
                {
                    var client = await _context.ClientCreation.Where(c => c.clientId == organisation.clientId).FirstOrDefaultAsync();
                    if (client != null)
                    {
                        if (client.status == (int)Statuses.Deleted)
                        {
                            return Conflict(new { message = $"Please enable client '{client.clientName}' before enabling company !!!" });
                        }
                        else
                        {
                            organisation.status = (int)Statuses.Draft;
                            organisation.updatedBy = userEmail;
                            organisation.updatedDate = DateTime.UtcNow;
                            _context.Entry(organisation).State = EntityState.Modified;
                            await _context.SaveChangesAsync();
                        }
                    }

                }
                else
                {
                    return Conflict(new { message = "Company not found !!!" });
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"{ex.Message}" });
            }

            return new { message = "Company Enabled successfully !!!" };
        }

        // PUT: api/DisableClientOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("DisableClientOnboarding/{ClientId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> DisableClientOnboarding(long ClientId)
        {

            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            try
            {
                var client = await _context.ClientCreation.Where(c => c.clientId == ClientId).FirstOrDefaultAsync();
                if (client != null)
                {
                    client.status = (int)Statuses.Deleted;
                    client.updatedBy = userEmail;
                    client.updatedDate = DateTime.UtcNow;
                    _context.Entry(client).State = EntityState.Modified;
                    await _context.SaveChangesAsync();

                    var organisations = await _context.Organisations.Where(org => org.clientId == ClientId).ToListAsync();
                    organisations.ForEach(org =>
                    {
                        var organisation = _context.Organisations.Where(o => o.companyId == org.companyId).FirstOrDefault();
                        if (organisation != null)
                        {
                            organisation.status = (int)Statuses.Deleted;

                            organisation.updatedBy = userEmail;
                            organisation.updatedDate = DateTime.UtcNow;
                            _context.Entry(organisation).State = EntityState.Modified;
                        }
                    });
                    await _context.SaveChangesAsync();
                }
                else
                {
                    return Conflict(new { message = "Client does not exist !!!" });
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"{ex.Message}" });
            }

            return new { message = "Client disabled successfully !!!" };
        }

        // PUT: api/EnableClientOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("EnableClientOnboarding/{ClientId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> EnableClientOnboarding(long ClientId)
        {

            string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);
            try
            {
                var client = await _context.ClientCreation.Where(c => c.clientId == ClientId).FirstOrDefaultAsync();
                if (client != null)
                {
                    client.status = (int)Statuses.Draft;
                    client.updatedBy = userEmail;
                    client.updatedDate = DateTime.UtcNow;
                    _context.Entry(client).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                return Conflict(new { message = $"{ex.Message}" });
            }

            return new { message = "Client enabled successfully !!!" };
        }


        // GET: api/ClientCreations/GetClientCompanyOnboarding/5
        [HttpGet("GetClientCompanyOnboarding/{CompanyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetClientCompanyOnboarding(long CompanyId)
        {
            //long CompanyId = Common_Schema_Context.CurrentCompanyId;
            //var clientCreation = await _context.ClientCreation.FindAsync(id);
            var clientCreation = await (from company in _context.Organisations.Where(m => m.companyId == CompanyId)
                                        join client in _context.ClientCreation on company.clientId equals client.clientId into Clients
                                        from clientV in Clients.DefaultIfEmpty()
                                        select new
                                        {
                                            company.companyId,
                                            company.companyName,
                                            clientV.clientId,
                                            clientV.clientName,
                                            company.organization,
                                            company.companyAddress1,
                                            clientV.pincode,
                                            clientV.mobileNo,
                                            stateId = clientV.stateId == 1 ? null : clientV.stateId,
                                            countryId = clientV.countryId == 1 ? null : clientV.countryId,
                                        }
                                           ).FirstOrDefaultAsync();

            var clientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                     where (clientuser.clientId == clientCreation.clientId && clientuser.status == (int)Statuses.Approved)
                                     join employee in _context.EmployeePersonalDetails.Where(c => c.status != (int)Statuses.Deleted) on clientuser.employeeId equals employee.employeePersonalDetailId
                                     join UR in _context.UserRoles on clientuser.roleId equals UR.userRoleId
                                     where UR.userRoleId != (int)UserRoles.SuperAdmin
                                     select new
                                     {
                                         clientuser.employeeId,
                                         clientuser.clientId,
                                         clientuser.roleId,
                                         employee.email,
                                         name = $"{employee.firstName} {employee.lastName}",
                                         UR.roleName
                                     }
                               ).ToListAsync();
            var companyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                      where (companyuser.companyId == clientCreation.companyId && companyuser.status == (int)Statuses.Approved)
                                      join employee in _context.EmployeePersonalDetails.Where(c => c.status != (int)Statuses.Deleted) on companyuser.employeeId equals employee.employeePersonalDetailId
                                      join UR in _context.UserRoles on companyuser.roleId equals UR.userRoleId
                                      where UR.userRoleId != (int)UserRoles.SuperAdmin
                                      select new
                                      {
                                          companyuser.employeeId,
                                          companyuser.companyId,
                                          companyuser.roleId,
                                          employee.email,
                                          name = $"{employee.firstName} {employee.lastName}",
                                          UR.roleName
                                      }
                               ).ToListAsync();

            var clientCompanyOnboarding = new
            {
                clientId = clientCreation.clientId,
                clientName = clientCreation.clientName,
                companyId = clientCreation.companyId,
                pincode = clientCreation.pincode,
                mobileNo = clientCreation.mobileNo,
                companyName = clientCreation.companyName,
                organization = clientCreation.organization,
                companyAddress1 = clientCreation.companyAddress1,
                stateId = clientCreation.stateId,
                countryId = clientCreation.countryId,
                companyUsers = companyUsers,
                clientUsers = clientUsers
            };

            var clientCompanyOnboardingJson = JsonConvert.SerializeObject(clientCompanyOnboarding);
            if (clientCreation == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCompanyOnboardingJson);
        }

        // GET: api/ClientCreations/GetClientCompanyOnboardingList
        [HttpGet("GetClientCompanyOnboardingList")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetClientCompanyOnboardingList()
        {
            //var clientCreation = await _context.ClientCreation.FindAsync(id);
            var statuses = await _context.Statuses.ToListAsync();
            var clientCompanyOnboardingList = await (from company in _context.Organisations
                                                     join client in _context.ClientCreation on company.clientId equals client.clientId into Clients
                                                     from clientV in Clients.DefaultIfEmpty()
                                                     where company.isOwnerCompany != true // clientV.isOwnerClient != true
                                                     select new
                                                     {
                                                         company.companyId,
                                                         company.companyName,
                                                         companyStatus = company.status,
                                                         clientV.clientId,
                                                         clientV.clientName,
                                                         clientV.pincode,
                                                         clientV.mobileNo,
                                                         clientStatus = clientV.status,
                                                         company.createdTime,
                                                         company.organization,
                                                         company.companyAddress1,
                                                         stateId = clientV.stateId == 1 ? null : clientV.stateId,
                                                         countryId = clientV.countryId == 1 ? null : clientV.countryId,


                                                     }
                                           ).ToListAsync();
            List<object> clientCompanylist = new List<object>();
            clientCompanyOnboardingList.ForEach(clientCompany =>
            {
                clientCompanylist.Add(new
                {
                    clientCompany.companyId,
                    clientCompany.companyName,
                    companyStatusName = statuses.Where(status => status.statusId == clientCompany.companyStatus).First().statusName,
                    clientCompany.clientId,
                    clientCompany.clientName,
                    clientStatusName = statuses.Where(status => status.statusId == clientCompany.clientStatus).First().statusName,
                    clientCompany.createdTime,
                    clientCompany.organization,
                    clientCompany.companyAddress1,
                    clientCompany.pincode,
                    clientCompany.mobileNo,
                    clientCompany.stateId,
                    clientCompany.countryId

                });

            });

            var clientCompanyOnboardingListJson = JsonConvert.SerializeObject(clientCompanylist);
            if (clientCompanyOnboardingList == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(clientCompanyOnboardingListJson);
        }

        // GET: api/ClientCreations/GetClientUsers/5
        [HttpGet("GetClientUsers/ClientId")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetClientUsers(long ClientId)
        {

            var clientUsers = await (from clientuser in _context.ClientUserRoleMappers
                                     where (clientuser.clientId == ClientId)
                                     join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId
                                     join UR in _context.UserRoles on clientuser.roleId equals UR.userRoleId
                                     where UR.userRoleId != (int)UserRoles.SuperAdmin
                                     select new
                                     {
                                         clientuser.employeeId,
                                         clientuser.clientId,
                                         clientuser.roleId,
                                         employee.email,
                                         name = $"{employee.firstName} {employee.lastName}",
                                         UR.roleName
                                     }
                               ).ToListAsync();


            var clientUsersJson = JsonConvert.SerializeObject(clientUsers);
            if (clientUsers == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(clientUsersJson);
        }

        // GET: api/ClientCreations/GetCompanyUsers/5
        [HttpGet("GetCompanyUsers/CompanyId")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetCompanyUsers(long CompanyId)
        {

            var companyUsers = await (from companyuser in _context.CompanyUserRoleMappers
                                      where (companyuser.companyId == CompanyId)
                                      join employee in _context.EmployeePersonalDetails on companyuser.employeeId equals employee.employeePersonalDetailId
                                      join UR in _context.UserRoles on companyuser.roleId equals UR.userRoleId
                                      where UR.userRoleId != (int)UserRoles.SuperAdmin
                                      select new
                                      {
                                          companyuser.employeeId,
                                          companyuser.companyId,
                                          companyuser.roleId,
                                          employee.email,
                                          name = $"{employee.firstName} {employee.lastName}",
                                          UR.roleName
                                      }
                               ).ToListAsync();


            var companyUsersJson = JsonConvert.SerializeObject(companyUsers);
            if (companyUsers == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(companyUsersJson);
        }

        // GET: api/ClientCreations/GetExistingClientUserDetails/5
        [HttpGet("GetExistingClientUserDetails/ClientId")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetExistingClientUserDetails(long ClientId)
        {

            var clientUserName = await (from clientuser in _context.ClientUserRoleMappers
                                        where (clientuser.clientId == ClientId)
                                        join employee in _context.EmployeePersonalDetails on clientuser.employeeId equals employee.employeePersonalDetailId
                                        join UR in _context.UserRoles on clientuser.roleId equals UR.userRoleId
                                        where UR.userRoleId != (int)UserRoles.SuperAdmin
                                        select new
                                        {
                                            clientuser.employeeId,
                                            employeeName = $"{employee.firstName} {employee.lastName}",
                                            clientuser.roleId,
                                            UR.roleName,
                                            employee.email


                                        }
                                ).ToListAsync();


            var clientUsersNameJson = JsonConvert.SerializeObject(clientUserName);
            if (clientUserName == null)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(clientUsersNameJson);
        }



        //// PUT: api/UpdateClientCompanyOnboarding
        //// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("UpdateClientCompanyOnboarding/{CompanyId}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //[ServiceFilter(typeof(ValidationFilterAttribute))]
        //public async Task<ActionResult<object>> UpdateClientCompanyOnboarding(long CompanyId, ClientCompanyCreation clientCompanyCreation)
        //{
        //    try
        //    {

        //        string userEmail = JwtHelpers.JwtHelpers.GetEmailFromToken(Request.Headers["Authorization"]);

        //        var clientValue = await _context.ClientCreation.Where(client => client.ClientId == clientCompanyCreation.ClientId).FirstOrDefaultAsync();

        //        if (clientValue == null)
        //        {
        //            return Conflict(new { message = "Client does not exist !!!" });
        //        }
        //        clientValue.CheckerId = 0;
        //        clientValue.MakerId = 0;
        //        clientValue.UpdatedDate = DateTime.UtcNow;
        //        clientValue.UpdatedBy = userEmail;
        //        clientValue.ClientName = clientCompanyCreation.ClientName;
        //        _context.Entry(clientValue).State = EntityState.Modified;

        //        var companyValue = await _context.Organisations.Where(company => company.CompanyId == CompanyId).FirstOrDefaultAsync();
        //        if (companyValue == null)
        //        {
        //            return Conflict(new { message = "Company does not exist" });
        //        }
        //        companyValue.ClientId = clientCompanyCreation.ClientId;
        //        companyValue.MakerId = 0;
        //        companyValue.CheckerId = 0;
        //        companyValue.CompanyName = clientCompanyCreation.CompanyName;
        //        companyValue.UpdatedDate = DateTime.UtcNow;
        //        companyValue.UpdatedBy = userEmail;
        //        _context.Entry(companyValue).State = EntityState.Modified;
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateException ex)
        //    {
        //        if (!ClientCreationExists((long)clientCompanyCreation.ClientId))
        //        {
        //            return Conflict(new { message = "Client Id does not exist !!!" });
        //        }
        //        else
        //        {
        //            //throw;
        //            return Conflict(new { message = $"{ex.Message}" });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return Conflict(new { message = $"{ex.Message}" });
        //    }

        //    var clientCreationJson = JsonConvert.SerializeObject(clientCompanyCreation);
        //    return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationJson);
        //}

        // PUT: api/DisableClientCompanyOnboarding
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("DisableClientCompanyOnboarding/{CompanyId}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //[ServiceFilter(typeof(ValidationFilterAttribute))]
        //public async Task<ActionResult<object>> DisableClientCompanyOnboarding(long CompanyId, ClientCompanyCreation clientCompanyCreation)
        //{
        //    try
        //    {



        //        var companyValue = await _context.Organisations.Where(company => company.CompanyId == CompanyId).FirstOrDefaultAsync();
        //        if (companyValue == null)
        //        {
        //            return Conflict(new { message = "Company does not exist" });
        //        }
        //        companyValue.Status = (int)Statuses.Deleted;
        //        companyValue.UpdatedDate = DateTime.UtcNow;
        //        _context.Entry(companyValue).State = EntityState.Modified;
        //        await _context.SaveChangesAsync();

        //        // If the client does not have any company mapped then disable the client
        //        var companies = await _context.Organisations.Where(org => org.ClientId == clientCompanyCreation.ClientId).ToListAsync();
        //        if (companies.Count == 0)
        //        {
        //            var clientValue = await _context.ClientCreation.Where(client => client.ClientId == clientCompanyCreation.ClientId).FirstOrDefaultAsync();

        //            if (clientValue == null)
        //            {
        //                return Conflict(new { message = "Client does not exist !!!" });
        //            }
        //            clientValue.Status = (int)Statuses.Deleted;
        //            clientValue.UpdatedDate = DateTime.UtcNow;
        //            _context.Entry(clientValue).State = EntityState.Modified;
        //            await _context.SaveChangesAsync();
        //        }
        //    }
        //    catch (DbUpdateException ex)
        //    {
        //        if (!ClientCreationExists((long)clientCompanyCreation.ClientId))
        //        {
        //            return Conflict(new { message = "Client Id does not exist !!!" });
        //        }
        //        else
        //        {
        //            //throw;
        //            return Conflict(new { message = $"{ex.Message}" });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return Conflict(new { message = $"{ex.Message}" });
        //    }

        //    var clientCreationJson = JsonConvert.SerializeObject(clientCompanyCreation);
        //    return System.Text.Json.JsonSerializer.Deserialize<object>(clientCreationJson);
        //}


        // DELETE: api/ClientCreations/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteClientCreation(long id)
        {
            var clientCreation = await _context.ClientCreation.FindAsync(id);
            if (clientCreation == null)
            {
                return NotFound();
            }
            clientCreation.status = (int)Statuses.Deleted;
            _context.ClientCreation.Update(clientCreation);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        private bool ClientCreationExists(long id)
        {
            return _context.ClientCreation.Any(e => e.clientId == id);
        }

        private bool ClientNameExists(string name)
        {
            return _context.ClientCreation.Any(e => e.clientName == name);
        }

        private bool CompanyNameExists(string name)
        {
            return _context.Organisations.Any(e => e.companyName == name);
        }

        private bool ClientCodeExists(string code)
        {
            return _context.ClientCreation.Any(e => e.clientCode == code);
        }

        private async Task<object> ClientUserAlreadyExists(long clientId, long employeeId)
        {
            var result = await _context.ClientUserRoleMappers.Where(client => client.employeeId == employeeId && client.clientId == clientId).FirstOrDefaultAsync();
            return result;
        }

        private async Task<object> CompanyUserAlreadyExists(long companyId, long employeeId)
        {
            var result = await _context.CompanyUserRoleMappers.Where(company => company.employeeId == employeeId && company.companyId == companyId).FirstOrDefaultAsync();
            return result;
        }
    }
}
