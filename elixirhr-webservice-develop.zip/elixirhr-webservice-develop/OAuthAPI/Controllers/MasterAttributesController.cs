﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.Models.Common_Schema;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterAttributesController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public MasterAttributesController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/MasterAttributes
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<MasterAttribute>>> GetMasters()
        {
            return await _context.Masters.ToListAsync();
        }

        // GET: api/MasterAttributes/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<MasterAttribute>> GetMasterAttribute(long id)
        {
            var masterAttribute = await _context.Masters.FindAsync(id);

            if (masterAttribute == null)
            {
                return NotFound();
            }

            return masterAttribute;
        }

        // PUT: api/MasterAttributes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> PutMasterAttribute(long id, MasterAttribute masterAttribute)
        {
            if (id != masterAttribute.masterId)
            {
                return BadRequest();
            }

            _context.Entry(masterAttribute).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MasterAttributeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MasterAttributes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPost]
        //public async Task<ActionResult<List<MasterAttribute>>> PostMasterAttribute(List<MasterAttribute> masterAttribute)
        //{
        //    _context.Masters.UpdateRange(masterAttribute);
        //    await _context.SaveChangesAsync();
        //    return Ok(masterAttribute);
        //   // return CreatedAtAction("GetMasterAttribute", new { id = masterAttribute.Id }, masterAttribute);
        //}
        [HttpPost("MasterAttribute")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<List<MasterAttribute>>> PostMasterOrgMapper( List<MasterAttribute> masterAttribute)
        {
            try
            {
                if (_context.Masters == null)
                {
                    return Problem("Entity set 'MasterContext.Masters'  is null.");
                }

                _context.Masters.UpdateRange(masterAttribute);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return Conflict(new { message = $"Error: {ex.Message}" });

            }

            return Ok(masterAttribute);



            //return CreatedAtAction("GetMasterOrgMapper", new { id = masterOrgMapper.MasterOrgId }, masterOrgMapper);
        }


        // DELETE: api/MasterAttributes/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteMasterAttribute(long id)
        //{
        //    var masterAttribute = await _context.Masters.FindAsync(id);
        //    if (masterAttribute == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Masters.Remove(masterAttribute);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool MasterAttributeExists(long id)
        {
            return _context.Masters.Any(e => e.masterId == id);
        }
    }
}
