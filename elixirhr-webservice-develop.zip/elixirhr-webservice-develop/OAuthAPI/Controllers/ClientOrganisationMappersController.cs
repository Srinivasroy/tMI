﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientOrganisationMappersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public ClientOrganisationMappersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/ClientOrganisationMappers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClientOrganisationMapper>>> GetClientOrganisationMappers()
        {
            return await _context.ClientOrganisationMappers.ToListAsync();
        }

        // GET: api/ClientOrganisationMappers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ClientOrganisationMapper>> GetClientOrganisationMapper(int id)
        {
            var clientOrganisationMapper = await _context.ClientOrganisationMappers.FindAsync(id);

            if (clientOrganisationMapper == null)
            {
                return NotFound();
            }

            return clientOrganisationMapper;
        }

        // PUT: api/ClientOrganisationMappers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<object> PutClientOrganisationMapper(int id, ClientOrganisationMapper clientOrganisationMapper)
        {
            if (id != clientOrganisationMapper.clientOrganisationMapperId)
            {
                return BadRequest();
            }

            _context.Entry(clientOrganisationMapper).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ClientOrganisationMapperExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/ClientOrganisationMappers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<object>> PostClientOrganisationMapper(ClientOrganisationsMapper clientOrganisationsMapper)
        {
            if (clientOrganisationsMapper.companyIds.Count() > 0)
            {
                if (!Helper.ClientIdExists((long)clientOrganisationsMapper.clientId))
                {
                    return Conflict(new { message = "Client Id does not exist !!!" });
                }
                foreach (var companyId in clientOrganisationsMapper.companyIds)
                {
                    if (!ClientOrganisationExists(companyId, (long)clientOrganisationsMapper.clientId))
                    {
                        if (!Helper.OrganisationIdExists(companyId))
                        {
                            return Conflict(new { message = "Company Id does not exist !!!" });
                        }
                        ClientOrganisationMapper clientOrganisationMapper = new ClientOrganisationMapper
                        {
                            clientId = clientOrganisationsMapper.clientId,
                            companyId = companyId,
                            status = clientOrganisationsMapper.status,
                            createdBy = clientOrganisationsMapper.createdBy,
                            updatedBy = clientOrganisationsMapper.updatedBy
                        };
                        _context.ClientOrganisationMappers.Add(clientOrganisationMapper);
                        try
                        {
                            clientOrganisationMapper.createdDate = DateTime.UtcNow;
                            clientOrganisationMapper.updatedDate = DateTime.UtcNow;
                            await _context.SaveChangesAsync();
                            _context.Entry(clientOrganisationMapper).State = EntityState.Detached;
                        }
                        catch (DbUpdateException)
                        {
                            if (ClientOrganisationMapperExists(clientOrganisationMapper.clientOrganisationMapperId))
                            {
                                return Conflict();
                            }
                            else
                            {
                                throw;
                            }
                        }
                    }
                    else
                    {
                        if (!Helper.OrganisationIdExists(companyId))
                        {
                            return Conflict(new { message = "Company Id does not exist !!!" });
                        }
                        var clientOrganisationMapper = await _context.ClientOrganisationMappers.Where(clientOrg => clientOrg.clientId == clientOrganisationsMapper.clientId && clientOrg.companyId == companyId).FirstOrDefaultAsync();
                        clientOrganisationMapper.updatedBy = clientOrganisationsMapper.updatedBy;
                        clientOrganisationMapper.updatedDate = DateTime.UtcNow;
                        clientOrganisationMapper.status = clientOrganisationsMapper.status;
                        _context.Entry(clientOrganisationMapper).State = EntityState.Modified;
                        await _context.SaveChangesAsync();
                    }
                }
            }

            var getAllCompanies = await _context.ClientOrganisationMappers.Where(clientOrg=> clientOrg.clientId == clientOrganisationsMapper.clientId).ToListAsync();
            foreach(var company in getAllCompanies)
            {
                if (!clientOrganisationsMapper.companyIds.Contains((int)company.companyId))
                {
                    _context.ClientOrganisationMappers.Remove(company);
                    await _context.SaveChangesAsync();
                }
            }

            var clienOrganisationJson = JsonConvert.SerializeObject(clientOrganisationsMapper);
            var clientOrganisation = System.Text.Json.JsonSerializer.Deserialize<object>(clienOrganisationJson);
            return clientOrganisation;
        }

        // DELETE: api/ClientOrganisationMappers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteClientOrganisationMapper(int id)
        {
            var clientOrganisationMapper = await _context.ClientOrganisationMappers.FindAsync(id);
            if (clientOrganisationMapper == null)
            {
                return NotFound();
            }

            _context.ClientOrganisationMappers.Remove(clientOrganisationMapper);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ClientOrganisationMapperExists(int id)
        {
            return _context.ClientOrganisationMappers.Any(e => e.clientOrganisationMapperId == id);
        }
        private bool ClientOrganisationExists(long companyId, long clientId)
        {
            return _context.ClientOrganisationMappers.Any(e => e.companyId == companyId && e.clientId == clientId);
        }
    }
}
