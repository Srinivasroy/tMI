﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeAddressDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public EmployeeAddressDetailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        //// GET: api/EmployeeAddressDetails
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<EmployeeAddressDetail_Response>>> GetEmployeeAddressDetails()
        //{
        //    return await _context.EmployeeAddressDetails.ToListAsync();
        //}

        // GET: api/EmployeeAddressDetails/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<String>> GetEmployeeAddressDetail(long id)
        {
            var employeeAddressDetail = await _context.EmployeeAddressDetails.FindAsync(id);

            if (employeeAddressDetail == null)
            {
                return NotFound();
            }

            var result = JsonConvert.SerializeObject(employeeAddressDetail);

            return result;
        }

        // PUT: api/EmployeeAddressDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutEmployeeAddressDetail(long id, EmployeeAddressDetail employeeAddressDetail)
        {
            //if (id != employeeAddressDetail.Id)
            //{
            //    return BadRequest();
            //}
            if (!EmployeeAddressDetailExists(id))
            {
                return NotFound();
            }

            if (!EmployeePersonalDetailIdExists((long)employeeAddressDetail.employeeId))
            {
                return NotFound(new { Message= $"Employee Id '{employeeAddressDetail.employeeId}' does not exist"});
            }

            employeeAddressDetail.employeeAddressDetailId = id;
            employeeAddressDetail.updatedDate = DateTime.UtcNow;
            _context.Entry(employeeAddressDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeAddressDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/EmployeeAddressDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<EmployeeAddressDetail>> PostEmployeeAddressDetail(EmployeeAddressDetail employeeAddressDetail)
        {
                
            if(employeeAddressDetail.employeeId == null)
            {
                return NotFound(new { Message = $"Employee Id should not be null" });
            }
            _context.EmployeeAddressDetails.Add(employeeAddressDetail);
            try
            {

                employeeAddressDetail.createdTime=DateTime.UtcNow;
                employeeAddressDetail.updatedDate=DateTime.UtcNow;    
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (EmployeeAddressDetailExists(employeeAddressDetail.employeeAddressDetailId))
                {
                    return Conflict();
                }
                else if(!EmployeePersonalDetailIdExists((long)employeeAddressDetail.employeeId))
                {
                    return NotFound(new { Message = $"Employee Id '{employeeAddressDetail.employeeId}' does not exist" });
                }
                else if (EmployeePersonalDetailEmployeeIdExists((long)employeeAddressDetail.employeeId))
                {
                    return Conflict(new { Message = $"Address for this Employee Id '{employeeAddressDetail.employeeId}' already exists" });
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetEmployeeAddressDetail", new { id = employeeAddressDetail.employeeAddressDetailId}, employeeAddressDetail);
        }

        // DELETE: api/EmployeeAddressDetails/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteEmployeeAddressDetail(long id)
        //{
        //    var employeeAddressDetail = await _context.EmployeeAddressDetails.FindAsync(id);
        //    if (employeeAddressDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.EmployeeAddressDetails.Remove(employeeAddressDetail);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool EmployeeAddressDetailExists(long id)
        {
            return _context.EmployeeAddressDetails.Any(e => e.employeeAddressDetailId == id);
        }

        private bool EmployeePersonalDetailIdExists(long id)
        {
            return _context.EmployeePersonalDetails.Any(e => e.employeePersonalDetailId == id);
        }
        private bool EmployeePersonalDetailEmployeeIdExists(long employeeId)
        {
            return _context.EmployeeAddressDetails.Any(e => e.employeeId == employeeId);
        }
    }
}
