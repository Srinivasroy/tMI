﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CostcentersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public CostcentersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Costcenters
        [HttpGet]
        public async Task<ActionResult<ArrayList>> GetCostcenters()
        {
            var costCenters = await _context.Costcenters.ToListAsync();
            var costCentersJson = JsonConvert.SerializeObject(costCenters);
            ArrayList constCentersList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(costCentersJson);
            return constCentersList;
        }

        // GET: api/Costcenters/5
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetCostcenter(long id)
        {
            var costcenter = await _context.Costcenters.FindAsync(id);

            if (costcenter == null)
            {
                return NotFound();
            }

            var costcenterJson = JsonConvert.SerializeObject(costcenter);
            var _costcenter = System.Text.Json.JsonSerializer.Deserialize<object>(costcenterJson);
            return _costcenter;

        }

        // PUT: api/Costcenters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<object> PutCostcenter(long id, Costcenter costcenter)
        {
            costcenter.costCenterId = id;
            costcenter.updatedDate = DateTime.UtcNow;
            _context.Entry(costcenter).State = EntityState.Modified;
            if (costcenter.employeeId == null)
            {
                return Conflict(new { message = "Employee Id is mandatory !!!" });
            }
            if (!Helper.EmployeePersonalDetailIdExists((long)costcenter.employeeId))
            {
                return Conflict(new { message = "Employee Id does not exist !!!" });
            }
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CostcenterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/Costcenters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult> PostCostcenter(Costcenter costcenter)
        {
            if (costcenter.employeeId == null)
            {
                return Conflict(new { message = "Employee Id is mandatory !!!" });
            }
            if (!Helper.EmployeePersonalDetailIdExists((long)costcenter.employeeId))
            {
                return Conflict(new { message = "Employee Id does not exist !!!" });
            }
            costcenter.createdTime = DateTime.UtcNow;
            costcenter.updatedDate = costcenter.createdTime;
            _context.Costcenters.Add(costcenter);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (CostcenterExists(costcenter.costCenterId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetCostcenter", new { id = costcenter.costCenterId }, costcenter);
        }

        // DELETE: api/Costcenters/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteCostcenter(long id)
        //{
        //    var costcenter = await _context.Costcenters.FindAsync(id);
        //    if (costcenter == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Costcenters.Remove(costcenter);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool CostcenterExists(long id)
        {
            return _context.Costcenters.Any(e => e.costCenterId == id);
        }
    }
}
