﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OAuthAPI.models.common_schema;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeProfessionalDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public EmployeeProfessionalDetailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/EmployeeProfessionalDetailsController
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<String>> GetEmployeeProfessionalDetails(bool? GetAll = false)
        {
            if (GetAll == true)
            {
                var employeeprofessionaldetaillist = await _context.EmployeeProfessionalDetails.ToListAsync();
                return JsonConvert.SerializeObject(employeeprofessionaldetaillist);
            }

            var _employeeprofessionaldetaillist = await _context.EmployeeProfessionalDetails.ToListAsync();
            return JsonConvert.SerializeObject(_employeeprofessionaldetaillist);
        }

        //GET: api/EmployeeProfessionalDetails/id
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<String>> GetEmployeeProfessionalDetail(long id)
        {
            var employeeProfessionalDetail = await _context.EmployeeProfessionalDetails.FindAsync(id);
            var employeeProfessionalDetail_json = JsonConvert.SerializeObject(employeeProfessionalDetail);
            if (employeeProfessionalDetail == null)
            {
                return NotFound();
            }
            return employeeProfessionalDetail_json;
        }


        // PUT: api/EmployeeProfessionalDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutEmployeeProfessionalDetail(long id, EmployeeProfessionalDetail employeeProfessionalDetail)
        {
            if (!EmployeeProfessionalDetailsIdExists(id))
            {
                return NotFound();
            }
            if (!AddressIdExists((long)employeeProfessionalDetail.addressId))
            {
                return Conflict(new { message = $"Address Id '{employeeProfessionalDetail.addressId}' not found." });
            }

            employeeProfessionalDetail.employeeProfessionaldetailId = id;
            employeeProfessionalDetail.updatedDate = DateTime.UtcNow;
            //EmployeePersonalDetail_Response _employeePersonalDetail = GetMappedValue(employeePersonalDetail);
            _context.Entry(employeeProfessionalDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeProfessionalDetailsIdExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }


            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/EmployeeProfessionalDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<string>> PostEmployeeProfessionalDetail(EmployeeProfessionalDetail employeeProfessionalDetail)
        {
            if (employeeProfessionalDetail.addressId == null)
            {
                return NotFound(new { Message = $"Address Id should not be null" });
            }
            // var _employeePersonalDetail = GetMappedValue(employeePersonalDetail);
            _context.EmployeeProfessionalDetails.Add(employeeProfessionalDetail);
            try
            {
                if (!AddressIdExists((long)employeeProfessionalDetail.addressId))
                {
                    return Conflict(new { message = $"Address Id '{employeeProfessionalDetail.addressId}' not found." });
                }
                employeeProfessionalDetail.employeeProfessionaldetailId = _context.EmployeeProfessionalDetails.Count() + 1;

                employeeProfessionalDetail.createdTime = DateTime.UtcNow;
                employeeProfessionalDetail.updatedDate = employeeProfessionalDetail.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (EmployeeProfessionalDetailsIdExists(employeeProfessionalDetail.employeeProfessionaldetailId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            // var employeeProfessionalDetail_ = _context.EmployeeProfessionalDetails.FirstOrDefault(x => x.Id == employeeProfessionalDetail.Id);
            var employeeProfessionalDetail_json = JsonConvert.SerializeObject(employeeProfessionalDetail);
            //var test= new { Id = employeeProfessionalDetail.Id,}            
            return employeeProfessionalDetail_json;
        }


        private bool EmployeeProfessionalDetailsIdExists(long id)
        {
            return _context.EmployeeProfessionalDetails.Any(e => e.employeeProfessionaldetailId == id);
        }

        private bool AddressIdExists(long id)
        {
            return _context.EmployeeAddressDetails.Any(e => e.employeeAddressDetailId == id);
        }


    }
}
