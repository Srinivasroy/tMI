﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatesController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public StatesController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/States
        [HttpGet]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetStates()
        {
            try
            {

                var states = await (from state in _context.States
                                    select new
                                    {
                                        state.stateId,
                                        state.stateName,
                                        state.createdBy,
                                        state.createdTime,
                                        state.updatedBy,
                                        state.updatedDate
                                    }).ToListAsync();

                if (states == null)
                {
                    return NotFound();
                }
                var statesJson = JsonConvert.SerializeObject(states);
                ArrayList statesList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(statesJson);
                //return Conflict(new { message = "API is working!!!!" });
                return statesList;
            }
            catch (Exception ex)
            {
                //return Conflict(ex.Message);
                throw ex;
            }

        }

        // GET: api/States/5
        [HttpGet("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetState(int id)
        {
            var stateV = await (from state in _context.States.Where(state => state.stateId == id)
                                select new
                                {
                                    state.stateId,
                                    state.stateName,
                                    state.createdBy,
                                    state.createdTime,
                                    state.updatedBy,
                                    state.updatedDate,
                                    state.companyId,
                                    state.countryId,
                                    state.status
                                }).ToListAsync();

            if (stateV == null)
            {
                return NotFound();
            }
            var stateJson = JsonConvert.SerializeObject(stateV);
            var stateValue = System.Text.Json.JsonSerializer.Deserialize<object>(stateJson);

            return stateValue;
        }

        // PUT: api/States/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutState(int id, State state)
        {
            //if (id != state.Id)
            //{
            //    return BadRequest();
            //}
            state.stateId = id;
            state.updatedDate = DateTime.UtcNow;
            _context.Entry(state).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StateExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/States
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<State>> PostState(State state)
        {
            _context.States.Add(state);
            try
            {
                state.updatedDate = DateTime.UtcNow;
                state.createdTime = DateTime.UtcNow;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (StateExists(state.stateId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetState", new { id = state.stateId }, state);
        }

        // DELETE: api/States/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteState(int id)
        //{
        //    var state = await _context.States.FindAsync(id);
        //    if (state == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.States.Remove(state);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool StateExists(long id)
        {
            return _context.States.Any(e => e.stateId == id);
        }
    }
}
