﻿#nullable disable
#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DesignationsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public DesignationsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Designations
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetDesignations(bool? GetAll = false)
        {
            if (GetAll == true)
            {
                var designations = await _context.Designations.ToListAsync();
                var designationsjson = JsonConvert.SerializeObject(designations);
                ArrayList designationslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(designationsjson);

                return designationslist;
            }

            var _designations = await _context.Designations.ToListAsync();
            var _designationsjson = JsonConvert.SerializeObject(_designations);
            ArrayList _designationslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_designationsjson);
            return _designationslist;
        }

        // GET: api/Designations/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetDesignation(long id)
        {
            var designation = await _context.Designations.FindAsync(id);

            if (designation == null)
            {
                return NotFound();
            }

            var designationjson = JsonConvert.SerializeObject(designation);
            var _designation = System.Text.Json.JsonSerializer.Deserialize<object>(designationjson);

            return _designation;
        }

        // PUT: api/Designations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutDesignation(long id, Designation designation)
        {
            if (!DesignationExists(id))
            {
                return Conflict(new { message = $"Designation Id '{designation.designationId}' not found." });
            }
            if (!EmployeeIdExists((long)designation.employeeId))
            {
                return Conflict(new { message = $"Employee Id '{designation.employeeId}' not found." });
            }

            designation.designationId = id;
            designation.updatedDate = DateTime.UtcNow;
            _context.Entry(designation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DesignationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/Designations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostDesignation(Designation designation)
        {
            _context.Designations.Add(designation);
            try
            {

                if (!EmployeeIdExists((long)designation.employeeId))
                {
                    return Conflict(new { message = $"Employee Id '{designation.employeeId}' not found." });
                }
                designation.designationId = _context.Designations.Count() + 1;

                designation.createdTime = DateTime.UtcNow;
                designation.updatedDate = designation.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                throw;
            }

            var designationjson = JsonConvert.SerializeObject(designation);
            var _designation = System.Text.Json.JsonSerializer.Deserialize<object>(designationjson);

            return _designation;
        }



        private bool DesignationExists(long id)
        {
            return _context.Designations.Any(e => e.designationId == id);
        }

        private bool EmployeeIdExists(long id)
        {
            return _context.EmployeePersonalDetails.Any(e => e.employeePersonalDetailId == id);
        }
    }
}
