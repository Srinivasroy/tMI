﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserGroupsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public UserGroupsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/UserGroups
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetUserGroups()
        {
            
                //var userGroups = await _context.UserGroups.ToListAsync();
                var userGroups = await (from userGroup in _context.UserGroups
                                          join org in _context.Organisations on userGroup.companyId equals org.companyId into company
                                          from comp in company.DefaultIfEmpty()
                                          select new
                                          {
                                              userGroup.userGroupId,
                                              userGroup.groupName,
                                              userGroup.updatedDate,
                                              userGroup.updatedBy,
                                              userGroup.createdBy,
                                              userGroup.createdTime,
                                              userGroup.isMultiCompany,
                                              comp.companyId,
                                              comp.companyName
                                          }
                                          ).ToListAsync();
                var userGroupsjson = JsonConvert.SerializeObject(userGroups);
                ArrayList userGroupslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(userGroupsjson);

                return userGroupslist;
        }

        // GET: api/UserGroups/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetUserGroup(long id)
        {
            //var userGroup = await _context.UserGroups.FindAsync(id);
            var userGroup = await (from userGrp in _context.UserGroups where userGrp.userGroupId == id
                                    join org in _context.Organisations on userGrp.companyId equals org.companyId into company
                                    from comp in company.DefaultIfEmpty()
                                    select new
                                    {
                                        userGrp.userGroupId,
                                        userGrp.groupName,
                                        userGrp.updatedDate,
                                        userGrp.updatedBy,
                                        userGrp.createdBy,
                                        userGrp.createdTime,
                                        userGrp.isMultiCompany,
                                        comp.companyId,
                                        comp.companyName
                                    }
                                         ).ToListAsync();
            if (userGroup == null)
            {
                return NotFound();
            }

            var userGroupjson = JsonConvert.SerializeObject(userGroup);
            var _userGroup = System.Text.Json.JsonSerializer.Deserialize<object>(userGroupjson);

            return _userGroup;
        }

        // PUT: api/UserGroups/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutUserGroup(long id, UserGroup userGroup)
        {
            if (!UserGroupExists(id))
            {
                return Conflict(new { message = $"UserGroup Id '{userGroup.userGroupId}' not found." });
            }
            if (!Helper.OrganisationIdExists((long)userGroup.companyId))
            {
                return Conflict(new { message = $"Company Id '{userGroup.companyId}' not found." });
            }
            if (UserGroupNameExists(userGroup.groupName))
            {
                return Conflict(new { message = $"UserGroup Name '{userGroup.groupName}' already exists" });
            }

            userGroup.userGroupId = id;
            userGroup.updatedDate = DateTime.UtcNow;
            _context.Entry(userGroup).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserGroupExists(id))
                {
                    return NotFound();
                }
                if (UserGroupNameExists(userGroup.groupName))
                {
                    return Conflict(new { message = $"Group name '{userGroup.groupName}' already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/UserGroups
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostUserGroup(UserGroup userGroup)
        {
            _context.UserGroups.Add(userGroup);
            try
            {

                if (!Helper.OrganisationIdExists((long)userGroup.companyId))
                {
                    return Conflict(new { message = $"Company Id '{userGroup.companyId}' not found." });
                }

                if (UserGroupNameExists(userGroup.groupName))
                {
                    return Conflict(new { message = $"UserGroup Name '{userGroup.groupName}' already exists" });
                }
                userGroup.userGroupId = _context.UserGroups.Count() + 1;

                userGroup.createdTime = DateTime.UtcNow;
                userGroup.updatedDate = userGroup.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (UserGroupExists(userGroup.userGroupId))
                {
                    return Conflict(new { message = $"A userGroup with the id '{userGroup.userGroupId}' was already found." });
                }
                if (UserGroupNameExists(userGroup.groupName))
                {
                    return Conflict(new { message = $"Group name '{userGroup.groupName}' already exists !!!" });
                }
                else
                {
                    throw;
                }

            }

            var userGroupjson = JsonConvert.SerializeObject(userGroup);
            var _userGroup = System.Text.Json.JsonSerializer.Deserialize<object>(userGroupjson);

            return _userGroup;
        }

        private bool UserGroupExists(long id)
        {
            return _context.UserGroups.Any(e => e.userGroupId == id);
        }

        private bool UserGroupNameExists(string groupName)
        {
            return _context.UserGroups.Any(e => e.groupName == groupName);
        }

    }
}
