﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.ActionFilters;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PasswordConfigurationsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public PasswordConfigurationsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/PasswordConfigurations
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<PasswordConfiguration>>> GetPasswordConfigurations()
        {
            return await _context.PasswordConfigurations.ToListAsync();
        }

        // GET: api/PasswordConfigurations/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<PasswordConfiguration>> GetPasswordConfiguration(int id)
        {
            var passwordConfiguration = await _context.PasswordConfigurations.FindAsync(id);

            if (passwordConfiguration == null)
            {
                return NotFound();
            }

            return passwordConfiguration;
        }

        // GET: api/GetPasswordMessage
        [HttpGet("GetPasswordMessage/EmployeeId")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<List<string>>> GetPasswordMessage(long EmployeeId)
        {
            var passwordConfiguration = await _context.PasswordConfigurations.FirstOrDefaultAsync();
            List<string> message = new List<string>();
            if (passwordConfiguration == null)
            {
                return NotFound();
            }
            if (passwordConfiguration != null)
            {
                if (passwordConfiguration.minimumLength > 0)
                {
                    message.Add($"Password should have atleast {passwordConfiguration.minimumLength} characters");
                }
                if (passwordConfiguration.maximumLength > 0)
                {
                    message.Add($"Password should not exceed {passwordConfiguration.maximumLength} characters");
                }
                if (passwordConfiguration.specialCharacters > 0)
                {
                    message.Add($"Password should not have more than {passwordConfiguration.specialCharacters} special characters");
                }
                if (passwordConfiguration.specialCharactersAllowed.Length > 0)
                {
                    message.Add($"Allowed special characters are {passwordConfiguration.specialCharacters}");
                }

            }

            return message;
        }

        // GET: api/GetPasswordMessage
        [HttpGet("ValidatePassword/{Password}/{UserId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> ValidatePassword(string Password, long UserId)
        {
            var passwordConfiguration = await _context.PasswordConfigurations.FirstOrDefaultAsync();
            bool message = true;
            if (passwordConfiguration == null)
            {
                return NotFound();
            }
            if (passwordConfiguration != null)
            {
                // Validate password with last few records
                if (passwordConfiguration.noOfHistory > 0)
                {
                    var LastFewPasswords = _context.TrackPasswords.OrderByDescending(password => password.trackPassId == UserId).Take((int)passwordConfiguration.noOfHistory).ToList();
                    string password = Helpers.Helpers.SHA256Hash(Password);

                    var PasswordList = LastFewPasswords.Where(pass => pass.password == password).ToList();
                    if (PasswordList.Count() > 0)
                    {
                        return Conflict($"Password should not match last {passwordConfiguration.noOfHistory} passwords.");
                    }

                }

                if (Password.Length < passwordConfiguration.minimumLength)
                {
                    return Conflict(new { message = $"Password should contain atleast {passwordConfiguration.minimumLength} characters." });
                }
                if (Password.Length > passwordConfiguration.maximumLength)
                {
                    return Conflict(new { message = $"Password should not exceed {passwordConfiguration.maximumLength} characters." });
                }
                string numbersAndLetters = string.Empty;
                Regex regex = new Regex("[^A-Za-z0-9]");
                string specialCharacters = string.Empty;
                string UpperCaseCharacters = string.Empty;
                string LowerCaseCharacters = string.Empty;
                for (int i = 0; i < Password.Length; i++)
                {
                    if (regex.IsMatch(Password[i].ToString()))
                    {
                        specialCharacters += Password[i].ToString();
                    }
                    else
                    {
                        numbersAndLetters += Password[i].ToString();
                    }

                }
                if (specialCharacters.Length < passwordConfiguration.specialCharacters)
                {
                    return Conflict(new { message = $"Atleast {passwordConfiguration.specialCharacters} special characters to be entered." });
                }

                UpperCaseCharacters = string.Concat(Regex
   .Matches(numbersAndLetters, "[A-Z]")
   .OfType<Match>()
   .Select(match => match.Value));
                if (UpperCaseCharacters.Length < passwordConfiguration.upperCase)
                {
                    return Conflict(new { message = $"Atleast {passwordConfiguration.upperCase} upper case characters to be entered." });
                }
                LowerCaseCharacters = string.Concat(Regex
   .Matches(numbersAndLetters, "[a-z]")
   .OfType<Match>()
   .Select(match => match.Value));
                if (LowerCaseCharacters.Length < passwordConfiguration.lowerCase)
                {
                    return Conflict(new { message = $"Atleast {passwordConfiguration.lowerCase} lower case characters to be entered." });
                }
                // Validate the password has the list of allowed special characters
                for (int i = 0; i < specialCharacters.Length; i++)
                {
                    if (!passwordConfiguration.specialCharactersAllowed.Contains(specialCharacters[i]))
                    {
                        return Conflict(new { message = $"{specialCharacters[i]} - Special character entered is not allowed." });
                    }
                }




            }

            return new { message = "Password is valid !!!" };
        }

        // PUT: api/PasswordConfigurations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> PutPasswordConfiguration(int id, PasswordConfiguration passwordConfiguration)
        {
            //if (id != passwordConfiguration.Id)
            //{
            //    return BadRequest();
            //}
            passwordConfiguration.passConfigId = id;
            passwordConfiguration.updatedDate = DateTime.UtcNow;
            _context.Entry(passwordConfiguration).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PasswordConfigurationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // PUT: api/ChangePassword/{EmployeeId}/{OldPassword}/{NewPassword}
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangePassword/{EmployeeId}/{OldPassword}/{NewPassword}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> ChangePassword(string OldPassword, string NewPassword, long EmployeeId)
        {

            string[] parts = NewPassword.Split('%');

            StringBuilder convertedWord = new StringBuilder();
            convertedWord.Append(parts[0]);

            for (int i = 1; i < parts.Length; i++)
            {
                if (parts[i].Length >= 2)
                {
                    string hexValue = parts[i].Substring(0, 2);
                    int asciiValue = int.Parse(hexValue, System.Globalization.NumberStyles.HexNumber);
                    convertedWord.Append((char)asciiValue);
                    convertedWord.Append(parts[i].Substring(2));
                }
            }

              var NewPassword1 =   convertedWord.ToString();
            
            string oldPassword = Helpers.Helpers.SHA256Hash(OldPassword);
            var employee = await _context.EmployeePersonalDetails.Where(emp => emp.employeePersonalDetailId == EmployeeId).FirstOrDefaultAsync();
            if (employee == null)
            {
                return Conflict(new { message = "Employee not found !!!" });
            }
            else
            {
                if (oldPassword != employee.password)
                {
                    return Conflict(new { message = "Current password does not match" });
                }
                //added now
                //var pass = await ValidatePassword(NewPassword, EmployeeId);
                var passwordConfiguration = await _context.PasswordConfigurations.FirstOrDefaultAsync();
                bool message = true;
                if (passwordConfiguration == null)
                {
                    return NotFound();
                }
                if (passwordConfiguration != null)
                {
                    // Validate password with last few records
                    //if (passwordConfiguration.noOfHistory > 0)
                    //{
                    //    var LastFewPasswords = _context.TrackPasswords.OrderByDescending(password => password.trackPassId == EmployeeId).Take((int)passwordConfiguration.noOfHistory).ToList();
                    //    string password = Helpers.Helpers.SHA256Hash(NewPassword);

                    //    var PasswordList = LastFewPasswords.Where(pass => pass.password == password).ToList();
                    //    if (PasswordList.Count() > 0)
                    //    {
                    //        return Conflict($"Password should not match last {passwordConfiguration.noOfHistory} passwords.");
                    //    }

                    //}

                    //var pass = 0;
                    //var trackpassword = _context.TrackPasswords.Where(r => r.employeeId == EmployeeId).Select(r => r.password).ToList();
                    //foreach (string password in trackpassword)
                    //{
                    //    if (NewPassword.Equals(password))
                    //    {
                    //        pass++;
                    //        //return Conflict(new { message = "Password exists in history !!!" });
                    //    }
                    //}
                    //if (pass > 0)
                    //{
                    //    return Conflict(new { message = "Password exists in history !!!" });
                    //}

                    if (NewPassword1.Length < passwordConfiguration.minimumLength)
                    {
                        return Conflict(new { message = $"Password should contain atleast {passwordConfiguration.minimumLength} characters." });
                    }
                    if (NewPassword1.Length > passwordConfiguration.maximumLength)
                    {
                        return Conflict(new { message = $"Password should not exceed {passwordConfiguration.maximumLength} characters." });
                    }
                    string numbersAndLetters = string.Empty;
                    Regex regex = new Regex("[^A-Za-z0-9]");
                    string specialCharacters = string.Empty;
                    string UpperCaseCharacters = string.Empty;
                    string LowerCaseCharacters = string.Empty;
                    for (int i = 0; i < NewPassword1.Length; i++)
                    {
                        if (regex.IsMatch(NewPassword1[i].ToString()))
                        {
                            specialCharacters += NewPassword1[i].ToString();
                        }
                        else
                        {
                            numbersAndLetters += NewPassword1[i].ToString();
                        }

                    }
                    if (specialCharacters.Length < passwordConfiguration.specialCharacters)
                    {
                        return Conflict(new { message = $"Atleast {passwordConfiguration.specialCharacters} special characters to be entered." });
                    }

                    UpperCaseCharacters = string.Concat(Regex
       .Matches(numbersAndLetters, "[A-Z]")
       .OfType<Match>()
       .Select(match => match.Value));
                    if (UpperCaseCharacters.Length < passwordConfiguration.upperCase)
                    {
                        return Conflict(new { message = $"Atleast {passwordConfiguration.upperCase} upper case characters to be entered." });
                    }
                    LowerCaseCharacters = string.Concat(Regex
       .Matches(numbersAndLetters, "[a-z]")
       .OfType<Match>()
       .Select(match => match.Value));
                    if (LowerCaseCharacters.Length < passwordConfiguration.lowerCase)
                    {
                        return Conflict(new { message = $"Atleast {passwordConfiguration.lowerCase} lower case characters to be entered." });
                    }
                    // Validate the password has the list of allowed special characters
                    for (int i = 0; i < specialCharacters.Length; i++)
                    {
                        if (!passwordConfiguration.specialCharactersAllowed.Contains(specialCharacters[i]))
                        {
                            return Conflict(new { message = $"{specialCharacters[i]} - Special character entered is not allowed." });
                        }
                    }

                }

                employee.password = Helpers.Helpers.SHA256Hash(NewPassword1);

                var pass = 0;
                //var trackpassword = _context.TrackPasswords.Where(r => r.employeeId == EmployeeId).Select(r => r.password).ToList();
                var trackpassword = _context.TrackPasswords.Where(r => r.employeeId == EmployeeId).OrderByDescending(r => r.lastChanged).Take(3).Select(r => r.password).ToList();

                foreach (string password in trackpassword)
                {
                    if (employee.password.Equals(password))
                    {
                        pass++;
                        //return Conflict(new { message = "Password exists in history !!!" });
                    }
                }
                if (pass > 0)
                {
                    return Conflict(new { message = "Password exists in history !!!" });
                }


                employee.updatedDate = DateTime.UtcNow;
                _context.Entry(employee).State = EntityState.Modified;
                TrackPassword trackPassword = new TrackPassword
                {
                    employeeId = EmployeeId,
                    lastChanged = DateTime.UtcNow,
                    password = employee.password
                };
                _context.TrackPasswords.Add(trackPassword);
                await _context.SaveChangesAsync();
            }

            return new { message = "Password updated successfully !!!" };
        }

        // PUT: api/ResetPassword/{EmployeeId}/{PassKey}/{NewPassword}
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ResetPassword/{EmployeeId}/{PassKey}/{NewPassword}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<object> ResetPassword(long EmployeeId, string PassKey, string NewPassword)
        {
            var employee = await _context.EmployeePersonalDetails.Where(emp => emp.employeePersonalDetailId == EmployeeId && emp.password == PassKey).FirstOrDefaultAsync();


            string[] parts = NewPassword.Split('%');

            StringBuilder convertedWord = new StringBuilder();
            convertedWord.Append(parts[0]);

            for (int i = 1; i < parts.Length; i++)
            {
                if (parts[i].Length >= 2)
                {
                    string hexValue = parts[i].Substring(0, 2);
                    int asciiValue = int.Parse(hexValue, System.Globalization.NumberStyles.HexNumber);
                    convertedWord.Append((char)asciiValue);
                    convertedWord.Append(parts[i].Substring(2));
                }
            }

            var NewPassword1 = convertedWord.ToString();



            if (employee == null)
            {
                return Conflict(new { message = "User does not exist." });
            }
            employee.password = Helpers.Helpers.SHA256Hash(NewPassword1);

            //added now
            //var pass = await ValidatePassword(NewPassword, EmployeeId);
            var passwordConfiguration = await _context.PasswordConfigurations.FirstOrDefaultAsync();
            bool message = true;
            if (passwordConfiguration == null)
            {
                return NotFound();
            }
            if (passwordConfiguration != null)
            {
                // Validate password with last few records
                //if (passwordConfiguration.noOfHistory > 0)
                //{
                //    var LastFewPasswords = _context.TrackPasswords.OrderByDescending(password => password.trackPassId == EmployeeId).Take((int)passwordConfiguration.noOfHistory).ToList();
                //    string password = Helpers.Helpers.SHA256Hash(NewPassword);

                //    var PasswordList = LastFewPasswords.Where(pass => pass.password == password).ToList();
                //    if (PasswordList.Count() > 0)
                //    {
                //        return Conflict($"Password should not match last {passwordConfiguration.noOfHistory} passwords.");
                //    }

                //}

                //var pass = 0;
                //var trackpassword = _context.TrackPasswords.Where(r => r.employeeId == EmployeeId).Select(r => r.password).ToList();
                //foreach (string password in trackpassword)
                //{
                //    if (NewPassword.Equals(password))
                //    {
                //        pass++;
                //        //return Conflict(new { message = "Password exists in history !!!" });
                //    }
                //}
                //if (pass > 0)
                //{
                //    return Conflict(new { message = "Password exists in history !!!" });
                //}

                if (NewPassword1.Length < passwordConfiguration.minimumLength)
                {
                    return Conflict(new { message = $"Password should contain atleast {passwordConfiguration.minimumLength} characters." });
                }
                if (NewPassword1.Length > passwordConfiguration.maximumLength)
                {
                    return Conflict(new { message = $"Password should not exceed {passwordConfiguration.maximumLength} characters." });
                }
                string numbersAndLetters = string.Empty;
                Regex regex = new Regex("[^A-Za-z0-9]");
                string specialCharacters = string.Empty;
                string UpperCaseCharacters = string.Empty;
                string LowerCaseCharacters = string.Empty;
                for (int i = 0; i < NewPassword1.Length; i++)
                {
                    if (regex.IsMatch(NewPassword1[i].ToString()))
                    {
                        specialCharacters += NewPassword1[i].ToString();
                    }
                    else
                    {
                        numbersAndLetters += NewPassword1[i].ToString();
                    }

                }
                if (specialCharacters.Length < passwordConfiguration.specialCharacters)
                {
                    return Conflict(new { message = $"Atleast {passwordConfiguration.specialCharacters} special characters to be entered." });
                }

                UpperCaseCharacters = string.Concat(Regex
   .Matches(numbersAndLetters, "[A-Z]")
   .OfType<Match>()
   .Select(match => match.Value));
                if (UpperCaseCharacters.Length < passwordConfiguration.upperCase)
                {
                    return Conflict(new { message = $"Atleast {passwordConfiguration.upperCase} upper case characters to be entered." });
                }
                LowerCaseCharacters = string.Concat(Regex
   .Matches(numbersAndLetters, "[a-z]")
   .OfType<Match>()
   .Select(match => match.Value));
                if (LowerCaseCharacters.Length < passwordConfiguration.lowerCase)
                {
                    return Conflict(new { message = $"Atleast {passwordConfiguration.lowerCase} lower case characters to be entered." });
                }
                // Validate the password has the list of allowed special characters
                for (int i = 0; i < specialCharacters.Length; i++)
                {
                    if (!passwordConfiguration.specialCharactersAllowed.Contains(specialCharacters[i]))
                    {
                        return Conflict(new { message = $"{specialCharacters[i]} - Special character entered is not allowed." });
                    }
                }

            }

            employee.password = Helpers.Helpers.SHA256Hash(NewPassword1);

            var pass = 0;
            //var trackpassword = _context.TrackPasswords.Where(r => r.employeeId == EmployeeId).Select(r => r.password).ToList();
            var trackpassword = _context.TrackPasswords.Where(r => r.employeeId == EmployeeId).OrderByDescending(r => r.lastChanged).Take(3).Select(r => r.password).ToList();

            foreach (string password in trackpassword)
            {
                if (employee.password.Equals(password))
                {
                    pass++;
                    //return Conflict(new { message = "Password exists in history !!!" });
                }
            }
            if (pass > 0)
            {
                return Conflict(new { message = "Password exists in history !!!" });
            }
            //till here


            // employee.password = Helpers.Helpers.SHA256Hash(NewPassword);
            employee.updatedDate = DateTime.UtcNow;
            _context.Entry(employee).State = EntityState.Modified;
            TrackPassword trackPassword = new TrackPassword
            {
                employeeId = EmployeeId,
                lastChanged = DateTime.UtcNow,
                password = employee.password
            };
            _context.TrackPasswords.Add(trackPassword);
            await _context.SaveChangesAsync();


            return new { message = "Password updated successfully !!!" };
        }

        // POST: api/PasswordConfigurations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<PasswordConfiguration>> PostPasswordConfiguration(PasswordConfiguration passwordConfiguration)
        {
            passwordConfiguration.updatedDate = DateTime.UtcNow;
            passwordConfiguration.createdTime = DateTime.UtcNow;
            _context.PasswordConfigurations.Add(passwordConfiguration);

            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPasswordConfiguration", new { id = passwordConfiguration.passConfigId }, passwordConfiguration);
        }

        // DELETE: api/PasswordConfigurations/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeletePasswordConfiguration(int id)
        {
            var passwordConfiguration = await _context.PasswordConfigurations.FindAsync(id);
            if (passwordConfiguration == null)
            {
                return NotFound();
            }

            _context.PasswordConfigurations.Remove(passwordConfiguration);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PasswordConfigurationExists(int id)
        {
            return _context.PasswordConfigurations.Any(e => e.passConfigId == id);
        }
    }
}
