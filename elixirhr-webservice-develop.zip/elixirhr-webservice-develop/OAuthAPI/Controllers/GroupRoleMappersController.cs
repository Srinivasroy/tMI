﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupRoleMappersController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public GroupRoleMappersController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/GroupRoleMappers
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetGroupRoleMappers()
        {
            //var groupRoleMappers = await _context.GroupRoleMappers.ToListAsync();
            var groupRoleMappers = await (from groupRoleMapper in _context.GroupRoleMappers
                                          join
userGroup in _context.UserGroups on groupRoleMapper.groupId equals userGroup.userGroupId into userGroups
                                          from userGrp in userGroups.DefaultIfEmpty()
                                          join
userRole in _context.UserRoles on groupRoleMapper.roleId equals userRole.userRoleId into userRoles
                                          from userRol in userRoles.DefaultIfEmpty()
                                          select new
                                          {
                                              groupRoleMapper.groupRoleMapperId,
                                              groupRoleMapper.groupId,
                                              userGrp.groupName,
                                              groupRoleMapper.roleId,
                                              userRol.roleName,
                                              groupRoleMapper.createdBy,
                                              groupRoleMapper.createdTime,
                                              groupRoleMapper.updatedBy,
                                              groupRoleMapper.updatedDate
                                          }).ToListAsync();
            var groupRoleMappersJson = JsonConvert.SerializeObject(groupRoleMappers);
            ArrayList groupRoleMappersList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(groupRoleMappersJson);
            return groupRoleMappersList;
        }

        // GET: api/GroupRoleMappers/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetGroupRoleMapper(long id)
        {
            //var groupRoleMapper = await _context.GroupRoleMappers.FindAsync(id);
            var groupRoleMapper = await (from GRM in _context.GroupRoleMappers where GRM.groupRoleMapperId == id
                                         join
                                        userGroup in _context.UserGroups on GRM.groupId equals userGroup.userGroupId into userGroups
                                                                                    from userGrp in userGroups.DefaultIfEmpty()
                                                                                    join
                                        userRole in _context.UserRoles on GRM.roleId equals userRole.userRoleId into userRoles
                                         from userRol in userRoles.DefaultIfEmpty()
                                         select new
                                         {
                                             GRM.groupRoleMapperId,
                                             GRM.groupId,
                                             userGrp.groupName,
                                             GRM.roleId,
                                             userRol.roleName,
                                             GRM.createdBy,
                                             GRM.createdTime,
                                             GRM.updatedBy,
                                             GRM.updatedDate
                                         }).ToListAsync();
            var groupRoleMapperJson = JsonConvert.SerializeObject(groupRoleMapper);


            if (groupRoleMapper.Count == 0)
            {
                return NotFound();
            }

            return System.Text.Json.JsonSerializer.Deserialize<object>(groupRoleMapperJson);
        }

        // PUT: api/GroupRoleMappers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutGroupRoleMapper(long id, GroupRoleMapper groupRoleMapper)
        {
            if (groupRoleMapper.groupId == null)
            {
                return Conflict(new { message = "Group Id is mandatory" });
            }
            if (groupRoleMapper.roleId == null)
            {
                return Conflict(new { message = "Role Id is mandatory" });
            }
            groupRoleMapper.groupRoleMapperId = id;
            groupRoleMapper.updatedDate = DateTime.UtcNow;
            _context.Entry(groupRoleMapper).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GroupRoleMapperExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (!Helper.GroupIdExists((long)groupRoleMapper.groupId))
                {
                    return Conflict(new { message = "Group Id does not exist !!!" });
                }
                else if (GroupRoleMapperAlreadyExists((long)groupRoleMapper.roleId, (long)groupRoleMapper.groupId))
                {
                    return Conflict(new { message = "Group is already assigned with this role." });
                }
                if (!Helper.GroupIdExists((long)groupRoleMapper.roleId))
                {
                    return Conflict(new { message = "Role Id does not exist !!!" });
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/GroupRoleMappers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<GroupRoleMapper>> PostGroupRoleMapper(GroupRoleMapper groupRoleMapper)
        {
            if (groupRoleMapper.groupId == null)
            {
                return Conflict(new { message = "Group Id is mandatory" });
            }
            if (groupRoleMapper.roleId == null)
            {
                return Conflict(new { message = "Role Id is mandatory" });
            }
            _context.GroupRoleMappers.Add(groupRoleMapper);
            try
            {
                groupRoleMapper.updatedDate = DateTime.UtcNow;
                groupRoleMapper.createdTime = groupRoleMapper.updatedDate;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (GroupRoleMapperExists(groupRoleMapper.groupRoleMapperId))
                {
                    return Conflict();
                }
                else if(GroupRoleMapperAlreadyExists((long)groupRoleMapper.roleId, (long)groupRoleMapper.groupId))
                {
                    return Conflict(new {message="Group is already assigned with this role."});
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetGroupRoleMapper", new { id = groupRoleMapper.groupRoleMapperId }, groupRoleMapper);
        }

        //// DELETE: api/GroupRoleMappers/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteGroupRoleMapper(long id)
        //{
        //    var groupRoleMapper = await _context.GroupRoleMappers.FindAsync(id);
        //    if (groupRoleMapper == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.GroupRoleMappers.Remove(groupRoleMapper);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool GroupRoleMapperExists(long id)
        {
            return _context.GroupRoleMappers.Any(e => e.groupRoleMapperId == id);
        }

        private bool GroupRoleMapperAlreadyExists(long roleId,long groupId)
        {
            return _context.GroupRoleMappers.Any(e => e.roleId == roleId && e.groupId == groupId);
        }
    }
}
