﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;
namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GradeDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public GradeDetailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/GradeDetails
        [HttpGet]
        public async Task<ActionResult<ArrayList>> GetGradeDetails()
        {
            var grades = await _context.GradeDetails.ToListAsync();
            var gradesJson = JsonConvert.SerializeObject(grades);
            ArrayList gradelist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(gradesJson);
            return gradelist;
        }

        // GET: api/GradeDetails/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetGradeDetail(long id)
        {
            var gradeDetail = await _context.GradeDetails.FindAsync(id);

            if (gradeDetail == null)
            {
                return NotFound();
            }
            var gradeJson = JsonConvert.SerializeObject(gradeDetail);
            var _grade = System.Text.Json.JsonSerializer.Deserialize<object>(gradeJson);
            return _grade;
        }

        // PUT: api/GradeDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutGradeDetail(long id, GradeDetail gradeDetail)
        {
            //if (id != gradeDetail.Id)
            //{
            //    return BadRequest();
            //}
            if (gradeDetail.employeeId == null)
            {
                return Conflict(new { message = "Employee Id is mandatory." });
            }
            if (gradeDetail.grade == null)
            {
                return Conflict(new { message = "Grade field is mandatory." });
            }
            if (!Helper.EmployeePersonalDetailIdExists((long)gradeDetail.employeeId))
            {
                return Conflict(new { message = "Employee Id not exist." });
            }
            gradeDetail.gradeId = id;
            gradeDetail.updatedDate = DateTime.UtcNow;
            _context.Entry(gradeDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GradeDetailExists(id))
                {
                    return NotFound();
                }

                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (GradeExists(gradeDetail.grade))
                {
                    return Conflict(new { message = "Same grade already exists !!!" });
                }
                else { throw; }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/GradeDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<GradeDetail>> PostGradeDetail(GradeDetail gradeDetail)
        {
            if (gradeDetail.employeeId == null)
            {
                return Conflict(new { message = "Employee Id is mandatory." });
            }
            if (!Helper.EmployeePersonalDetailIdExists((long)gradeDetail.employeeId))
            {
                return Conflict(new { message = "Employee Id not exist." });
            }
            gradeDetail.createdTime = DateTime.UtcNow;
            gradeDetail.updatedDate = gradeDetail.createdTime;
            _context.GradeDetails.Add(gradeDetail);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (GradeDetailExists(gradeDetail.gradeId))
                {
                    return Conflict(new { messsage = "Grade already exists !!!" });
                }
                else if (GradeExists(gradeDetail.grade))
                {
                    return Conflict(new { message = "Same grade already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetGradeDetail", new { id = gradeDetail.gradeId }, gradeDetail);
        }

        // DELETE: api/GradeDetails/5
        //[HttpDelete("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> DeleteGradeDetail(long id)
        //{
        //    var gradeDetail = await _context.GradeDetails.FindAsync(id);
        //    if (gradeDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.GradeDetails.Remove(gradeDetail);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool GradeDetailExists(long id)
        {
            return _context.GradeDetails.Any(e => e.gradeId == id);
        }

        private bool GradeExists(string grade)
        {
            return _context.GradeDetails.Any(e => e.grade == grade);
        }
    }
}
