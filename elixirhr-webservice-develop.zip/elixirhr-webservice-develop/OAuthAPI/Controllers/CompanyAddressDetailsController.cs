﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.Models.Common_Schema;
using OAuthAPI.models.common_schema;
using Microsoft.AspNetCore.Authorization;
using OAuthAPI.models.Helpers;
using Newtonsoft.Json;
using System.Collections;
using OAuthAPI.ActionFilters;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyAddressDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public CompanyAddressDetailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/CompanyAddressDetails
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ArrayList> GetCompanyAddressDetails()
        {
            var _companyAddress = await _context.CompanyAddressDetails.ToListAsync();
            var _companyAddressJson = JsonConvert.SerializeObject(_companyAddress);
            ArrayList _companyAddressList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_companyAddressJson);
            return _companyAddressList;
        }

        // GET: api/CompanyAddressDetails/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<CompanyAddressDetail>> GetCompanyAddressDetail(long id)
        {
            var companyAddressDetail = await _context.CompanyAddressDetails.FindAsync(id);

            if (companyAddressDetail == null)
            {
                return NotFound();
            }

            return companyAddressDetail;
        }

        // PUT: api/CompanyAddressDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutCompanyAddressDetail(long id, CompanyAddressDetail companyAddressDetail)
        {
            if (companyAddressDetail.companyId == null)
            {
                return Conflict(new { message = "CompanyId is mandatory !!!" });
            }
            if (companyAddressDetail.companyId != null && !Helper.OrganisationIdExists((long)companyAddressDetail.companyId))
            {
                return Conflict(new { message = "CompanyId is does not exist !!!" });
            }

            companyAddressDetail.addressId = id;
            companyAddressDetail.updatedDate = DateTime.UtcNow;
            _context.Entry(companyAddressDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CompanyAddressDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (CompanyAddressDetailExists(companyAddressDetail.addressId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/CompanyAddressDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //[ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ActionResult<CompanyAddressDetail>> PostCompanyAddressDetail(CompanyAddressDetail companyAddressDetail)
        {
            if (companyAddressDetail.companyId == null)
            {
                return Conflict(new { message = "CompanyId is mandatory !!!" });
            }
            if (companyAddressDetail.companyId != null && !Helper.OrganisationIdExists((long)companyAddressDetail.companyId))
            {
                return Conflict(new { message = "CompanyId is does not exist !!!" });
            }
            companyAddressDetail.createdDate = DateTime.UtcNow;
            companyAddressDetail.updatedDate = companyAddressDetail.createdDate;
            _context.CompanyAddressDetails.Add(companyAddressDetail);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (CompanyAddressDetailExists(companyAddressDetail.addressId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetCompanyAddressDetail", new { id = companyAddressDetail.addressId }, companyAddressDetail);
        }

        // DELETE: api/CompanyAddressDetails/5
        //[HttpDelete("{id}")]
        //[Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        //public async Task<IActionResult> DeleteCompanyAddressDetail(long id)
        //{
        //    var companyAddressDetail = await _context.CompanyAddressDetails.FindAsync(id);
        //    if (companyAddressDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.CompanyAddressDetails.Remove(companyAddressDetail);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool CompanyAddressDetailExists(long id)
        {
            return _context.CompanyAddressDetails.Any(e => e.addressId == id);
        }
    }
}
