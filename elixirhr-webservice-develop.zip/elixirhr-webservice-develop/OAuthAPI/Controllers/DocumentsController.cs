﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
//using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public DocumentsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Documents
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetDocuments(bool? GetAll = false)
        {
            if (GetAll == true)
            {
                var documents = await _context.Documents.Where(x => x.status == true).ToListAsync();
                var documentjson = JsonConvert.SerializeObject(documents);
                ArrayList documentlist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(documentjson);

                return documentlist;
            }

            var _documents = await _context.Documents.Where(x => x.status == true).ToListAsync();
            var _documentjson = JsonConvert.SerializeObject(_documents);
            ArrayList _documentlist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_documentjson);


            return _documentlist;
        }

        // GET: api/Documents/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetDocument(long id)
        {
            var document = await _context.Documents.FindAsync(id);

            if (document == null)
            {
                return NotFound();
            }

            var documentjson = JsonConvert.SerializeObject(document);
            var _document = System.Text.Json.JsonSerializer.Deserialize<object>(documentjson);

            return _document;
        }

        // PUT: api/Documents/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutDocument(long id, Document document)
        {
            if (!DocumentExists(id))
            {
                return Conflict(new { message = $"Document Id '{document.docId}' not found." });
            }
            if (!Helper.OrganisationIdExists((long)document.companyId))
            {
                return Conflict(new { message = $"Company Id '{document.companyId}' not found." });
            }

            if (document.activeStatus.Length > 5)
            {
                return Conflict(new { message = $"Active Status '{document.activeStatus}' too long" });
            }

            document.docId = id;
            document.updatedDate = DateTime.UtcNow;
            _context.Entry(document).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DocumentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/Documents
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostDocument(Document document)
        {
            _context.Documents.Add(document);
            try
            {

                if (!Helper.OrganisationIdExists((long)document.companyId))
                {
                    return Conflict(new { message = $"Company Id '{document.companyId}' not found." });
                }
                document.docId = _context.Documents.Count() + 1;

                document.createdTime = DateTime.UtcNow;
                document.updatedDate = document.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (document.activeStatus.Length > 5)
                {
                    return Conflict(new { message = $"Active Status '{document.activeStatus}' too long" });
                }
                else
                {
                    throw;
                }
            }

            var documentjson = JsonConvert.SerializeObject(document);
            var _document = System.Text.Json.JsonSerializer.Deserialize<object>(documentjson);

            return _document;
        }

        // DELETE: api/Documents/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteDocument(long id)
        {
            var document = await _context.Documents.FindAsync(id);
            if (document == null)
            {
                return NotFound();
            }

            document.status = false;
            _context.Documents.Update(document);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DocumentExists(long id)
        {
            return _context.Documents.Any(e => e.docId == id);
        }

    }
}
