﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailConfigurationsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public EmailConfigurationsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/EmailConfigurations
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IEnumerable<EmailConfiguration>>> GetEmailConfigurations()
        {
          if (_context.EmailConfigurations == null)
          {
              return NotFound();
          }
            return await _context.EmailConfigurations.ToListAsync();
        }

        // GET: api/EmailConfigurations/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<EmailConfiguration>> GetEmailConfiguration(int id)
        {
          if (_context.EmailConfigurations == null)
          {
              return NotFound();
          }
            var emailConfiguration = await _context.EmailConfigurations.FindAsync(id);

            if (emailConfiguration == null)
            {
                return NotFound();
            }

            return emailConfiguration;
        }

        // PUT: api/EmailConfigurations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> PutEmailConfiguration(int id, EmailConfiguration emailConfiguration)
        {
            if (id != emailConfiguration.emailConfigId)
            {
                return BadRequest();
            }

            _context.Entry(emailConfiguration).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmailConfigurationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EmailConfigurations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<EmailConfiguration>> PostEmailConfiguration(EmailConfiguration emailConfiguration)
        {
          if (_context.EmailConfigurations == null)
          {
              return Problem("Entity set 'Common_Schema_Context.EmailConfigurations'  is null.");
          }
            _context.EmailConfigurations.Add(emailConfiguration);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEmailConfiguration", new { id = emailConfiguration.emailConfigId }, emailConfiguration);
        }

        // DELETE: api/EmailConfigurations/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeleteEmailConfiguration(int id)
        {
            if (_context.EmailConfigurations == null)
            {
                return NotFound();
            }
            var emailConfiguration = await _context.EmailConfigurations.FindAsync(id);
            if (emailConfiguration == null)
            {
                return NotFound();
            }

            _context.EmailConfigurations.Remove(emailConfiguration);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmailConfigurationExists(int id)
        {
            return (_context.EmailConfigurations?.Any(e => e.emailConfigId == id)).GetValueOrDefault();
        }
    }
}
