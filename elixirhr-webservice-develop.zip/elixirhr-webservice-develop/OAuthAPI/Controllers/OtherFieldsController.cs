﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class OtherFieldsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public OtherFieldsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/OtherFields
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ArrayList> GetOtherFields()
        {
            var _otherFields = await _context.OtherFields.ToListAsync();
            var _otherFieldsJson = JsonConvert.SerializeObject(_otherFields);
            ArrayList _otherFieldsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_otherFieldsJson);
            return _otherFieldsList;
        }

        // GET: api/OtherFields/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<OtherField>> GetOtherField(int id)
        {
            var otherField = await _context.OtherFields.FindAsync(id);

            if (otherField == null)
            {
                return NotFound();
            }

            return otherField;
        }

        // PUT: api/OtherFields/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutOtherField(int id, OtherField otherField)
        {
            if (otherField.clientId == 0)
            {
                Conflict(new { message = "Client Id is mandatory !!!" });
            }
            if (otherField.moduleId == 0)
            {
                Conflict(new { message = "Client Id is mandatory !!!" });
            }
            otherField.fieldId = id;
            otherField.updatedDate = DateTime.UtcNow;
            _context.Entry(otherField).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OtherFieldExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (OtherFieldExists(otherField.fieldId))
                {
                    return Conflict();
                }
                else if (OtherFieldNameExists(otherField.fieldName))
                {
                    return Conflict(new { message = "Field name already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/OtherFields
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<OtherField>> PostOtherField(OtherField otherField)
        {
            _context.OtherFields.Add(otherField);
            try
            {
                otherField.updatedDate = DateTime.UtcNow;
                otherField.createdTime = otherField.updatedDate;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OtherFieldExists(otherField.fieldId))
                {
                    return Conflict();
                }
                else if (OtherFieldNameExists(otherField.fieldName))
                {
                    return Conflict(new { message = "Field name already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOtherField", new { id = otherField.fieldId }, otherField);
        }

        //// DELETE: api/OtherFields/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteOtherField(int id)
        //{
        //    var otherField = await _context.OtherFields.FindAsync(id);
        //    if (otherField == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.OtherFields.Remove(otherField);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool OtherFieldExists(int id)
        {
            return _context.OtherFields.Any(e => e.fieldId == id);
        }
        private bool OtherFieldNameExists(string fieldName)
        {
            return _context.OtherFields.Any(e => e.fieldName == fieldName);
        }

    }
}
