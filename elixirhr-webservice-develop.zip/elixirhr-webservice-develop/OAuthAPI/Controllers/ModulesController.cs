﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OAuthAPI.models.common_schema;
using Newtonsoft.Json;
using MySql.Data.MySqlClient;
using static OAuthAPI.models.Helpers.Helper;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModulesController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public ModulesController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Modules
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetModules(bool? getAll = false)
        {
            if (getAll == true)
            {
                var modules = await (from module in _context.Modules
                                     join status in _context.Statuses on module.status equals status.statusId
                                     select new
                                     {
                                         module.moduleId,
                                         module.moduleDescription,
                                         module.moduleName,
                                         module.isDropdown,
                                         module.updatedDate,
                                         module.createdTime,
                                         module.updatedBy,
                                         module.createdBy,
                                         module.isEnabled,
                                         module.moduleUrl,
                                         StatusId = module.status,
                                         Status = status.statusName

                                     }).ToListAsync();
                var modulesjson = JsonConvert.SerializeObject(modules);
                ArrayList moduleslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(modulesjson);
                return moduleslist;
            }
            else
            {
                var _modules = await (from module in _context.Modules
                                      where module.status == (int)Statuses.Approved
                                      join status in _context.Statuses on module.status equals status.statusId
                                      select new
                                      {
                                          module.moduleId,
                                          module.moduleDescription,
                                          module.moduleName,
                                          module.isDropdown,
                                          module.updatedDate,
                                          module.createdTime,
                                          module.updatedBy,
                                          module.createdBy,
                                          module.isEnabled,
                                          module.moduleUrl,
                                          StatusId = module.status,
                                          Status = status.statusName
                                      }
                ).ToListAsync();
                var _modulesjson = JsonConvert.SerializeObject(_modules);
                ArrayList _moduleslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_modulesjson);
                return _moduleslist;
            }
        }

        // GET: api/Modules/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetModule(long id)
        {
            var module = await _context.Modules.FindAsync(id);

            if (module == null)
            {
                return NotFound();
            }

            var modulejson = JsonConvert.SerializeObject(module);
            var _module = System.Text.Json.JsonSerializer.Deserialize<object>(modulejson);

            return _module;
        }

        // GET: api/Modules/5
        [HttpGet("GetModulesForCompanyId/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetModulesForCompanyId(long companyId)
        {
            try
            {
                var modulesList = await (from moduleOrg in _context.ModuleOrganisationMappers
                                         where moduleOrg.companyId == companyId && moduleOrg.status != (int)Statuses.Deleted
                                         join module in _context.Modules on moduleOrg.moduleId equals module.moduleId into ModulesList
                                         from moduleValue in ModulesList.DefaultIfEmpty()
                                         join org in _context.Organisations on moduleOrg.companyId equals org.companyId into CompanyList
                                         from company in CompanyList.DefaultIfEmpty()
                                         join status in _context.Statuses on moduleOrg.status equals status.statusId into StatusList
                                         from statusV in StatusList.DefaultIfEmpty()
                                         select new
                                         {
                                             ModuleId = moduleOrg.moduleId,
                                             ModuleName = moduleValue.moduleName,
                                             CompanyId = company.companyId,
                                             ComapnyName = company.companyName,
                                             Status = statusV.statusName
                                         }

                              ).ToListAsync();

                if (modulesList == null)
                {
                    return NotFound();
                }

                var modulejson = JsonConvert.SerializeObject(new
                {
                    modules = modulesList,
                    overAllStatus = modulesList.Where(m => m.Status == "rejected").ToList().Count() > 0 ? "Rejected" :
                    modulesList.Where(m => m.Status == "pending").ToList().Count() > 0 ? "Pending" : "Approved"
                });
                var _module = System.Text.Json.JsonSerializer.Deserialize<object>(modulejson);

                return _module;
            }
            catch
            {
                throw;
            }
        }


        // PUT: api/Modules/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
       // [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutModule(long id, Module module)
        {
            if (!ModuleExists(id))
            {
                return Conflict(new { message = $"Module Id '{module.moduleId}' not found." });
            }
           var  micon =await _context.Modules.Where(m => m.moduleId == id).FirstOrDefaultAsync();
            module.moduleId = id;
            module.updatedDate = DateTime.UtcNow;
            if(module.versionNo == null || module.versionNo == null)
            {
                module.versionNo= micon.versionNo;
                module.moduleIcon = micon.moduleIcon;
            }
            _context.Entry(module).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ModuleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (ModuleExists(module.moduleId))
                {
                    return Conflict(new { message = $"A Module with the id '{module.moduleId}' was already found." });
                }
                if (ModuleNameExists(module.moduleName))
                {
                    return Conflict(new { message = $"A Module with the name '{module.moduleName}' was already found." });
                }
                else
                {
                    throw;
                }

            }

            //return NoContent();
            return new { message = "Module updated successfully !!!" };
        }

        // PUT: api/Modules/ChangeModuleStatus/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("ChangeModuleStatus/{companyId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> ChangeModuleStatus(long CompanyId, ModuleStatus moduleStatus)
        {
            long moduleId = 0;
            bool isConflict = false;
            var status = _context.Statuses.Where(m => m.statusId == moduleStatus.Status).FirstOrDefault();
            try
            {
                if (status == null) { return Conflict(new { message = "Status does not exist !!!" }); }
                else
                {
                    _context.ModuleOrganisationMappers.Where(p => p.companyId == CompanyId).ToList().ForEach((x) =>
                    {
                        if (moduleStatus.Modules.IndexOf((int)x.moduleId) > -1)
                        {
                            moduleId = (long)x.moduleId; x.status = moduleStatus.Status; x.updatedBy = moduleStatus.UpdatedBy; x.updatedDate = DateTime.UtcNow;
                            if (status.statusName.Contains("approve"))
                            {
                                var module = _context.Modules.Where(m => m.moduleId == moduleId).FirstOrDefault();
                                var company = _context.Organisations.Where(m => m.companyId == CompanyId).FirstOrDefault();
                                if (module != null && company != null)
                                {
                                    if (company.schemaName != null && module.moduleScript != null)
                                    {
                                        IConfigurationRoot configuration = new ConfigurationBuilder()
                                       .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                                       .AddJsonFile("appsettings.json")
                                       .Build();
                                        string connStr = configuration.GetConnectionString("CompayCreationConnnection");
                                        MySqlConnection conn = new MySqlConnection(connStr);
                                        conn.Open();
                                        string sql = $"create database if not exists `{company.schemaName}`;\n";
                                        sql += $"use `{company.schemaName}`; {module.moduleScript}";
                                        MySqlScript script = new MySqlScript(conn);
                                        //script.Delimiter = "??";
                                        script.Query = sql;
                                        int count = script.Execute();
                                        script.Delimiter = ";";
                                        Console.WriteLine("Delimiter: " + script.Delimiter);
                                        Console.WriteLine("Query: " + script.Query);
                                    }
                                }
                                else
                                {
                                    isConflict = true;
                                    //return Conflict(new { message = "Module or company does not exists" });
                                }
                            }
                        }

                    });
                }


                await _context.SaveChangesAsync();
                if (isConflict)
                {
                    return Conflict(new { message = "Module or company does not exists" });
                }
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ModuleExists(moduleId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (DbUpdateException)
            {
                if (ModuleExists(moduleId))
                {
                    return Conflict(new { message = $"A Module with the id '{moduleId}' was already found." });
                }
                else
                {
                    throw;
                }

            }

            //return NoContent();
            return new { message = "Module status updated successfully !!!" };
        }

        // POST: api/Modules
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<object>> PostModule(Module module)
        {
            _context.Modules.Add(module);
            try
            {
                var lastModule = await _context.Modules.OrderBy(module => module.moduleId).LastOrDefaultAsync();
                module.moduleId = lastModule != null ? lastModule.moduleId + 1 : 1;

                module.createdTime = DateTime.UtcNow;
                module.updatedDate = module.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (ModuleExists(module.moduleId))
                {
                    return Conflict(new { message = $"A Module with the id '{module.moduleId}' was already found." });
                }
                if (ModuleNameExists(module.moduleName))
                {
                    return Conflict(new { message = $"A Module with the name '{module.moduleName}' was already found." });
                }
                else
                {
                    throw;
                }

            }

            var modulejson = JsonConvert.SerializeObject(module);
            var _module = System.Text.Json.JsonSerializer.Deserialize<object>(modulejson);

            return _module;
        }

        [HttpGet("GetScreensList/{moduleId}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetScreensList(long moduleId)
        {
            // var name = ModuleNameExists(moduleName);
            if (!ModuleExists(moduleId))
            {
                return Conflict(new { message = $"Module  not exists !!!" });



            }
            var ScreenList = await (from m in _context.Modules
                                    join sname in _context.Screens on m.moduleId equals sname.moduleId
                                    where m.moduleId == moduleId
                                    select new
                                    {
                                        m.moduleName,
                                        m.moduleDescription,
                                        m.moduleUrl,
                                        sname.screenName,
                                    }).ToListAsync();
            return ScreenList;
        }

        [HttpGet("GetModuleList")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<object>> GetModuleList()
        {
            var ModuleList = await (from mname in _context.Modules 
                                     select new
                                    {
                                         mname.moduleName
                                     }).ToListAsync();
            return ModuleList;
        }

        [HttpPut("Enable/{id}/{isenable}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PutEnable(long id,bool isenable)
        {

            Module module = _context.Modules.Where(o => o.moduleId ==id).FirstOrDefault();
            if (!ModuleExists(id))
            {
                return Conflict(new { message = $"Module Id '{module.moduleId}' not found." });
            }
            module.isEnabled = isenable;
            _context.Modules.Update(module);
            module.updatedDate = DateTime.UtcNow;
            _context.Entry(module).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return module;
        }
        private bool ModuleExists(long id)
        {
            return _context.Modules.Any(e => e.moduleId == id);
        }

        private bool ModuleNameExists(string name)
        {
            return _context.Modules.Any(e => e.moduleName == name);
        }

    }
}
