﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.ActionFilters;
using OAuthAPI.models.common_schema;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(ValidationFilterAttribute))]
    public class BankDetailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public BankDetailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/BankDetails
        [HttpGet]

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ArrayList> GetBankDetails()
        {
            var _bankDetails = await _context.BankDetails.ToListAsync();
            var _bankDetailsJson = JsonConvert.SerializeObject(_bankDetails);
            ArrayList _bankDetailsList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_bankDetailsJson);
            return _bankDetailsList;
        }

        // GET: api/BankDetails/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<BankDetail>> GetBankDetail(string id)
        {
            var bankDetail = await _context.BankDetails.FindAsync(id);

            if (bankDetail == null)
            {
                return NotFound();
            }

            return bankDetail;
        }

        // PUT: api/BankDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutBankDetail(int id, BankDetail bankDetail)
        {
            if (bankDetail.CompanyId == null)
            {
                return Conflict(new { message = "Company Id is mandatory." });
            }
            if (!Helper.OrganisationIdExists((long)bankDetail.CompanyId))
            {
                return Conflict(new { message = "Company Id does not exist." });
            }
            if (!BankDetailExists(id))
            {
                return NotFound();
            }
            bankDetail.Id = id;
            bankDetail.UpdatedDate = DateTime.UtcNow;
            bankDetail.CreatedDate = bankDetail.UpdatedDate;
            _context.Entry(bankDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BankDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/BankDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<BankDetail>> PostBankDetail(BankDetail bankDetail)
        {
            if (bankDetail.CompanyId == null)
            {
                return Conflict(new { message = "Company Id is mandatory." });
            }
            if (!Helper.OrganisationIdExists((long)bankDetail.CompanyId))
            {
                return Conflict(new { message = "Company Id does not exist." });
            }
            _context.BankDetails.Add(bankDetail);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (BankDetailExists(bankDetail.Id))
                {
                    return Conflict(new { message = "Bank Id already exists !!!" });
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetBankDetail", new { id = bankDetail.Id }, bankDetail);
        }

        //// DELETE: api/BankDetails/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteBankDetail(string id)
        //{
        //    var bankDetail = await _context.BankDetails.FindAsync(id);
        //    if (bankDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.BankDetails.Remove(bankDetail);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool BankDetailExists(int id)
        {
            return _context.BankDetails.Any(e => e.Id == id);
        }

    }
}
