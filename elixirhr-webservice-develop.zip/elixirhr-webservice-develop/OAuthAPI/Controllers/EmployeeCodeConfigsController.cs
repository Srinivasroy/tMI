﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
//using Newtonsoft.Json;
using OAuthAPI.models.common_schema;
using OAuthAPI.Models.Common_Schema;
using Newtonsoft.Json;
using OAuthAPI.models.Helpers;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeCodeConfigsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public EmployeeCodeConfigsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/EmployeeCodeConfigs
        [HttpGet]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<ArrayList>> GetEmployeeCodeConfigs(bool? GetAll = false)
        {
            if (GetAll == true)
            {
                var employeeCodeConfigs = await _context.EmployeeCodeConfig.Where(x => x.status == true).ToListAsync();
                var employeeCodeConfigsjson = JsonConvert.SerializeObject(employeeCodeConfigs);
                ArrayList employeeCodeConfigslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(employeeCodeConfigsjson);

                return employeeCodeConfigslist;
            }

            var _employeeCodeConfigs = await _context.EmployeeCodeConfig.Where(x => x.status == true).ToListAsync();
            var _employeeCodeConfigsjson = JsonConvert.SerializeObject(_employeeCodeConfigs);
            ArrayList _employeeCodeConfigslist = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(_employeeCodeConfigsjson);
            return _employeeCodeConfigslist;
        }

        // GET: api/EmployeeCodeConfigs/5
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> GetEmployeeCodeConfig(long id)
        {
            var employeeCodeConfig = await _context.EmployeeCodeConfig.FindAsync(id);

            if (employeeCodeConfig == null)
            {
                return NotFound();
            }

            var employeeCodeConfigjson = JsonConvert.SerializeObject(employeeCodeConfig);
            var _employeeCodeConfig = System.Text.Json.JsonSerializer.Deserialize<object>(employeeCodeConfigjson);

            return _employeeCodeConfig;
        }


        // PUT: api/EmployeeCodeConfigs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<object> PutEmployeeCodeConfig(long id, EmployeeCodeConfig employeeCodeConfig)
        {
            if (!EmployeeCodeConfigExists(id))
            {
                return Conflict(new { message = $"EmployeeCodeConfig Id '{employeeCodeConfig.employeeConfigId}' not found." });
            }
            if (!Helper.OrganisationIdExists((long)employeeCodeConfig.companyId))
            {
                return Conflict(new { message = $"Company Id '{employeeCodeConfig.companyId}' not found." });
            }
            if (employeeCodeConfig.empCodeAssigned.Length > 3)
            {
                return Conflict(new { message = $" Emp code assigned '{employeeCodeConfig.empCodeAssigned}' too long" });
            }
            employeeCodeConfig.employeeConfigId = id;
            employeeCodeConfig.updatedDate = DateTime.UtcNow;
            _context.Entry(employeeCodeConfig).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeCodeConfigExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return new { message = "Record updated successfully !!!" };
        }
        // POST: api/EmployeeCodeConfigs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<object>> PostEmployeeCodeConfig(EmployeeCodeConfig employeeCodeConfig)
        {
            _context.EmployeeCodeConfig.Add(employeeCodeConfig);
            try
            {

                if (!Helper.OrganisationIdExists((long)employeeCodeConfig.companyId))
                {
                    return Conflict(new { message = $"Company Id '{employeeCodeConfig.companyId}' not found." });
                }
                employeeCodeConfig.employeeConfigId = _context.EmployeeCodeConfig.Count() + 1;

                employeeCodeConfig.createdTime = DateTime.UtcNow;
                employeeCodeConfig.updatedDate = employeeCodeConfig.createdTime;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (employeeCodeConfig.empCodeAssigned.Length > 3)
                {
                    return Conflict(new { message = $"Emp code assigned'{employeeCodeConfig.empCodeAssigned}' too long" });
                }
                else
                {
                    throw;
                }
            }

            var employeeCodeConfigjson = JsonConvert.SerializeObject(employeeCodeConfig);
            var _employeeCodeConfig = System.Text.Json.JsonSerializer.Deserialize<object>(employeeCodeConfigjson);

            return _employeeCodeConfig;
        }

        // DELETE: api/EmployeeCodeConfigs/5
        [HttpDelete("{id}")]
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        // There is no hard delete, only the status will be set to false
        public async Task<IActionResult> DeleteEmployeeCodeConfigs(long id)
        {
            var employeeCodeConfig = await _context.EmployeeCodeConfig.FindAsync(id);
            if (employeeCodeConfig == null)
            {
                return NotFound();
            }
            employeeCodeConfig.status = false;
            _context.EmployeeCodeConfig.Update(employeeCodeConfig);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmployeeCodeConfigExists(long id)
        {
            return _context.EmployeeCodeConfig.Any(e => e.employeeConfigId == id);
        }

    }
}
