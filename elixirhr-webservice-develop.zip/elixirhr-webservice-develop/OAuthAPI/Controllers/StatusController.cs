﻿#nullable disable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatusController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public StatusController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/Status
        [HttpGet]
        public async Task<ActionResult<ArrayList>> GetStatuses()
        {
            var statuses = await _context.Statuses.ToListAsync();
            var statusesJson = JsonConvert.SerializeObject(statuses);
            ArrayList statusesList = System.Text.Json.JsonSerializer.Deserialize<ArrayList>(statusesJson);
            return statusesList;
        }

        // GET: api/Status/5
        [HttpGet("{id}")]
        public async Task<object> GetStatus(int id)
        {
            var status = await _context.Statuses.FindAsync(id);

            if (status == null)
            {
                return NotFound();
            }
            var statusJson = JsonConvert.SerializeObject(status);
            object statusValue = System.Text.Json.JsonSerializer.Deserialize<object>(statusJson);
            return statusValue;
        }

        // PUT: api/Status/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<object> PutStatus(int id, Status status)
        {
            //if (id != status.Id)
            //{
            //    return BadRequest();
            //}
            status.statusId = id;
            _context.Entry(status).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StatusExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/Status
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Status>> PostStatus(Status status)
        {
            _context.Statuses.Add(status);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (StatusExists(status.statusId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetStatus", new { id = status.statusId }, status);
        }

        //// DELETE: api/Status/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteStatus(int id)
        //{
        //    var status = await _context.Statuses.FindAsync(id);
        //    if (status == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Statuses.Remove(status);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        private bool StatusExists(int id)
        {
            return _context.Statuses.Any(e => e.statusId == id);
        }
    }
}
