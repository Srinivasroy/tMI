﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OAuthAPI.models.common_schema;

namespace OAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuditTrailsController : ControllerBase
    {
        private readonly Common_Schema_Context _context;

        public AuditTrailsController(Common_Schema_Context context)
        {
            _context = context;
        }

        // GET: api/AuditTrails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AuditTrail>>> GetAuditTrails()
        {
            return await _context.AuditTrails.ToListAsync();
        }

        // GET: api/AuditTrails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AuditTrail>> GetAuditTrail(int id)
        {
            var auditTrail = await _context.AuditTrails.FindAsync(id);

            if (auditTrail == null)
            {
                return NotFound();
            }

            return auditTrail;
        }

        // PUT: api/AuditTrails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<object> PutAuditTrail(int id, AuditTrail auditTrail)
        {
            if (id != auditTrail.auditTrailId)
            {
                return BadRequest();
            }

            _context.Entry(auditTrail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AuditTrailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return NoContent();
            return new { message = "Record updated successfully !!!" };
        }

        // POST: api/AuditTrails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AuditTrail>> PostAuditTrail(AuditTrail auditTrail)
        {
            _context.AuditTrails.Add(auditTrail);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AuditTrailExists(auditTrail.auditTrailId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAuditTrail", new { id = auditTrail.auditTrailId }, auditTrail);
        }

        // DELETE: api/AuditTrails/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAuditTrail(int id)
        {
            var auditTrail = await _context.AuditTrails.FindAsync(id);
            if (auditTrail == null)
            {
                return NotFound();
            }

            _context.AuditTrails.Remove(auditTrail);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AuditTrailExists(int id)
        {
            return _context.AuditTrails.Any(e => e.auditTrailId == id);
        }
    }
}
